# Changelog

Questo file è **grow-only**: le voci pubblicate non si eliminano, non si riscrivono e non
si riordinano. Ogni nuova voce viene inserita in alto, immediatamente sotto questa
introduzione, così la modifica più recente precede la più vecchia.

Vanno registrate tutte le modifiche con impatto osservabile per utenti, amministratori,
operatori o integratori, incluse quelle richieste manualmente dall'utente. Refactoring e
formattazione senza effetti osservabili possono essere omessi. Eventuali correzioni a una
voce precedente si effettuano aggiungendo una nuova voce, senza alterare quella esistente.

## 2026-10-12 — Riservato il candidate consecutivo `0.1.0-13`

- La revisione Debian corrente è `13` e dichiara esclusivamente `0.1.0-12` come
  predecessor supportato; versioni diverse restano negate fail-closed.
- Il contratto di upgrade documenta ora l'arco esatto `0.1.0-12 → 0.1.0-13`. La presenza
  del metadato non autorizza ancora l'upgrade reale, che resta subordinato a firma e drill
  R07–R11.

## 2026-10-12 — Drill incidenti M4.3 completato sul laboratorio

- Il laboratorio ha rilevato realmente `RECONCILER_STALE` dopo 600 secondi senza
  riavviare il reconciler, poi è tornato sano dopo restart esplicito e quattro cicli
  riusciti.
- Un socket helper inesistente confinato al solo reconciler ha prodotto tre fallimenti
  con backoff 2/4 secondi e `RECONCILER_FAILED`; web e helper reali sono rimasti attivi e
  il cleanup ha ripristinato due cicli sani.
- Readiness Unix/HTTPS, timer, namespace journald, audit, hash persistenti, registry e
  assenza di risorse rete sono stati verificati prima e dopo. M4.3 e `R04` sono chiuse.
- Il runbook ora specifica l'override temporaneo di `ExecStart`: `Environment=` da solo
  non prevale sull'`EnvironmentFile` systemd. Il primo tentativo innocuo è registrato come
  P-015.

## 2026-10-12 — Baseline Debian ricostruita con `0.1.0-12`

- Il laboratorio esegue ora `wireguard-system 0.1.0-12`: dpkg è integro, systemd è
  `running`, web, helper, reconciler, health timer e Caddy sono attivi e readiness Unix e
  HTTPS è verde.
- Environment, keyring, dati, registry e Caddyfile conservano gli hash baseline;
  registry v2 e rete sono vuoti, senza WireGuard, VRF, nftables o forwarding residui.
- Due controlli errati dell'harness hanno causato rollback sicuri a `0.1.0-5` prima del
  tentativo conclusivo: uno azzerava il PATH di `doctor`, l'altro interpretava il simbolo
  `●` di systemd come nome unità. Nessuno dei due era un difetto del candidate.
- `R03` è chiusa; recovery set, rollback package e identity offline restano confinati e
  conservati per il successivo drill, non come stato live del portale.

## 2026-10-12 — Candidate corretto `0.1.0-12` verificato localmente

- La pipeline normativa dal commit pulito `f290ad9` ha superato 1.005 test, auditato 24
  dipendenze senza finding e prodotto SBOM, package Debian, sorgente e provenienza.
- Il `.deb` `amd64` ha SHA-256
  `4b993ef06306a037fef9786dff5ecc1ecbabb76a1bdad354ccae8238b7f60269`; il suo
  inventario di 1.240 entry conferma il contratto dei permessi introdotto per P-013.
- Il bundle resta non firmato e non pubblicabile; l'installazione controllata sul
  laboratorio è ancora necessaria per chiudere R03.

## 2026-10-12 — Permessi del payload Debian resi verificabili

- Il builder normalizza a `0755` tutte le directory del package e a `0644` tutti i file
  regolari di `site-packages`, impedendo che l'`umask 077` della pipeline renda il portale
  illeggibile all'utente di servizio.
- Generazione e verifica della provenienza rifiutano ora package con directory non
  attraversabili, moduli Python non leggibili o inventario payload diverso dal `.deb`.
- La correzione riceve l'identità `0.1.0-12`; i candidate rifiutati `0.1.0-10` e
  `0.1.0-11` restano immutabili e non pubblicabili.

## 2026-10-12 — Candidate con payload non leggibile rifiutato nel laboratorio

- `0.1.0-11` ha superato il nuovo guard clean-install ed è stato unpacked, ma il postinst
  ha fallito chiuso perché l'`umask 077` del builder rendeva directory Python non
  attraversabili dall'utente `wg-portal`.
- Il recovery ha rimosso senza purge il payload incompleto e reinstallato `0.1.0-5`:
  dpkg, servizi, dati, keyring, registry, Caddy e stato rete sono tornati coerenti.
- `0.1.0-11` resta immutabile e non pubblicabile; la prossima revisione dovrà normalizzare
  e verificare i mode del payload prima di un nuovo deploy.

## 2026-10-12 — Clean install sicura dopo remove senza purge

- Il drill reale ha rilevato che dpkg passa le versioni precedente e nuova al `preinst`
  quando un package rimosso conserva lo stato `config-files`; `0.1.0-10` ha negato
  correttamente prima dell'unpack ed è stato seguito dal rollback integro a `0.1.0-5`.
- Con `upgrade-from: none`, il maintainer script ammette ora `install OLD NEW` ma continua
  a negare ogni `upgrade OLD NEW`; il `postinst` segue coerentemente il percorso fresh.
- La correzione usa la nuova revisione `0.1.0-11`; il primo arco pianificato diventa
  `0.1.0-11 → 0.1.0-12`, senza ricostruire gli artefatti immutabili `0.1.0-10`.

## 2026-10-12 — Predecessor candidate `0.1.0-10` verificato

- La pipeline normativa dal commit pulito `6dab5a8` ha superato 1.003 test, auditato 24
  dipendenze senza finding e prodotto SBOM, package Debian, sorgente e provenienza.
- Il `.deb` `amd64` ha SHA-256
  `76296a306e88dd7f6808feec28c6fc6c72e3878fc1203f7ac9ecc6213a8ac652` e incorpora
  esplicitamente il contratto clean-install-only.
- Il bundle resta non firmato e non pubblicabile; può essere usato soltanto come baseline
  del laboratorio isolato fino ai successivi gate di firma e upgrade.

## 2026-10-12 — Lineage fail-closed del nuovo predecessor Debian

- La revisione corrente diventa `0.1.0-10`; `0.1.0-9` resta un artefatto storico non
  pubblicabile legato esclusivamente al proprio commit originario.
- Il nuovo metadato `upgrade-from: none` rende `0.1.0-10` installabile soltanto da zero e
  rifiuta esplicitamente qualunque upgrade in ingresso.
- Il primo arco pianificato con il recovery protocol completo è
  `0.1.0-10 → 0.1.0-11`; non è dichiarato supportato prima dei drill reali.

## 2026-10-12 — Inventario e piano di recupero del laboratorio Debian

- Un nuovo inventario esclusivamente read-only conferma `wireguard-system 0.1.0-5`
  installato e integro, servizi principali attivi e due vecchie istanze helper fallite che
  mantengono systemd in stato `degraded`.
- Dati, secrets e registry hanno permessi coerenti; non risultano reti gestite,
  interfacce WireGuard/VRF, tabelle nftables o forwarding abilitato.
- Il piano vincolante di ricostruzione richiede recovery set cifrato verificato, rimozione
  senza purge, installazione pulita del nuovo predecessor, confronto hash e rollback sul
  package `0.1.0-5` conservato.
- È registrato il margine disco ridotto del laboratorio; nessun percorso estraneo è
  autorizzato come bersaglio di cleanup.
- Le unità concluse senza decisioni o azioni pendenti del maintainer possono ora essere
  committate autonomamente; in presenza di un suo intervento necessario il commit resta
  sospeso.

## 2026-10-09 — Recovery confinato dei trigger esterni candidate

- `upgrade-preflight --repair-candidate-awaited-triggers` ripara ora il candidate in
  `triggers-awaited` usando il percorso dpkg globale previsto per il rilevamento cicli.
- Prima dell'handoff viene congelata in un intent root-only la chiusura esatta dei package
  attesi, con versioni, architetture, stati e trigger; package pending estranei bloccano
  l'operazione.
- Il lock frontend esclude APT, mentre backend e lock transazionale sono ceduti a
  `dpkg --triggers-only --pending`; retry e completamento dopo crash sono idempotenti.
- Recovery status espone azioni dedicate senza più richiedere recovery manuale per questo
  stato, mantenendo writer congelati fino alla finalizzazione verificata.

## 2026-10-09 — Rollback con restore del recovery set attestato

- `upgrade-preflight --rollback-with-restore` reinstalla il predecessor attestato,
  ripristina esclusivamente i due bundle legati alla request firmata e riattiva infine
  l'esatto set di writer precedente.
- Bundle e identity restano pinned durante il restore; UUID, SHA-256, package, schema e
  quiesce vengono verificati prima e dopo le operazioni mutanti.
- Intent e receipt root-only rendono ritentabili errori e crash senza ripetere un restore
  già confermato né riavviare prematuramente i servizi.
- Recovery status espone `rollback_restore_incomplete` e
  `rollback_restored_resume_pending` con azione `retry_rollback_with_restore`.

## 2026-10-09 — Reinstallazione attestata e ritentabile del candidate

- `upgrade-preflight --reinstall-candidate` reinstalla soltanto il `.deb` candidate il cui
  SHA-256 è contenuto nella request verificata persistita della transazione consumata.
- L'artefatto resta pinned tramite descriptor; il lock frontend esclude APT mentre backend
  dpkg e lock transazionale vengono ceduti esclusivamente ai maintainer script autorizzati.
- L'intenzione `candidate-reinstall-intent` è durevole: errori dpkg, avanzamenti parziali e
  crash dopo l'installazione possono essere ritentati senza riscriverla o avviare i writer.
- Solo candidate finale `installed`, architettura e schema invariati consentono receipt
  `finalized` e ripristino dell'esatto set di servizi pre-upgrade.

## 2026-10-09 — Handshake fail-closed per reinstallazione candidate

- Il `preinst` del candidate riconosce una reinstallazione della stessa versione soltanto
  con una singola `candidate-reinstall-intent` coerente con marker consumato e request
  verificata persistita.
- SHA-256 del `.deb`, arco, architettura, schema e writer quiescenti vengono ricontrollati;
  intenzioni candidate e rollback concorrenti sono rifiutate come stato ambiguo.
- Il finalizer verifica nuovamente la stessa catena e mantiene i writer congelati, senza
  pubblicare `finalized` prima della verifica dell'executor.
- Nessun comando di reinstallazione è ancora esposto: l'intenzione non va creata a mano.

## 2026-10-09 — Autorizzazione firmata persistita per il recovery candidate

- L'arming conserva ora la request firmata già verificata in forma canonica root-only,
  indicizzata dallo stesso SHA-256 registrato nel marker monouso.
- La copia `verified-authorization` mantiene il digest del `.deb` candidate necessario a
  una futura reinstallazione attestata ed è riutilizzata in modo idempotente nei retry.
- File corrotti, link, ownership o permessi non sicuri bloccano l'arming prima del freeze;
  il formato del marker e il recovery protocol v1 del predecessor restano invariati.
- La reinstallazione candidate non è ancora esposta: questo incremento ne prepara la
  provenienza esatta senza ampliare le operazioni dpkg autorizzate.

## 2026-10-09 — Repair confinato dei trigger candidate

- `upgrade-preflight --repair-candidate-triggers` elabora soltanto i trigger pending del
  package `wireguard-system`, senza usare operazioni globali su altri package.
- Il comando usa intenzione root-only, lock frontend, handoff controllato a dpkg e
  finalizzazione verificata; errori e crash sono ritentabili senza riattivare i writer.
- `triggers-awaited` è ora distinto: dipende da altri package e resta fail-closed con
  recovery manuale, evitando un pericoloso `dpkg --configure --pending` globale.

## 2026-10-09 — Rollback attestato e ritentabile del predecessor

- `upgrade-preflight --rollback-predecessor` installa o reinstalla soltanto il `.deb`
  predecessor il cui SHA-256 è legato all'autorizzazione consumata.
- L'artefatto resta aperto tramite descriptor durante ispezione e handoff; il lock frontend
  esclude APT, mentre i lock backend e transazionale sono ceduti ai maintainer script.
- Stato dpkg, architettura, schema, writer e intenzione root-only vengono verificati prima
  e dopo dpkg; errori o crash lasciano un retry deterministico senza riattivare i writer.
- Solo lo stato finale `installed` del predecessor produce `predecessor-resumed` e
  ripristina esattamente le unità attive prima dell'upgrade.

## 2026-10-09 — Handshake fail-closed dei maintainer script per rollback

- I package dichiarano il recovery protocol v1; preflight e firma rifiutano artefatti che
  non espongono esattamente questa capacità.
- Il `preinst` del predecessor accetta reinstallazione o downgrade soltanto con una
  `rollback-intent` root-only coerente col marker consumato e writer ancora congelati.
- Durante il configure di rollback, il finalizer verifica la stessa intenzione ma non
  avvia servizi e non pubblica successo: il resume resta responsabilità dell'executor.
- Nessun comando dpkg di rollback è ancora esposto; invocazioni manuali continuano a
  fallire chiuse.

## 2026-10-09 — Package di rollback legato all’autorizzazione upgrade

- La request firmata v2 richiede ora anche il `.deb` esatto del predecessor e ne lega
  package, versione, architettura, schema e SHA-256 alla transazione.
- Verifica e arming ricalcolano il descrittore; il marker monouso v2 conserva il digest
  necessario a una futura reinstallazione o rollback attestati.
- Package di rollback mancante, sostituito, incompatibile o coincidente con un altro
  artefatto blocca l'autorizzazione prima dell'unpack.

## 2026-10-09 — Repair ritentabile della configurazione candidate

- `upgrade-preflight --repair-candidate-configuration` esegue ora `dpkg --configure`
  soltanto per il candidate esatto in stato `unpacked` o `half-configured`.
- Prima del handoff viene pubblicata un'intenzione canonica `candidate-repair`, che rende
  verificabili e ritentabili errori, interruzioni e completamenti avvenuti nel `postinst`.
- Il lock frontend dpkg resta acquisito durante il handoff, impedendo ad APT di modificare
  il package mentre i lock backend e transazionale vengono ceduti al comando di repair.
- Versione, architettura, schema, writer e storia delle ricevute vengono ricontrollati;
  `half-installed` e stati trigger restano negati.

## 2026-10-09 — Matrice fail-closed degli stati package incompleti

- Il recovery distingue ora configurazione incompleta, installazione incompleta e trigger
  pendenti sia per candidate sia per predecessor, con azioni dichiarative separate.
- Solo `unpacked` e `half-configured` sono candidati al futuro repair di configurazione;
  `half-installed` resta vincolato a reinstallazione o rollback con artefatto attestato.
- Gli stati trigger non vengono più assimilati alla configurazione e restano bloccati fino
  a un executor specifico.

## 2026-10-09 — Finalizzazione ritentabile del candidate configurato

- `upgrade-preflight --resume-configured-candidate` completa ora il resume quando dpkg
  conferma che il candidate esatto è già completamente configurato e lo schema coincide.
- Il comando condivide lock, validazione e formato della ricevuta `finalized` con il flusso
  package, preservando l'idempotenza tra retry manuale e `postinst`.
- Stati `unpacked`, `half-configured`, versioni/architetture/schema divergenti e writer
  estranei restano bloccati senza tentativi impliciti di configurazione o rollback.

## 2026-10-09 — Recovery sicuro del predecessor dopo il consumo

- `upgrade-preflight --resume-consumed-predecessor` ripristina ora il set esatto dei
  writer se dpkg conferma che il predecessor è ancora completamente configurato e lo
  schema live coincide con l'autorizzazione consumata.
- L'operazione serializza stato upgrade e database dpkg, completa eventuali claim hard-link
  interrotti e produce una ricevuta canonica `predecessor-resumed` idempotente.
- Package/schema divergenti, writer estranei, ricevute orfane o corrotte e lock insicuri
  bloccano il resume senza tentare repair, downgrade o restore.

## 2026-10-09 — Classificazione read-only del recovery post-consumo

- `upgrade-preflight --recovery-status` restituisce ora JSON canonico con stato del claim,
  package dpkg, arco autorizzato, schema live e prossima azione dichiarativa.
- Il controllo distingue predecessor ancora configurato, candidate configurato o
  incompleto, divergenze di versione/architettura/schema e hard link di consumo interrotto.
- Il classificatore non crea stato, non modifica dpkg e non avvia servizi; le azioni di
  repair e rollback restano negate finché non avranno executor e ricevute dedicate.

## 2026-10-09 — Annullamento sicuro dell'upgrade armato

- Il nuovo comando root-only `upgrade-preflight --cancel-armed-upgrade` ritira un marker
  non ancora consumato e ripristina esattamente i writer attivi prima dell'arming.
- Tombstone e ricevuta canonici impediscono il riuso dell'autorizzazione e rendono
  ritentabile il recovery dopo crash o errore di avvio; la ripetizione riuscita è un no-op.
- Stato dpkg/schema divergente, writer estranei o un marker già consumato bloccano il
  comando senza cancellazioni manuali o fallback permissivi.
- Il resume di successo e quello di annullamento trattano correttamente la health oneshot:
  ne richiedono lo start riuscito senza pretendere che resti artificialmente `active`.

## 2026-10-09 — Lock unico per le transazioni di upgrade

- Arming, guard `preinst` e finalizer serializzano ora ogni mutazione dello stato upgrade
  con lo stesso lock root-only, evitando consumo, annullamento o resume concorrenti.
- Lock assente viene creato `0600`; symlink, ownership, tipo, link count o permessi anomali
  bloccano l'operazione in modalità fail-closed.

## 2026-10-09 — Resume esatto dopo upgrade riuscito

- Il `postinst` di upgrade ripristina ora soltanto le unità che erano attive prima del
  freeze, preservando anche le unità intenzionalmente ferme.
- La ricevuta root-only viene scritta solo dopo la verifica dei servizi; gli errori
  restano pendenti e ritentabili, mentre una ripetizione dopo il successo è un no-op.
- L'installazione pulita conserva il bootstrap standard; recupero pre-unpack e rollback
  post-unpack restano gate aperti prima dell'uso in produzione e le invocazioni abort di
  `postinst` non riattivano automaticamente il set standard.

## 2026-10-09 — Freeze verificato dei writer durante l'upgrade

- L'arming ferma ora web, reconciler, health e helper, ripete i gate con i writer congelati
  e ripristina le sole unità originariamente attive se il tentativo fallisce.
- Il `preinst` nega l'unpack se una unità o istanza helper riparte dopo l'arming.
- Resume esatto dopo successo/crash e rollback post-unpack restano esplicitamente aperti;
  fino ad allora il percorso di upgrade rimane pre-release.

## 2026-10-09 — Stime residue espresse anche in passaggi

- Su richiesta del maintainer, ogni resoconto finale indica anche una forchetta dei
  passaggi Codex ancora prevedibili, oltre alla percentuale indicativa, evitando falsa
  precisione e aggiornando la scomposizione quando emergono nuovi failure domain.

## 2026-10-09 — Reti ferme obbligatorie prima dell'upgrade

- L'arming richiede ora che ogni VPN sia stata fermata tramite il normale workflow e che
  non rimangano risorse nel registry privilegiato dell'host.
- Stato desiderato `stopped` e cleanup effettivo devono concordare; registry mancante,
  insicuro, corrotto o ancora popolato blocca l'upgrade.
- Il verifier rimane read-only: il freeze dei writer necessario a eliminare la race fra
  arming e `dpkg` resta il prossimo incremento.

## 2026-10-09 — Gate operativo prima dell'arming upgrade

- L'arming dell'upgrade rifiuta ora storage o reconciler non sani, restore incompleti,
  job ancora pendenti e spazio insufficiente, senza modificare il data tree.
- Il budget conserva spazio per una copia dei dati e riserve separate per dati e package,
  sommando i requisiti quando condividono il filesystem.
- Il preflight riconosce correttamente i metadati privati posseduti dall'utente di servizio;
  quiesce dei writer/reti e rollback post-unpack restano il prossimo gate.

## 2026-10-09 — Autorizzazione upgrade obbligatoria e monouso

- La verifica firmata può ora armare un marker root-only che lega il tentativo al
  candidate, al predecessor, all'architettura, allo schema e alla scadenza autorizzati.
- Il nuovo `preinst` rifiuta l'upgrade prima dell'unpack se il marker manca o diverge e lo
  consuma atomicamente; replay e retry richiedono una nuova ricevuta firmata.
- L'installazione pulita resta consentita. Health, spazio, job/recovery, quiesce, rollback
  e drill Debian rimangono gate aperti prima dell'uso upgrade in produzione.

## 2026-10-08 — Ricevuta firmata per il backup pre-upgrade

- Il preflight può creare una request canonica che lega host, candidate, stato installato,
  schema, UUID e hash dei due bundle recovery con validità breve e nessun segreto.
- Dopo verify e restore preflight offline, una firma SSHSIG operativa separata autorizza
  esattamente quei bytes; revoca, expiry, altro host o qualsiasi tampering sono negati.
- Il protocollo e i test sono completi, ma la ricevuta non è ancora imposta dal `preinst`:
  chiave reale, guard monouso e drill restano gate distinti.

## 2026-10-08 — Primo gate del percorso di upgrade

- Il package dichiara ora schema dati e singolo predecessor supportato; il primo arco è
  `0.1.0-8` verso `0.1.0-9`, senza dedurre compatibilità da versioni intermedie saltate.
- Un preflight read-only confronta control del candidate, stato `dpkg`, architettura e
  `meta.json`, rifiutando reinstall, downgrade, salti, link e permessi insicuri.
- Questo controllo non autorizza ancora l'upgrade: ricevuta del backup verificato,
  guard pre-unpack, quiesce, rollback e drill Debian restano gate espliciti aperti.

## 2026-10-08 — Deploy verificato in repository APT

- Un nuovo tool inserisce il package di un bundle SSHSIG valido in una root locale
  `reprepro`, senza accettare repository unsigned, root ambigue o configurazioni permissive.
- Il deploy è idempotente e ricontrolla fingerprint OpenPGP di `InRelease`, hash
  dell'indice `Packages`, record e bytes nel pool prima di dichiarare successo.
- Chiavi private e passphrase non attraversano la CLI; client e operatori devono usare una
  keyring APT dedicata, mentre replica remota e provisioning delle chiavi restano separati.

## 2026-10-08 — Protocollo di firma release SSHSIG

- I bundle verificati possono ora produrre un `SHA256SUMS` canonico che copre esattamente
  package, sorgente, provenienza, inventario, lock, audit e SBOM senza accettare file extra.
- La verifica SSHSIG usa identità e namespace fissi, allowlist pubblica e revocation list,
  poi ricontrolla ogni hash e la provenienza semantica; tampering, chiavi revocate, scope
  errati, link e manifest incompleti sono negati.
- La chiave Ed25519 privata deve essere generata e usata soltanto offline. Tooling e test
  sono pronti, ma il candidate non diventa firmato finché la cerimonia reale non pubblica
  chiave pubblica verificata e firma.

## 2026-10-08 — Candidate `0.1.0-9` verificato end-to-end

- La pipeline clean-tree è stata eseguita realmente sul commit `10272fa`: 812 test verdi,
  audit di 24 dipendenze pulito, build Debian `amd64` e verifica offline del bundle riusciti.
- Il package ha SHA-256 `98f49a3d0ea69d29863a958c51b5754337b58bdeeaf1eca9516e3422e1f1654b`;
  provenienza, sorgente, due lock, SBOM, audit e inventario di 1.203 entry sono collegati
  nel bundle `dist/releases/0.1.0-9`.
- Il candidate resta non firmato: integrità interna e provenienza dichiarata sono
  verificate, ma autenticità, riproducibilità indipendente e pubblicazione restano aperte.

## 2026-10-08 — Pipeline di release hash-locked

- Un solo comando esegue quality gate, audit, build Debian, provenienza e verifica da un
  worktree pulito, rifiutando package o bundle esistenti per evitare sovrascritture.
- Frontend, backend e scanner di release sono interamente pinned e hashati; vengono
  installati come sole wheel in un virtualenv effimero che ignora configurazioni e indici
  pip locali. Il build non effettua più una seconda risoluzione isolata dei backend.
- Il bundle include anche il lock della toolchain e verifica la coerenza delle versioni
  effettive. La pipeline reale del candidate resta da eseguire dopo il commit; firma e
  autenticità non sono ancora disponibili.

## 2026-10-08 — Provenienza SLSA del candidate

- Un generatore fail-closed prepara da un commit pulito un bundle versionato con `.deb`,
  archivio sorgente, lock, audit, SBOM e inventario completo del payload Debian.
- La provenienza usa una Statement in-toto v1 con predicate SLSA v1 e registra commit,
  SHA-256, backend pinned e versioni dei tool Debian/Python senza dati dell'operatore.
- Il verificatore offline controlla ogni riferimento e hash senza estrarre il package. La
  Statement resta esplicitamente non firmata e non attribuisce un livello SLSA; la
  revisione passa a `0.1.0-9`, da costruire sul commit pulito nel prossimo gate.

## 2026-10-08 — Audit dipendenze e SBOM Python

- Un gate di rilascio scansiona direttamente tutte le dipendenze Python pinned e hashate,
  senza risolverle dall'ambiente o correggerle automaticamente; ogni finding blocca il
  candidate ma conserva il report per la remediation.
- Sono prodotti report JSON, SBOM CycloneDX e manifest con versione tool e SHA-256; il
  generatore fallisce se report o SBOM non coprono esattamente tutte le entry del lock.
- La prova reale con `pip-audit 2.10.1` ha coperto 24 dipendenze senza vulnerabilità note.
  Il candidate locale `0.1.0-8` è stato costruito con la nuova documentazione; firma,
  provenienza completa del `.deb` e upgrade path restano gate M4.4 separati.

## 2026-10-08 — Runbook incidenti e matrice diagnostica

- Pubblicato il triage read-only per web, Caddy, storage, recovery, keyring, helper,
  reconciler, WireGuard e journald, con severità, raccolta evidenze ed exit criteria.
- Tutti i codici readiness e di processo hanno significato, verifiche sicure e risposta
  operativa; sono vietati dump di segreti, cancellazioni, bypass e restart loop.
- Il protocollo di drill Debian separa prerequisiti, fault controllati, recupero e cleanup;
  il verbale resta pendente finché il laboratorio intranet non torna raggiungibile.

## 2026-10-08 — Health persistente del reconciler

- Ogni ciclo reconciler salva atomicamente timestamp, esito, fallimenti consecutivi e
  soli contatori redatti in uno stato runtime derivato, escluso dai backup.
- Readiness e `wg-portal reconciler-health` rilevano stato mancante, invalido o stale,
  fallimenti ripetuti e job outstanding troppo vecchi senza creare lock, chiamare il
  helper o modificare configurazioni.
- Un timer systemd esegue il controllo read-only ogni minuto e segnala il guasto senza
  restart o autoriparazioni; soglie di staleness, fallimenti e backlog sono configurabili.

## 2026-10-08 — Namespace journald operativo limitato

- Web, reconciler e helper scrivono nel namespace journald dedicato `wg-portal`, con
  identificatori e campo componente indicizzato distinti e rate limit per unità.
- Il pacchetto configura esclusivamente quel namespace: retention massima 30 giorni,
  rotazione massima giornaliera, quota persistente 256 MiB e fallback runtime 64 MiB.
- Il forwarding verso altri sink è disabilitato per evitare duplicazioni; audit HMAC e
  journal operativo restano separati e gli override locali possono vivere sotto `/etc`.

## 2026-10-08 — Logging operativo JSON allowlistato

- Web, reconciler e helper producono eventi applicativi JSON line correlabili e limitati a
  schemi chiusi; eventi o campi non registrati vengono rifiutati prima della scrittura.
- Il web registra solo endpoint simbolico, metodo, stato, durata e request ID. Query, route
  concrete, token, cookie, payload, chiavi, path, eccezioni e traceback non attraversano
  il logger; gli errori inattesi diventano risposte e codici redatti.
- Il reconciler espone soltanto esito e conteggi dei cicli, il helper soltanto codici stabili
  di processo. `WG_PORTAL_LOG_LEVEL` controlla la soglia da `DEBUG` a `ERROR`.

## 2026-10-08 — Readiness operativa redatta

- Aggiunto `GET /readyz`: verifica storage/schema, recovery pendente, keyring e helper con
  capability attesa, restituendo `503` quando il control plane non è pronto.
- Le risposte espongono soltanto componenti e codici stabili, mai path, eccezioni o output
  host. Il probe read-only è memorizzato per worker per 5 secondi configurabili.
- `GET /healthz` resta una liveness minimale indipendente dalle dipendenze, evitando loop
  di riavvio durante guasti operativi recuperabili.

## 2026-10-08 — Migrazioni forward-only integrate nel restore

- Il restore pianifica una catena completa `N → N+1` prima di estrarre e rifiuta versioni
  future, passaggi mancanti, duplicati o incrementi non unitari.
- Le migrazioni operano esclusivamente su una copia sibling privata e sincronizzata;
  albero estratto e bundle cifrati sorgente restano immutati. Un nuovo manifest descrive
  la copia corrente prima della validazione semantica e della promozione.
- Link, hard link, permessi estesi, file speciali o una migrazione fallita bloccano il
  restore e rimuovono la copia di lavoro. Preflight e restore segnalano la versione
  migrata senza esporre path sensibili.

## 2026-10-08 — Disaster-recovery drill Debian completato

- Il candidate `0.1.0-5` è stato installato realmente su Debian 12 preservando environment,
  keyring e data tree; backup cifrato, verifica offline, preflight e restore live sono
  riusciti end-to-end.
- `restore-apply` ha rifiutato sia la sostituzione senza `--replace` sia un set ID errato
  senza fermare i servizi. Il restore confermato ha rimosso lo stato post-backup e ha
  riportato socket, web, reconciler e helper attivi in 3 secondi.
- Un fault finale iniettato ha verificato rollback byte-per-byte, assenza di residui e
  servizi intenzionalmente fermi; il riavvio manuale ha ripristinato health Unix e HTTPS.
  Identity, bundle e script effimeri sono stati eliminati al termine.

## 2026-10-08 — Comando operativo di restore con conferme esplicite

- Il nuovo comando root-only `wg-portal restore-apply` applica un recovery set verificato
  soltanto quando l'operatore conferma il relativo UUID e, per un data dir non vuoto,
  fornisce anche `--replace`.
- L'output espone soltanto set ID e conteggi operativi, senza path di identity o secrets.
  Un errore viene redatto e avvisa che i servizi possono essere rimasti intenzionalmente
  fermi; dopo un successo tutte le reti recuperate restano `stopped`.
- La CLI è coperta da test di wiring, riepilogo e failure policy. Il supporto resta
  candidate finché il disaster-recovery drill su Debian non è completato.

## 2026-10-08 — Orchestratore interno del restore completo

- `RestoreApplier` collega ora decifratura e preflight, conferma esplicita del recovery set,
  preparazione inerte, quiesce systemd, stop delle reti registrate, promozione coordinata e
  verifiche post-promozione sotto un’unica operazione root-only.
- Dopo la promozione vengono ricontrollati environment, keyring, documenti, envelope,
  audit, reti ferme, indice ricostruibile e prerequisiti host prima della decisione di
  commit; ogni errore precedente esegue rollback e mantiene i servizi fermi.
- Un journal pendente viene recuperato soltanto con servizi e reti gestite ferme. Set ID
  non confermati e sostituzioni non esplicite vengono rifiutati prima della mutazione live.
  La CLI pubblica resta disabilitata fino al prossimo gate e al collaudo reale.

## 2026-10-08 — Journal coordinato per data tree e secrets

- Il journal restore v2 registra ora path e identità device/inode dei candidati environment
  e keyring insieme al data tree; i journal v1 pendenti restano recuperabili dopo upgrade.
- La promozione coordinata scambia atomicamente keyring, environment e data tree sui loro
  filesystem, poi rende durevole una sola decisione di commit o rollback.
- Un arresto durante qualsiasi exchange ripristina tutti i contenuti precedenti; dopo
  `commit_pending` il recovery conserva tutti i nuovi contenuti e completa soltanto il
  cleanup. Path, parent, mode o identità ambigui falliscono chiusi mantenendo il journal.

## 2026-10-08 — Candidati secrets sicuri per il restore

- Environment e master keyring staged possono ora essere copiati come candidati privati
  accanto ai rispettivi file live, anche quando data tree e `/etc` risiedono su filesystem
  diversi, senza pubblicare o modificare alcun secret live.
- La preparazione richiede target esistenti, assoluti, canonici, regolari, non linkati e in
  parent non scrivibili da gruppo/altri; preserva owner, gruppo e mode del file host e
  sincronizza contenuto e directory.
- Errori intermedi eliminano i candidati già creati; detach e promozione dati sono
  bloccati finché i candidati non vengono ripuliti o presi in carico dalla futura
  transazione coordinata.

## 2026-10-08 — Staging restore reso inerte prima della promozione

- La nuova fase interna di preparazione interrompe come falliti i job `queued` e `running`
  recuperati e forza tutte le reti a `stopped`, impedendo che attività obsolete o start
  accodati riattivino lo stato host dopo il restore.
- Ogni modifica incrementa la revisione e produce audit HMAC; meta-documento e indice
  ricostruibile vengono aggiornati con un unico timestamp UTC e la fase è idempotente.
- I lock creati durante verifica e ricostruzione vengono eliminati e sincronizzati prima
  della promozione; directory, link o lock non sicuri bloccano l’operazione.

## 2026-10-08 — Recovery crash-safe della promozione restore

- Ogni promozione del data tree pubblica ora un journal privato e sincronizzato prima del
  primo rename, registrando fasi monotone e identità device/inode dei tree vecchio e nuovo.
- Dopo un arresto, `recover_pending_restore` completa una decisione di commit già resa
  durevole oppure ripristina il tree precedente per tutte le fasi antecedenti, includendo
  le finestre tra exchange, rename del rollback e cleanup.
- Nuovi workspace sono bloccati finché una transazione incompleta non viene recuperata;
  path, mode, hard link, UUID, transizioni e identità inattese falliscono chiusi senza
  scegliere euristicamente quale stato conservare.

## 2026-10-08 — Transazione atomica del data tree di restore

- La nuova primitiva interna `RestorePromotion` scambia atomicamente staging e data tree
  live tramite `renameat2(RENAME_EXCHANGE)`, conservando lo stato precedente fino al
  commit e ripristinandolo per qualsiasi eccezione.
- La sostituzione di un target non vuoto richiede consenso esplicito; host o filesystem
  senza exchange atomico falliscono chiusi e non usano sequenze di rename degradate.
- Commit, rollback e cleanup validano path, tipo e permessi, sincronizzano la directory
  padre e impediscono detach o rimozione di una transazione irrisolta. La funzione resta
  interna finché journal, secrets, stop host e verifiche finali non saranno collegati.

## 2026-10-08 — Preflight semantico offline del restore

- Il nuovo `wg-portal restore-preflight` decifra entrambi i bundle in uno staging sibling
  privato e verifica semanticamente un recovery set senza caricare l’environment live,
  richiedere root o modificare il data dir di destinazione.
- Il gate controlla secrets e variabili allowlistate, meta/schema, path canonici, relazioni
  tra tenant/reti/client/principal/credenziali, regole dominio e coppie WireGuard,
  idempotenza, catene HMAC audit e apertura di ogni envelope privato con il keyring
  recuperato.
- Lo staging plaintext viene sempre eliminato, anche in errore; target incoerenti con il
  data dir dichiarato nel recovery set e file semantici non canonici sono rifiutati con
  output CLI redatto. La promozione live resta intenzionalmente non implementata.

## 2026-10-08 — Fondazione sicura del restore staging

- Il nuovo workspace di restore crea staging privato `0700` sullo stesso filesystem del
  data dir, mantenendo separate le radici `data` e `secrets` senza modificare lo stato live.
- I file staged usano creazione esclusiva senza symlink, limite esatto, verifica SHA-256,
  mode del manifest e fsync; contenuti incompleti o alterati vengono eliminati.
- Il workspace viene rimosso automaticamente e soltanto un detach esplicito può passarlo
  alla futura promozione; il cleanup rifiuta percorsi che non corrispondono al sibling
  temporaneo creato dal sistema.

## 2026-10-08 — Verifica offline dei recovery set

- Il nuovo `wg-portal backup-verify` autentica la coppia cifrata con una singola identity
  X25519 `0600`, senza richiedere root o configurazione applicativa e senza scrivere
  plaintext su disco.
- La verifica impone limiti a ciphertext, dimensione espansa, singolo file e manifest;
  rifiuta link, sparse, metadata anomali, membri non dichiarati, mismatch di mode/size/hash
  e stream che non completano correttamente l'autenticazione `age`.
- I manifest `data` e `secrets` devono condividere set ID, timestamp e versione, avere
  bundle ID distinti e schema dati supportato; set mescolati o incompleti falliscono con
  errore redatto.

## 2026-10-08 — Creazione offline dei recovery set

- Il nuovo comando root-only `wg-portal backup-create` ferma socket e servizi applicativi,
  reconciler e helper, verifica l'assenza di writer e ripristina soltanto le unità che
  erano attive prima dell'operazione, incluso il rollback dopo un quiesce parziale.
- Prima della cifratura vengono validati documenti canonici e idempotenza, catene audit,
  keyring e decifrabilità di ogni envelope di rete/client; un errore produce un messaggio
  redatto e nessun recovery set parziale.
- La destinazione deve esistere fuori dal data tree, non può essere un symlink né essere
  scrivibile da gruppo/altri. Il comando restituisce UUID e path della coppia
  `data`/`secrets`, che resta non verificata finché non sarà disponibile il comando
  offline dedicato.

## 2026-10-08 — Streaming sicuro dei recovery bundle

- L'inventario secrets accetta soltanto environment e master keyring espliciti, distinti,
  senza symlink/hard link e fuori dal data tree, imponendo mode `0600` oppure `0640` per
  l'environment e `0600` per il keyring.
- Il bundle tar+gzip viene generato direttamente nello stream di cifratura: manifest per
  primo, soli file allowlistati, metadata host normalizzati e nessun archivio plaintext
  temporaneo.
- Ogni fonte viene riaperta con `O_NOFOLLOW` e verificata nuovamente per inode, mode,
  dimensione, timestamp e SHA-256; drift o mismatch eliminano il ciphertext parziale.

## 2026-10-08 — Cifratura recovery age/X25519

- Confermata la soluzione consigliata: i bundle `data` e `secrets` useranno `age` con un
  recipient X25519 pubblico sul server, mentre almeno due copie della identity privata
  resteranno offline; non è previsto alcun fallback a passphrase.
- Aggiunta la cifratura streaming fail-closed: argv assoluto senza shell, ambiente minimo,
  output temporaneo `0600`, pubblicazione atomica senza overwrite, fsync e rimozione dei
  parziali in caso di errore o timeout, senza archivio plaintext persistente.
- `age >= 1.1` diventa dipendenza del pacchetto Debian e prerequisito verificato da
  `doctor`; la revisione candidate passa a `0.1.0-5` per il prossimo build.
- Installazione e round trip effimero sono stati verificati con `age 1.1.1` sul target
  Debian 12 `vrt-debian1`; ciphertext `0600`, identity e payload di prova sono stati
  rimossi al termine.

## 2026-10-08 — Contratto di backup e restore v1

- Definito un recovery set offline con bundle `data` e `secrets` separati, manifest
  versionato e policy esplicita dello stato recuperabile; idempotenza e audit sono inclusi,
  mentre cache, lock, output generati e registry host sono ricostruiti dopo il restore.
- Le primitive di inventario bloccano path ignoti, symlink, file speciali, permessi estesi
  e mutazioni durante l’hash; manifest e aggregati sono validati da JSON Schema e controlli
  semantici prima di poter alimentare un futuro archivio.
- L’inizializzazione rende ora `0700` anche i contenitori intermedi `audit/` e `runtime/`,
  correggendo directory che con l’umask standard potevano restare leggibili da altri utenti.
- Registrata la scelta ancora aperta del cifratore, raccomandando `age` con destinatario
  X25519 e identity di recovery conservata soltanto offline.

## 2026-10-08 — Compatibilità Debian 12 del confine web production

- Il collaudo reale su Debian 12 ha rilevato e corretto due incompatibilità prima della
  pubblicazione: l’allowlist usa ora il matcher `remote_ip` disponibile in Caddy 2.6 e
  continua a essere valida soltanto con Caddy esposto direttamente.
- Gunicorn viene avviato direttamente da systemd con Python safe-path e payload privato;
  usa l’autorilevamento `LISTEN_FDS` senza registrare una seconda volta il medesimo
  descrittore e il launcher condiviso non viene più usato dal servizio web.
- Il `Referrer-Policy` diventa `same-origin`: nessun referrer esce dall’origine, mentre i
  form HTTPS conservano il controllo CSRF strict di Flask-WTF. L’allowlist Caddy include
  esplicitamente i loopback necessari al bootstrap tramite tunnel SSH.
- La revisione Debian passa a `0.1.0-4`; gli upgrade intermedi vengono usati come test
  reale di persistenza di environment, keyring e storage.
- Il candidate ha completato installazione, upgrade e remove/reinstall su Debian 12 con
  stato invariato; HTTPS/HSTS, socket e permessi, allowlist, header anti-spoofing e
  bootstrap via tunnel SSH sono stati verificati sul servizio reale, chiudendo M4.1.

## 2026-10-08 — Pacchetto Debian candidate riproducibile

- Il builder produce un `.deb` amd64 autosufficiente da un lockfile con hash e sole wheel
  binarie; due build indipendenti hanno generato lo stesso artifact byte per byte.
- Launcher Python shell-free e safe-path isolano il payload in `/usr/lib`; l’installazione non
  scarica dipendenze e resta compatibile con Python 3.11 di Debian 12 senza usare le
  versioni native obsolete di Flask o Gunicorn.
- Il primo configure crea utente, directory, segreti distinti, keyring e storage una sola
  volta. Upgrade preserva i contenuti; remove e purge fermano i servizi ma non cancellano
  dati, audit o chiavi. Caddy resta disabilitato finché hostname e allowlist non vengono
  configurati esplicitamente.

## 2026-10-08 — Ingresso web di produzione e confine Caddy

- Aggiunti Gunicorn 23 e unità systemd socket-activated: il processo web non privilegiato
  riceve un socket Unix `0660` condiviso esclusivamente con Caddy, senza listener TCP,
  capability o access log HTTP.
- La fiducia negli header proxy è ora opt-in per il trasporto Unix e chiusa per default;
  Caddy limita UI e API alle reti amministrative configurate, sovrascrive gli header
  inoltrati, termina HTTPS e imposta HSTS.
- Pubblicati ambiente production fail-closed e Caddyfile di riferimento con test su permessi,
  hardening, allowlist e spoofing. Pacchetto Debian e collaudo su host pulito restano gate
  obbligatori prima dell’uso in produzione.

## 2026-10-08 — Dashboard aggregata e chiusura M3.13

- La dashboard aggiorna senza reload conteggi scoped, stato effettivo e numero di client
  online per tutte le reti visibili, mantenendo il dettaglio peer sulla rete selezionata.
- Un solo probe privilegiato serve l’intero ciclo: tutte le reti sono autorizzate prima
  della chiamata, poi verificate indipendentemente come `running`, `stopped` o `unknown`;
  il drift di una rete non degrada le altre.
- Completati i gate HTML per manager, admin e superadmin, IDOR, redazione, selector
  etichettato e landmark accessibili; gli aggiornamenti DOM restano allowlistati e senza
  HTML dinamico.

## 2026-10-07 — Guida d’installazione del prototipo

- Aggiunta una procedura autonoma per installare da sorgente su Debian o WSL Debian,
  configurare segreti e keyring, inizializzare lo storage, eseguire i controlli e
  completare in sicurezza il primo accesso loopback.
- La guida distingue esplicitamente il prototipo locale dal deployment production M4.1:
  server Flask, helper/reconciler parzialmente impacchettati e assenza della configurazione
  Caddy non devono essere esposti come servizio definitivo.
- Documentati comportamento atteso dei probe, limiti delle operazioni WireGuard reali,
  aggiornamento del checkout e principali errori di configurazione.

## 2026-10-07 — Prima dashboard operativa scoped

- La panoramica mostra i conteggi di tenant, reti e client autorizzati e consente di
  scegliere una rete senza rivelare nomi o quantità appartenenti ad altri scope.
- Il pannello live espone IP VPN, stato amministrativo, endpoint osservato, ultimo
  handshake, traffico RX/TX, presenza e “online dal”; presenza e inizio finestra sono
  dichiarati come stime e un errore di probe rimane `unknown`.
- Rendering server-side e polling session-based condividono una proiezione redatta. Il
  browser osserva una sola rete con un probe per ciclo, sospende le richieste quando è
  nascosto, applica backoff e aggiorna il DOM senza HTML dinamico.

## 2026-10-07 — Monitoraggio live dei job e protezione doppio invio

- Dopo un’azione asincrona la UI apre un dialogo accessibile che aggiorna stato e
  avanzamento tramite polling session-based dello stesso job; il polling applica backoff,
  si ferma allo stato terminale e si sospende quando la pagina non è visibile.
- Gli errori job vengono trasformati da codici allowlistati in indicazioni operative
  redatte, senza esporre messaggi interni. Endpoint JSON e pagina restano scoped e
  restituiscono lo stesso `404` auditato per job inesistenti o fuori ambito.
- Un asset JavaScript locale protegge tutti i form POST dal doppio invio mantenendo il
  fallback server-rendered. La CSP consente esclusivamente script same-origin e continua
  a vietare inline script, `unsafe-eval`, CDN e handler HTML.

## 2026-10-07 — Download configurazione client dalla UI

- Gli utenti autorizzati possono scaricare il profilo WireGuard completo di un singolo
  client `pending`, `active` o `disabled` dopo avere reinserito la password corrente;
  utente, stato e scope RBAC vengono ricaricati e rivalidati prima della decifratura.
- Il profilo viene compilato soltanto in memoria e restituito come attachment con
  `no-store`, `no-cache` e senza ETag; password, chiave privata e configurazione non
  entrano in HTML, audit o storage temporaneo.
- Form chiuso e CSRF, risposta non enumerabile per oggetti fuori scope, throttling dei
  tentativi e audit dedicato proteggono la riautenticazione; client revocati o archiviati
  non mostrano né accettano il download.

## 2026-10-07 — Lifecycle client e stato operazioni nella UI

- Le pagine client espongono activate, disable, revoke, archive e rilascio IP secondo lo
  stato corrente; ogni azione usa una conferma esplicita, revisione ottimistica e un UUID
  stabile per retry, mentre revoca e archiviazione conservano la reservation.
- Su reti running, le variazioni dei peer accodano un solo `network.sync` senza contattare
  il helper dal processo HTTP. Il job appartiene all’utente interattivo e il worker ne
  rivalida identità, ruolo e scope prima di produrre effetti host.
- Aggiunte lista e dettaglio operazioni scoped con avanzamento, esito redatto e refresh
  manuale; job e client fuori scope restano non enumerabili con `404` auditato, e la coda
  piena restituisce `429` con `Retry-After` senza mutazioni parziali.

## 2026-10-07 — Inventario e CRUD base dei client HTML

- Ogni ruolo autorizzato può selezionare una rete, elencarne i client e consultarne IP,
  stato, reservation e fingerprint; accessi cross-tenant o a reti diverse ricevono lo
  stesso `404` auditato.
- La creazione assegna un IP permanente automaticamente oppure valida quello manuale,
  genera internamente le chiavi e crea il client `pending`; retry con lo stesso UUID non
  duplica client o reservation.
- La modifica revisionata riguarda soltanto nome e descrizione, anche su rete running;
  IP, chiavi, stato e reservation non sono campi accettati e nessun segreto raggiunge HTML.

## 2026-10-07 — Modifica e archiviazione reti HTML

- Admin, superadmin e manager possono modificare nome, descrizione, endpoint e modalità
  porta delle reti autorizzate; CIDR e hub restano immutabili e le revisioni obsolete
  producono `409` senza sovrascrivere modifiche concorrenti.
- Una rete running accetta solo cambi descrittivi: endpoint, porta e lifecycle richiedono
  prima lo stop. Il passaggio fra porta automatica e manuale rivalida range, endpoint e
  collisioni.
- Solo admin e superadmin possono archiviare o riattivare; archive richiede una conferma
  esplicita, mentre campi lifecycle forgiati da manager vengono rifiutati.

## 2026-10-07 — Creazione reti HTML con anteprima validata

- Superadmin e admin possono elencare e consultare le reti autorizzate e creare una rete
  in un tenant attivo; manager vede esclusivamente le reti assegnate e non può crearne.
- Prima del salvataggio il form mostra una preview read-only con CIDR, hub, capacità
  client, endpoint, porta UDP automatica o manuale e nome interfaccia, segnalando overlap
  e collisioni senza generare chiavi o scrivere configurazioni.
- La creazione ripete risoluzione DNS e controlli sotto lock, genera le chiavi solo dopo
  la conferma e crea la rete ferma; retry con lo stesso UUID converge sulla stessa rete.

## 2026-10-07 — Gestione HTML scoped di utenti e assegnazioni

- Superadmin e admin possono elencare, consultare, creare e modificare gli utenti visibili
  dai propri scope; manager, oggetti estranei e UUID inesistenti ricevono lo stesso `404`
  auditato, mentre la modifica del proprio account è negata.
- Il form ruoli supporta più tenant e reti. Un admin può cambiare soltanto le assegnazioni
  dei tenant amministrati: quelle esterne sono ricostruite e preservate dal server, e lo
  stato di un account condiviso resta immutabile.
- Password iniziali, revisioni e input sono gestiti senza segreti riflessi: la password
  deve essere cambiata al primo accesso, non viene riproposta dopo errori, UUID forgiati e
  campi duplicati/inattesi sono rifiutati e le revisioni obsolete producono `409`.

## 2026-10-07 — Gestione HTML scoped dei tenant

- Superadmin può elencare, creare, consultare e modificare tenant dalla UI; admin e
  manager vedono soltanto i tenant autorizzati e ricevono lo stesso `404` per oggetti
  inesistenti o fuori scope.
- I form sono protetti da CSRF, rifiutano campi/query inattesi, mantengono un UUID stabile
  per retry di creazione e usano la revisione per impedire sovrascritture concorrenti.
- Validazioni, conflitti slug e transizioni lifecycle producono errori accessibili e
  redatti; successi e negazioni restano auditati dai service o dall’adattatore UI.

## 2026-10-07 — Fondamenta UI accessibili e navigazione scoped

- Login, cambio password, dashboard ed errori condividono ora una shell responsive con
  stylesheet locale, skip link, landmark semantici, focus visibile, contrasto WCAG AA,
  dark mode e riduzione delle animazioni richiesta dal sistema.
- La navigazione e gli ambiti mostrati sono derivati server-side dalle assegnazioni
  superadmin/admin/manager; nomi tenant/rete mancanti o corrotti vengono redatti e la UI
  non sostituisce mai i controlli RBAC del backend.
- Errori UI redatti includono un request ID azionabile, mentre route API sconosciute
  continuano a ricevere Problem Details. CSP vieta script e risorse esterne consentendo
  soltanto il CSS locale.

## 2026-10-07 — Contratto OpenAPI pubblico e gate di compatibilità v1

- Il contratto OpenAPI 3.1 è ora scaricabile anonimamente da
  `GET /api/v1/openapi.json`; è servito da una risorsa inclusa nel pacchetto, senza
  console interattiva, hostname reali o esempi sensibili.
- Aggiunti esempi sicuri e validati per paginazione tenant, Problem Details, job
  asincroni e telemetria; il runbook mostra chiamate `curl` senza inserire il bearer
  token negli argomenti del processo.
- Il quality gate confronta route Flask e operazioni documentate, valida risposte runtime
  ed esempi contro JSON Schema, impedisce drift della copia packaged e blocca modifiche
  incompatibili rispetto alla baseline v1 congelata.

## 2026-10-07 — Download API protetto delle configurazioni client

- Implementato il download del singolo profilo WireGuard completo per service account
  con permesso dedicato `client.config:read`, scope RBAC e credenziale di durata massima
  24 ore; il permesso resta negato per default anche ai superadmin.
- Account, credenziale attiva, permessi e assegnazioni vengono ricaricati sotto lock prima
  di decifrare la chiave client. Rotazione, revoca, stati non scaricabili e accessi fuori
  scope falliscono in modo non enumerabile e sono auditati.
- Il profilo è compilato soltanto in memoria e restituito come attachment `no-store`; non
  esistono export massivi né accesso alla chiave server, e gli errori crittografici sono
  redatti.

## 2026-10-07 — Coda job limitata con backpressure esplicita

- I job queued/running sono ora soggetti a limiti configurabili globali e per identità,
  tenant e rete; controllo e creazione sono serializzati fra processi, mentre replay e
  retry dello stesso job non consumano nuova capacità.
- Una coda piena rifiuta l'azione prima della mutazione canonica con
  `429 QUEUE_CAPACITY_EXCEEDED` e `Retry-After`; il retry conserva la stessa chiave
  idempotente e può proseguire appena un job diventa terminale.
- Il reconciler rispetta i limiti globale/tenant/rete e usa il proprio backoff quando non
  può accodare; l'identità interna non compete invece con la quota delle identità API.

## 2026-10-07 — Lifecycle client live con sincronizzazione accodata

- Activate, disable, revoke e archive possono ora modificare i peer di una rete running:
  il client canonico viene aggiornato e l'API restituisce `202` con un job
  `network.sync` e relativo `Location`.
- Le azioni che non richiedono convergenza host continuano a restituire `200` con client
  ed ETag; `release-ip` resta esplicita e non provoca modifiche WireGuard.
- Un marker interno e il lock condiviso con worker/reconciler rendono recuperabile il
  crash fra patch client ed enqueue. Retry e replay non duplicano né mutazione né job, e
  il worker rivalida la credenziale API prima di applicare la configurazione.

## 2026-10-07 — Azioni live rete API accodate e rivalidate

- Esposti `start`, `stop`, `sync` e `reconcile` delle reti con body chiuso, ETag,
  idempotenza persistente e risposta `202` contenente job ID e `Location`; il processo
  HTTP non esegue il worker e non contatta il helper.
- Start/stop committano lo stato desiderato e un marker di recovery sotto il lock del
  worker prima dell'enqueue, consentendo retry dopo crash senza duplicare job o perdere
  la mutazione.
- I job API legano service account e credenziale usata. Prima dell'effetto host il worker
  rivalida account, credenziale attiva/non scaduta, RBAC, tenant e rete; rotazione, revoca
  o sospensione intervenute dopo l'enqueue fanno fallire il job in modo redatto.

## 2026-10-06 — Lifecycle API dei client e reservation IP

- Esposti create, update, activate, disable, revoke, archive e rilascio IP con RBAC
  scoped, ETag, idempotenza persistente e audit; le risposte non includono chiavi o
  envelope e mostrano soltanto la fingerprint pubblica.
- Create genera internamente la coppia WireGuard, cifra la privata, assegna il primo IP
  libero o quello richiesto e crea un client `pending` con reservation permanente e
  keepalive 25 secondi. In assenza della master key fallisce chiuso con `503`.
- Le transizioni che aggiungono o rimuovono peer attivi richiedono la rete stopped e non
  accodano job in M3.4. Revoca e archiviazione non liberano l'IP: `release-ip` resta
  un'azione esplicita, idempotente e ammessa solo dopo revoke/archive.

## 2026-10-06 — CRUD API delle reti senza effetti host impliciti

- Esposti create, update e archive delle reti con idempotenza, ETag, RBAC scoped e audit;
  create produce sempre una rete stopped e non accoda job né contatta il helper.
- Generati internamente nome interfaccia e coppia WireGuard; la privata viene salvata
  soltanto nell'envelope cifrato e chiavi, envelope e mapping host non compaiono nelle
  risposte. In assenza della master key la creazione fallisce chiusa con `503`.
- Allocazione automatica e porte manuali verificano range, hostname normalizzati e alias
  IPv4 risolti. Overlap nello stesso tenant, collisioni e modifiche runtime su reti
  running vengono negati; archive resta admin/superadmin-only.

## 2026-10-05 — Lifecycle API sicuro dei service account

- Esposti create, rotate e revoke superadmin-only con JSON chiuso, ETag, idempotenza
  persistente, audit e invalidazione immediata delle credenziali sostituite o revocate.
- Create e rotate mostrano il bearer token soltanto nella prima risposta e persistono
  esclusivamente account e metadati redatti; un retry completato restituisce
  `409 CREDENTIAL_RECOVERY_REQUIRED` e richiede una rotazione con nuova chiave.
- Aggiunto recovery crash-safe per singola risorsa: un marker interno distingue l'esatto
  retry da una nuova richiesta con revisione obsoleta, mentre token e secret restano
  assenti da storage, record idempotency, audit e proiezioni API.

## 2026-10-05 — Retention e quota dello store idempotency

- Confermata e implementata la policy consigliata: record completati eliminati dopo 24
  ore, mentre i `pending` non vengono mai cancellati automaticamente e sono elencati per
  riconciliazione.
- Aggiunte quota configurabile predefinita di 1000 record per service account e riserva
  minima di 256 MiB sul filesystem; nuove mutazioni oltre soglia ricevono `429` prima di
  creare il record o chiamare l'use case.
- Aggiunto `wg-portal idempotency-maintain`; la manutenzione è anche eseguita in modo
  opportunistico prima di una nuova chiave, sotto lock multiprocesso.

## 2026-10-05 — Mutazioni API scoped per utenti e assegnazioni

- Esposti `POST /api/v1/users` e `PATCH /api/v1/users/{id}` con idempotenza, ETag e
  proiezioni senza hash: le password iniziali rispettano la policy a 14 caratteri, sono
  hashate Argon2id e impongono il cambio al primo accesso.
- Gli admin possono creare e modificare assegnazioni soltanto nei tenant amministrati,
  preservando eventuali assegnazioni esterne; modifiche con effetto globale richiedono
  controllo completo dell'account e manager/cross-tenant ricevono 404 non enumerabili.
- Serializzati unicità case-insensitive degli username e controllo dell'ultimo
  superadmin attivo; password e payload non entrano in risposta, audit o record
  idempotency.

## 2026-10-05 — Prime mutazioni API idempotenti per tenant

- Esposti `POST /api/v1/tenants` e `PATCH /api/v1/tenants/{id}` con JSON chiuso,
  lifecycle validato, ETag forte e precondizione `If-Match`; creazione e modifica restano
  superadmin-only e le negazioni non rivelano l'esistenza delle risorse.
- Aggiunto uno store idempotency file-backed per identità e chiave UUID: lega operazione e
  digest canonico, prealloca l'ID per il recovery post-crash e riproduce soltanto risposte
  2xx redatte, senza conservare bearer token o payload richiesta.
- Serializzata globalmente l'unicità degli slug tenant e auditati intenti, esiti, rifiuti
  di validazione e conflitti. Le API bearer sono esenti dal CSRF a cookie, mentre la UI
  conserva la protezione CSRF esistente.

## 2026-10-05 — Telemetria API e presenza client persistente

- Completata M3.3 con `GET /api/v1/networks/{id}/telemetry`: ogni risposta scoped mostra
  IP VPN, endpoint osservato, ultimo handshake, RX/TX, presenza e “online dal” stimato,
  senza esporre chiavi pubbliche o nomi interfaccia.
- La correlazione richiede coerenza fra rete/client canonici, registry privilegiato,
  isolamento VRF e peer WireGuard. Probe assenti, vecchi, malformati o in drift producono
  `unknown`, mai un falso `offline`, e non aggiornano la cache.
- Aggiunta cache JSON atomica e ricostruibile per client: `online` entro la soglia globale
  configurabile (180 secondi di default), `stale` fino al doppio e `offline` oltre. La
  continuità “online dal” sopravvive ai riavvii solo fra campioni temporalmente coerenti.

## 2026-10-05 — Prima superficie API v1 read-only scoped

- Esposti endpoint Bearer read-only per tenant, utenti, reti, client, job e service
  account, con proiezioni separate che omettono password hash, chiavi, envelope, attori e
  payload interni; le reti dichiarano `actual_state=unknown` finché non è disponibile uno
  snapshot runtime affidabile.
- Aggiunti paginazione deterministica e cursori AES-256-GCM a vita breve, vincolati a
  identità, collezione e filtri; query sconosciute o duplicate, cursori alterati, scaduti
  o riusati fuori scope vengono rifiutati.
- Applicati RBAC object-level, 404 non enumerabili e audit delle negazioni; errori
  Problem Details, request ID, ETag, `no-store` e `Retry-After` sono verificati da test
  negativi. La telemetria read-only resta il sottogate aperto di M3.3.

## 2026-10-05 — Service account e token API file-backed

- Aggiunte identità macchina con assegnazioni RBAC, permesso sensibile opzionale e
  credenziali separate: i bearer token hanno 256 bit casuali, sono mostrati una volta e
  persistiti esclusivamente come hash Argon2id.
- Rotazione e revoca cambiano atomicamente il puntatore alla sola credenziale attiva;
  token precedenti, scaduti, revocati, ignoti o corrotti falliscono con risposta uniforme.
- Introdotti scadenza massima di 90 giorni (24 ore con `client.config:read`), audit del
  lifecycle, compensazione degli orfani e rate limit file-backed per credenziale+IP e IP.
  I servizi sono registrati nell'app factory, ma nessuna route API è ancora pubblicata.

## 2026-10-05 — Contratto OpenAPI 3.1 e threat model API v1

- Definito il contratto normativo `/api/v1` con proiezioni prive di segreti storage,
  autenticazione bearer, errori Problem Details, paginazione a cursore limitata, ETag e
  idempotenza obbligatoria per le mutazioni.
- Contrattualizzati CRUD e azioni pianificati per tenant, utenti, reti, client, job,
  telemetria e service account; operazioni live asincrone restituiscono sempre un job.
- Aggiunti threat model per replay, IDOR, confused deputy, mass assignment, cursori,
  resource exhaustion, proxy e secret leakage, più nove test automatici degli invarianti.
  Gli endpoint restano non implementati fino agli incrementi successivi.

## 2026-10-05 — M2.6 completata con isolamento multi-client reale

- Corretta la policy nftables per la semantica VRF effettiva del kernel: input e traffico
  inoltrato identificano il master VRF in ingresso, mantenendo la slave WireGuard in
  uscita. La verifica fail-closed riconosce e ripara ruleset precedenti o alterati.
- Collaudati sul Debian target due client comunicanti via hub, due tenant con CIDR
  identico reciprocamente isolati e blocco di LAN/Internet anche con un client ostile che
  richiede la default route attraverso la VPN.
- Verificata la revoca live di un peer senza ricreare l'interfaccia né interrompere gli
  altri client. Cleanup completo e ripristino di `ip_forward=0`; M2.6 è chiusa e il
  prossimo incremento è M3.1 (threat model e contratto OpenAPI 3.1).

## 2026-10-05 — Stime di avanzamento a ogni consegna

- Su richiesta del maintainer, ogni esecuzione termina ora con una stima separata del
  lavoro residuo per una versione utilizzabile e per il completamento totale della
  roadmap, motivata dai gate ancora aperti.

## 2026-10-05 — Overlap cross-tenant attestato e verificato

- Aggiunta la capability versionata `per-network-vrf-v1`: solo il helper isolato la
  pubblica e il dominio la richiede per accettare CIDR sovrapposti tra tenant diversi.
- Il reconciler rifiuta helper legacy o deployment parziali privi della capability,
  evitando che il solo stato WireGuard venga scambiato per isolamento verificato.
- Due VPN reali con CIDR identico sono state collaudate sul Debian target: ciascun client
  raggiungeva il proprio hub, il traffico cross-tenant falliva in entrambi i versi e il
  cleanup finale non ha lasciato risorse.

## 2026-10-05 — Reconcile consapevole dell'isolamento

- Il probe privilegiato espone al reconciler lo stato verificato `ok`, `drift` o `legacy`
  delle risorse VRF/nftables registrate, senza includere configurazioni o chiavi.
- Il reconciler ora ripara isolamento mancante o alterato e arresta risorse ancora
  registrate per reti stopped; payload incompleti, duplicati o malformati falliscono in
  chiusura. Gli errori host di isolamento restano azionabili ma redatti nei job.
- Verificati sul Debian reale rilevamento di una regola nft estranea, riparazione, stop e
  cleanup completo attraverso il socket autenticato come `wg-portal`.

## 2026-10-05 — Transazione isolata WireGuard, VRF e nftables

- Il helper applica ogni rete come insieme verificato: WireGuard resta down finché VRF e
  firewall non sono installati, e il registry viene scritto soltanto dopo la verifica.
- Retry identici sono no-op; drift, stop ed errori intermedi attivano sostituzione o
  rollback espliciti. Collisioni non gestite non vengono cancellate e rollback incompleti
  sono segnalati senza dichiarare successo.
- Verificati sul Debian reale creazione, retry idempotente, riparazione di drift nftables,
  stop e cleanup completo tramite il socket privilegiato.

## 2026-10-05 — Primitive host VRF e nftables verificate

- Aggiunte operazioni privilegiate a argv fisso per creare, collegare e rimuovere VRF e
  per applicare/rimuovere la policy nftables tramite stdin, senza shell.
- La verifica fail-closed controlla forwarding, VRF, master e ruleset JSON completo,
  ignorando soltanto handle e metadati runtime; regole estranee vengono rilevate come
  drift.
- Collaudati apply, verifica, drift negativo e cleanup sul Debian reale, ripristinando il
  forwarding disabilitato e senza lasciare interfacce o tabelle firewall.

## 2026-10-03 — Registry privilegiato v2 per l'identità VRF

- Esteso il registry root-owned con modalità VRF, route table, CIDR e IP hub validati,
  preservando l'identità sui retry e negando collisioni o cambi incoerenti.
- Aggiunta migrazione atomica v1→v2: le reti legacy restano intenzionalmente non isolate
  finché un apply non verifica la VRF; versioni sconosciute non vengono riscritte.
- Migrazione e secondo avvio idempotente verificati sul target Debian reale senza creare
  interfacce o modificare il forwarding.

## 2026-10-03 — Avvio isolamento M2.6 con piano VRF

- Scelta una VRF per ogni rete per supportare in sicurezza CIDR sovrapposti tra tenant
  senza concedere `CAP_SYS_ADMIN` al helper privilegiato.
- Aggiunti allocazione deterministica delle route table riservate e rendering nftables
  validato che consente solo hub/rete e forwarding intra-VPN, negando LAN, Internet e
  transito tra interfacce gestite.
- Suddivisa M2.6 in gate indipendenti; l'overlap resta negato finché registry, executor e
  test di isolamento reali non saranno completati.

## 2026-10-03 — Completamento M2.5 con test end-to-end

- Verificati handshake e traffico bidirezionale reali tra hub Debian e peer WSL, inclusi
  interruzione, ricreazione dell'interfaccia hub e nuovo handshake dopo il recovery.
- Corretto lo stop e il rollback dopo traffico reale: gli snapshot ignorano esclusivamente
  l'endpoint peer appreso dinamicamente da WireGuard, continuando a rifiutare direttive
  inattese. Aggiunto il relativo test di regressione unitario e sul target Debian.
- Cleanup verificato su entrambi gli host senza route, interfacce, chiavi, script o record
  residui; M2.5 è ora completata e il prossimo incremento è l'isolamento M2.6.

## 2026-10-03 — Collaudo reale del reconciler drift-aware

- Verificati su Debian reale il ripristino automatico di porta e indirizzo modificati
  fuori banda, il reporting del CIDR canonico e l'arresto del ciclo continuo su `SIGTERM`.
- Validata la nuova unità con `systemd-analyze verify` e confermato il cleanup completo:
  nessuna interfaccia, istanza helper, chiave temporanea o record di rete residuo; il
  forwarding IPv4 è rimasto disabilitato.

## 2026-10-02 — Reconciler periodico basato sul drift

- Aggiunto `wg-portal reconciler` e l'unità systemd non privilegiata per polling continuo,
  arresto tramite segnali e backoff esponenziale configurabile.
- Il probe include ora gli indirizzi delle interfacce e fingerprint SHA-256 completi; il
  reconciler crea job soltanto per drift di presenza, indirizzo, porta, fwmark o peer e
  fallisce in chiusura quando lo snapshot runtime non è affidabile.
- Il helper ripara modifiche fuori banda a configurazione o indirizzo con verifica e
  rollback in memoria. Stato già convergente non genera nuovi job.

## 2026-09-27 — Conferma del confine di sicurezza API v1

- Confermate integralmente le quattro raccomandazioni aperte per autenticazione API,
  download delle configurazioni client, esposizione di rete e operazioni distruttive.
- Stabiliti service account con token hashati e scadenza massima di 90 giorni,
  `client.config:read` separato, accesso iniziale da reti amministrative tramite Caddy e
  assenza di cancellazioni fisiche nell'API v1.
- Aggiornati roadmap, threat baseline, processo operativo e ADR 0016; non sono ancora
  stati implementati endpoint o credenziali API.

## 2026-09-27 — Reconcile one-shot e recovery host

- Aggiunto `wg-portal reconcile-once`, che recupera job interrotti e converge tutte le
  reti tramite job persistenti attribuiti a un attore interno limitato al solo reconcile.
- Serializzati worker e reconciler con un lock globale, evitando recovery concorrenti e
  doppia esecuzione tra processi.
- Il helper ora ricrea in sicurezza un'interfaccia scomparsa quando il registry root-owned
  ne conferma l'identità, oppure rimuove il record stale quando lo stato desiderato è
  stopped; collisioni e mismatch continuano a fallire in chiusura. Il recovery è stato
  verificato sul target Debian reale con cleanup completo.

## 2026-09-26 — Pianificazione API pubblica

- Aggiunta alla specifica un'API HTTPS versionata per gestire da remoto tenant, utenti,
  assegnazioni, reti, client, job e telemetria usando gli stessi service, RBAC e audit.
- Definiti la baseline `/api/v1`, il contratto OpenAPI, paginazione, concorrenza
  ottimistica, idempotenza, job asincroni, rate limit, quote e test di sicurezza.
- Registrate quattro decisioni aperte su autenticazione macchina, download delle
  configurazioni client, esposizione di rete e operazioni distruttive remote.

## 2026-09-26 — Worker per job di rete

- Collegati job persistenti, rivalidazione RBAC, documenti canonici, chiavi cifrate,
  compiler WireGuard e helper privilegiato in un worker sincrono fail-closed.
- Start, sync e reconcile-running compilano lo stato corrente; stop non decifra chiavi.
  Ruoli revocati, desired state incompatibile e risorse mancanti chiudono il job in errore.
- Aggiunto `wg-portal worker-once` per processare al massimo un job queued, con transizioni
  e progresso persistenti, risposta redatta e codici helper sicuri ma azionabili.

## 2026-09-26 — Executor WireGuard con rollback

- Abilitati apply/start, sync idempotente e stop nel helper privilegiato usando soltanto
  argv fissi di `ip` e `wg`, senza shell, `wg-quick`, path forniti dal chiamante o hook.
- Aggiunta una validazione root indipendente della configurazione server e una verifica
  completa dell'actual state dopo ogni mutazione.
- Snapshot e rollback restano esclusivamente in memoria: nessuna configurazione o chiave
  privata server viene persistita in chiaro; le mutazioni concorrenti sono serializzate.
- Verificati sul target Debian reale creazione, retry idempotente, stop e cleanup completo,
  senza cambiare forwarding o lasciare interfacce, route e record nel registry.

## 2026-09-25 — Envelope mutazioni e registry privilegiato

- Esteso il protocollo locale con richieste tipizzate `network.apply` e `network.stop`,
  limitate a UUID canonici, nomi interfaccia sicuri e configurazioni ASCII con digest
  SHA-256 verificato; path, argv e campi extra vengono rifiutati.
- Aggiunto un registry atomico root-owned, separato dai dati della UI, che impedisce il
  riuso di un nome interfaccia o la sostituzione dell'identità tenant/rete e non conserva
  configurazioni né chiavi private.
- Configurato systemd per creare la directory privata del registry. Le mutazioni restano
  disabilitate in sicurezza fino al collegamento dell'executor con snapshot e rollback.
- Verificati sul target Debian reale socket, unità systemd e registry root:`root` con
  permessi `0700`/`0600`; una richiesta stop reale è stata rifiutata senza effetti perché
  l'executor non è ancora abilitato.

## 2026-09-25 — Job persistenti per le operazioni live

- Aggiunta una coda file-backed per start, stop, sync e reconcile delle reti, con request
  ID usato come chiave di idempotenza e conflitti espliciti in caso di riuso differente.
- Applicati RBAC object-level, optimistic concurrency e transizioni controllate da queued
  a running e quindi succeeded/failed, con progresso monotono e timestamp UTC.
- Registrati intent ed esiti nell'audit senza includere messaggi di errore visibili o
  payload; i job rimasti running dopo un crash vengono chiusi come interrotti da sistema.

## 2026-09-25 — Topologia di integrazione end-to-end autorizzata

- Registrato `vrt-debian1.lsinet.it` come hub WireGuard di test e la WSL Debian corrente come peer
  client, così M2.5–M2.6 potranno verificare handshake e traffico reali tra due macchine.
- Registrata la disponibilità di `sudo` per l'utente di sviluppo locale; installazioni e
  mutazioni di rete restano limitate ai test espliciti, con inventario e cleanup verificati.

## 2026-09-25 — Validazione su Debian reale e compatibilità iproute2

- Predisposto l'host di integrazione Debian 12 `vrt-debian1.lsinet.it` con WireGuard, virtualenv,
  bootstrap isolato e socket systemd del helper; nessuna interfaccia VPN resta attiva.
- Eseguiti con successo 311 test anche sul target, il probe privilegiato come utente di
  servizio e i test negativi che rifiutano root e utenti estranei al gruppo del socket.
- Verificate le unità con `systemd-analyze verify` e ottenuta esposizione `4.5 OK` dalla
  valutazione security di systemd.
- Corretto il rilevamento dei link WireGuard su iproute2 Debian 12: il probe enumera i
  link dettagliati e filtra `info_kind=wireguard`, evitando i record vuoti prodotti dal
  filtro `type wireguard` quando non esistono interfacce.

## 2026-09-25 — Helper privilegiato a protocollo ristretto

- Aggiunti client e helper locale con framing JSON rigoroso, versione esplicita, request ID
  e allowlist iniziale limitata al solo probe read-only.
- Autenticati entrambi i lati tramite credenziali kernel `SO_PEERCRED`: il client accetta
  soltanto il peer root e il helper soltanto l'UID configurato del control plane.
- Rifiutati campi extra, chiavi JSON duplicate, frame multipli o sovradimensionati,
  operazioni sconosciute e socket non autentici; gli errori operativi restano redatti.
- Aggiunti socket activation e servizio systemd per connessione con permessi di gruppo,
  capability limitate e direttive di hardening, oltre al comando diagnostico
  `helper-probe` che non richiede i segreti applicativi.

## 2026-09-24 — Compiler deterministico WireGuard

- Aggiunto il compiler puro per configurazioni server e client in formato `wg-quick`, con
  output canonico, ordinamento stabile dei peer e golden test versionati.
- Limitati i peer server ai soli client attivi e i relativi `AllowedIPs` al singolo `/32`;
  le configurazioni client instradano soltanto il CIDR VPN e non una default route.
- Verificata la corrispondenza tra chiave privata e pubblica prima del rendering e aggiunti
  rifiuti fail-closed per scope, duplicati, lifecycle, keepalive e chiavi malformate.
- Esclusi dal rendering campi liberi, firewall inline, DNS, hook e `SaveConfig`, così dati
  utente non possono diventare direttive e le policy host restano responsabilità del helper.

## 2026-09-24 — Custodia cifrata e rotazione delle chiavi WireGuard

- Aggiunta generazione locale delle coppie WireGuard e cifratura AES-256-GCM delle chiavi
  private, vincolata tramite AAD a tipo, risorsa, tenant e rete.
- Introdotto un keyring master esterno al data tree, con permessi `0600`, rotazione senza
  perdita delle vecchie chiavi e rewrap idempotente e auditabile degli envelope salvati.
- Protetti download e rotazione delle chiavi client con RBAC object-level, verifica della
  password corrente, lifecycle consentito, risposta generica e audit redatto.
- Aggiunte CLI di inizializzazione, rotazione e rewrap; il bootstrap di sviluppo crea il
  keyring separato prima dei dati applicativi.
- Documentato Windows 11 Pro con WSL Debian come ambiente di sviluppo: i probe che
  dipendono da systemd, nftables o privilegi host possono risultare non disponibili; il
  target di produzione resta Debian nativo.

## 2026-09-24 — Probe host e telemetria WireGuard read-only

- Aggiunto `host-probe` per verificare eseguibili, modulo kernel, forwarding IPv4,
  systemd, nftables, link e interfacce WireGuard senza modificare la macchina.
- Aggiunto un parser rigoroso del dump WireGuard per endpoint, AllowedIPs, handshake,
  traffico e keepalive, scartando chiavi private e preshared e serializzando solo il
  fingerprint della chiave pubblica peer.
- Limitata l'esecuzione a argv assoluti senza shell, timeout e output massimo, con stati
  espliciti per dati mancanti, non leggibili o malformati.
- Aggiunta la verifica fail-closed delle collisioni UDP tra hostname differenti che
  risolvono allo stesso indirizzo IPv4.

## 2026-09-23 — Audit append-only e retention verificabile

- Aggiunto un audit JSONL giornaliero redatto con catena HMAC separata, validazione dello
  schema e blocco fail-closed in caso di modifica, rimozione o riordino dei record.
- Registrati login, logout, cambio password, rate limit e rifiuti CSRF senza conservare
  username, credenziali o payload delle richieste.
- Aggiunte archiviazione gzip dopo 30 giorni, eliminazione al compimento di tre mesi
  calendario e manifest verificabili con checksum e HMAC finale.
- Aggiunte CLI per verifica, manutenzione ed export `tar.gz` di intervalli audit, con
  lock inter-processo e divieto di sovrascrivere una destinazione esistente.

## 2026-09-23 — Autorizzazione multi-tenant centralizzata

- Aggiunta una policy RBAC deny-by-default per tutte le azioni tenant, utenti, reti,
  client, dashboard, job e audit, con scope object-level espliciti.
- Impediti accessi a tenant o reti adiacenti, operazioni prive dello scope richiesto e
  amministrazione dei superadmin da ruoli subordinati.
- Protetti gli utenti condivisi: gli admin possono cambiare solo assegnazioni nei propri
  tenant e non possono applicare mutazioni globali con effetti su tenant non amministrati.
- Impedita la rimozione o disabilitazione dell'ultimo superadmin attivo.

## 2026-09-23 — Autenticazione web sicura

- Aggiunti login/logout e cambio password obbligatorio con Argon2id, risposte
  anti-enumerazione, sessioni protette e policy password minima di 14 caratteri.
- Protetti tutti i POST con CSRF, incluso login e logout, e confinato il bootstrap
  `admin/admin` al client loopback anche dietro un proxy locale fidato.
- Aggiunto rate limiting file-backed condiviso tra worker, per IP+utente e per IP globale,
  con parametri configurabili e identificatori bucket non leggibili.

## 2026-09-23 — Validazione dominio di reti e lifecycle

- Aggiunti validatori puri per RFC1918 `/16`–`/30`, hub e IP client utilizzabili, overlap
  intra/cross-tenant, endpoint, interfacce e porte WireGuard.
- Aggiunte allocazioni automatiche deterministiche di porte e IP con override manuale
  sottoposto agli stessi controlli e messaggi di errore stabili.
- Formalizzate le transizioni tenant/rete/client e la reservation IP: revoca o archivio
  non liberano l'indirizzo senza un'azione esplicita e auditabile.

## 2026-09-23 — Repository JSON versionato

- Aggiunti CRUD persistenti con path scoped e UUID canonici, patch atomiche, revisioni
  compare-and-swap e conflitti espliciti per impedire aggiornamenti persi.
- Resi immutabili identità e scope, verificata la coerenza tra contenuto e path e aggiunto
  un indice runtime completamente ricostruibile che non partecipa alle autorizzazioni.
- Aggiunto un registry di migrazioni forward-only che preserva l'identità e valida ogni
  risultato contro lo schema di destinazione.

## 2026-09-23 — Contratti JSON v1

- Aggiunti schemi versionati e packaged per utenti, tenant, reti, client, job e audit,
  tutti chiusi a proprietà sconosciute e verificati anche nei formati UUID/IP/data.
- Formalizzati scope RBAC, desired state delle reti, lifecycle client, porte WireGuard,
  keepalive e struttura degli envelope cifrati per le chiavi private.
- Rafforzata la validazione dello storage e aggiunti test positivi e negativi per ogni
  tipo di documento persistente.

## 2026-09-23 — Chiusura delle decisioni aperte iniziali

- Confermati keepalive client di 25 secondi e soglia online globale configurabile con
  valore predefinito di 180 secondi.
- Confermato il pacchetto Debian come formato di distribuzione ufficiale della versione 1,
  con unità systemd e Caddy; supporto container rinviato.
- Il registro non contiene più decisioni in attesa di risposta.

## 2026-09-23 — Raccomandazioni nel registro decisionale

- Aggiunta a ogni decisione utente una soluzione consigliata con motivazione e trade-off,
  mantenendola distinta dall'esito scelto dall'utente.
- Aggiornato l'handoff affinché ogni nuova richiesta decisionale includa sempre una
  raccomandazione tecnica concreta.

## 2026-09-23 — Presenza client nella dashboard

- Prevista la visualizzazione di IP VPN, endpoint pubblico osservato, ultimo handshake,
  traffico e stato di presenza per ciascun client autorizzato.
- Definito “online dal” come stima del monitor, poiché WireGuard non espone una sessione
  connessa tradizionale; gli errori del probe producono stato `unknown`, non `offline`.
- Registrata la decisione aperta su soglia online e `PersistentKeepalive`, proponendo
  rispettivamente 180 e 25 secondi.

## 2026-09-23 — Decisioni iniziali di prodotto e infrastruttura

- Limitata la versione 1 a subnet IPv4 private RFC1918 da `/16` a `/30`; overlap vietato
  nello stesso tenant e consentito tra tenant solo con isolamento L3 reale.
- Riservate le porte WireGuard `51820–51999/UDP`, con assegnazione automatica predefinita,
  override manuale validato e divieto di collisione sullo stesso endpoint/IP.
- Scelte conservazione cifrata e download successivi delle chiavi private, appartenenza
  multi-tenant degli utenti e Caddy come reverse proxy supportato.
- Definita la policy audit: rotazione giornaliera, 30 giorni operativi, eliminazione al
  compimento di 3 mesi ed export/backup nel formato nativo compresso.
- Chiusa la review delle decisioni iniziali; resta aperta, senza bloccare le milestone
  correnti, la scelta del formato di distribuzione della versione 1.

## 2026-09-23 — Registro delle decisioni utente

- Aggiunto un registro canonico diviso tra decisioni aperte e chiuse, con una riga per
  scelta, motivazione, stato, data di richiesta, data di risposta ed esito.
- Registrate separatamente le sei decisioni già aperte emerse durante la specifica.
- Aggiornate le istruzioni di handoff per impedire che decisioni richieste all'utente
  restino implicite o disperse nella documentazione.

## 2026-09-23 — Regole di contribuzione e tracciamento

- Introdotto il changelog grow-only in ordine cronologico inverso.
- Stabilito che le modifiche importanti o con riscontro sull'utente, comprese le richieste
  manuali, devono essere registrate qui.
- Stabilito che, quando richiesti, i commit devono descrivere esaustivamente il relativo
  cambiamento mantenendo il messaggio conciso.

## 2026-09-23 — Fondazioni del progetto

- Definite specifica funzionale, architettura, modello dati file-based, threat model,
  roadmap e istruzioni di handoff.
- Creato lo scaffold Flask con configurazione, health check e header HTTP difensivi.
- Aggiunti storage JSON atomico, lock inter-processo, permessi restrittivi e JSON Schema.
- Aggiunti CLI di bootstrap e diagnostica, account iniziale `admin/admin` con hash Argon2
  e obbligo di cambio password.
- Aggiunti requirements, packaging, script di setup e quality gate con test, lint e type
  checking.
