# API pubblica — baseline di progetto

Stato: contratto, credenziali, letture e milestone M3.4–M3.6 implementati; le azioni live
usano job limitati e il download client applica un confine sensibile dedicato. Le
decisioni vincolanti sono registrate in `USER_DECISIONS.md` e negli ADR 0016, 0019–0032.
La fonte normativa machine-readable è `openapi/v1.json`.

## Scopo

L'API permette ad automazioni remote di amministrare tenant, utenti e assegnazioni, reti,
client e relativi job, oltre a leggere stato e telemetria. Usa gli stessi service layer,
validatori, policy RBAC, repository e audit della UI: non esistono scorciatoie API verso
file, helper privilegiato o comandi host.

La prima versione usa JSON su HTTPS sotto `/api/v1`. Sono esclusi password login, cookie
di sessione, bootstrap `admin/admin`, accesso diretto al filesystem e qualunque endpoint
che accetti comandi, path o configurazioni WireGuard arbitrarie.

## Contratto HTTP

- Content type JSON UTF-8; errori nel formato `application/problem+json` con `type`,
  `status`, `code`, `title`, `request_id` e dettagli non sensibili.
- UUID opachi negli URL. Il tenant/rete effettivo deriva sempre dall'oggetto canonico e
  viene confrontato con lo scope dell'identità, non è considerato affidabile perché
  presente nel path o body.
- Collezioni paginate con cursore opaco, ordine deterministico, limite predefinito 50 e
  massimo 200; il cursore è lungo al massimo 512 caratteri. Niente offset o dump illimitati.
- ETag forte `"rev-N"` derivato dalla revisione e `If-Match` obbligatorio per PATCH e
  azioni revisionate. Header assente restituisce `428`, revisione obsoleta `412`, senza
  sovrascrivere.
- `Idempotency-Key` UUID obbligatorio per POST mutanti e azioni live. Stessa chiave e
  stesso payload restituiscono la risposta originaria; un riuso differente restituisce
  conflitto. La retention delle chiavi va dimensionata e documentata prima del rilascio.
- Creazioni/patch puramente file-backed rispondono sincronicamente. Start, stop, sync e
  reconcile rete sono collegati alla coda con `202 Accepted`, job ID e
  `Location: /api/v1/jobs/<uuid>`. Le transizioni client che aggiungono o rimuovono peer
  su rete running usano la stessa coda tramite `network.sync`; quelle senza effetto host
  restituiscono `200` ed ETag.
- Ogni risposta include `X-Request-ID`; un UUID valido fornito dal client può essere
  propagato, altrimenti viene generato. Non viene mai usato come autorizzazione.
- CORS disabilitato per default. Eventuale accesso browser cross-origin richiederà una
  decisione e una allowlist esplicita; non si usa `*` con credenziali.

Il cursore rappresenta l'ultima coppia ordinata `(created_at, id)` e viene cifrato e
autenticato legandolo a major API, identità, filtri e verso di ordinamento. È opaco al chiamante: un
cursore alterato, scaduto o riusato con filtri/scope differenti restituisce
`400 INVALID_CURSOR`, senza ripartire implicitamente dalla prima pagina.

### Catalogo errori v1

| HTTP | Codice stabile | Significato pubblico |
|---|---|---|
| 400 | `INVALID_REQUEST` / `INVALID_CURSOR` | Sintassi, header o cursore non accettabili |
| 401 | `AUTHENTICATION_REQUIRED` | Credenziale assente, ignota, scaduta o revocata |
| 404 | `RESOURCE_NOT_FOUND` | Risorsa inesistente oppure fuori scope |
| 409 | `RESOURCE_CONFLICT` / `IDEMPOTENCY_CONFLICT` | Vincolo dominio o chiave riusata con altra richiesta |
| 412 | `PRECONDITION_FAILED` | ETag valido ma non più corrente |
| 422 | `VALIDATION_FAILED` | Campi noti ma semanticamente invalidi |
| 428 | `PRECONDITION_REQUIRED` | `If-Match` obbligatorio assente |
| 429 | `RATE_LIMITED` | Budget richieste o quota idempotency esauriti; include `Retry-After` |
| 429 | `QUEUE_CAPACITY_EXCEEDED` | Quota job globale/identità/tenant/rete esaurita; retry con la stessa chiave dopo `Retry-After` |
| 500 | `INTERNAL_ERROR` | Errore interno redatto e correlabile con `request_id` |
| 503 | `SERVICE_UNAVAILABLE` | Store, worker o helper temporaneamente non affidabili |

`title` è una frase generica localizzabile e non è un identificatore macchina. Il client
deve usare `code`; `type` è un URI stabile della major. Errori campo riportano soltanto
path allowlistati e codici, mai valori ricevuti, regole RBAC o eccezioni interne.

## Superficie prevista

| Area | Lettura | Mutazione |
|---|---|---|
| tenant | elenco/dettaglio scoped | create, update, suspend, archive secondo RBAC |
| utenti e assegnazioni | elenco/dettaglio visibile | create/update/disable/assegnazioni con protezioni multi-tenant |
| reti | configurazione redatta, desired/actual state | create/update/archive e azioni start/stop/sync/reconcile asincrone |
| client | lifecycle, IP, chiave pubblica redatta/fingerprint | create/update/activate/disable/revoke/archive/rotate |
| configurazione client | metadati disponibilità | download completo con `client.config:read`, token breve, audit e `no-store` |
| job | elenco/dettaglio nello scope della risorsa | nessuna riscrittura o cancellazione dell'esito |
| dashboard/telemetria | snapshot scoped e timestampato | nessuna mutazione |
| audit | lettura/export secondo policy | nessuna modifica dei record |
| token/service account | elenco senza secret | create, rotate e revoke con scadenza massima di 90 giorni |

Le chiavi private server non sono mai restituite. Liste e risposte non includono envelope
cifrati, password hash, token hash, socket/path host o output grezzo di WireGuard.

## Autenticazione e autorizzazione

La v1 usa service account distinti dagli utenti interattivi, con token bearer ad alta
entropia mostrati una sola volta, secret memorizzato solo come hash e identificatore non
segreto per la ricerca. Ogni
identità possiede assegnazioni equivalenti a superadmin/admin/manager e permessi aggiuntivi
minimi per operazioni sensibili; la scadenza massima è 90 giorni e rotazione e revoca sono
obbligatorie e auditate. Il contratto resta predisposto per OAuth 2.1/OIDC futuro.

Ogni richiesta autentica prima il token, verifica stato/scadenza e applica la stessa
policy object-level della UI. Un token revocato deve cessare immediatamente di creare job;
un job già queued rivalida l'identità al consumo come avviene per gli utenti. Token e loro
hash non compaiono in log, audit, URL o errori. L'audit registra soltanto UUID dell'identità
API e, se utile, fingerprint non reversibile del token/versione.

M3.2 implementa il formato `wgp_v1.<credential-uuid>.<secret-base64url>`, con 256 bit di
entropia, hash Argon2id e puntatore atomico alla sola credenziale attiva. La durata massima
è 90 giorni, ridotta a 24 ore quando è concesso `client.config:read`. Il rate limit
file-backed usa per default una finestra di 60 secondi, 120 richieste per credenziale+IP e
600 per IP; i tre valori sono configurabili.

Il primo sottogate M3.3 registra le route `GET` per tenant, utenti, reti, client, job e
service account. Le liste applicano ordine `(created_at, id)`, limite 50/200 e cursori
AES-256-GCM validi 15 minuti, derivati da una chiave separata e legati a identità,
collezione e filtri. Le query sono chiuse e non ammettono parametri duplicati. Le
proiezioni omettono i campi storage sensibili; fuori scope e inesistente producono lo
stesso `404 RESOURCE_NOT_FOUND` e una negazione auditata. Lo stato runtime delle reti è
temporaneamente `unknown` nella proiezione generale, per evitare un probe privilegiato
per ogni elenco.

Il secondo sottogate M3.3 espone `/networks/{id}/telemetry`. Autorizza la rete prima di
contattare il helper e correla fingerprint peer esclusivamente in memoria con client
canonici attivi. Registry root-owned, interfaccia, isolamento VRF, indirizzo hub, porta,
peer e route `/32` devono essere coerenti. Campioni oltre 60 secondi, errori, drift,
duplicati o mismatch restituiscono una pagina con presenza `unknown` e non modificano la
cache. La soglia `online` è globale e configurabile, 180 secondi per default; `stale`
copre fino al doppio e `offline` gli handshake più vecchi. Una cache JSON atomica conserva
la finestra stimata `online_since_estimated`, ma non è fonte di autorizzazione o stato
desiderato e non contiene chiavi/fingerprint.

Il primo sottogate M3.4 espone create/update di tenant e utenti. I tenant sono
superadmin-only; per gli utenti, gli admin possono agire soltanto su assegnazioni nello
scope interamente controllato e non possono produrre effetti su altri tenant. L'ultimo
superadmin attivo è protetto. POST richiede una chiave idempotente canonica, mentre PATCH
richiede `If-Match: "rev-N"`. JSON non oggetto, non UTF-8, con costanti non finite, chiavi
duplicate o proprietà sconosciute viene rifiutato. Lo store persiste identità, operazione,
SHA-256 del JSON canonico, ID risorsa preallocato e risposta redatta: non persiste il
payload né credenziali. Un record `pending` viene ritentato con lo stesso ID dopo un
crash. Le password iniziali hanno almeno 14 caratteri, vengono hashate Argon2id, non
entrano nel risultato idempotente e forzano il cambio al primo login. I completati
scadono dopo 24 ore; i pending sono soltanto segnalati. Ogni identità ha quota predefinita
di 1000 record e lo store preserva almeno 256 MiB liberi, entrambi configurabili.

Il sottogate successivo espone `POST /service-accounts` e
`POST /service-accounts/{id}/actions/{rotate|revoke}`, sempre superadmin-only. Create e
rotate restituiscono il bearer token soltanto nella prima risposta e persistono nel record
idempotency esclusivamente la proiezione redatta. Un retry completato restituisce
`409 CREDENTIAL_RECOVERY_REQUIRED`: non viene emessa una credenziale aggiuntiva e il
client deve ruotare esplicitamente con una nuova `Idempotency-Key`. Revoke non contiene
segreti ed è normalmente riproducibile. Le azioni richiedono `If-Match`; un marker interno
per mutazione consente di recuperare un crash senza accettare come retry una richiesta
diversa con revisione obsoleta. Rotate richiede `{"expires_at": ...}`, revoke un oggetto
JSON vuoto. Ogni risposta sensibile usa `Cache-Control: no-store`.

Il CRUD rete espone `POST /networks` e `PATCH /networks/{id}` senza invocare helper o
creare job. Create richiede un tenant attivo nello scope, genera internamente chiavi e
nome interfaccia, cifra la privata e restituisce soltanto la proiezione redatta in stato
`stopped`. In modalità `automatic` il body non accetta `listen_port`; in modalità
`manual` la porta è obbligatoria e limitata a `51820–51999`. Allocazione e conflitti
considerano anche gli IPv4 risolti degli hostname. Nome e descrizione sono aggiornabili
anche a rete running; endpoint, porta e lifecycle richiedono `desired_state=stopped`,
altrimenti rispondono `409 RESOURCE_CONFLICT` sul campo `desired_state`. Archive richiede
admin/superadmin, mentre un manager può aggiornare soltanto la propria rete. CIDR e hub
restano immutabili. ADR 0027 registra il confine che impedisce effetti host impliciti.

Il lifecycle client espone `POST /networks/{id}/clients`, `PATCH /clients/{id}` e azioni
`activate|disable|revoke|archive|release-ip`. Create genera la coppia WireGuard, cifra la
privata e riserva un IP automatico o richiesto in stato `pending`; la risposta contiene
soltanto la fingerprint pubblica. PATCH accetta nome e descrizione. Le transizioni che
aggiungono o rimuovono peer attivi richiedono `desired_state=stopped`, quindi non creano
job né effetti host in M3.4. Revoca e archive conservano la reservation; `release-ip` è
esplicita e ammessa solo dopo tali stati. ADR 0028 registra questo confine.

M3.5 estende quel confine: su rete `running`, una transizione che aggiunge o rimuove un
peer attivo aggiorna il client sotto il lock del worker e accoda `network.sync`. Risponde
`202` con `Location`; le transizioni tra stati non attivi e `release-ip` restano `200`.
Il marker interno permette il recovery fra patch ed enqueue senza duplicazioni. ADR 0030
registra il protocollo.

Il primo sottogate M3.5 espone
`POST /networks/{id}/actions/{start|stop|sync|reconcile}` con body JSON vuoto, ETag e
idempotenza. Start/stop aggiornano `desired_state` e un marker interno, poi accodano il
job sotto il lock condiviso con worker e reconciler; un crash fra i due effetti è
recuperabile senza duplicazioni. La risposta `202` non implica successo host. Il job
conserva gli ID del service account e della credenziale, non il token; al consumo il
worker richiede che account, credenziale, scadenza, assegnazioni e stato tenant/rete siano
ancora validi. ADR 0029 registra il protocollo.

La capacità M3.5 conta job `queued` e `running`: default 1000 globali, 25 per identità,
100 per tenant e 10 per rete. Il check precede ogni patch collegata e scan/create sono
serializzati; un job già legato alla medesima richiesta bypassa il nuovo conteggio. A
quota esaurita l'API restituisce `429 QUEUE_CAPACITY_EXCEEDED` e `Retry-After: 30` senza
modificare lo stato canonico. Il client riusa `Idempotency-Key` e applica backoff con
jitter; un job terminale libera subito capacità. ADR 0031 registra la policy.

M3.6 implementa `GET /clients/{id}/configuration` soltanto per service account con
`client.config:read`, scope RBAC e credenziale con durata totale massima di 24 ore. Il
servizio ricarica sotto lock account, puntatore alla credenziale, permessi e assegnazioni,
poi decifra esclusivamente la chiave privata del client e compila un singolo profilo. La
risposta è un attachment `text/plain` con `no-store`, `no-cache` ed expiry immediata,
senza ETag. Permesso/stato/scope negati e risorsa inesistente condividono lo stesso 404;
errori crittografici o di compilazione sono 503 redatti. Non esistono endpoint bulk né
accesso a chiavi private server. ADR 0032 registra il confine.

## Protezioni operative

- TLS obbligatorio tramite Caddy; HTTP viene rifiutato o rediretto senza accettare bearer
  token. HSTS e limiti di body sono coerenti con la UI.
- La route `/api/v1` è inizialmente raggiungibile soltanto dalle reti amministrative
  configurate; mTLS è disponibile come protezione aggiuntiva per integrazioni privilegiate.
- Rate limit separati per identità e IP, con budget più restrittivi per autenticazione,
  export, rotazione e operazioni live; `429` include `Retry-After`.
- Body e query hanno schema chiuso, dimensione massima e rifiuto di campi sconosciuti.
- Nessun secret in query string. Download sensibili usano `Cache-Control: no-store`,
  `Content-Disposition`, MIME esplicito e audit intent/esito.
- Caddy elimina header forwarded forniti dal client e imposta quelli fidati. Accesso
  diretto a Gunicorn resta vietato.
- Errori di autenticazione sono non enumerabili; scope negato e oggetto inesistente non
  rivelano l'esistenza di risorse cross-tenant.
- Una quota limita numero di job queued e operazioni concorrenti per identità/tenant;
  retry e backoff impediscono che l'API diventi un amplificatore verso il helper root.

## Versioning e compatibilità

Il contratto iniziale è `/api/v1` e viene descritto da OpenAPI 3.1 versionato nel
repository. Modifiche additive compatibili possono entrare nella stessa major; rimozioni,
rinomine o cambi semantici richiedono una nuova major. Ogni deprecazione deve indicare
alternativa, data di rimozione e header di sunset, con almeno una release di sovrapposizione.

OpenAPI è validato nel quality gate contro gli endpoint e alimenta esempi `curl` privi di
segreti reali. `GET /api/v1/openapi.json` pubblica senza autenticazione la copia
machine-readable inclusa nel pacchetto: il documento non contiene endpoint interni,
hostname reali o esempi sensibili. La console interattiva resta assente.

Il contratto sorgente è JSON per essere validabile senza dipendenze aggiuntive. M3.1 ne
controlla parsing senza chiavi duplicate, riferimenti locali, JSON Schema delle componenti,
operation ID, autenticazione, errori, paginazione, precondizioni, idempotenza, risposte
asincrone e assenza dei principali campi storage sensibili. M3.7 aggiunge inventario
esatto Flask↔OpenAPI, conformance JSON Schema di risposte runtime ed esempi, identità della
copia packaged e confronto con una baseline strutturale v1 congelata. Modifiche additive
sono ammesse; rimozioni, cambi di sicurezza e input più restrittivi bloccano la CI.

## Piano di test obbligatorio

- contract test request/response contro OpenAPI e test di compatibilità delle fixture;
- matrice RBAC positiva/negativa per ogni endpoint, inclusi IDOR cross-tenant e oggetti
  condivisi tra tenant;
- token assente, malformato, scaduto, ruotato e revocato; nessuna differenza enumerabile;
- idempotenza, `If-Match`, doppio submit, retry dopo timeout e concorrenza multi-processo;
- rate limit per token/IP, quote job, payload oversize, campi extra e fuzzing parser;
- test che assicurano assenza di secret in body ordinari, errori, log, audit e cache;
- E2E via Caddy HTTPS per superadmin/admin/manager/service account e job asincroni;
- test restore/revoca per token compromesso prima di consentire esposizione Internet.

## Gate di implementazione

1. Aggiornare il threat model e approvare OpenAPI iniziale prima del codice endpoint.
2. Implementare identità/token e test negativi prima di qualunque CRUD remoto.
3. Esporre prima letture scoped, poi CRUD file-backed, quindi job live e infine i download
   sensibili con permesso dedicato.
4. Eseguire penetration test, drill di revoca e verifica Caddy prima di dichiarare l'API
   raggiungibile da Internet.
