# Pubblicazione in una repository APT

Questo documento definisce il deploy di un package verificato in una repository APT
esistente gestita da `reprepro`. Il tool riceve come primo argomento la root assoluta
della repository; non crea repository, chiavi o configurazioni e non pubblica verso host
remoti. La root può essere esposta successivamente da un web server, purché `conf/`,
`db/`, `logs/` e `lists/` non siano raggiungibili via HTTP.

## Due domini di fiducia obbligatori

La pubblicazione attraversa due firme indipendenti:

1. la firma SSHSIG offline `SHA256SUMS.sig` autentica bundle, `.deb`, sorgente,
   provenienza, lock, audit e SBOM mediante `release-allowed-signers` e revoche;
2. la firma OpenPGP configurata da `SignWith` autentica l'indice APT `InRelease` ai
   client mediante una keyring pubblica dedicata e un fingerprint completo atteso.

Il primo controllo impedisce di pubblicare un package non approvato dalla release
ceremony. Il secondo impedisce che il client APT accetti indici sostituiti. Uno non
sostituisce l'altro. `scripts/deploy-apt-package.py` fallisce prima di modificare la
repository se il bundle non supera la verifica SSHSIG o se la configurazione non usa
esattamente il fingerprint richiesto.

## Prerequisiti della repository

Installare gli strumenti sul nodo di pubblicazione:

```bash
sudo apt install --yes reprepro gnupg gpgv
```

La root deve già esistere, essere indicata con path assoluto, non attraversare symlink,
appartenere a root o all'utente effettivo e non essere scrivibile da gruppo/altri. Anche
la keyring pubblica deve essere un file regolare non scrivibile da gruppo/altri. Il file
`ROOT/conf/distributions` deve contenere un solo paragrafo per il codename scelto, abilitare
l'architettura del package e impostare il fingerprint completo:

```text
Codename: bookworm
Suite: stable
Architectures: amd64
Components: main
SignWith: 0123456789ABCDEFFEDCBA987654321001234567
Origin: WireGuard System
Label: WireGuard System
Description: WireGuard System packages
```

La chiave privata OpenPGP della repository non è un argomento del tool. `reprepro` la
trova tramite la propria configurazione GnuPG e `gpg-agent`; il wrapper non passa passphrase
su CLI, ambiente, stdin o log. La keyring fornita al wrapper contiene soltanto la chiave
pubblica attesa. Custodia, backup, rotazione e revoca della chiave APT sono responsabilità
dell'operatore della repository e restano separate dalla chiave SSHSIG offline.

## Deploy

Dopo la firma offline del bundle:

```bash
.venv/bin/python scripts/deploy-apt-package.py /srv/apt/wireguard-system \
  --bundle dist/releases/0.1.0-12 \
  --distribution bookworm \
  --release-allowed-signers /etc/wireguard-system/release/allowed_signers \
  --release-revoked-keys /etc/wireguard-system/release/revoked_keys \
  --repository-keyring /usr/share/keyrings/wireguard-system-archive.gpg \
  --repository-fingerprint 0123456789ABCDEFFEDCBA987654321001234567
```

Il comando:

- verifica firma SSHSIG, checksum e provenienza del bundle;
- accetta esattamente un `.deb` denominato internamente `wireguard-system`;
- valida root, permessi, codename, architettura e `SignWith`;
- se la stessa versione è già presente e verificata, termina senza mutazioni;
- altrimenti esegue `reprepro --basedir ROOT --waitforlock 0 includedeb` senza shell;
- verifica con `gpgv` che `InRelease` abbia una sola firma valida del fingerprint atteso;
- collega hash di `InRelease`, indice `Packages`, record del package e file nel `pool/`.

Il collaudo locale reale, separato dalla suite non privilegiata, crea package, chiave e
repository effimeri sotto la directory temporanea e li elimina a fine prova:

```bash
WG_PORTAL_RUN_APT_INTEGRATION=1 \
  .venv/bin/pytest -q tests/test_apt_repository_deployment.py
```

Il 2026-10-08 il round-trip è stato eseguito su WSL Debian 12 con `reprepro 5.3.1`:
creazione di package/repository/chiave effimeri, prima inclusione, verifica completa e
seconda esecuzione idempotente sono riuscite. Nessuna chiave di test è stata conservata.

Errori CLI sono deliberatamente redatti. Se `reprepro` termina con errore o il controllo
post-deploy fallisce, considerare la repository potenzialmente modificata: non cancellare
file manualmente, bloccare la pubblicazione web, conservare le evidenze operative e usare
i comandi di verifica/riesportazione di `reprepro` secondo il runbook dell'archivio.

## Configurazione dei client

Distribuire la chiave pubblica attraverso un canale autenticato e usare sempre una keyring
dedicata, mai il trust store globale. Esempio deb822 equivalente a `signed-by=`:

```text
Types: deb
URIs: https://packages.example.invalid/wireguard-system
Suites: bookworm
Components: main
Signed-By: /usr/share/keyrings/wireguard-system-archive.gpg
```

Non usare `trusted=yes`, `allow-insecure=yes` o downgrade a una repository unsigned. HTTPS
resta richiesto per distribuire in sicurezza configurazione iniziale e chiave pubblica,
anche se gli indici APT sono firmati.

## Limiti correnti

- Il tool gestisce una repository locale `reprepro`; upload/rsync verso mirror è fuori
  scope e deve avvenire solo dopo il successo del controllo locale.
- La cerimonia reale SSHSIG e il provisioning della chiave OpenPGP APT non sono eseguiti
  automaticamente.
- `reprepro` non conserva più versioni dello stesso package nello stesso indice; rollback
  e upgrade supportati devono seguire il gate upgrade M4.4.
