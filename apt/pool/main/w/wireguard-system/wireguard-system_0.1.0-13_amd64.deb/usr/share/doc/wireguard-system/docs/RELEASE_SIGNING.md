# Firma e verifica delle release

## Contratto

La firma di release usa il formato SSHSIG di OpenSSH con chiave Ed25519 privata offline.
Il namespace e il principal sono entrambi `release@wireguard-system`. `SHA256SUMS.sig`
firma `SHA256SUMS`, che a sua volta copre esattamente ogni artefatto del bundle esclusi i
due file di firma. La verifica non si limita al risultato crittografico: ricalcola tutti
gli hash e riesegue il verificatore della provenienza.

OpenSSH richiede un namespace durante firma e verifica per separare domini d'uso e usa un
file `allowed_signers` per legare principal e chiave. Il formato e le opzioni sono
documentati nel [manuale ufficiale di ssh-keygen](https://man.openbsd.org/ssh-keygen.1).

## Cerimonia iniziale offline

Usare una postazione affidabile scollegata dalla rete e un supporto cifrato dedicato. Non
eseguire questi comandi sul server WireGuard o sulla workstation di build.

```bash
umask 077
ssh-keygen -t ed25519 -a 100 \
  -C 'WireGuard System offline release key' \
  -f wireguard-system-release-ed25519
ssh-keygen -lf wireguard-system-release-ed25519.pub -E sha256
```

Impostare una passphrase lunga e non riutilizzata; non usare `-N ''`. Conservare almeno
due backup cifrati e fisicamente separati della chiave privata e della passphrase. Copiare
fuori dalla postazione soltanto `.pub` e il fingerprint SHA-256. Verificare il fingerprint
attraverso due canali indipendenti prima di creare `release/allowed_signers`:

```text
release@wireguard-system namespaces="release@wireguard-system" ssh-ed25519 AAAA...
```

Creare anche `release/revoked_keys`, inizialmente vuoto o contenente soli commenti. Entrambi
i file sono materiale di trust pubblico e devono essere revisionati e distribuiti insieme
al verificatore. Nessuna chiave reale è inclusa finché questa cerimonia non è completata.

## Firma di un candidate

La pipeline connessa prepara il manifest senza firma:

```bash
.venv/bin/python scripts/release-signing.py prepare dist/releases/0.1.0-12
```

Il comando rifiuta materiale preesistente. Trasferire l'intero bundle sulla postazione
offline, non soltanto `SHA256SUMS`, quindi eseguire offline:

```bash
cd 0.1.0-12
sha256sum --check SHA256SUMS
ssh-keygen -Y sign \
  -f /media/offline/wireguard-system-release-ed25519 \
  -n release@wireguard-system SHA256SUMS
```

Riportare sulla workstation connessa soltanto `SHA256SUMS.sig`. Non usare agent forwarding
e non copiare la chiave privata per automatizzare questo passaggio.

## Verifica e pubblicazione

```bash
.venv/bin/python scripts/release-signing.py verify dist/releases/0.1.0-12 \
  --allowed-signers release/allowed_signers \
  --revoked-keys release/revoked_keys
```

Un exit code diverso da zero blocca la pubblicazione. Pubblicare atomicamente bundle
completo, `SHA256SUMS`, firma, `allowed_signers`, `revoked_keys` e fingerprint annunciato.
Il consumatore deve ottenere almeno fingerprint o policy da un canale indipendente: una
chiave pubblica scaricata dallo stesso mirror del package non costituisce da sola una root
of trust.

La firma autentica il contenuto ma non impedisce a un mirror di servire una release vecchia
correttamente firmata. Il consumatore deve anche verificare che la versione sia quella
attesa tramite un canale di aggiornamento autenticato; questo vincolo sarà integrato nel
task upgrade path.

## Rotazione e revoca

Per una rotazione pianificata, generare offline una nuova chiave, verificare il fingerprint
su due canali e aggiungerla ad `allowed_signers` prima del primo utilizzo. Pubblicare un
avviso di transizione firmato dalla vecchia chiave e mantenere entrambe le chiavi soltanto
per la finestra dichiarata; le nuove release usano esclusivamente la nuova.

In caso di compromissione presunta:

1. interrompere immediatamente release e pubblicazione;
2. aggiungere la chiave pubblica compromessa a `revoked_keys`, senza cancellare la storia;
3. pubblicare policy e avviso di revoca attraverso canali indipendenti;
4. generare offline una nuova chiave e incrementare la versione del candidate;
5. ripetere build, audit, firma e verifica; non rifirmare silenziosamente gli stessi file.

La revoca aggiornata invalida anche firme storiche della chiave compromessa. Una copia
vecchia di `revoked_keys` può ancora accettarle: data e autenticità della policy pubblicata
sono quindi parte della verifica operativa.
