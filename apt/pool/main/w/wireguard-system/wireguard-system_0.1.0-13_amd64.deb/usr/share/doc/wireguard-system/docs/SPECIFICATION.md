# Specifica funzionale

Versione: 0.1 (baseline)  
Stato: baseline approvata; M4.2 e M4.3 completate, M4.4 in corso

## 1. Scopo e confini

Il sistema amministra N tenant; ogni tenant possiede N reti WireGuard indipendenti; ogni
rete usa una topologia hub-and-spoke. La macchina Linux che ospita UI e control plane è
anche il peer hub. I client comunicano tra loro passando dall'hub. Non è previsto NAT,
default route o inoltro verso Internet.

Nel perimetro: utenti e autorizzazioni, tenant, reti, peer client, assegnazione IP stabile,
generazione configurazioni, lifecycle delle interfacce, dashboard e audit. Fuori
perimetro per la prima release: cluster/HA, database SQL, gestione DNS, client agent,
site-to-site, full mesh, billing e provisioning della macchina.

## 2. Attori e autorizzazioni

Il controllo è deny-by-default e verificato nel backend su ogni richiesta.

| Operazione | superadmin | admin tenant | manager rete |
|---|---:|---:|---:|
| Gestire tenant | sì | no | no |
| Gestire utenti globali | sì | no | no |
| Gestire utenti del tenant | sì | sì, salvo superadmin | no |
| Gestire tutte le reti del tenant | sì | sì | no |
| Gestire rete assegnata e client | sì | sì | sì |
| Leggere/esportare chiavi private client | regolato da policy | regolato da policy | regolato da policy |
| Modificare ruoli propri | no | no | no |

Un utente può avere più assegnazioni, anche in tenant differenti. Il ruolo è una
relazione: `admin + tenant_id` oppure `manager + tenant_id + network_id`. Il contesto
tenant/rete deve essere esplicito e verificato per ogni operazione. Le assegnazioni
incompatibili o riferite a oggetti inesistenti sono rifiutate. L'ultimo superadmin attivo
non può essere eliminato o disabilitato.

La visibilità di un utente multi-tenant richiede almeno un tenant amministrato in comune.
Un admin può cambiare esclusivamente le assegnazioni nei tenant che amministra, senza
rimuovere o alterare quelle esterne. I campi globali dell'account e la disabilitazione
sono modificabili da un admin solo quando tutte le assegnazioni dell'utente ricadono nei
suoi tenant; altrimenti l'operazione avrebbe effetti cross-tenant ed è negata. Solo un
superadmin può assegnare o modificare il ruolo superadmin.

## 3. Lifecycle

- Tenant: `active`, `suspended`, `archived`. La sospensione ferma le reti; l'archiviazione
  è reversibile e vieta modifiche operative. La cancellazione fisica è un'azione separata,
  superadmin-only, con verifica che non esistano reti.
- Rete: il documento canonico separa lifecycle (`active`, `archived`) e stato desiderato
  (`running`, `stopped`). Gli stati effettivi `starting`, `running`, `stopping`, `stopped`
  ed `error` sono runtime e ricostruibili. Modifiche a subnet/porta/interfaccia che
  invalidano configurazioni richiedono piano esplicito.
- Client: `pending`, `active`, `disabled`, `revoked`, `archived`. `disabled` conserva
  identità/IP/chiavi e può essere riattivato; `revoked` invalida le chiavi e non è
  riattivabile senza nuova coppia; `archived` nasconde il record ma preserva audit e IP.
  La cancellazione fisica non è offerta normalmente.

La revoca è preferibile alla cancellazione. Un IP rimane riservato finché il client è
presente; un IP revocato/archiviato può essere riutilizzato solo con azione esplicita e
tracciata. Il rilascio imposta `address_reservation=released`; non è consentito per client
pending, attivi o disabilitati. Revoca e archiviazione non rilasciano automaticamente
l'indirizzo.

## 4. Reti e indirizzamento

In creazione sono obbligatori: nome, tenant, CIDR IPv4 privato RFC1918 con prefisso da
`/16` a `/30`, indirizzo hub, nome interfaccia ed endpoint pubblico. IPv6 è fuori scope
per la versione 1. La porta UDP viene assegnata automaticamente per default nel range
`51820–51999`; l'utente può indicarne una manualmente, sempre nello stesso range. Il
sistema valida:

- CIDR canonico e dimensione compatibile con almeno hub + un client;
- nessuna sovrapposizione tra reti dello stesso tenant;
- sovrapposizione tra tenant differenti solo quando l'engine garantisce isolamento L3
  reale tramite namespace di rete o VRF separati; in assenza di tale capacità la
  validazione rifiuta l'overlap. La v1 usa la capability versionata
  `per-network-vrf-v1`, attestata dal helper privilegiato; un valore configurato o
  dichiarato soltanto dal chiamante non è sufficiente;
- indirizzi network/broadcast e hub mai assegnati ai client;
- unicità globale del nome interfaccia e assenza di collisioni `endpoint/IP + porta`;
- `AllowedIPs` client lato server limitato agli IP host (`/32`, `/128`);
- configurazione client con route delle sole subnet VPN, mai `0.0.0.0/0` o `::/0`.

Per i client l'indirizzo è assegnato automaticamente scegliendo il primo host disponibile,
oppure manualmente su richiesta. In entrambi i casi sono esclusi hub, network, broadcast
e indirizzi ancora riservati, inclusi quelli di client revocati o archiviati.

Per consentire client-to-client, sull'hub viene abilitato IP forwarding in modo
controllato e vengono create regole firewall per la sola interfaccia/rete VPN. La policy
di default nega forwarding verso interfacce non autorizzate e tra reti/tenant diversi.

## 5. Operazioni live

Ogni mutazione con effetti sull’host crea un job con ID, stato e log redatto. La UI mostra
un dialogo non ambiguo (`queued/running/succeeded/failed`) e interroga un endpoint di
stato. La transazione applicativa è:

1. autorizzare e validare la richiesta;
2. acquisire lock della risorsa;
3. scrivere stato desiderato in modo atomico;
4. compilare e validare la configurazione candidata;
5. applicarla con API tipizzate verso il helper privilegiato;
6. verificare stato reale; in errore ripristinare l'ultima configurazione nota valida;
7. registrare audit e risultato del job.

Il reconcile automatico usa job persistenti attribuiti a un attore interno non
interattivo, autorizzato esclusivamente a convergere lo stato già dichiarato nei documenti
canonici. Worker e recovery sono mutuamente esclusivi tra processi. Dopo la perdita di
un'interfaccia, il helper può ricrearla soltanto se tenant, rete e nome coincidono con il
registry privilegiato; non adotta mai interfacce estranee.

Mai costruire comandi shell concatenando input. Usare `subprocess` con argv fissi, timeout,
ambiente minimo e allowlist di interfacce/file. Gli aggiornamenti peer live usano dove
possibile `wg syncconf`; start/stop passa esclusivamente dalle operazioni tipizzate del
helper privilegiato.

Le azioni client che aggiungono o rimuovono un peer attivo aggiornano lo stato canonico e
accodano un job `network.sync` quando la rete è running. La risposta `202` indica solo
accettazione persistente; le transizioni senza effetto sui peer restituiscono subito il
client aggiornato. Il processo HTTP non applica configurazioni host.

Per utenti interattivi il job conserva l’ID utente, non una credenziale sintetica. Per
service account conserva account e credenziale. In entrambi i casi il worker ricalcola
l’autorità corrente al consumo. La pagina stato espone soltanto metadati allowlistati e
applica lo stesso scope RBAC della risorsa rete.

La coda limita i job non terminali globalmente e per identità, tenant e rete. Se manca
capacità, l'azione non modifica lo stato canonico e restituisce `429` con un intervallo di
retry; il chiamante conserva la stessa chiave idempotente e applica backoff con jitter.

## 6. Download configurazione client

Il file contiene chiave privata client, indirizzi, chiave pubblica server, endpoint,
AllowedIPs delle subnet VPN e keepalive configurabile. Le chiavi private vengono
conservate cifrate e il file può essere scaricato nuovamente dagli utenti autorizzati.
Ogni download UI richiede la password corrente, RBAC ricalcolato sul documento utente
ricaricato, rate limit, CSRF, header `no-store` e audit; profilo e password non vengono
mai inclusi in pagine, log o file temporanei. Resta disponibile la rotazione della
chiave. M2.2 sostituisce atomicamente la coppia nello stato desiderato; l'effettiva
invalidazione live della configurazione precedente richiede l'apply/reconcile di M2.5 e
la UI dovrà attendere l'esito del relativo job prima di dichiarare successo.

## 7. UI e dashboard

Login obbligatorio; cambio password forzato per il bootstrap. Le password sono Argon2id,
le nuove password richiedono almeno 14 caratteri, la sessione scade dopo 30 minuti e
ogni POST usa CSRF. Il login è limitato per IP+username e globalmente per IP usando stato
file-backed condiviso tra worker. Le viste rispettano lo scope del ruolo. Le dashboard
mostrano conteggi e stato desiderato/reale di tenant, reti e client; auto-refresh via
polling con backoff e pausa quando la pagina non è visibile.
Ogni client mostra, nel rispetto dello scope RBAC:

- nome e IP VPN assegnato permanentemente;
- stato amministrativo (`pending`, `active`, `disabled`, `revoked`, `archived`);
- stato di presenza stimato (`never_seen`, `online`, `stale`, `offline`, `unknown`);
- endpoint pubblico osservato da WireGuard come IP e porta, se disponibile;
- data/ora e tempo trascorso dall'ultimo handshake riuscito;
- byte ricevuti e trasmessi, con timestamp del campionamento;
- “online dal” stimato dal primo campionamento della finestra continua corrente.

WireGuard non mantiene una sessione connessa tradizionale. `online` significa quindi
handshake recente entro una soglia globale configurabile, predefinita a 180 secondi, non
una connessione garantita in quel momento. Le configurazioni client impostano
`PersistentKeepalive = 25` secondi. Anche “online dal” è una stima prodotta dal monitor e
deve essere etichettata come tale: non può precedere il primo campionamento osservato e
può essere azzerata da un periodo senza handshake.

La v1 classifica `stale` un handshake più vecchio della soglia ma non oltre il doppio e
`offline` un handshake ancora più vecchio, oppure una rete desiderata stopped la cui
assenza è confermata da un probe sano. Peer attesi mancanti da una rete running, drift,
campioni vecchi o dati ambigui producono sempre `unknown`.

Il monitor legge soltanto l'output macchina di `wg show ... dump`, associa i peer tramite
chiave pubblica senza esporla nella UI, e persiste lo stato di presenza necessario a
ricostruire la finestra corrente dopo un riavvio. Le dashboard usano polling con backoff,
mostrano sempre l'ora dell'ultimo aggiornamento e non interpretano un errore del probe
come peer offline. Ogni form mutante usa CSRF e protezione da doppio submit.

Prima di applicare una rete, l'engine risolve tutti i record IPv4 correnti di ogni
endpoint e vieta la stessa porta su qualunque indirizzo in comune, anche quando hostname
o alias DNS sono differenti. Un errore o una risposta vuota del resolver blocca
l'operazione; la verifica viene ripetuta a ogni applicazione e non è sostituita dal
controllo testuale eseguito alla creazione.

Il reconciler periodico confronta il desired state con il probe privilegiato di
interfacce, indirizzi, porta, fwmark e peer. Crea job soltanto per reti divergenti; un probe
non affidabile blocca il ciclo senza assumere stato stopped. Dopo errori usa backoff
esponenziale limitato, mentre dopo un ciclo sano torna all'intervallo ordinario.

## 8. API pubblica di automazione

Il sistema espone un'API HTTPS versionata per amministrare da remoto tenant, utenti e
assegnazioni, reti, client, job e telemetria. L'API è un adattatore dello stesso service
layer usato dalla UI: non accede direttamente al repository, al helper privilegiato o al
sistema operativo e applica le medesime policy RBAC e di audit. Il contratto completo è
definito in `docs/API.md`.

La prima versione usa il prefisso `/api/v1`, payload JSON con schemi chiusi ed errori
`application/problem+json`. Le collezioni sono paginate; le mutazioni supportano
concorrenza ottimistica tramite `ETag`/`If-Match` e idempotenza tramite
`Idempotency-Key`. Le operazioni che cambiano lo stato live restituiscono `202 Accepted`
con una risorsa job interrogabile, senza attendere nel processo HTTP.

L'API deve inoltre fornire:

- un contratto OpenAPI 3.1 versionato e verificato automaticamente;
- autenticazione macchina-macchina separata dalle sessioni browser, scadenza, rotazione
  e revoca delle credenziali tramite service account e bearer token con scadenza massima
  di 90 giorni, secondo la decisione registrata in `docs/USER_DECISIONS.md`;
- rate limit per credenziale e IP, quote sui job, limiti sui body e request ID;
- autorizzazione sullo scope canonico di ogni oggetto per impedire IDOR cross-tenant;
- rivalidazione di identità, scope e stato della credenziale quando un worker consuma un
  job accodato;
- nessun segreto in URL, log, audit o risposte di errore; CORS disabilitato per default;
- download delle configurazioni client protetto da `client.config:read` negato per
  default, credenziale a vita breve, audit e `Cache-Control: no-store`.

L'API è inizialmente accessibile soltanto da reti amministrative configurabili tramite
Caddy, con mTLS opzionale. La v1 non offre cancellazioni fisiche: espone soltanto lifecycle,
disabilitazione, revoca e archiviazione. Nessun endpoint viene aperto a Internet prima del
threat review, del penetration test, del drill di revoca e dei test negativi di
autorizzazione.

## 9. Requisiti non funzionali e criteri di accettazione

- Linux Debian con systemd; Python >= 3.11; WireGuard preinstallato e verificato dal
  comando `doctor`; Caddy è il reverse proxy ufficialmente supportato. La versione 1 è
  distribuita ufficialmente come pacchetto Debian; i container sono fuori scope.
- Nessun DB: JSON versionato, scrittura atomica, lock inter-processo, permessi 0700/0600,
  backup coerente e recovery testato.
- UI e API solo HTTPS dietro Caddy in produzione; cookie Secure/HttpOnly/SameSite;
  timeout sessione, rate limit login e password Argon2id.
- Nessun segreto nel repository, URL, log o audit. Private key cifrate at-rest prima di
  una release di produzione; la master key non vive nel data tree copiabile.
- Audit JSONL ruotato giornalmente e concatenato con HMAC, mantenuto nello storage
  operativo per 30 giorni ed eliminato definitivamente al compimento di 3 mesi. Export e
  backup includono stream di integrità e manifest nel formato nativo compresso e
  rispettano la stessa scadenza salvo obblighi esterni esplicitamente documentati.
- Operazioni idempotenti; crash non deve lasciare JSON parziale o configurazione attiva
  non riconciliabile.
- Test unitari per validatori/RBAC/storage/compiler; integration test in network namespace;
  test E2E autorizzativi; quality gate documentato.
- Accessibilità WCAG 2.2 AA come obiettivo e UI responsive.

Riferimenti tecnici per la telemetria: il protocollo userspace ufficiale espone endpoint,
`rx_bytes`, `tx_bytes` e timestamp dell'ultimo handshake; il protocollo WireGuard rinnova
le chiavi in base a traffico e timer e non offre un evento nativo “sessione connessa”.
Vedere `https://www.wireguard.com/xplatform/` e
`https://www.wireguard.com/protocol/`.

## 10. Decisioni da confermare

Le decisioni che richiedono una risposta dell'utente, il loro stato e l'esito sono
registrati esclusivamente in `docs/USER_DECISIONS.md`. Le decisioni necessarie a una
milestone devono essere chiuse prima di iniziare i task che ne dipendono.
