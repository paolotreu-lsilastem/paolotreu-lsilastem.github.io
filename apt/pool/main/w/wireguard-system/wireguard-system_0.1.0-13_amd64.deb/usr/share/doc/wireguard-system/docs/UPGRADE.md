# Contratto di upgrade

Questo documento definisce il percorso supportato per aggiornare il package Debian senza
interpretare la semplice accettazione di `dpkg` come prova di compatibilità applicativa.
La policy iniziale accetta soltanto il predecessore immediato dichiarato dal candidate.

## Matrice corrente

| Stato iniziale | Candidate | Schema dati | Esito |
|---|---|---:|---|
| nessuna installazione o solo `config-files` | `0.1.0-12` | nessuno/1 | installazione pulita collaudata in R03 |
| qualsiasi package installato | `0.1.0-12` | qualsiasi | negato: il candidate non dichiara predecessor |
| `0.1.0-12` | `0.1.0-13` | 1 | predecessor dichiarato; non supportato operativamente fino ai drill R07–R11 |
| qualsiasi altra versione | `0.1.0-13` | qualsiasi | negato: predecessor non esatto |

`0.1.0-12` è intenzionalmente un predecessor **clean-install-only**. Non esiste un arco
supportato verso questa revisione: `0.1.0-9` è storico e non incorpora il recovery
completo corrente. Il primo arco dichiarato è **0.1.0-12 → 0.1.0-13**, ma diventerà
supportato soltanto dopo i drill previsti dalla roadmap. Ogni candidate
successivo deve aggiornare intenzionalmente `packaging/debian/upgrade-from` e mantenere
un test del singolo arco. La compatibilità non si deduce mai dalla sola uguaglianza dello
schema.

## Metadati e preflight artefatto

Il package contiene tre campi control privati:

```text
X-WireGuard-System-Data-Schema: 1
X-WireGuard-System-Upgrade-From: 0.1.0-12
X-WireGuard-System-Recovery-Protocol: 1
```

`packaging/debian/data-schema-version` deve coincidere con
`CURRENT_DATA_SCHEMA_VERSION`; `packaging/debian/upgrade-from` contiene un solo
predecessore oppure il valore riservato `none`, non un minimo semantico. Con `none` il
preflight rifiuta sempre un upgrade in ingresso, mentre il maintainer script consente
ancora l'installazione pulita. L'esempio operativo seguente descrive l'arco dichiarato
`0.1.0-12 → 0.1.0-13` e non va eseguito finché i relativi gate della roadmap non sono
chiusi. Dopo avere scaricato e verificato il bundle firmato, eseguire sul target:

```bash
sudo /usr/lib/wireguard-system/upgrade-preflight \
  /percorso/wireguard-system_0.1.0-13_amd64.deb
```

Dal checkout equivalente:

```bash
sudo .venv/bin/python scripts/upgrade-preflight.py \
  /percorso/wireguard-system_0.1.0-13_amd64.deb \
  --data-dir /var/lib/wg-portal
```

Il comando legge il control con `dpkg-deb`, lo stato installato con `dpkg-query` e solo
`meta.json` dal data tree. Rifiuta package/link/permessi insicuri, package diverso,
predecessore non esatto, architettura diversa, schema live incompatibile e artefatti privi
del recovery protocol v1. Non esegue shell e redige gli errori. La modalità read-only non
autorizza l'installazione; soltanto la verifica firmata con arming esplicito descritta
sotto può creare il marker del package.

## Ricevuta firmata del recovery set

Dopo `backup-create`, mantenendo candidate e coppia cifrata immutati, preparare sul target
una richiesta con validità predefinita di due ore (massimo quattro):

```bash
sudo /usr/lib/wireguard-system/upgrade-preflight \
  /percorso/wireguard-system_0.1.0-13_amd64.deb \
  --prepare-authorization /root/upgrade-authorization.json \
  --rollback-package /percorso/wireguard-system_0.1.0-12_amd64.deb \
  --data-bundle /root/recovery/data.tar.gz.age \
  --secrets-bundle /root/recovery/secrets.tar.gz.age \
  --backup-set-id 12345678-1234-5678-9234-567812345678
```

Il JSON canonico v2 `0600` include hash SHA-256 di candidate, package predecessor di
rollback e due bundle, oltre a versione/arco/schema, UUID, scadenza e un hash
contestualizzato di `/etc/machine-id`; non include machine-id in chiaro, chiavi o
contenuti del backup. Il rollback deve essere il `.deb` esatto della versione installata,
ottenuto da un bundle release già verificato. Il file esistente non viene sovrascritto.

Trasferire request, candidate, predecessor e bundle sulla postazione offline. Verificare
anche il bundle release del predecessor; con la identity `age` eseguire entrambi i
controlli, verificando che l'UUID stampato coincida con quello nel JSON:

```bash
wg-portal backup-verify \
  --data-bundle data.tar.gz.age \
  --secrets-bundle secrets.tar.gz.age \
  --identity /media/offline/recovery-identity.txt

wg-portal restore-preflight \
  --data-bundle data.tar.gz.age \
  --secrets-bundle secrets.tar.gz.age \
  --identity /media/offline/recovery-identity.txt \
  --target-data-dir /var/lib/wg-portal
```

Solo dopo esito positivo firmare la request con una chiave Ed25519 operativa distinta
dalla chiave release e dalla identity `age`:

```bash
ssh-keygen -Y sign \
  -f /media/offline/wireguard-system-upgrade-operator-ed25519 \
  -n upgrade@wireguard-system upgrade-authorization.json
```

La policy pubblica usa identità e namespace fissi:

```text
upgrade-operator@wireguard-system namespaces="upgrade@wireguard-system" ssh-ed25519 AAAA...
```

Riportare sul target soltanto JSON e firma, poi verificare nuovamente stato e bytes:

Prima dell'arming, fermare ogni rete dalla UI o API e attendere il completamento dei job.
Non rimuovere interfacce manualmente: il reconciler deve portare a `stopped` sia lo stato
desiderato canonico sia il registry privilegiato e le risorse host. La dashboard non deve
più mostrare operazioni pendenti.

```bash
sudo /usr/lib/wireguard-system/upgrade-preflight \
  /percorso/wireguard-system_0.1.0-13_amd64.deb \
  --verify-authorization /root/upgrade-authorization.json \
  --authorization-signature /root/upgrade-authorization.json.sig \
  --authorization-allowed-signers /etc/wireguard-system/upgrade/allowed_signers \
  --authorization-revoked-keys /etc/wireguard-system/upgrade/revoked_keys \
  --rollback-package /percorso/wireguard-system_0.1.0-12_amd64.deb \
  --data-bundle /root/recovery/data.tar.gz.age \
  --secrets-bundle /root/recovery/secrets.tar.gz.age \
  --arm-upgrade
```

Il verifier rifiuta firma o namespace errati, chiavi revocate, request non canonica,
scadenza, clock futuro oltre cinque minuti, altro host, stato dpkg mutato e ogni variazione
di candidate, predecessor o bundle. Non riceve mai le chiavi private. `--arm-upgrade`
richiede root e, prima di scrivere, impone inoltre tutti questi gate read-only:

- data tree e metadati privati, regolari e senza link;
- nessun restore journal e nessun job `queued` o `running`;
- ultimo ciclo reconciler riuscito, senza failure/probe error e recente al massimo dieci
  minuti;
- ogni documento rete con `desired_state=stopped` e registry privilegiato v2 root-only
  vuoto, così una rete solo dichiarata ferma ma ancora presente sull'host viene negata;
- spazio libero per una copia allocata del data tree più 1 GiB di riserva e, sul
  filesystem di `/usr`, quattro volte il candidate più 512 MiB. Se i due path condividono
  il filesystem, i requisiti vengono sommati.

Solo dopo questi controlli crea `armed.json` canonico `0600` in
`/var/lib/wireguard-system-upgrade`, directory `root:root` `0700` separata dai dati del
servizio. Conserva inoltre la request firmata già verificata, byte per byte in forma
canonica, come `verified-authorization/<hash-ricevuta>.json`: directory `0700`, file
root-only `0600`, regolare e single-link, con nome e contenuto verificati contro lo stesso
SHA-256 del marker. La copia non contiene chiavi private, resta come storia della
transazione e viene riutilizzata in modo idempotente se l'arming viene ritentato. Non
modificarla o rimuoverla durante un recovery.

Questa persistenza rende disponibile anche il digest firmato del `.deb` candidate senza
cambiare il marker v2 né il recovery protocol v1 compreso dal predecessor. La
reinstallazione candidate non è ancora disponibile: un executor successivo dovrà
richiedere questa copia e ricontrollare l'artefatto esatto prima di invocare dpkg.

Durante l'arming ferma socket web, servizio web, reconciler, timer/check health, socket
helper e istanze helper; ricontrolla quindi tutti i gate con i writer fermi. Se lo stop o
il secondo controllo falliscono, riavvia soltanto le unità che risultavano attive prima
del tentativo. Una verifica senza `--arm-upgrade` resta deliberatamente read-only.

Il `preinst` incorporato nel nuovo package consente le installazioni pulite, ma per un
upgrade esige il marker. Prima dell'unpack ricontrolla predecessor esatto, versione e
architettura del candidate, schema dichiarato e schema live, permessi, forma canonica e
scadenza; nega inoltre l'unpack se un writer o un'istanza helper è tornato attivo. Poi
consuma il marker atomicamente spostandolo, tramite hard link esclusivo e unlink, sotto
`consumed/<hash-ricevuta>.json`. La ricevuta è quindi monouso: un retry dopo qualsiasi
tentativo richiede una nuova request verificata e firmata. Symlink, permessi rilassati,
marker già consumato o stato divergente fanno fallire `dpkg` prima dell'estrazione. I
record consumati non vengono rimossi automaticamente perché impediscono il replay; non
contengono segreti o path dei bundle.

Dopo un unpack riuscito, il `postinst` invoca
`/usr/lib/wireguard-system/upgrade-finalize`: seleziona l'unico marker consumato ma non
ancora finalizzato per la coppia predecessor/candidate incorporata, riavvia esattamente
le unità registrate in `active_units` secondo un ordine fisso e ne verifica lo stato; per
la health oneshot verifica invece che lo start termini con successo, perché per contratto
torna `inactive` dopo l'esecuzione. Solo allora crea la ricevuta canonica root-only `0600`
`finalized/<hash-ricevuta>.json`. Un errore lascia l'operazione pendente e ritentabile;
una finalizzazione già riuscita è un no-op idempotente. L'installazione pulita conserva
invece il bootstrap delle unità standard; le invocazioni `abort-*` del `postinst` non
avviano servizi e lasciano il recupero esplicito all'operatore.

Arming, consumo `preinst` e finalizzazione acquisiscono tutti lo stesso lock advisory
root-only `/var/lib/wireguard-system-upgrade/.transaction.lock` `0600`. Il lock resta sul
filesystem come inode stabile, viene rilasciato automaticamente anche alla morte del
processo e impedisce che due fasi mutino contemporaneamente marker e ricevute. Link,
ownership o permessi anomali sul lock fanno fallire l'operazione senza proseguire.

Il marker è un'attestazione locale root-only del verifier: il `preinst` non ricalcola
l'hash del file `.deb`, che non è portabile ottenere dal maintainer script. Autenticità e
bytes del package restano coperti dalla verifica del bundle release/APT; l'arming deve
usare il tool dello stesso source bundle verificato del candidate. Root rimane il confine
di fiducia della macchina.

## Annullamento prima del consumo

Se la finestra viene annullata dopo l'arming ma prima di avviare `dpkg`, non cancellare
mai `armed.json` manualmente. Eseguire invece:

```bash
sudo /usr/lib/wireguard-system/upgrade-preflight \
  --cancel-armed-upgrade \
  --data-dir /var/lib/wg-portal
```

Il comando acquisisce il lock transazionale, richiede che dpkg mostri ancora esattamente
il predecessor e che lo schema live coincida con il marker, quindi ritira
l'autorizzazione sotto `cancelled/<hash-ricevuta>.json`. Il tombstone impedisce di armare
nuovamente la stessa autorizzazione. Riavvia in ordine fisso soltanto le unità registrate
in `active_units`, verifica che nessun writer persistente estraneo sia attivo e considera
la health oneshot ripristinata dopo uno start concluso con successo; scrive infine la
ricevuta canonica `cancel-resumed/<hash-ricevuta>.json` `0600`.

L'annullamento resta consentito anche dopo la scadenza della firma: la scadenza impedisce
l'uso per installare, non il recupero dei writer già fermati. Se il riavvio o la scrittura
della ricevuta falliscono, rilanciare lo stesso comando; il claim e il resume sono
ritentabili. Un secondo comando dopo il successo è un no-op verificato. Se `preinst` ha
già creato il record `consumed`, il comando rifiuta di procedere: non eliminare marker o
ricevute e usare il futuro percorso di rollback post-consumo.

## Diagnosi dopo il consumo

Se `preinst` ha già consumato il marker e l'installazione non termina, acquisire prima una
classificazione read-only:

```bash
sudo /usr/lib/wireguard-system/upgrade-preflight \
  --recovery-status \
  --data-dir /var/lib/wg-portal
```

Il comando richiede il lock già esistente, non crea directory o ricevute, non modifica
dpkg e non avvia servizi. Valida marker e ricevute canoniche, interroga stato/versione/
architettura da dpkg, legge lo schema live e restituisce un singolo JSON canonico. Il campo
`claim_state=hardlink_incomplete` identifica anche un crash tra la creazione del claim
`consumed` e la rimozione di `armed.json`.

| `classification` | Significato | `next_action` dichiarativa |
|---|---|---|
| `predecessor_configured_after_consumption` | il predecessor è ancora configurato e lo schema coincide | `resume_verified_predecessor` |
| `candidate_configured_resume_pending` | il candidate risulta configurato ma manca la finalizzazione | `retry_candidate_finalization` |
| `candidate_configuration_incomplete` | candidate `unpacked` o `half-configured` | `repair_candidate_configuration` |
| `candidate_installation_incomplete` | candidate `half-installed`, `config-files` o stato equivalente | `reinstall_or_rollback_candidate` |
| `candidate_trigger_processing_incomplete` | candidate in `triggers-pending` | `repair_candidate_triggers` |
| `candidate_external_trigger_awaited` | candidate attende il trigger di un altro package | `repair_candidate_awaited_triggers` |
| `candidate_trigger_repair_incomplete` | repair trigger già autorizzato ma ancora pending | `retry_candidate_trigger_repair` |
| `candidate_triggers_processed_resume_pending` | trigger completati ma manca la receipt finale | `retry_candidate_trigger_repair` |
| `candidate_awaited_trigger_repair_incomplete` | chiusura trigger esterna autorizzata non completata | `retry_candidate_awaited_trigger_repair` |
| `candidate_awaited_triggers_processed_resume_pending` | trigger esterni completati, manca la receipt finale | `retry_candidate_awaited_trigger_repair` |
| `rollback_restore_incomplete` | predecessor installato, restore autorizzato non completato | `retry_rollback_with_restore` |
| `rollback_restored_resume_pending` | recovery set ripristinato, writer ancora congelati | `retry_rollback_with_restore` |
| `rollback_restore_predecessor_incomplete` | restore autorizzato ma predecessor non più configurato | `retry_rollback_with_restore` |
| `predecessor_configuration_incomplete` | predecessor `unpacked` o `half-configured` | `repair_predecessor_configuration` |
| `predecessor_installation_incomplete` | predecessor `half-installed`, `config-files` o stato equivalente | `reinstall_or_rollback_predecessor` |
| `predecessor_trigger_processing_incomplete` | predecessor in `triggers-awaited`/`triggers-pending` | `repair_predecessor_triggers` |
| `data_schema_diverged` | lo schema live non coincide col marker | `restore_verified_recovery_set` |
| `package_version_diverged` / `package_architecture_diverged` | package host fuori dall'arco autorizzato | `manual_offline_recovery` |

Le stringhe `next_action` sono classificazioni per il runbook, non comandi autorizzati.
Finché il relativo executor non è implementato e collaudato, non usare `dpkg --force-*`,
non rimuovere hard link o ricevute e non riavviare manualmente il portale.

### Resume del predecessor verificato

Soltanto quando `classification` vale `predecessor_configured_after_consumption`, eseguire:

```bash
sudo /usr/lib/wireguard-system/upgrade-preflight \
  --resume-consumed-predecessor \
  --data-dir /var/lib/wg-portal
```

Il comando acquisisce sia il lock transazionale sia il lock nativo del database dpkg e
ricontrolla sotto lock stato `installed`, versione, architettura e schema. Nega writer
attivi estranei, completa in modo durevole un eventuale unlink rimasto a metà, ripristina
e verifica esattamente `active_units`, quindi scrive
`predecessor-resumed/<hash-ricevuta>.json` canonico `0600`. Un retry dopo un errore di
avvio riparte dal marker consumato; dopo la ricevuta, lo stesso comando è un no-op.

Questo percorso non configura package incompleti, non effettua downgrade e non ripristina
dati. Per tutte le altre classificazioni restano obbligatori gli executor ancora aperti o
il recovery manuale documentato.

### Finalizzazione del candidate configurato

Soltanto quando `classification` vale `candidate_configured_resume_pending`, eseguire:

```bash
sudo /usr/lib/wireguard-system/upgrade-preflight \
  --resume-configured-candidate \
  --data-dir /var/lib/wg-portal
```

Anche questo comando trattiene insieme lock dpkg e lock transazionale e ricontrolla
package `installed`, versione/architettura candidate e schema live prima di mutare stato.
Ripristina il set esatto di writer e pubblica la stessa ricevuta canonica
`finalized/<hash-ricevuta>.json` del `postinst`, quindi retry automatico e manuale sono
interoperabili e idempotenti.

Non usare questo percorso per stati incompleti. `unpacked` e `half-configured` richiedono
un repair di configurazione esplicito; `half-installed` richiede reinstallazione o
rollback con artefatto attestato; `triggers-pending` usa l'executor dedicato seguente.

### Repair della configurazione candidate

Soltanto quando `classification` vale `candidate_configuration_incomplete`, eseguire:

```bash
sudo /usr/lib/wireguard-system/upgrade-preflight \
  --repair-candidate-configuration \
  --data-dir /var/lib/wg-portal
```

Il comando accetta esclusivamente candidate `unpacked` o `half-configured` con versione,
architettura e schema esatti. Sotto i lock verifica marker, receipt e writer, normalizza un
eventuale claim hard-link incompleto e pubblica prima
`candidate-repair/<hash-ricevuta>.json` canonico `0600`. Trattiene il lock frontend di
dpkg per escludere APT durante l'intera operazione; rilascia temporaneamente soltanto il
lock backend dpkg e quello transazionale per consentire a
`dpkg --configure wireguard-system` e al relativo `postinst` di procedere, usando argv e
ambiente fissi e non interattivi.

Dopo dpkg riacquisisce i lock backend e transazionale e richiede stato `installed`. Se il `postinst` ha già
pubblicato `finalized`, la valida; altrimenti completa direttamente il resume esatto dei
writer e la stessa receipt. Un errore lascia l'intenzione e il marker consumato intatti:
rilanciare lo stesso comando. Non usarlo per `half-installed`, stati trigger, predecessor
incompleto o schema divergente.

### Repair dei trigger candidate

Soltanto quando `classification` vale `candidate_trigger_processing_incomplete`,
`candidate_trigger_repair_incomplete` o `candidate_triggers_processed_resume_pending`,
eseguire:

```bash
sudo /usr/lib/wireguard-system/upgrade-preflight \
  --repair-candidate-triggers \
  --data-dir /var/lib/wg-portal
```

Il comando accetta inizialmente soltanto il candidate esatto in `triggers-pending` e
pubblica `candidate-trigger-repair/<hash-ricevuta>.json` canonico `0600`. Mantiene il lock
frontend per escludere APT, cede backend e lock transazionale esclusivamente a
`dpkg --triggers-only wireguard-system`, quindi richiede stato `installed`, architettura e
schema invariati prima di creare `finalized` e ripristinare il set esatto dei writer.
L'argv è confinato al package gestito: non vengono processati package estranei.

Un errore dpkg, un crash dopo il completamento dei trigger o un resume fallito lasciano
l'intenzione invariata e rendono sicuro rilanciare lo stesso comando. Non usare questo
percorso per `triggers-awaited`, che richiede l'executor seguente.

### Repair della chiusura trigger attesa dal candidate

Quando `classification` vale `candidate_external_trigger_awaited`,
`candidate_awaited_trigger_repair_incomplete` oppure
`candidate_awaited_triggers_processed_resume_pending`, eseguire:

```bash
sudo /usr/lib/wireguard-system/upgrade-preflight \
  --repair-candidate-awaited-triggers \
  --data-dir /var/lib/wg-portal
```

Lo stato `triggers-awaited` indica che il candidate dipende dal completamento dei trigger
di altri package. Elaborare soltanto il candidate eluderebbe il rilevamento cicli previsto
da dpkg. L'executor legge quindi l'inventario completo `Triggers-Awaited`/
`Triggers-Pending`, risolve ricorsivamente la chiusura a partire da `wireguard-system` e
richiede che non esista alcun altro package con stato trigger attivo.

Prima della mutazione pubblica
`candidate-awaited-trigger-repair/<hash-ricevuta>.json` canonico `0600`, contenente per
ogni package nome, versione, architettura, stato iniziale, package attesi e trigger
pending. Il lock frontend esclude APT; backend dpkg e lock transazionale vengono ceduti
soltanto durante `dpkg --triggers-only --pending`, che conserva il rilevamento nativo dei
cicli. Nessun `--configure --pending` viene eseguito.

Dopo dpkg l'inventario deve essere privo di trigger attivi e il candidate deve risultare
`installed` con versione, architettura e schema esatti. Solo allora vengono creati
`finalized` e il resume dei writer. Un retry accetta avanzamenti soltanto fra i package
registrati nell'intent e con identità package invariata; un nuovo package pending, una
versione cambiata o una dipendenza ambigua bloccano il percorso e richiedono analisi
offline. L'operatore non deve eseguire altri comandi dpkg durante l'handoff.

### Handshake dei maintainer script per reinstallazione candidate

Il recovery protocol v1 distingue una reinstallazione del candidate dallo stesso numero
di versione usato per reinstallare il predecessor durante un rollback. Il `preinst` del
candidate accetta il primo caso soltanto se trova una singola
`candidate-reinstall-intent/<hash-ricevuta>.json` canonica, root-only `0600`, coerente con
il marker consumato e con `verified-authorization/<hash-ricevuta>.json`. La request
persistita deve legare package, versione, architettura, schema e SHA-256 del candidate;
lo stato iniziale ammesso è esclusivamente `half-installed` e tutti i writer devono
restare quiescenti. Il percorso è selezionato prima del normale consumo anche se dpkg
riporta come versione precedente l'ultimo predecessor configurato anziché il candidate
parzialmente installato.

Il finalizer del `postinst` ricontrolla marker, intenzione e request persistita, rifiuta
una `rollback-intent` concorrente e lascia i writer congelati senza creare `finalized`.
Non creare `candidate-reinstall-intent` a mano e non invocare direttamente dpkg: l'unico
ingresso supportato è l'executor seguente.

### Reinstallazione attestata del candidate

Quando `classification` vale `candidate_installation_incomplete` con candidate
`half-installed`, eseguire usando lo stesso `.deb` legato alla request firmata:

```bash
sudo /usr/lib/wireguard-system/upgrade-preflight \
  --reinstall-candidate /root/release/wireguard-system_0.1.0-13_amd64.deb \
  --data-dir /var/lib/wg-portal
```

Il comando apre e mantiene il descriptor dell'artefatto, verifica metadati e SHA-256
contro `verified-authorization/<hash-ricevuta>.json`, richiede schema live invariato e
writer ancora quiescenti, quindi pubblica
`candidate-reinstall-intent/<hash-ricevuta>.json`. Trattiene il lock frontend per
escludere APT e cede lock backend dpkg e transazionale solo durante
`dpkg --install /proc/self/fd/<n>` con argv e ambiente fissi.

Dopo dpkg ricontrolla descriptor, request, intenzione, package `installed`, architettura e
schema; soltanto allora ripristina `active_units` e crea `finalized`. Se dpkg fallisce dopo
aver avanzato a `unpacked`, `half-configured` o uno stato trigger, oppure completa prima
di un crash dell'executor, rilanciare lo stesso comando e lo stesso `.deb`. Recovery status
restituisce `candidate_reinstall_incomplete` o `candidate_reinstalled_resume_pending` con
azione `retry_candidate_reinstall`. Il retry non riscrive l'intenzione e non ripete dpkg
quando il candidate è già `installed`.

### Handshake dei maintainer script per rollback

I package compatibili col recovery protocol v1 contengono un percorso fail-closed usato
soltanto dall'executor di rollback. Il `preinst` del predecessor accetta
`install`/`upgrade` verso la propria versione solo se trova una singola
`rollback-intent/<hash-ricevuta>.json` canonica `0600`, coerente con marker consumato,
digest del `.deb`, arco, architettura e schema; richiede inoltre che tutti i writer siano
ancora quiescenti e che non esista una ricevuta di completamento.

Il `postinst` verifica nuovamente la stessa intenzione tramite il finalizer e lascia i
writer congelati, senza creare `finalized`. Non creare `rollback-intent` a mano e non
eseguire direttamente `dpkg --force-downgrade`: l'unico ingresso supportato è il comando
seguente.

### Rollback attestato del predecessor

Quando il recovery status indica candidate o predecessor incompleto e lo schema live è
ancora quello autorizzato, eseguire con lo stesso `.deb` usato nella request firmata:

```bash
sudo /usr/lib/wireguard-system/upgrade-preflight \
  --rollback-predecessor \
  --rollback-package /percorso/wireguard-system_0.1.0-12_amd64.deb \
  --data-dir /var/lib/wg-portal
```

L'executor apre e mantiene pinned l'inode del package, ne ricontrolla control e SHA-256,
trattiene il lock frontend per escludere APT e pubblica una sola intenzione canonica
`rollback-intent/<hash-ricevuta>.json`. Rilascia i lock backend e transazionale soltanto
durante l'invocazione non interattiva di dpkg, così `preinst` e `postinst` possono validare
lo stesso handoff senza deadlock. Sono ammessi soltanto candidate o predecessor
`unpacked`, `half-configured`, `half-installed`, `installed`, `triggers-awaited` o
`triggers-pending`, con versione e architettura appartenenti all'arco autorizzato.

Dopo dpkg il comando riacquisisce entrambi i lock, richiede il predecessor esatto in stato
`installed`, schema invariato e writer ancora congelati; soltanto allora ripristina il set
precedente e crea `predecessor-resumed`. Un ritorno non zero, un'interruzione dopo dpkg o
un errore nel resume lasciano l'intenzione valida: rilanciare lo stesso comando con lo
stesso `.deb`. Se il predecessor era già integro senza intenzione, usare invece
`--resume-consumed-predecessor`. Un esito positivo ripetuto è un no-op verificato.

### Rollback con restore del recovery set attestato

Quando occorre ripristinare anche lo stato file precedente, usare il recovery set e la
identity offline già verificati durante la preparazione della stessa autorizzazione:

```bash
sudo /usr/lib/wireguard-system/upgrade-preflight \
  --rollback-with-restore \
  --rollback-package /percorso/wireguard-system_0.1.0-12_amd64.deb \
  --data-bundle /root/recovery/data.tar.gz.age \
  --secrets-bundle /root/recovery/secrets.tar.gz.age \
  --identity /root/recovery/identity.txt \
  --backup-set-id 12345678-1234-5678-9234-567812345678 \
  --data-dir /var/lib/wg-portal
```

Il comando richiede che package, UUID e SHA-256 dei due bundle coincidano con
`verified-authorization/<hash-ricevuta>.json`; tutti e tre gli input recovery devono avere
modo `0600`. Tiene aperti bundle e identity e li passa
al restore tramite descriptor del processo padre, evitando che una sostituzione del path
cambi i byte usati. Prima installa il predecessor senza riavviare i writer, quindi crea
`rollback-restore-intent/<hash-ricevuta>.json` e invoca `wg-portal restore-apply` con
conferma del set e consenso esplicito alla sostituzione. L'output del sottoprocesso non
viene propagato, per non esporre dettagli del recovery.

Solo dopo restore riuscito, digest invariati, predecessor `installed` e schema esatto
viene pubblicata `rollback-restored/<hash-ricevuta>.json`; infine il normale resume crea
`predecessor-resumed` e ripristina esclusivamente `active_units`. Un errore lascia i
writer congelati: rilanciare lo stesso comando con gli stessi artefatti quando recovery
status restituisce `retry_rollback_with_restore`. Se la receipt di restore esiste già, il
retry non ripete il restore e completa soltanto il resume.
`--resume-consumed-predecessor` rifiuta esplicitamente un intent di restore privo della
receipt corrispondente, quindi non può aggirare accidentalmente questo gate.

La identity privata deve essere copiata sul target solo per la finestra di recovery e
rimossa con la procedura operativa prevista dopo il successo; non viene copiata nello
stato upgrade né registrata. Il recovery protocol v1 autorizza soltanto archi con schema
candidate/predecessor uguale: un downgrade tra schemi diversi richiede un futuro protocollo
esplicito e resta fail-closed.

## Gate ancora obbligatori

1. Creare un recovery set cifrato immediatamente prima della finestra di manutenzione,
   trasferirne entrambi i bundle e completarvi `backup-verify` e `restore-preflight` su una
   postazione separata con la identity offline.
2. I writer sono fermati e ricontrollati dall'arming, il `preinst` impedisce che ripartano
   prima dell'unpack e il `postinst` ripristina esattamente il set precedente con ricevuta
   idempotente; l'annullamento pre-consumo è monouso e ritentabile. Resume, repair di
   configurazione e trigger, reinstallazione candidate, rollback e restore attestato sono
   disponibili; il collaudo reale resta obbligatorio prima del rilascio.
3. Collaudare realmente due candidate consecutivi su Debian 12, inclusi fallimento prima
   dell'unpack, fallimento post-unpack, ripristino del package precedente quando lo schema
   resta compatibile, restore del recovery set autorizzato e cleanup delle evidenze.

## Rollback e downgrade

Un downgrade ad hoc con `dpkg -i` non è supportato. Prima di ogni mutazione conservare
package precedente, bundle release, recovery set verificato e inventario degli hash. Se
il nuovo package non ha modificato lo schema, `--rollback-predecessor` può reinstallare
esclusivamente il predecessor attestato e `--rollback-with-restore` può ripristinare anche
il recovery set firmato. Un cambio schema non è autorizzato dal protocollo v1 e richiede
un nuovo arco/protocollo esplicito. Non editare `meta.json`, non copiare singoli JSON e non
invocare direttamente `--force-downgrade`.
