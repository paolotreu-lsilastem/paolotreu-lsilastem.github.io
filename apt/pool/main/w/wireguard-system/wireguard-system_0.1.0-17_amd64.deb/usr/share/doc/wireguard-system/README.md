# WireGuard System

Portale web Flask, multi-utente e multi-tenant, per amministrare più reti private
WireGuard a stella usando esclusivamente file JSON come storage applicativo.

> Stato: **M4.3 chiusa; M4.4 supply-chain in corso (R11 in lavorazione)**. Sono operativi
> storage/repository JSON, dominio,
> autenticazione, RBAC, audit, probe host/WireGuard read-only e custodia cifrata delle
> chiavi, compiler deterministico, job persistenti, worker, applicazione WireGuard
> tipizzata e reconciler periodico drift-aware tramite helper privilegiato; test E2E e
> isolamento VRF/nftables sono completati. Gli endpoint API scoped per tenant, utenti,
> reti, client, job, telemetria e service account sono registrati; create/update tenant e
> utenti, service account, reti e client usano idempotenza persistente, RBAC scoped ed
> ETag. Start, stop, sync e reconcile rete e le transizioni client che cambiano peer live
> restituiscono job asincroni con quote e backpressure globali/per-scope. Il download
> della singola configurazione client richiede permesso dedicato e token breve. Il
> contratto OpenAPI, gli esempi sicuri e i gate automatici di conformità/compatibilità
> sono pubblicati. Login, cambio password, dashboard e pagine d’errore usano ora un
> design system responsive e una navigazione server-side limitata agli scope assegnati.
> Elenco, dettaglio, creazione e modifica di tenant, utenti e assegnazioni multi-tenant
> sono disponibili con RBAC, CSRF, preservazione degli scope e concorrenza ottimistica.
> Le reti possono essere elencate, consultate, validate in anteprima e create: CIDR,
> capacità client, endpoint, porta e conflitti sono verificati prima del salvataggio.
> Modifica e archiviazione rispettano revisioni, ruoli e vincoli delle reti running. I
> client possono essere elencati per rete, creati con IP automatico o manuale stabile,
> consultati, modificati e gestiti nel lifecycle senza esporre chiavi. Le variazioni dei
> peer live producono job scoped consultabili dalla UI. Il profilo WireGuard completo è
> scaricabile individualmente dopo riautenticazione, con audit e risposta non cacheabile.
> I job asincroni sono mostrati in un dialogo accessibile con polling scoped, backoff ed
> errori azionabili; tutti i form POST bloccano il doppio invio. La dashboard riepiloga
> tenant, reti e client visibili, aggiorna conteggi e stato runtime di tutte le reti con
> un solo probe per ciclo e mostra per la rete selezionata IP VPN, endpoint, handshake,
> traffico, presenza e “online dal” esplicitamente stimati. Gunicorn dispone ora di unità
> socket-activated non privilegiata e di un esempio Caddy HTTPS con allowlist amministrativa;
> gli header client vengono fidati solo sul socket Unix configurato. Il build Debian genera
> ora un `.deb` autosufficiente da dipendenze Python bloccate con hash, inizializzazione
> one-shot di utente, segreti, keyring e storage, preservandoli agli upgrade e alla rimozione.
> Installazione, Caddy HTTPS, upgrade e remove/reinstall sono collaudati su Debian 12. Il
> contratto di recovery M4.2 è definito, la cifratura streaming `age`/X25519 è integrata e
> `backup-create` produce recovery set offline dopo quiesce/validazione e `backup-verify`
> li autentica senza estrazione. `restore-preflight` esegue estrazione temporanea e
> validazione semantica completa senza modificare lo stato live; le primitive interne
> rendono lo staging inerte, ricostruiscono gli indici e promuovono data tree, environment e
> keyring con un journal crash-safe coordinato. L'orchestratore interno root-only collega
> ora quiesce, stop host e controlli finali; il comando root-only `restore-apply` richiede
> conferma esplicita del recovery set e consenso alla sostituzione, redige gli errori e
> lascia le reti recuperate ferme. Il disaster-recovery drill reale su Debian 12 ha
> verificato successo, guard rail, rollback, failure policy e health post-ripristino con
> RTO osservato di 3 secondi sul dataset di laboratorio. Le migrazioni restore forward-only
> usano copie di lavoro private, catene complete e nuovi manifest senza modificare i bundle
> sorgente. M4.2 è conclusa; il candidate non è ancora una release production 1.0.
> Liveness e readiness sono ora separate: `/readyz` controlla in modo redatto storage,
> recovery, keyring e helper/capability con cache breve, mentre `/healthz` resta indipendente
> dalle dipendenze. Il logging applicativo JSON line usa eventi/campi allowlistati e request
> ID canonici senza URI, payload, token, cookie, chiavi, path o testo delle eccezioni.
> I log operativi vivono in un namespace journald dedicato con quota, retention e rate
> limit separati dall'audit. Il reconciler pubblica inoltre health persistente redatta:
> readiness e timer systemd rilevano cicli stale, fallimenti ripetuti e backlog vecchio
> senza scritture o autoriparazioni. Il runbook incidenti M4.3 è pubblicato con matrice
> completa dei codici e il relativo drill reale su Debian è superato.
> Il primo gate M4.4 scansiona tutte le dipendenze Python hashate e produce audit JSON,
> SBOM CycloneDX e manifest verificabile. Il formato della provenienza è implementato come
> Statement in-toto/SLSA non firmata con bundle sorgente/package e inventario Debian. La
> toolchain di release è interamente pinned e hashata e un orchestratore clean-tree collega
> test, audit, build e verifica in un ambiente effimero. Il vecchio candidate `0.1.0-9`
> resta evidenza storica non pubblicabile. Il drill ha inoltre escluso `0.1.0-10` dal
> percorso remove/reinstall prima dell'unpack e `0.1.0-11` per mode non sicuri del
> payload. La revisione corretta `0.1.0-12` ha ricostruito la baseline Debian R03 e il
> candidate consecutivo `0.1.0-13` ha completato il primo arco reale. Il nuovo candidate
> recovery `0.1.0-15`, compatibile solo con `0.1.0-14`, ha completato pipeline, firma e
> upgrade reale. La revisione `0.1.0-16`, compatibile solo con `0.1.0-15`, ha completato
> fault, rollback e restore reali, esponendo il falso stato recovery P-026 dopo il cleanup.
> La correzione è riservata a `0.1.0-17`, ancora vincolata a `0.1.0-15`. Il drill incidenti
> R04, la cerimonia offline R06, l'upgrade reale happy path R07, i failure point
> pre-unpack/consumo R08 e i recovery dpkg di configurazione/trigger R09–R10 sono
> superati; rollback attestato, consolidamento e pubblicazione restano gate aperti.

## Obiettivo

Ogni rete ha un peer server sulla macchina del portale e più client con indirizzo stabile.
Il server inoltra soltanto traffico interno alla VPN; non offre uscita Internet. Tenant e
reti sono isolati. I ruoli previsti sono:

- `superadmin`: tutti i tenant e tutte le reti;
- `admin`: tutte le risorse del proprio tenant;
- `manager`: una specifica rete del proprio tenant.

La fonte normativa del progetto è [docs/SPECIFICATION.md](docs/SPECIFICATION.md). Le
scelte ancora richieste all'utente sono nel
[registro decisioni](docs/USER_DECISIONS.md), mentre le modifiche osservabili sono
riportate in [CHANGELOG.md](CHANGELOG.md). Per riprendere il lavoro leggere
[docs/AI_HANDOFF.md](docs/AI_HANDOFF.md) e scegliere il primo task `TODO` in
[docs/ROADMAP.md](docs/ROADMAP.md).
Le convenzioni per template, accessibilità, navigazione e componenti sono definite in
[docs/UI.md](docs/UI.md).
Per installare da sorgente o costruire il candidate Debian seguire [INSTALL.md](INSTALL.md).
Il contratto e i limiti correnti del recovery sono in
[docs/BACKUP_RESTORE.md](docs/BACKUP_RESTORE.md); le evidenze dell'ultimo collaudo sono in
[docs/DISASTER_RECOVERY_DRILL.md](docs/DISASTER_RECOVERY_DRILL.md).
Il contratto dei probe e i vincoli del logging sono in
[docs/OBSERVABILITY.md](docs/OBSERVABILITY.md).
Il gate delle dipendenze e gli artefatti SBOM sono descritti in
[docs/SUPPLY_CHAIN.md](docs/SUPPLY_CHAIN.md).
Le evidenze del candidate rollback osservato `0.1.0-16` sono in
[docs/RELEASE_CANDIDATE_0.1.0-16.md](docs/RELEASE_CANDIDATE_0.1.0-16.md); il predecessor
firmato resta documentato in
[docs/RELEASE_CANDIDATE_0.1.0-15.md](docs/RELEASE_CANDIDATE_0.1.0-15.md) e il primo arco
consecutivo `0.1.0-12 → 0.1.0-13` resta documentato nei verbali immutabili precedenti.
Le evidenze del rifiuto fail-closed `0.1.0-10` sono in
[docs/RELEASE_CANDIDATE_0.1.0-10.md](docs/RELEASE_CANDIDATE_0.1.0-10.md); il successivo
rifiuto del payload `0.1.0-11` è documentato in
[docs/RELEASE_CANDIDATE_0.1.0-11.md](docs/RELEASE_CANDIDATE_0.1.0-11.md). Le evidenze
storiche non pubblicabili di `0.1.0-9` restano separate nel relativo verbale; la roadmap
identifica la revisione predecessor corrente.
Il protocollo SSHSIG, la custodia offline e la verifica delle firme sono descritti in
[docs/RELEASE_SIGNING.md](docs/RELEASE_SIGNING.md); fingerprint, hash e prove negative
della cerimonia corrente sono nel
[verbale R06](docs/RELEASE_SIGNING_CEREMONY_2026-10-13.md).
Il verbale dell'upgrade firmato reale è in
[docs/UPGRADE_DRILL_R07_2026-10-13.md](docs/UPGRADE_DRILL_R07_2026-10-13.md).
I rifiuti e i crash del marker monouso sono registrati nel
[verbale R08](docs/UPGRADE_FAILURE_DRILL_R08_2026-10-13.md).
Il deploy di un package firmato in una root APT `reprepro` e la verifica indipendente
dell'indice OpenPGP sono descritti in
[docs/APT_REPOSITORY_DEPLOYMENT.md](docs/APT_REPOSITORY_DEPLOYMENT.md). Lo stesso tool può
esportare in modo controllato i soli file pubblici verso il symlink locale `publish/`
collegato a GitHub Pages, senza esporre database o configurazione `reprepro`.
Il canale tecnico corrente è disponibile su
<https://paolotreu-lsilastem.github.io/apt/> come suite `bookworm-testing`; non è ancora
il canale stabile v1.
La matrice dei candidate consecutivi, il preflight artefatto e i gate ancora necessari
prima di autorizzare un upgrade sono in [docs/UPGRADE.md](docs/UPGRADE.md).

È disponibile un'API HTTPS pubblica e versionata per l'automazione remota. Contratto,
controlli e confini sono descritti in [docs/API.md](docs/API.md); le decisioni di sicurezza
della v1 sono approvate e registrate nel [registro decisioni](docs/USER_DECISIONS.md).
Il contratto machine-readable è disponibile senza autenticazione su
`GET /api/v1/openapi.json`; non viene esposta una console interattiva. Esempi e procedura
di aggiornamento sono in [docs/openapi/README.md](docs/openapi/README.md).

## Avvio per sviluppo

Prerequisiti: Debian Linux, Python 3.11+, `ip`, `wg`, `wg-quick` e `age`. Lo sviluppo corrente
avviene anche su Windows 11 Pro tramite WSL Debian; in WSL la disponibilità di systemd,
nftables e accesso al kernel dipende dalla configurazione della distribuzione. Il
bootstrap non modifica interfacce di rete né `/etc/wireguard`. La versione 1 verrà distribuita
ufficialmente come pacchetto Debian; i container non fanno parte del supporto iniziale.

```bash
cp .env.example .env
./scripts/bootstrap.sh
source .venv/bin/activate
wg-portal doctor
wg-portal host-probe --json
wg-portal helper-probe --json
wg-portal keyring-rewrap
wg-portal audit-verify
wg-portal worker-once
wg-portal reconcile-once
wg-portal reconciler
wg-portal run --debug
```

Aprire `http://127.0.0.1:8080/`, accedere con `admin/admin` e sostituire immediatamente
la password con una di almeno 14 caratteri. Il bootstrap viene rifiutato se l'indirizzo
client effettivo non è loopback.

Al primo bootstrap viene creato `admin/admin`, `superadmin`, con
`must_change_password=true`. È una credenziale deliberatamente insicura, utilizzabile
solo da loopback e da cambiare prima di qualsiasi esposizione del servizio.

## Test e controlli

```bash
./scripts/check.sh
```

Per un candidate di rilascio, con accesso di rete al database advisory, eseguire inoltre:

```bash
./scripts/build-release-candidate.sh
```

La pipeline richiede un commit pulito, crea un ambiente effimero dai lock hashati e non
sovrascrive candidate esistenti. Procedura e limiti di autenticità sono in
[docs/SUPPLY_CHAIN.md](docs/SUPPLY_CHAIN.md).

## Layout

```text
src/wg_portal/       applicazione, primitive di storage e JSON Schema versionati
tests/               test senza privilegi di root
scripts/             bootstrap e quality gate
docs/                specifica, sicurezza, modello dati e roadmap
var/                  dati locali ignorati da Git
```

## Licenza

AGPL-3.0-or-later, scelta per mantenere disponibili le modifiche anche quando il
software viene offerto come servizio. Le configurazioni e le chiavi degli utenti non
sono parte del codice sorgente né della licenza.
