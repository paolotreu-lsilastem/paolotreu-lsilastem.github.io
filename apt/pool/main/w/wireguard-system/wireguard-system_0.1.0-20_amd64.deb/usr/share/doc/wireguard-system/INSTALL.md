# Installazione

Questa guida installa l’attuale prototipo da sorgente su Debian o WSL Debian. Consente di
usare UI, API, storage JSON, gestione delle configurazioni e test senza modificare la
rete host durante il bootstrap.

> **Stato pre-release:** questa non è ancora una procedura di produzione. Il candidate
> tecnico firmato `0.1.0-17` ha completato installazione, recovery, upgrade/rollback,
> osservabilità e pubblicazione nella sola suite `bookworm-testing`. Consolidamento
> M4.4, sicurezza API M4.6, manuali R16–R17 e freeze sorgente R18 sono chiusi. R19 è
> chiuso con waiver: l'audit indipendente non è stato eseguito. I controlli compensativi
> interni R20–R21, la regressione R22 e la chiusura documentale R23 sono completati.
> La revisione `0.1.0-18` è stata costruita dal tag annotato
> `v0.1.0-18-rc1-freeze`, firmata offline e verificata insieme alla keyring APT in R24;
> R25 l'ha respinta per P-054 nel gate remove/reinstall. `0.1.0-19` ha superato upgrade
> firmato e cleanup bytecode, ma è stata respinta dallo stesso gate perché il preinst
> interrogava dpkg dopo la transizione di stato. La revisione correttiva `0.1.0-20`,
> predecessor `0.1.0-17`, deve essere congelata, costruita, firmata e collaudata.
> R25 resta aperta.
> Non usare il candidate su un host di produzione.

## 1. Piattaforme e prerequisiti

Ambiente di riferimento:

- Debian 12 Bookworm `amd64` con Python 3.11 per il package supportato;
- Debian in WSL 2 per lo sviluppo non privilegiato;
- host Debian nativo per prove reali di WireGuard, VRF, nftables e systemd.

Installare i pacchetti di base:

```bash
sudo apt update
sudo apt install --yes git python3 python3-venv python3-pip wireguard-tools iproute2 nftables age
```

Per eseguire i test systemd è necessario che la distribuzione usi systemd. In WSL alcune
verifiche host possono risultare `unavailable`: non è un errore del bootstrap e non va
aggirato avviando Flask come root.

## 2. Checkout e configurazione locale

Clonare o copiare il repository e posizionarsi nella sua radice:

```bash
git clone <URL-DEL-REPOSITORY> wireguard-system
cd wireguard-system
```

Creare il file d’ambiente locale con permessi restrittivi:

```bash
umask 077
cp .env.example .env
chmod 600 .env
```

Prima dell’avvio sostituire in `.env` almeno questi due valori con segreti distinti,
casuali e lunghi almeno 32 byte:

```dotenv
WG_PORTAL_SECRET_KEY=replace-with-at-least-32-random-bytes
WG_PORTAL_AUDIT_HMAC_KEY=replace-with-a-distinct-random-secret-of-at-least-32-bytes
```

Un valore adatto allo sviluppo può essere generato senza dipendenze aggiuntive con:

```bash
python3 -c 'import secrets; print(secrets.token_urlsafe(48))'
```

Eseguire il comando due volte e non conservare i valori in Git, cronologia condivisa,
ticket o log. Le impostazioni predefinite mantengono dati e keyring in directory separate:

```text
./var/lib/wg-portal/                 documenti JSON e stato runtime
./var/secrets/master-keyring.json   chiavi master degli envelope
```

I percorsi relativi in `.env` presuppongono che i comandi vengano eseguiti dalla radice
del checkout. Per installazioni persistenti usare percorsi assoluti e mantenere il
keyring fuori dal data tree e dai suoi backup.

## 3. Bootstrap

Lo script crea `.venv`, installa progetto e dipendenze di sviluppo, crea il keyring master
se assente e inizializza il data tree:

```bash
./scripts/bootstrap.sh
source .venv/bin/activate
```

Il bootstrap è idempotente: può essere rilanciato per riallineare l’ambiente Python e non
sovrascrive account, dati o keyring esistenti. Non installa unità systemd, non crea
interfacce WireGuard e non scrive in `/etc/wireguard`.

Verificare immediatamente l’installazione:

```bash
wg-portal doctor
wg-portal audit-verify
./scripts/check.sh
```

`doctor` restituisce un exit code non zero se mancano prerequisiti host. `check.sh` esegue
lint, type-check, compatibilità OpenAPI, test e coverage; non richiede privilegi root né
crea reti.

## 4. Primo avvio locale

Avviare esclusivamente il server di sviluppo in ascolto loopback:

```bash
wg-portal run
```

Da un secondo terminale verificare la health route:

```bash
curl --fail http://127.0.0.1:8080/healthz
```

Aprire `http://127.0.0.1:8080/`, autenticarsi con `admin/admin` e cambiare subito la
password con una di almeno 14 caratteri. L’account iniziale è `superadmin`; la password
bootstrap è accettata soltanto da loopback. Non modificare questa protezione per accedere
da un altro computer: usare un tunnel SSH verso loopback durante le sole prove locali.

Per terminare il server premere `Ctrl+C`.

## 5. Verifiche WireGuard read-only

Il probe diretto non modifica la macchina:

```bash
wg-portal host-probe
wg-portal host-probe --json
```

Un risultato `unavailable` per modulo kernel, forwarding, nftables o systemd descrive la
capacità reale dell’host. Non eseguire la UI come root per trasformarlo in successo.

Il comando seguente richiede invece il socket dell’helper privilegiato:

```bash
wg-portal helper-probe --json
```

In una normale installazione locale pre-release deve fallire finché helper e unità
systemd non sono stati installati nel layout controllato. Di conseguenza UI, CRUD,
download delle configurazioni e API sono valutabili, mentre start/stop/sync reali e la
telemetria kernel rimangono indisponibili oppure `unknown`.

## 6. Installazione production su Debian 12

Il percorso production supportato usa il pacchetto Debian costruito nella sezione
successiva. Installa Gunicorn sul solo `/run/wg-portal/web.sock`, helper e reconciler,
crea l’identità `wg-portal`, inizializza dati e chiavi e installa Caddy come unico listener
HTTPS. Non copiare manualmente unità o payload dal checkout.

Non creare symlink ad hoc in `/usr/bin`, non cambiare il gruppo del socket e non eseguire
il processo web come root. Per il laboratorio autorizzato e la checklist di test usare
[docs/LOCAL_TEST_ENVIRONMENT.md](docs/LOCAL_TEST_ENVIRONMENT.md); per modello operativo,
registry privilegiato, recovery e vincoli del helper usare
[docs/OPERATIONS.md](docs/OPERATIONS.md). Per triage e risposta agli incidenti usare
[docs/INCIDENT_RUNBOOK.md](docs/INCIDENT_RUNBOOK.md), senza improvvisare comandi host.

## 7. Costruzione del pacchetto Debian candidate

Il builder richiede Debian 12 amd64, `dpkg-deb`, Python 3.11 e il virtualenv di sviluppo.
Scarica soltanto wheel binarie i cui hash sono registrati in `requirements-prod.lock`,
costruisce il wheel applicativo con tool esattamente versionati e produce in `dist/`:

```bash
./packaging/debian/build-package.sh
./packaging/apt-keyring/build-package.sh
dpkg-deb --info dist/wireguard-system_0.1.0-18_amd64.deb
dpkg-deb --info dist/wireguard-system-archive-keyring_2026.10.15-1_all.deb
```

Su un host pulito il package può essere installato con `apt-get install` sul path locale.
Su un host che contiene già `wireguard-system`, non invocare direttamente apt/dpkg: la
revisione `0.1.0-18` accetta esclusivamente il predecessor `0.1.0-17` e richiede il
preflight e l'authorization firmata descritti in `docs/UPGRADE.md`.

Il `.deb` incorpora il payload Python privato sotto `/usr/lib/wireguard-system`; l’installazione non
usa PyPI e non dipende dalle versioni Flask/Gunicorn di Debian 12. `postinst` crea una sola
volta l’utente di sistema, due segreti distinti, il keyring `0600`, lo storage e
`admin/admin`, quindi abilita socket, reconciler e relativo timer health read-only.
Installa inoltre `age`, richiesto dai bundle di recovery cifrati. Un environment esistente
non viene riscritto e i dati non vengono cancellati nemmeno dal purge.

Il pacchetto crea inoltre il namespace journald `wg-portal`, limitato e distinto dal
journal globale. Dopo l'installazione verificare configurazione e primi eventi con:

```bash
systemd-analyze cat-config systemd/journald@wg-portal.conf
journalctl --namespace=wg-portal --since today -o cat
sudo -u wg-portal /usr/bin/wg-portal reconciler-health
systemctl status wg-portal-reconciler-health.timer
```

La configurazione Caddy non viene attivata automaticamente perché hostname e allowlist
sono specifici dell’installazione. Dopo l’installazione copiare
`/usr/share/wireguard-system/wg-portal.caddy.example`, sostituire dominio e CIDR, importarla
dal Caddyfile principale, eseguire `caddy validate` e soltanto dopo ricaricare Caddy. Il
primo accesso `admin/admin` deve arrivare come loopback, ad esempio tramite un tunnel SSH,
e deve terminare immediatamente con il cambio password.

Per rigenerare intenzionalmente il lockfile dopo una revisione dipendenze:

```bash
PIP_TOOLS_CACHE_DIR=/tmp/wg-portal-pip-tools-cache \
  .venv/bin/pip-compile --generate-hashes --strip-extras \
  --output-file requirements-prod.lock pyproject.toml
```

La variazione completa del lockfile deve essere revisionata e sottoposta alla suite; non
modificare manualmente singoli hash.

Per costruire un candidate dal commit pulito eseguire il gate supply-chain completo, che
richiede accesso a PyPI e al database advisory:

```bash
./scripts/build-release-candidate.sh
```

Il comando rifiuta un tree sporco, output preesistenti o un `HEAD` diverso dal tag
annotato indicato in `packaging/debian/release-freeze-tag`; esegue la suite, installa la
toolchain da `requirements-release.lock` in un virtualenv effimero, genera audit/SBOM,
costruisce package applicativo e keyring APT e verifica il bundle che li attesta
entrambi. Un exit code diverso da zero blocca il build.
Internamente il gate invoca `scripts/security-artifacts.py`; per una diagnosi isolata lo
si può eseguire con il medesimo Python della toolchain, senza considerarlo un rilascio.
La verifica dimostra integrità e collegamenti, non autenticità: la provenienza non è ancora
firmata e il candidate non deve essere pubblicato come release attendibile. Formato,
limiti e remediation sono descritti in [docs/SUPPLY_CHAIN.md](docs/SUPPLY_CHAIN.md).

La pipeline prepara anche `SHA256SUMS`, ma non possiede la chiave privata. Dopo la
cerimonia offline, verificare obbligatoriamente firma, revoche, checksum e provenienza:

```bash
.venv/bin/python scripts/release-signing.py verify dist/releases/0.1.0-18 \
  --allowed-signers release/allowed_signers \
  --revoked-keys release/revoked_keys
```

La policy pubblica è versionata sotto `release/`; il comando deve riuscire sul bundle
`0.1.0-18` completo. R24 ha registrato il risultato nel
[verbale candidate finale](docs/FINAL_CANDIDATE_R24_2026-10-15.md), ma questo non rende
ancora il candidate pubblicabile: approvazione e `GO` restano nel gate R25. Il verificatore
non richiede la chiave privata. Le copie locali deliberate dal maintainer sono il rischio
accettato P-019 e non devono essere passate a tool, server o log. Seguire
[docs/RELEASE_SIGNING.md](docs/RELEASE_SIGNING.md).

Per inserire successivamente il package in una repository APT locale già configurata e
firmata, installare `reprepro` e usare `scripts/deploy-apt-package.py` passando la root
assoluta. Il comando richiede sia la policy SSHSIG della release sia keyring pubblica e
fingerprint OpenPGP della repository; sintassi, permessi e configurazione client
`Signed-By` sono in [docs/APT_REPOSITORY_DEPLOYMENT.md](docs/APT_REPOSITORY_DEPLOYMENT.md).

Un upgrade non equivale a una nuova installazione. Il candidate dichiara un solo
predecessore supportato e il suo `preinst` rifiuta l'unpack senza una ricevuta recovery
firmata, verificata e armata esplicitamente con `upgrade-preflight.py --arm-upgrade`. Il
marker root-only è monouso. L'arming controlla health, job/restore pendenti e spazio in
modo read-only e richiede tutte le VPN ferme sia nello stato desiderato sia nel registry
host. Quiesce, recovery e rollback sono stati collaudati in R07–R11, ma devono essere
rieseguiti sul candidate finale in R25. Fino al `GO` non eseguire
`apt install` o `dpkg -i` in produzione; seguire sempre la procedura in
[docs/UPGRADE.md](docs/UPGRADE.md).

## 8. Aggiornamento del checkout di sviluppo

Prima di aggiornare eseguire un backup coerente del data tree e separatamente del
keyring. Quindi, dalla radice del repository:

```bash
git pull --ff-only
./scripts/bootstrap.sh
./scripts/check.sh
wg-portal audit-verify
```

Non copiare il keyring nello stesso archivio dei dati cifrati. M4.2 fornisce create,
verify, preflight, restore e migrazioni forward-only: usare `wg-portal backup-create` per
ottenere una coppia cifrata consistente e provarla secondo la procedura prima di eliminare
copie precedenti. Comandi e requisiti sono descritti in `docs/BACKUP_RESTORE.md`.

## 9. Problemi comuni

- `WG_PORTAL_SECRET_KEY must contain at least 32 characters`: il processo sta usando
  `production` oppure il segreto configurato è troppo corto; non usare il fallback
  casuale di sviluppo per dati persistenti.
- `WG_PORTAL_MASTER_KEY_FILE must be outside WG_PORTAL_DATA_DIR`: spostare il keyring in
  una directory separata, come già fa `.env.example`.
- `FAIL privileged helper probe`: atteso nel solo bootstrap locale; non abilita operazioni
  host reali finché non viene completata l’installazione M4.1.
- `unknown` come IP client dietro Gunicorn: il deployment Unix non ha impostato
  `WG_PORTAL_TRUST_UNIX_PROXY=true`, oppure Caddy non ha sovrascritto
  `X-Forwarded-For`; non rendere pubblico un listener Gunicorn per aggirare il controllo.
- redirect continuo a cambio password: completare il cambio della credenziale bootstrap
  dalla stessa sessione loopback.
- stato client `unknown`: il sistema non ha ricevuto un probe affidabile e, per sicurezza,
  non lo converte in `offline`.
- il package build rifiuta una dipendenza: non disabilitare `--require-hashes` o
  `--only-binary`; rigenerare e revisionare il lockfile oppure correggere la piattaforma
  di build.

Le impostazioni, i limiti e le procedure di gestione successive al bootstrap sono
documentati in [docs/OPERATIONS.md](docs/OPERATIONS.md). I vincoli di sicurezza normativi
sono in [docs/SECURITY.md](docs/SECURITY.md).
