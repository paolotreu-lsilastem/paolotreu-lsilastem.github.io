# Manuale dell'amministratore

## Scopo, supporto e stato

Questa è la guida operativa unica per installare e amministrare WireGuard System v1.
Rimanda ai runbook specialistici quando un'operazione richiede controlli di sicurezza o
recovery più dettagliati: non sostituirli con comandi improvvisati.

La matrice supportata è **Debian 12 Bookworm `amd64` con systemd**. WSL Debian è adatto
allo sviluppo, non al server supportato. Debian 10, 11, 13, altre architetture, container,
IPv6 ed esposizione Internet della UI/API sono fuori scope. Il package `0.1.0-17` è un
candidate tecnico pubblico nella suite `bookworm-testing`: può essere installato solo su
un laboratorio pulito. R25 ha respinto `0.1.0-18` e `0.1.0-19` per P-054; il candidate
correttivo `0.1.0-20` è riservato ma non ancora costruito o firmato e non costituisce il `GO`
production. Il canale stabile rimane chiuso
fino a R25 e la v1 deve essere dichiarata non sottoposta ad audit indipendente.

Documenti normativi collegati:

- [installazione e build](../INSTALL.md);
- [operazioni e helper privilegiato](OPERATIONS.md);
- [sicurezza](SECURITY.md) e [specifica](SPECIFICATION.md);
- [API](API.md), [contratto OpenAPI](openapi/README.md) ed
  [evoluzione del contratto](API_EVOLUTION.md);
- [osservabilità](OBSERVABILITY.md), [backup/restore](BACKUP_RESTORE.md),
  [upgrade](UPGRADE.md) e [incident response](INCIDENT_RUNBOOK.md);
- [repository APT](APT_REPOSITORY_DEPLOYMENT.md) e [matrice di chiusura](ROADMAP.md).

## Modello operativo e responsabilità

Il portale è l'unica fonte canonica. Non modificare JSON, keyring, registry helper,
interfacce WireGuard, VRF o regole nftables a mano. Caddy è il solo ingresso HTTPS;
Gunicorn ascolta soltanto sul socket Unix. Il processo web e il reconciler non girano
come root; soltanto l'helper ristretto applica il piano tipizzato all'host.

| Ruolo | Ambito | Amministrazione consentita |
|---|---|---|
| superadmin | globale | tenant, utenti, tutte le reti, accessi API e operazioni |
| admin | uno o più tenant | utenti e tutte le reti dei tenant assegnati |
| manager | una o più reti | reti, client e operazioni delle sole reti assegnate |

Uno stesso utente può avere più assegnazioni. L'autorizzazione è applicata nel backend a
ogni oggetto; l'assenza di una voce dalla UI non è un controllo di sicurezza.

## Installazione pulita dal canale testing

Prima dell'installazione verificare Debian e architettura:

```bash
. /etc/os-release
test "$ID" = debian
test "$VERSION_ID" = 12
test "$(dpkg --print-architecture)" = amd64
```

Scaricare la keyring e confrontare il fingerprint completo
`2B3C FA67 79E3 95C0 CDA2 08B7 AE7A 30DC 2F97 0ACF` con un canale del maintainer
indipendente da GitHub Pages. Soltanto dopo il confronto installare keyring e source:

```bash
curl --fail --silent --show-error --location --remote-name \
  https://paolotreu-lsilastem.github.io/apt/wireguard-system-archive-keyring.gpg
gpg --show-keys --with-fingerprint wireguard-system-archive-keyring.gpg
sudo install -o root -g root -m 0644 wireguard-system-archive-keyring.gpg \
  /usr/share/keyrings/wireguard-system-archive-keyring.gpg
curl --fail --silent --show-error --location --remote-name \
  https://paolotreu-lsilastem.github.io/apt/wireguard-system.sources
sudo install -o root -g root -m 0644 wireguard-system.sources \
  /etc/apt/sources.list.d/wireguard-system.sources
sudo apt update
sudo apt install wireguard-system
```

Questi comandi descrivono il bootstrap del canale testing già pubblicato. Dal candidate
finale il repository distribuirà anche `wireguard-system-archive-keyring`: dopo la prima
verifica manuale del fingerprint installare entrambi i package, così rinnovi e rotazioni
del trust arriveranno tramite APT. Il passaggio è autorizzato soltanto dopo il drill R24.

Non usare `trusted=yes`, repository unsigned o installazione forzata su una piattaforma
diversa. Per un upgrade di un'installazione esistente fermarsi qui e seguire
[il runbook upgrade](UPGRADE.md): `apt install` diretto è deliberatamente negato.

Controllare package e servizi senza cambiare stato:

```bash
dpkg-query -W wireguard-system
systemctl is-active wg-portal-web.socket wg-portal-reconciler.service \
  wg-portal-helper.socket caddy
systemctl is-enabled wg-portal-web.socket wg-portal-reconciler.service \
  wg-portal-helper.socket wg-portal-reconciler-health.timer
sudo -u wg-portal /usr/bin/wg-portal doctor
sudo -u wg-portal /usr/bin/wg-portal helper-probe --json
```

Il package crea dati, segreti e account `admin/admin` una sola volta. Remove e purge non
cancellano automaticamente dati o keyring.

## Caddy e primo accesso

Partire dall'esempio packaged, sostituire hostname e CIDR con quelli realmente approvati,
quindi importarlo dal Caddyfile principale. Conservare loopback nell'allowlist per il
bootstrap via tunnel. Non includere `0.0.0.0/0`, `::/0` o reti Internet generiche.

```bash
sudo install -o root -g root -m 0644 \
  /usr/share/wireguard-system/wg-portal.caddy.example \
  /etc/caddy/wg-portal.caddy
sudo caddy validate --config /etc/caddy/Caddyfile
sudo systemctl reload caddy
```

La configurazione deve mantenere HTTPS, HSTS, limite body `1MB`, sovrascrittura degli
header forwarded e upstream `unix//run/wg-portal/web.sock`. Per integrazioni privilegiate
si può adottare l'esempio mTLS, dopo aver predisposto CA client e lifecycle dei
certificati. La policy completa e le prove negative sono nel
[drill Caddy R14](CADDY_EXPOSURE_DRILL_R14_2026-10-14.md).

Il primo login deve apparire al server come loopback. Aprire dal computer amministrativo
un tunnel e associare temporaneamente **il nome presente nel certificato TLS** a
`127.0.0.1` nel resolver locale:

```bash
ssh -N -L 8443:127.0.0.1:443 amministratore@vpn.example.invalid
```

Visitare `https://vpn.example.invalid:8443/`, accedere con `admin/admin` e impostare
immediatamente una password unica di almeno 14 caratteri. Non ignorare errori TLS e non
allargare l'allowlist per completare il bootstrap. Rimuovere poi l'associazione locale e
chiudere il tunnel.

## Ordine di configurazione nella UI

### Tenant e utenti

1. In **Tenant**, creare il tenant con nome e slug stabili. `suspended` blocca le
   operazioni; `archived` è terminale nella v1.
2. In **Utenti**, creare gli account con password iniziale distinta. Il cambio password è
   obbligatorio al primo accesso.
3. Assegnare `admin` a uno o più tenant oppure `manager` a una o più reti. Mantenere
   almeno un superadmin attivo e usare account nominativi, non condivisi.
4. Aprire una sessione di prova per ogni ruolo e verificare che tenant e reti estranei
   non siano visibili né raggiungibili tramite URL copiati.

### Reti

Creare prima il tenant e poi la rete. Il CIDR deve essere IPv4 RFC1918 con prefisso da
`/16` a `/30`. L'hub occupa un indirizzo della subnet; gli IP client sono prenotazioni
stabili. Due reti dello stesso tenant non possono sovrapporsi. La sovrapposizione fra
tenant è accettata soltanto quando il probe helper dichiara la capability VRF e
l'isolamento L3 è verificabile.

Usare per default l'allocazione automatica della porta UDP nel range `51820–51999`; una
porta manuale deve restare nel range e non collidere sullo stesso endpoint/IP risolto.
CIDR e indirizzo hub sono immutabili nella v1: per cambiarli creare una nuova rete.

### Client e stato live

Creare almeno due client per verificare la topologia a stella. L'IP può essere automatico
o manuale, ma rimane assegnato fino a `release-ip`. Il lifecycle è:

```text
pending -> active <-> disabled -> revoked -> archived -> release-ip
```

Revoca e archiviazione non liberano implicitamente l'indirizzo. Su una rete running,
activate/disable/revoke/archive accodano un job di sincronizzazione: la finestra di attesa
mostra esito o codice azionabile. Non ripetere il submit; aprire **Operazioni** e attendere
lo stato terminale. Start, stop, sync e reconcile della rete seguono lo stesso modello.

Il download del profilo client richiede la password dell'utente corrente e produce un
singolo file non cacheabile che contiene la chiave privata del client. Salvarlo con mode
`0600`, trasferirlo tramite canale autenticato e non allegarlo a ticket o log. Le chiavi
private server non sono scaricabili.

## Chiavi applicative

Il keyring master vive fuori dal data tree. La rotazione aggiunge una nuova chiave attiva;
il rewrap ricifra gli envelope senza cambiare le chiavi WireGuard:

```bash
sudo -u wg-portal /usr/bin/wg-portal keyring-rotate
sudo -u wg-portal /usr/bin/wg-portal keyring-rewrap
sudo -u wg-portal /usr/bin/wg-portal audit-verify
```

Eseguire rotazione e rewrap in una finestra controllata, verificare l'audit e creare poi
un nuovo recovery set. Non eliminare vecchie entry dal keyring a mano. Le chiavi di firma
release/upgrade e l'identity privata `age` non devono risiedere sul server.

## Bootstrap e uso dell'API

Soltanto un superadmin vede **Accessi API**. **Crea accesso bootstrap** emette una identità
globale e mostra il bearer token una sola volta in una risposta `no-store`. Copiarlo
direttamente in un secret manager. Se la pagina viene persa, il token non è recuperabile:
ruotare la credenziale. Il permesso `client.config:read` limita la durata a 24 ore; senza
quel permesso la durata massima è 90 giorni.

Usare subito il token bootstrap per creare via API una o più identità con il minimo scope
necessario, verificare l'automazione e poi revocare il bootstrap dalla UI. Non inserire
token in URL, file `.env`, cronologia shell, log CI o ticket. Il contratto scaricabile è:

```bash
curl --fail --proto '=https' \
  --output wireguard-system-openapi-v1.json \
  https://vpn.example.invalid/api/v1/openapi.json
```

Payload, header `Idempotency-Key`, ETag, retry e codici sono definiti dagli
[esempi OpenAPI](openapi/README.md). Un retry di create/rotate dopo che il token one-time
è stato emesso restituisce `CREDENTIAL_RECOVERY_REQUIRED`: generare una nuova rotazione,
non tentare di recuperare il secret dallo storage. In caso di compromissione seguire il
[drill di revoca](API_CREDENTIAL_COMPROMISE_DRILL.md).

## Osservabilità e manutenzione ordinaria

Liveness prova il processo; readiness prova storage, recovery, keyring, helper e
reconciler. Verificare prima il socket e poi Caddy:

```bash
curl --fail --unix-socket /run/wg-portal/web.sock http://localhost/healthz
curl --fail --unix-socket /run/wg-portal/web.sock http://localhost/readyz
sudo -u wg-portal /usr/bin/wg-portal reconciler-health
sudo -u wg-portal /usr/bin/wg-portal audit-verify
journalctl --namespace=wg-portal --since today -o cat
```

Un `503` readiness non autorizza restart ripetuti. Annotare il codice redatto e seguire il
runbook incidenti. La dashboard aggiorna automaticamente stato rete, IP VPN, endpoint
osservato, traffico, handshake, presenza e “online dal”; presenza e timestamp sono stime,
non prove di identità né autorizzazione.

La manutenzione audit applica rotazione giornaliera, retention attiva di 30 giorni e
eliminazione finale a 3 mesi. L'export nativo compresso deve uscire dal data tree:

```bash
sudo -u wg-portal /usr/bin/wg-portal audit-maintain
sudo -u wg-portal /usr/bin/wg-portal audit-export \
  --start 2026-10-01 --end 2026-10-15 --output /srv/wg-portal-audit-2026-10.tar.gz
sudo -u wg-portal /usr/bin/wg-portal idempotency-maintain
```

## Backup, restore e upgrade

Configurare sul server soltanto il recipient pubblico `age`; conservare l'identity
privata offline in almeno due copie. Creare il recovery set in una directory privata
esterna al data tree:

```bash
sudo install -d -o root -g root -m 0700 /srv/wg-portal-recovery
sudo /usr/bin/wg-portal backup-create \
  --environment-file /etc/wg-portal/wg-portal.env \
  --output-dir /srv/wg-portal-recovery
```

Trasferire entrambi i bundle sulla postazione isolata ed eseguire `backup-verify` e
`restore-preflight` secondo il [runbook backup/restore](BACKUP_RESTORE.md). Un backup non
è valido finché entrambi non riescono. `restore-apply` è root-only, richiede set ID e
consenso espliciti, può sostituire dati live e lascia tutte le reti ferme: usarlo solo in
una finestra di disaster recovery seguendo l'intera checklist, mai come test ordinario.

Ogni upgrade richiede predecessore esatto, tutte le VPN ferme, recovery set verificato,
authorization firmata e marker monouso. Seguire integralmente il
[contratto di upgrade](UPGRADE.md); non invocare direttamente `dpkg -i` o `apt install`
su un'installazione esistente. Gli archi collaudati correnti usano schema dati 1 e provano
una migrazione no-op, non compatibilità cross-schema.

## Incidenti

Considerare SEV-1 qualunque sospetta esposizione di chiavi/token, accesso cross-tenant,
instradamento Internet via VPN, perdita d'integrità audit o controllo non autorizzato
dell'helper. Non cancellare file, registry o journal e non eseguire comandi host manuali.
Preservare request ID, timestamp, versione package e soli log redatti, quindi applicare
[classificazione, contenimento e recovery](INCIDENT_RUNBOOK.md).

## Collaudo amministratore end-to-end

Eseguire questa procedura su host pulito o laboratorio autorizzato, mai su produzione.
Registrare data, package, hash configurazione e risultati senza includere segreti.

1. Verificare Debian 12 `amd64`, fingerprint APT e installazione pulita; confermare package,
   unità, `doctor`, helper, `/healthz`, `/readyz` e audit.
2. Configurare Caddy con hostname reale e allowlist minima; provare HTTPS da origine
   ammessa e `403` da origine negata. Verificare che Gunicorn non ascolti su TCP.
3. Completare `admin/admin` soltanto tramite tunnel loopback e cambiare password.
4. Creare due tenant, un admin multi-tenant, un manager per una sola rete e una sessione
   per ruolo; provare URL cross-tenant e aspettarsi una risposta non enumerabile.
5. Creare due reti RFC1918, inclusa una coppia sovrapposta cross-tenant solo con capability
   VRF presente; verificare il rifiuto dell'overlap nello stesso tenant e delle porte fuori
   range o duplicate.
6. Creare due client attivi nella prima rete, scaricare i profili con riautenticazione,
   avviare la rete e attendere il job. Verificare handshake, traffico client-to-client,
   assenza di default route/Internet e isolamento dall'altra rete.
7. Disabilitare, riattivare e revocare un client; verificare peer live, reservation IP,
   job e dashboard. Liberare l'IP soltanto dopo revoca/archiviazione.
8. Creare dalla UI l'accesso API bootstrap, creare tramite API un'identità manager scoped,
   provare lettura/mutazione/idempotenza/ETag, ruotare e revocare; vecchi token e job in
   coda devono essere negati.
9. Ruotare il keyring, eseguire rewrap e audit; verificare che i download esistenti siano
   ancora decifrabili soltanto tramite i flussi autorizzati.
10. Creare un recovery set, verificarlo e completare il restore preflight offline. Il
    restore applicativo si prova soltanto su una copia del laboratorio seguendo il runbook.
11. Eseguire il solo arco upgrade dichiarato usando authorization firmata; verificare
    rollback/restore in un drill separato. Non dedurre supporto per altre versioni.
12. Raccogliere health, readiness, audit e journal redatti; fermare e rimuovere tutte le
    reti di prova tramite UI/reconcile e confermare assenza di residui WG/VRF/nftables.

La release può avanzare soltanto se ogni risultato è verde, nessun segreto compare nelle
evidenze e ogni anomalia è registrata nella roadmap. Il verbale R16 dei comandi e link è
in [verifica del manuale amministratore](ADMIN_GUIDE_VERIFICATION_R16_2026-10-15.md).
