# Verifica manuale amministratore R16 — 2026-10-15

## Oggetto

Verifica della guida `docs/ADMIN_GUIDE.md` rispetto al candidate tecnico installato
`wireguard-system 0.1.0-17` e al codice sorgente corrente. La verifica è read-only sul
server, salvo i drill reali già referenziati; non sono stati ripetuti restore, upgrade o
mutazioni rete.

## Target e risultato

| Controllo | Risultato |
|---|---|
| host | `vrt-debian1`, Debian 12, `amd64` |
| package | `install ok installed 0.1.0-17` |
| unità attive | web socket, reconciler, helper socket e Caddy `active` |
| unità abilitate | web socket, reconciler, helper socket e health timer `enabled` |
| Caddy | `caddy validate --config /etc/caddy/Caddyfile`: valido |
| socket HTTP | `/healthz` `ok`; `/readyz` tutti i cinque check `OK` |
| reconciler | `reconciler-health`: `OK` |
| audit | due giornate e catene HMAC verificate |
| helper | probe JSON riuscito come `wg-portal` |
| dpkg | `dpkg --audit` senza output |

Il candidate contiene e accetta `--help` per tutti i sottocomandi citati dalla guida:
`doctor`, `helper-probe`, `audit-verify`, `audit-maintain`, `idempotency-maintain`,
`audit-export`, `keyring-rotate`, `keyring-rewrap`, `reconciler-health`, `backup-create`,
`backup-verify`, `restore-preflight` e `restore-apply`. Sono inoltre presenti i binari
operativi `apt-get`, `caddy`, `curl`, `dpkg-query`, `gpg`, `install`, `journalctl`,
`runuser`, `ssh`, `systemctl`, `wg` e `wg-quick`.

I comandi mutanti sono verificati per sintassi sul candidate e per comportamento dai
drill già conclusi: Caddy/installazione R04 e R14, backup/restore M4.2, upgrade R07–R11,
incident response R04 e rete reale M2.5/M2.6. Non sono stati rieseguiti soltanto per
documentare la guida.

## P-030 scoperto e corretto

La review operativa ha scoperto che `0.1.0-17` non offre un percorso per creare la prima
identità API: tutte le route service-account richiedono già un bearer superadmin e la voce
UI non era collegata. P-030 è stato registrato prima della modifica.

Il codice corrente aggiunge viste superadmin create/list/detail/rotate/revoke. Create
produce un'identità bootstrap globale, mostra il token una sola volta con `no-store`, non
lo persiste e consente poi di creare via API identità least-privilege e revocare il
bootstrap. I test esercitano token valido, rotazione, revoca immediata, RBAC, form chiusi,
limite di 24 ore per `client.config:read` e assenza dei bearer dallo storage. La correzione
entrerà nel candidate finale; non viene attribuita retroattivamente al package `0.1.0-17`.

## Verifica documentale automatica

`tests/test_admin_guide.py` risolve ogni link relativo della guida, confronta ogni comando
`wg-portal` citato con il parser CLI reale e richiede tutte le aree di R16. La suite
completa resta il gate conclusivo. Nessun link rotto o sottocomando inesistente è ammesso.

## Esito

Manuale, comandi e rinvii sono coerenti con il confine Debian 12 e con le evidenze reali.
Le operazioni distruttive restano subordinate ai rispettivi runbook. R16 può chiudersi
dopo il quality gate completo e il commit, senza promuovere il candidate testing a v1.
