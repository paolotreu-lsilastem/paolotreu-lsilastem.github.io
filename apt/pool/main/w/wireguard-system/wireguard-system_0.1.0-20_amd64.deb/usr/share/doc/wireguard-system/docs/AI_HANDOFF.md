# Handoff per AI e collaboratori

## Ordine di lettura obbligatorio

1. `README.md`
2. `INSTALL.md` per prerequisiti e confine fra prototipo e produzione
3. `docs/SPECIFICATION.md`
4. `docs/API.md`
5. `docs/UI.md` per route HTML, template o stili
6. `docs/SECURITY.md`
7. `docs/ARCHITECTURE.md`
8. `docs/DATA_MODEL.md`
9. `docs/USER_DECISIONS.md`
10. `docs/ROADMAP.md`
11. `CHANGELOG.md`
12. `docs/OPERATIONS.md` per modifiche a deploy, credenziali o runbook
13. `docs/LOCAL_TEST_ENVIRONMENT.md` e `docs/LAB_BASELINE_RECOVERY.md` quando servono
    test privilegiati o interventi sul laboratorio
14. `docs/DISASTER_RECOVERY_DRILL.md` per evidenze e limiti del restore reale
15. `docs/INCIDENT_RUNBOOK.md` e `docs/INCIDENT_DRILL.md` per osservabilità e incidenti
16. `docs/SUPPLY_CHAIN.md` per audit dipendenze, SBOM e gate di rilascio
17. `docs/RELEASE_SIGNING_CEREMONY_2026-10-13.md` per fingerprint ed evidenze R06
18. `docs/UPGRADE_DRILL_R07_2026-10-13.md` per authorization e upgrade reale R07
19. `docs/UPGRADE_FAILURE_DRILL_R08_2026-10-13.md` per rifiuti e crash consumo R08
20. `docs/UPGRADE_ROLLBACK_DRILL_R11_2026-10-14.md` per rollback/restore e P-026
21. `docs/M4_4_CLOSURE.md` per la matrice conclusiva R01–R12 e i limiti residui
22. `docs/API_CREDENTIAL_COMPROMISE_DRILL.md` per rotazione/revoca operativa R13
23. `docs/CADDY_EXPOSURE_DRILL_R14_2026-10-14.md` per il confine proxy/API R14
24. `docs/API_EVOLUTION.md` e il verbale R15 per versioning, migrazione e rollback API
25. `docs/ADMIN_GUIDE.md` e il verbale R16 per il percorso operativo end-to-end
26. `docs/OPERATOR_GUIDE.md` e il verbale R17 per workflow UI e ruoli
27. `docs/SECURITY_AUDIT_PACKAGE.md`, `docs/SECURITY_AUDIT_CONTROL_MATRIX.md`, verbale
    freeze R18, waiver R19, verbali R20–R22 e `docs/M4_5_CLOSURE_R23_2026-10-15.md`
    per il rischio di assurance e il freeze correnti
28. `docs/FINAL_CANDIDATE_R24_2026-10-15.md` per artefatti, firma e lifecycle APT finali
29. `docs/R25_REMEDIATION_P054_2026-10-15.md` per il NO-GO di `0.1.0-18` e il freeze correttivo
30. `docs/RELEASE_CANDIDATE_0.1.0-17.md` per il candidate tecnico storico corrente in testing
31. `docs/RELEASE_CANDIDATE_0.1.0-16.md` per il candidate rollback rifiutato in R11
32. `docs/RELEASE_CANDIDATE_0.1.0-13.md` per il primo candidate consecutivo di R05
33. `docs/RELEASE_CANDIDATE_0.1.0-12.md` per il predecessor installato di R03
34. `docs/RELEASE_CANDIDATE_0.1.0-11.md` per il più recente rifiuto fail-closed di R03
35. `docs/RELEASE_CANDIDATE_0.1.0-10.md` per il precedente rifiuto fail-closed di R03
36. `docs/RELEASE_CANDIDATE_0.1.0-9.md` per le evidenze storiche non pubblicabili
37. `docs/RELEASE_SIGNING.md` per firma, verifica, rotazione e revoca
38. test relativi al task scelto

## Stato corrente — R25 in remediation P-054

R25 ha installato con autorizzazione firmata `0.1.0-18` da `0.1.0-17` e completato i
gate UI, API, Caddy, rete multi-client, isolamento, dashboard/telemetria, revoca live e
restore isolato. Il gate remove/reinstall ha però trovato P-054: lo stato dpkg
`config-files` veniva instradato nel guard upgrade/rollback e la reinstallazione della
stessa revisione era negata. Il candidate `0.1.0-18` è quindi **respinto** e non va
pubblicato stable. Il laboratorio è nuovamente sano su `0.1.0-18` dopo purge non
distruttivo e installazione pulita, con hash persistenti invariati.

`0.1.0-19` ha superato upgrade firmato `0.1.0-17 → 0.1.0-19`, persistenza, health e
cleanup reale dei 292 bytecode P-055, ma è stata respinta nel successivo remove/reinstall.
Il debug dpkg ha provato l'invocazione `preinst install 0.1.0-19 0.1.0-19`: secondo
`deb-preinst(5)` questa forma identifica un package rimosso, mentre il query dello stato
interno usato da `0.1.0-19` avveniva dopo la transizione dpkg e non poteva più osservare
`config-files`. Il laboratorio è stato recuperato senza perdita con purge e installazione
pulita ed è sano su `0.1.0-19`.

La remediation corrente è `0.1.0-20`, predecessor invariato `0.1.0-17`, freeze previsto
`v0.1.0-20-rc3-freeze`. Il delta deve usare direttamente il contratto argomenti
`install old-version new-version`, mantenendo upgrade, rollback e recovery sui guard
firmati esistenti. Dopo gate locale e commit/tag servono build, firma release e retry
reale; una nuova authorization è necessaria perché cambia il digest del candidate.
Leggere prima `docs/R25_REMEDIATION_P054_2026-10-15.md` e il primo checkbox aperto R25.

Esistono scaffold Flask, configurazione rigorosa, CLI applicative e diagnostiche,
repository JSON atomico, schemi v1 per user, tenant, network, client, job e audit, CRUD scoped
con optimistic concurrency, indice derivato ricostruibile e registry di migrazioni
forward-only. Il dominio puro valida RFC1918, IP client, overlap fail-closed, endpoint,
porte, interfacce e lifecycle, inclusi allocazione deterministica e rilascio esplicito
degli IP. Il caricatore verifica gli schemi packaged e lo storage applica anche i format
checker. Login/logout/cambio password sono operativi con Argon2id, sessioni, CSRF e rate
limit persistente; tenant, utenti, reti, client, job e download configurazione dispongono
di flussi HTML scoped. La policy RBAC
centralizzata applica scope object-level, protezioni per utenti
multi-tenant e salvaguardia dell'ultimo superadmin, con matrice negativa cross-tenant. Il
registro audit JSONL è append-only, concatenato con HMAC, ruota per giornata, viene
compresso dopo 30 giorni ed eliminato al compimento di tre mesi; CLI dedicate verificano,
mantengono ed esportano intervalli. `doctor` e `host-probe` sono esclusivamente read-only.
Il probe usa argv fissi e assoluti, scarta le chiavi private del dump, espone fingerprint
peer e rileva kernel, forwarding, systemd e nftables. M2.2 cifra le chiavi private con
AES-256-GCM e AAD scoped, usa un keyring esterno rotabile, offre rewrap idempotente e
protegge accesso/rotazione client con RBAC, password corrente e audit. La rotazione è
persistita ma diventerà effettiva sul peer solo tramite il reconciler M2.5. M2.3 compila
configurazioni `wg-quick` deterministiche: server con soli client attivi e route `/32`,
client con solo CIDR VPN, keepalive 25 e chiavi private verificate contro la pubblica. I
campi liberi e le direttive host non entrano nell'output. M2.4 introduce un helper root
per connessione attivato da systemd, autenticazione UID bilaterale via `SO_PEERCRED` e un
protocollo JSON v1 chiuso. Il client è registrato nella app factory ma non connette durante
l'avvio. Le mutazioni non accettano mai argv, path o testo di configurazione non validato
nuovamente nel processo privilegiato.

M2.5 è completata: `JobService` persiste job di rete idempotenti usando il request ID,
applica RBAC, CAS, progresso monotono, audit intent/esito e recovery dei job `running`
interrotti. È registrato nella app factory. Il protocollo helper espone envelope chiusi
`network.apply`/`network.stop` collegati a un executor che
usa argv fissi `ip`/`wg`, rivalida la grammatica server, verifica l'actual state e tenta
rollback da snapshot esclusivamente in memoria. Il registry root-owned atomico è separato
dal data tree web, vincola rete/interfaccia e conserva solo digest e metadati. Apply,
retry idempotente e stop sono stati provati sul target Debian reale con cleanup completo.
Il worker `NetworkJobWorker` collega ora job, rivalidazione RBAC, documenti canonici,
compiler, chiavi in memoria e helper. `wg-portal worker-once` consuma al massimo il job
queued più vecchio e redige errori/payload. `wg-portal reconcile-once` e il servizio
`wg-portal reconciler` recuperano job interrotti e convergono soltanto reti con drift,
tramite job di sistema limitati al reconcile; worker e reconciler condividono un lock
globale. Il probe include indirizzi e fingerprint SHA-256 completi; errori causano backoff,
mai assunzione di stato stopped. Il helper ripara configurazione/indirizzo alterati con
rollback o pulisce record stale. Handshake, traffico bidirezionale, perdita/ricreazione
dell'interfaccia hub e nuovo handshake sono stati verificati tra la VM Debian e la WSL.
Lo snapshot ignora soltanto gli endpoint peer appresi a runtime, così stop e rollback
restano operativi dopo traffico reale. M2.6 implementa il piano di isolamento:
una VRF per rete, route table `10000`–`59999` allocata deterministicamente e tabella
nftables per interfaccia. Il registry privilegiato v2 persiste modalità VRF, route table,
CIDR e IP hub, impedisce collisioni/cambi d'identità e migra atomicamente v1 lasciando le
entry legacy con isolamento nullo. Migrazione e idempotenza sono state provate sul target
Debian reale. Le primitive host usano argv assoluti di `ip`/`nft`, confrontano
semanticamente VRF, master e ruleset JSON ignorando soltanto handle/metadati runtime e
rifiutano forwarding disabilitato. Il helper usa ora un executor multi-risorsa: prepara
WireGuard ancora down, crea e collega la VRF, applica nftables, attiva l'interfaccia e
registra lo stato soltanto dopo le verifiche. Retry, drift, stop e failure point hanno
rollback esplicito; un rollback incompleto produce `ROLLBACK_FAILED`. La transazione è
stata provata sul target reale tramite socket del helper, inclusi retry idempotente,
riparazione di una regola nft estranea e cleanup completo. L'overlap cross-tenant è ora accettato
dal dominio solo in presenza della capability esatta `per-network-vrf-v1`, pubblicata
unicamente dal helper isolato corrente; assenza o valori diversi restano fail-closed.
L'integrazione worker/reconciler è attiva: il probe privilegiato aggiunge per ogni entry root-owned lo stato
`ok`/`drift`/`legacy` di VRF e nftables, senza esporre segreti. Il reconciler valida la
forma completa, considera drift anche entry mancanti o residue e programma apply/stop;
risposte ambigue fanno fallire l'intero ciclo. I nuovi errori host vengono preservati dal
worker con messaggi pubblici redatti. Rilevamento e riparazione sono stati provati tramite
socket reale con l'UID `wg-portal`. Due tenant con `10.254.246.0/29` identico sono stati
provati in namespace distinti: ogni client raggiungeva il proprio hub, mentre entrambi i
tentativi cross-tenant fallivano; cleanup completo verificato. L'acceptance finale ha
inoltre verificato due client nella stessa VPN, traffico bidirezionale via hub, blocco
verso LAN e Internet simulati anche con `AllowedIPs = 0.0.0.0/0`, revoca live di un peer
senza ricreare l'interfaccia o interrompere gli altri e due reti con CIDR identico. La
policy nft usa il master VRF come interfaccia di ingresso nei hook input/forward e la
slave WireGuard come uscita forward, in accordo con quanto osservato sul kernel Debian.
M2.6 è chiusa.

L'API pubblica è stata accettata come requisito e pianificata in M3. M3.1 ha chiuso il
threat model e il contratto normativo OpenAPI 3.1 in `docs/openapi/v1.json`: prefisso
versionato, proiezioni senza segreti storage, Problem Details chiusi, paginazione a cursore
50/200, ETag `"rev-N"`, `If-Match`, `Idempotency-Key`, job asincroni e download `no-store`.
I contract test verificano JSON senza duplicati, riferimenti locali, schemi componenti,
security, operation ID, errori, paginazione, precondizioni e campi sensibili. ADR 0019
registra le scelte; M3.7 ha aggiunto conformance e compatibility test contro route reali.
Le quattro
decisioni su autenticazione, download delle configurazioni client, esposizione di rete e
operazioni distruttive sono state chiuse il 2026-09-27 confermando integralmente le
raccomandazioni; ADR 0016 ne fissa il confine di sicurezza.

M3.2 aggiunge documenti versionati separati `service_account` e `api_credential`, path
canonici e indici ricostruibili. Il token one-time `wgp_v1.<uuid>.<secret>` usa 32 byte
casuali; soltanto l'hash Argon2id viene persistito. L'identità conserva il puntatore alla
sola credenziale attiva: rotazione e revoca lo cambiano con CAS, così vecchi record non
sono autenticabili e i fallimenti rimuovono credenziali orfane. Scadenza massima 90 giorni,
ridotta a 24 ore per `client.config:read`. Errori ignoti/scaduti/revocati/corrotti sono
uniformi con hash dummy. Il rate limit persistente usa coppia credenziale+IP e IP globale;
servizi token/lifecycle sono registrati nell'app factory. Lifecycle superadmin-only,
scope di assegnazione canonici e audit intent/esito non contengono token o hash. ADR 0020
documenta il puntatore attivo.

Il primo sottogate M3.3 è implementato. Il blueprint `/api/v1` autentica Bearer token,
propaga/genera request ID, restituisce Problem Details, applica rate limit e registra
letture di tenant, utenti, reti, client, job e service account. `ApiReadService` effettua
RBAC object-level e proiezioni allowlistate; fuori scope e inesistente producono lo stesso
404 e le negazioni autenticate sono auditate. Le liste sono ordinate per
`(created_at,id)` con limiti 50/200 e cursori AES-256-GCM validi 15 minuti, legati a
identità, collezione e filtri. Query sconosciute/duplicate sono negate; chiavi, envelope,
password/token hash, attori e payload job non escono. ADR 0021 registra la scelta. M3.3
è completata anche dalla telemetria `/networks/{id}/telemetry`. `TelemetryService` autorizza
prima del probe e richiede coerenza fra capability, registry privilegiato, isolamento,
interfaccia e insieme completo dei peer; associa fingerprint e client attivi soltanto in
memoria. Probe vecchi oltre 60 secondi, errori e drift producono `unknown` senza aggiornare
la cache. `PresenceTracker` persiste sotto `runtime/presence` stato, endpoint, handshake,
contatori e finestra “online dal” stimata con schema chiuso e scritture atomiche. La soglia
globale è configurabile e vale 180 secondi: `stale` fino al doppio, poi `offline`; una rete
stopped è offline solo se l'assenza runtime è verificata. ADR 0022 registra il modello.
Il primo sottogate M3.4 aggiunge lo schema e lo store idempotency persistente: ogni UUID è
legato a service account, operazione e digest canonico, prealloca l'ID risorsa e conserva
solo risposte 2xx redatte. I record `pending` consentono recovery con lo stesso ID.
`POST /tenants` e `PATCH /tenants/{id}` sono superadmin-only, usano JSON chiuso,
ETag/If-Match, lock globale degli slug e audit di intenti/esiti/rifiuti; soltanto il
blueprint bearer API è esente dal CSRF a cookie. ADR 0023 registra il disegno. Il
secondo sottogate aggiunge create/update utenti: password iniziale Argon2id con cambio
obbligatorio, username globale case-insensitive, assegnazioni validate, ultimo superadmin
e modifiche admin prive di effetti cross-tenant. ADR 0024 registra la policy. Il terzo
sottogate espone create/rotate/revoke dei service account, superadmin-only, con ETag,
idempotenza e token casuale nella sola prima risposta. Create/rotate persistono una copia
redatta e un replay completato restituisce `409 CREDENTIAL_RECOVERY_REQUIRED`; un marker
interno per mutazione rende il recovery post-crash distinguibile da un ETag obsoleto senza
salvare o derivare il secret. Revoke resta normalmente riproducibile. ADR 0026 registra
la scelta confermata. Il quarto sottogate espone create/update/archive delle reti senza
effetti host: chiavi generate e cifrate, interfaccia derivata dall'UUID, porta automatica
con collisioni DNS/IP, overlap e RBAC validati. Endpoint, porta e lifecycle richiedono la
rete stopped per impedire apply indiretti del reconciler; manager non può archiviare.
Create fallisce `503` se la master key non è caricata. ADR 0027 registra questi invarianti.
Il quinto sottogate completa M3.4 con create/update e lifecycle client. Create genera e
cifra internamente la chiave, assegna un IP automatico o manuale e produce
`pending/reserved`; le risposte espongono solo la fingerprint. PATCH accetta nome e
descrizione. Le azioni sono `activate|disable|revoke|archive|release-ip`: activate e le
transizioni da active richiedono rete stopped, mentre revoca/archive conservano l'IP e
il rilascio resta separato. Nessuna operazione crea job o contatta il helper. ADR 0028
registra il confine. La retention
idempotency è confermata: completed a
24 ore, pending solo segnalati, quota predefinita 1000 per identità e riserva disco 256
MiB. `idempotency-maintain` applica la policy e ogni nuova chiave esegue cleanup lazy.
ADR 0025 registra retention, quota e comportamento fail-closed.

Il primo sottogate M3.5 espone le azioni rete `start|stop|sync|reconcile`. Il body deve
essere `{}` e sono obbligatori ETag e idempotency key. `NetworkActionService` condivide il
lock del worker/reconciler, aggiorna desired state e marker di recovery per start/stop e
accoda un job; la route restituisce `202` e non esegue inline il worker. I job API usano
`actor_service_account_id` e `actor_credential_id`, forma one-of additiva rispetto ai job
legacy con `actor_user_id`. Il worker rivalida account, credenziale esatta e non scaduta,
RBAC e tenant prima del helper. ADR 0029 registra il disegno.

Il secondo sottogate M3.5 abilita lifecycle client su reti running. `ClientActionService`
aggiorna client e marker sotto lo stesso lock globale; se la transizione aggiunge o
rimuove un peer attivo accoda `network.sync` e restituisce `202`, altrimenti restituisce
il client con `200`. Retry fra patch ed enqueue e job già esistenti sono idempotenti; il
job mantiene service account e credenziale per la rivalidazione worker. ADR 0030 registra
il protocollo.

Il terzo sottogate completa M3.5 con `JobQueueLimits`: conta job `queued/running` sotto
un lock di capacità e applica default 1000 globali, 25 per identità, 100 per tenant e 10
per rete. Le azioni eseguono il preflight prima della patch; a capacità esaurita l'API
risponde `429 QUEUE_CAPACITY_EXCEEDED` con `Retry-After` e lascia il pending idempotente
recuperabile. I terminali liberano quota, i retry esistenti non la duplicano e il
reconciler tratta la saturazione come contesa/backoff rispettando globale/tenant/rete.
ADR 0031 registra la policy.

M3.6 implementa il download individuale `/clients/{id}/configuration`.
`ClientConfigurationService` accetta solo principal macchina con `client.config:read`,
ricarica account e credenziale sotto il medesimo lock di rotate/revoke, verifica durata
totale ≤24 ore, scope e lifecycle attivi, quindi decifra la sola chiave client e usa il
compiler in memoria. La risposta è attachment `text/plain`, `no-store/no-cache`, senza
ETag; negazioni sono 404 non enumerabili, failure interne 503 redatte e ogni tentativo è
auditato senza segreti. ADR 0032 registra il confine.

R13 ha poi verificato la compromissione simulata end-to-end: un account manager di rete
con `client.config:read` può leggere, scaricare e accodare prima della rotazione; il
vecchio token riceve poi 401 uniforme e 429 su abuso, il job già queued termina
`JOB_AUTHORIZATION_REVOKED` senza raggiungere l'helper, la credenziale sostitutiva è
valida soltanto fino alla revoca e audit/persistenza non contengono token o configurazioni.
Il verbale è `docs/API_CREDENTIAL_COMPROMISE_DRILL.md`.

R14 ha poi verificato sul Caddy 2.6.2 reale HTTPS con CA, HTTP/2/HSTS, origine loopback
ammessa, origine LAN negata, spoofing dell'allowlist e sovrascrittura degli header fino
all'audit applicativo. Ha aggiunto il limite proxy `1MB` e una variante mTLS validata che
protegge l'intero origin senza rimuovere l'allowlist. Il test oversize ha trovato P-029:
un rifiuto CSRF pre-hook trasformava `413` in `500` per request ID nullo nel logger; la
regressione ora garantisce `413`, correlazione e log valido. Caddyfile live e servizi sono
rimasti invariati, nessun artefatto temporaneo è residuo e Internet resta vietata. Evidenze:
`docs/CADDY_EXPOSURE_DRILL_R14_2026-10-14.md`.

R15 formalizza in `docs/API_EVOLUTION.md` modifiche additive, deprecazione con header
standard, coesistenza per l'intera release stabile successiva, major parallele, rollout
server-first e rollback client-first dopo l'adozione. ADR 0097 vieta di sovrascrivere una
baseline pubblicata. `openapi-contract.py drill`, ora parte del quality gate, accetta in
memoria un parametro opzionale e rifiuta la rimozione di un'operazione preservando i byte
di contratto, baseline e copia packaged. Il verbale è
`docs/API_EVOLUTION_DRILL_R15_2026-10-14.md`; M4.6 è chiusa.

R16 pubblica `docs/ADMIN_GUIDE.md`: installazione, bootstrap, Caddy, RBAC, reti/client,
chiavi, API, osservabilità, recovery, upgrade, incidenti e collaudo end-to-end hanno ora
un percorso unico con rinvii ai runbook specialistici. Sul candidate `0.1.0-17` sono stati
verificati host, package, servizi, Caddy, health/readiness, audit/helper e help di ogni
sottocomando citato; i link e i nomi CLI sono sotto test automatico. La review ha trovato
P-030: non esisteva un bootstrap della prima identità API. Il sorgente corrente aggiunge
alla UI superadmin create/list/detail/rotate/revoke, token one-time `no-store`, bootstrap
globale transitorio e test di RBAC, revoca/rotazione, durata sensibile e assenza secret.
La correzione non è attribuita al package già costruito e deve entrare nel candidate
finale. Evidenze in `docs/ADMIN_GUIDE_VERIFICATION_R16_2026-10-15.md`; il prossimo task
vincolante era R17, manuale utente/operatore e scenario completo dei tre ruoli.

R17 pubblica `docs/OPERATOR_GUIDE.md`, che descrive accesso, scope dei tre ruoli,
lifecycle rete/client, job, dashboard, download e gestione degli errori senza procedure
shell. La review ha trovato P-031: start/stop/sync/reconcile erano disponibili via API ma
non dalla UI. Il sorgente corrente aggiunge azioni confermate, scoped, revisionate e
monitorate; test negativi coprono CSRF, IDOR, form chiusi e concorrenza. Il drill
`scripts/operator-role-drill.py` è verde come utente `wg-portal` su Debian 12 usando
Python e dipendenze del package `0.1.0-17`, overlay corrente e storage interamente
temporanei. Nessun documento live o servizio è stato mutato e gli artefatti sono stati
rimossi. P-030/P-031 entreranno nel candidate finale e non sono attribuiti al package
già pubblicato. Evidenze in
`docs/OPERATOR_GUIDE_VERIFICATION_R17_2026-10-15.md`.

R18 riserva senza costruirla la revisione `0.1.0-18`, vincolata a `0.1.0-17`, chiude
P-028 delimitando il package a Python `>=3.11, <<3.12` e pubblica dossier e matrice dei
controlli per una review senza briefing orale. `scripts/prepare-audit-package.py` accetta
soltanto il commit `HEAD` pulito, scansiona i blob per marcatori di chiavi private e
produce manifest, inventario e archivio deterministico. P-032 registra e corregge la
vecchia descrizione CSP con nonce. La revisione resta non costruita: il prossimo gate è
R19, audit indipendente, e P-018 sulla keyring APT resta aperto per R23/R24.
Il target preparato per la review è `d09bce0741b6d458385d7e84dde5767642620f04`; hash,
inventario, gate e limiti sono attestati in
`docs/SECURITY_AUDIT_FREEZE_R18_2026-10-15.md`. Il maintainer ha poi chiuso R19 senza
audit esterno per mancanza di risorse e urgenza di consegna. ADR 0099 e
`docs/SECURITY_AUDIT_WAIVER_R19_2026-10-15.md` vietano ogni rivendicazione di audit,
accettano P-005 come rischio alto e mantengono l'audit come debito post-v1. R20/R21 devono
eseguire i controlli compensativi interni; non costruire ancora `0.1.0-18`.

R20 ha trovato P-035: un cookie aperto su un altro browser sopravviveva a un cambio
password. Il cookie include ora la revisione utente e fallisce chiuso se assente, non
intera o stale; ADR 0100 e `docs/SECURITY_REMEDIATION_R20_2026-10-15.md` registrano
correzione e gate da 257 test. Non restano finding interni critici/alti noti nello scope
auth/sessioni/RBAC/API/job/segreti. R21 copre ora helper, isolamento, storage, recovery,
package e supply chain.

R21 non ha trovato nuovi finding critici/alti interni. Il gate ha rieseguito 463 test
avversariali su helper, WireGuard/VRF/nftables, storage, backup/restore, upgrade,
packaging e supply chain; soltanto l'integrazione APT reale opt-in è rimandata a R24/R25.
Una scansione `pip-audit 2.10.1` del 2026-10-15 copre tutte le 24 dipendenze production
hash-locked senza vulnerabilità note; manifest, audit JSON e SBOM sono versionati sotto
`docs/evidence/r21/`. `systemd-analyze security --offline=yes` classifica tutte le unità
come `OK` (helper 4.5, web 3.9, reconciler e health 3.8). Il verbale è
`docs/SECURITY_REMEDIATION_R21_2026-10-15.md`. Questi controlli non sostituiscono l'audit
indipendente: P-005/P-019 restano rischi accettati e P-018 resta blocker per il canale
stabile. Il prossimo task vincolante è R22.

R22 ha riconfermato il laboratorio Debian in sola lettura su `0.1.0-17`: dpkg e systemd
integri, audit e recovery terminali, helper/capability, reconciler, health/readiness e
permessi sono verdi; registry, WireGuard, VRF e tabelle nftables gestite sono vuoti e
forwarding resta `0`. Il socket helper accetta `wg-portal` ma rifiuta root e `nobody`.
Il confronto dal freeze `d09bce0` mostra come unico delta applicativo
`src/wg_portal/web/auth.py`; nessun confine privilegiato, engine, storage, recovery,
packaging, script di release o lock è cambiato. I tre falsi negativi dell'harness SSH
P-036–P-038 sono registrati e risolti senza mutazioni. Verbale e rischi residui sono in
`docs/SECURITY_REGRESSION_R22_2026-10-15.md` e
`docs/RESIDUAL_RISK_REGISTER_R22_2026-10-15.md`. P-005/P-019 restano rischi alti
accettati; a chiusura di R22 P-018 restava blocker del canale stabile e il task
vincolante successivo era R23.

R23 allinea README, installazione, specifica, sicurezza, manuali, supply chain e matrice
audit alla stessa piattaforma supportata: Debian 12 Bookworm `amd64`, Python 3.11,
package finale `0.1.0-18` con predecessor esclusivo `0.1.0-17`. Il candidato è
identificato dal tag annotato `v0.1.0-18-rc1-freeze`; la pipeline rifiuta un `HEAD`
diverso. P-039 è chiuso aggiornando SESS-01 al binding ID+revisione. P-040 è chiuso con
il package separato `wireguard-system-archive-keyring 2026.10.15-1`, builder
deterministico, provenienza/deploy multi-package e ADR 0101. P-018 resta aperto soltanto
per il drill reale di rinnovo/overlap R24. Non costruire o modificare il sorgente dopo il
freeze: R24 deve usare esattamente il tag e richiede firma offline del maintainer.

R24 ha costruito esattamente dal commit congelato `680a21a40ba8c053126ced4ebfbb3291c822719a`
il bundle `0.1.0-18`, poi firmato offline e verificato con policy release e revoche. Il
bundle contiene applicazione e keyring `2026.10.15-1`; checksum, provenienza, SBOM, audit,
metadata Debian, round-trip `reprepro`, idempotenza e client APT sono verdi. Un drill
isolato con chiavi effimere ha mantenuto `apt update` valido lungo A→A+B→B, chiudendo
P-018. Il verbale normativo è `docs/FINAL_CANDIDATE_R24_2026-10-15.md`. Non pubblicare
nel canale stabile: il solo task vincolante rimasto è R25, con installazione e acceptance
privilegiate su Debian pulito e decisione GO/no-GO.

M3.7 pubblica anonimamente soltanto `/api/v1/openapi.json`, servendo una copia packaged
byte-identica del contratto normativo senza console interattiva. `scripts/openapi-contract.py`
sincronizza la copia e confronta ogni modifica con `v1.compatibility.json`; route Flask,
risposte seeded ed esempi sono verificati contro OpenAPI/JSON Schema. ADR 0033 registra
il confine e `docs/openapi/README.md` documenta il processo.

M3.8 introduce `base.html`, lo stylesheet packaged `portal.css` e la proiezione
presentation-only in `web/ui.py`. Login, cambio password, dashboard ed errori condividono
landmark, skip link, focus, responsive/dark/reduced-motion e token colore verificati WCAG
AA. Navigazione e nomi scope sono derivati dalle assegnazioni ma non autorizzano alcuna
operazione. `web/errors.py` separa errori HTML e Problem Details API; CSP consente soltanto
CSS same-origin e vieta script. Le regole complete sono in `docs/UI.md` e ADR 0034.

Il primo sottogate M3.9 registra `web/management.py`: le view tenant usano esclusivamente
`ApiReadService` e `TenantMutationService`, mantengono UUID stabile nei retry create e
revisione nei form update, quindi applicano Post/Redirect/Get. Negazioni di lettura o
modifica producono lo stesso 404 e un evento `ui.authorization`. ADR 0035 registra il
pattern. Il secondo sottogate aggiunge lista, dettaglio, creazione e modifica degli utenti
con `UserMutationService`: form e query chiusi, password iniziale mai riproposta,
revisioni, scope esterni preservati server-side e IDOR uniforme. Admin gestisce soltanto
assegnazioni dei propri tenant; manager riceve 404 auditato e nessun utente può modificare
il proprio account dalla UI o le proprie assegnazioni attraverso il service. ADR 0036
registra il confine.

Il primo sottogate M3.10 registra il blueprint `web/networks.py` con lista e dettaglio
scoped e create a doppia azione preview/salvataggio. `NetworkMutationService.preview_create`
riusa validazione, resolver, allocazione porta e controlli conflitto sotto lock senza
generare chiavi né scrivere; restituisce CIDR, hub, capacità client, endpoint, porta e
nome interfaccia. Create rivalida e genera la chiave soltanto dopo la conferma. Manager
non vede la create e riceve 404 auditato; admin vede esclusivamente tenant e reti propri.
ADR 0037 documenta perché la preview non è una prenotazione. Il prossimo task eseguibile
era update/archive HTML: ora `/networks/{id}/edit` mantiene CIDR/hub immutabili, usa CAS
con revisione e consente nome/descrizione su rete running ma non endpoint, porta o
lifecycle. Manager non può inviare lifecycle; admin/superadmin devono confermare archive
esplicitamente e possono riattivare una rete archiviata. Il prossimo task eseguibile è
M3.11: elenco/dettaglio client per rete, lifecycle asincrono e download configurazione
protetto dalla UI.

Il primo sottogate M3.11 registra `web/clients.py`: `/clients` seleziona fra le reti
visibili, l’inventario è nested per rete e dettaglio/create/update applicano IDOR uniforme.
Create supporta IP automatico o manuale, genera chiavi soltanto nel service e crea sempre
`pending`; UUID stabile rende il retry convergente. Update modifica esclusivamente nome e
descrizione con CAS, lasciando IP, reservation, stato e chiavi immutabili. I template
ricevono solo fingerprint redatta. ADR 0038 registra questo confine.

Il secondo sottogate M3.11 aggiunge conferme dedicate per activate, disable, revoke,
archive e `release-ip`, con revisione e mutation UUID stabile. `ClientActionService`
accetta ora anche l’identità utente interattiva: su rete running accoda un solo
`network.sync` con `actor_user_id`, che il worker rivalida al consumo; le transizioni
senza effetti host restano sincrone. `/jobs` e `/jobs/{id}` mostrano soltanto operazioni
comprese negli scope dell’utente, avanzamento ed error code redatto. In quel sottogate il
refresh era manuale; polling e dialogo sono stati completati in M3.12. ADR 0039 registra
il confine. Il task successivo era il download individuale della configurazione dalla UI:
ora
`/clients/{id}/configuration` ricarica l’utente, rivalida RBAC e password corrente e
compila un solo profilo in memoria. La risposta attachment usa `no-store`, `no-cache`,
nessun ETag; form CSRF chiuso, rate limit e lifecycle scaricabile completano il confine.
ADR 0040 registra la scelta. M3.11 è chiusa.

M3.12 aggiunge `/jobs/{id}/status`, proiezione JSON minima e scoped dello stesso read
service usato dalle pagine. Il redirect dalle azioni live apre un `<dialog>` accessibile;
`static/portal.js` aggiorna stato/progresso, applica backoff fino a 10 secondi, sospende le
richieste a pagina nascosta e termina su `succeeded`/`failed`. I codici errore sono
tradotti server-side in istruzioni allowlistate; il messaggio interno del job non entra
nel JSON o nell’HTML. Lo stesso asset impedisce un secondo submit dei form POST senza
disabilitare il submitter, preservando quindi `name/value` dei pulsanti. CSP passa a
`script-src 'self'`, vietando ancora inline, eval e asset esterni. ADR 0041 registra il
confine.

M3.13 aggiunge `DashboardService`, l’inventario scoped e il pannello live della rete
selezionata. `/` offre un fallback server-rendered; gli endpoint sessione restituiscono
solo metadati allowlistati e riusano il controllo object-level di `TelemetryService`.
`/dashboard/snapshot` acquisisce un solo probe host e calcola separatamente lo stato
effettivo `running`, `stopped` o `unknown` di tutte le reti autorizzate; drift o cache
invalida di una rete non degrada quelle sane. `portal.js` aggiorna conteggi, riepiloghi
rete, client, endpoint, handshake, RX/TX, presenza e “online dal”, con una richiesta in
volo, pausa a pagina nascosta e backoff fino a 60 secondi. Client non attivi sono
`inactive`; errori runtime restano `unknown`. ADR 0042 e 0043 registrano il confine. I
test coprono manager, admin, superadmin, IDOR, redazione e struttura accessibile.

Il primo sottoblocco M4.1 aggiunge Gunicorn 23, `wg-portal-web.socket` e service con
attivazione socket nativa, `/run/wg-portal/web.sock` `wg-portal:caddy` `0660`, nessuna
capability e hardening systemd. `WG_PORTAL_TRUST_UNIX_PROXY` è falso per default e abilita
gli header forwarded solo quando il peer WSGI non ha indirizzo; loopback conserva il
comportamento di sviluppo. Il Caddyfile di riferimento restringe l’intero origin a CIDR
amministrativi e sovrascrive gli header verso il socket. ADR 0044 registra il confine.
Il secondo sottoblocco M4.1 aggiunge `requirements-prod.lock` con hash, builder `.deb`,
payload privato sotto `/usr/lib/wireguard-system`, launcher safe-path e maintainer script. `postinst` genera
environment e keyring solo se assenti, inizializza storage come utente di servizio e
abilita le unità; upgrade preserva contenuti, remove/purge non eliminano stato. Due build
indipendenti amd64 hanno prodotto lo stesso SHA-256. ADR 0045 registra la scelta.
Il collaudo M4.1 su `vrt-debian1` ha chiuso la milestone con il pacchetto `0.1.0-4`:
installazione e upgrade reali, remove/reinstall con stato invariato, socket e servizi,
Caddy 2.6 HTTPS/HSTS, allowlist, header proxy anti-spoofing e bootstrap via tunnel SSH.
Ha inoltre corretto il matcher Caddy, la doppia registrazione del fd Gunicorn e la policy
referrer incompatibile con CSRF strict. ADR 0046 registra le correzioni.

Il primo sottoblocco M4.2 definisce in `BACKUP_RESTORE.md` un recovery set offline con
bundle `data` e `secrets` separati ma legati dallo stesso UUID. Il manifest JSON v1
inventaria path, mode, dimensione e hash; `backup.py` include soltanto stato canonico,
job, audit e idempotenza, esclude cache/lock/registry e rifiuta symlink, file speciali,
permessi estesi, path ignoti o file mutati durante l’hash. ADR 0047 registra il confine.
La scelta `age` con recipient X25519 è approvata e registrata nell'ADR 0048. Il pacchetto
dipende da `age >= 1.1`, `doctor` lo controlla e `AgeEncryptor` pubblica atomicamente
ciphertext `0600` da stream con argv fisso, ambiente minimo e cleanup fail-closed. La
identity resta offline e non esiste fallback a passphrase.
`age 1.1.1` è installato su `vrt-debian1`; un round trip con identity effimera e output
`0600` è riuscito e tutti gli artefatti di prova sono stati eliminati.
Il sottoblocco seguente aggiunge `inventory_secret_files` e
`create_encrypted_bundle`: environment/keyring sono distinti, non linkati e fuori dal
data tree; il tar normalizza metadata e viene compresso direttamente verso `AgeEncryptor`.
Durante la seconda lettura ogni file viene riaperto con `O_NOFOLLOW` e confrontato con
mode, size, inode, timestamp e SHA-256 del manifest.
`recovery.py` aggiunge ora `BackupCreator` e `SystemdQuiescer`; il comando root-only
`backup-create` ferma socket/servizi web, reconciler e helper, verifica il quiesce e
ripristina soltanto le unità originariamente attive anche dopo errori. Prima di creare la
coppia valida repository, idempotenza, audit HMAC, keyring e decifrabilità di tutti gli
envelope. La directory output deve essere privata e fuori dal data tree.
`BackupVerifier` e `backup-verify` chiudono ora la verifica offline: identity X25519
esplicita `0600`, nessun environment/root, decifratura solo in pipe, limiti compressi ed
espansi, metadata tar chiusi, hash di ogni membro e correlazione obbligatoria della
coppia. `backup-verify` non estrae né promuove.
`restore.py` avvia il preflight con `RestoreWorkspace`: staging sibling `0700`, data e
secrets separati, file `O_EXCL|O_NOFOLLOW`, size/hash/mode verificati, fsync e cleanup
confinato automatico; il live data dir resta intatto. `restore-preflight` collega ora i
due stream decifrati allo staging e, senza caricare l’environment live o richiedere root,
valida secrets allowlistati, meta/schema, path canonici, relazioni tra documenti,
regole dominio rete/client, coerenza delle coppie WireGuard, idempotenza, audit HMAC e
tutti gli envelope privati. Il target deve coincidere con il
data dir dichiarato nel set e resta immutato; il plaintext staged viene sempre eliminato.
La promozione del solo data tree è ora implementata internamente da `RestorePromotion`:
su target esistente usa `renameat2(RENAME_EXCHANGE)` senza fallback non atomico, conserva
il vecchio tree in un rollback sibling e lo ripristina su eccezione; target non vuoti
richiedono `replace`. Anche l’uscita da un workspace con transazione irrisolta rollbacka.
L’ADR 0049 registra il vincolo Linux e i limiti dell’exchange. Il journal crash-safe del
data tree è ora implementato: JSON sibling `0600`, UUID, fasi
monotone e identità device/inode vengono sincronizzati prima dei rename. Recovery termina
un `commit_pending`; per ogni fase precedente esegue rollback, pulisce plaintext e blocca
stati ambigui. Nuovi workspace sono rifiutati se esiste una transazione incompleta. L’ADR
0050 registra il protocollo. `RestorePreparer` trasforma inoltre lo staging validato prima
della promozione: job `queued/running` diventano `failed/RESTORE_INTERRUPTED`, ogni rete
diventa `stopped`, revisioni, meta, audit e indice sono coerenti e i lock ricostruibili
vengono rimossi. La fase è idempotente e l’ADR 0051 ne registra il confine.
Il primo incremento secrets crea ora copie candidate sibling di environment e keyring sui
rispettivi filesystem di destinazione, preservando UID/GID/mode host e lasciando invariati i
file live. Target non canonici, linkati o in parent scrivibili falliscono chiusi; cleanup,
detach e promozione dati impediscono candidati orfani. ADR 0052 registra questa strategia.
Il journal v2 registra ora anche path e identità dei due secrets. La promozione coordinata
scambia keyring, environment e data tree; recovery esegue rollback globale prima di
`commit_pending` e completa il commit globale dopo la decisione. Validazione dei parent e
degli inode è fail-closed; i journal v1 del solo data tree restano compatibili. ADR 0053
registra il protocollo.
`RestoreApplier` implementa ora il sottostante flusso root-only: conferma UUID e replace,
recupera journal pendenti sotto quiesce, valida il set in staging, lo rende inerte, prepara
i candidati, ferma tutte le reti del registry e promuove lo stato coordinato. Prima del
commit ricontrolla environment/keyring, documenti ed envelope, audit, indice, reti ferme e
prerequisiti host; registra `restore.apply`. Gli errori nel quiesce lasciano le unità ferme
anche dopo rollback. `ManagedHostStopper` usa direttamente registry ed executor isolato
perché il socket helper è fermo. ADR 0054 registra sequenza e failure policy.
`wg-portal restore-apply` espone ora l'orchestratore con input tutti espliciti,
`--confirm-backup-set-id`, consenso `--replace`, output senza path sensibili e avviso che
gli errori possono lasciare i servizi fermi. ADR 0055 registra il confine CLI.
Il drill è ora completato sul candidate Debian `0.1.0-5`: backup e restore hanno impiegato
3 secondi ciascuno sul dataset di laboratorio, verifica e preflight offline sono passati,
i guard rail non hanno causato downtime e un check finale iniettato ha rollbackato
byte-per-byte lasciando correttamente le unità ferme. Riavvio manuale, health Unix/HTTPS,
audit, cleanup e ritorno degli hash environment/keyring sono stati verificati. Non erano
presenti reti o job canonici; questo limite è esplicito nel report
`DISASTER_RECOVERY_DRILL.md`.
Le migrazioni restore forward-only sono ora collegate: la registry verifica prima una
catena completa, migra soltanto una copia sibling privata, conserva separati albero
estratto e bundle originali, sincronizza ogni passaggio e costruisce un manifest corrente
prima della validazione semantica. Versioni future, step mancanti/non unitari e contenuti
non regolari falliscono chiusi con cleanup. Poiché lo schema corrente è v1 e non esistono
legacy rilasciati, la catena packaged è correttamente vuota; una futura v2 dovrà aggiungere
step v1→v2 e fixture v1. ADR 0056 registra il confine. M4.2 è completata.
M4.3 ha separato `/healthz` e `/readyz`. `ReadinessService` verifica in modo
read-only e redatto storage/schema, journal restore, keyring e helper/capability; risposte
positive e negative sono in cache breve per worker e un fallimento produce `503` senza
dettagli diagnostici. `OBSERVABILITY.md` e ADR 0057 fissano il contratto.
Il logging applicativo JSON line correlato al request ID è completato, con allowlist dei
campi e test negativi su token, cookie, payload, chiavi e path sensibili:
`JsonLineLogger` non accetta messaggi liberi, il web registra endpoint simbolici/stato/durata,
il reconciler soli conteggi e il helper codici stabili. Gli errori web inattesi sono redatti
senza traceback. ADR 0058 registra il confine.
Tutte le unità usano inoltre `LogNamespace=wg-portal`, identificatori,
campo componente e rate limit propri; il drop-in vendor impone 30 giorni/256 MiB
persistenti e 64 MiB runtime senza modificare il journal globale. ADR 0059 registra la
scelta. Il reconciler persiste ora dopo ogni ciclo un riepilogo runtime redatto e
atomico. Readiness, CLI e timer systemd verificano senza scritture freschezza, fallimenti
consecutivi e anzianità dei job outstanding; non chiamano il helper e non eseguono restart
o riparazioni. ADR 0060 registra soglie e failure policy. Il runbook incidenti pubblica
ora triage read-only, severità, matrice completa dei codici, raccolta evidenze redatta ed
exit criteria; un test impedisce omissioni future e comandi distruttivi. Il blocco DNS
del 2026-10-08 è storico: R04 ha completato il drill reale il 2026-10-12 e il verbale è in
`INCIDENT_DRILL.md`.

M4.4 è iniziata con un gate separato per le dipendenze Python di produzione.
`scripts/security-artifacts.py` valida che tutte le entry di `requirements-prod.lock`
siano pinned e hashate, quindi esegue `pip-audit` in modalità strict/disable-pip e produce
report JSON, SBOM CycloneDX e manifest con hash sotto `dist/security/`. Conteggio report e
componenti SBOM devono coincidere con le 24 entry del lock; output incompleti non
sostituiscono evidenze precedenti, mentre i finding vengono pubblicati con exit code 1.
La prova reale del 2026-10-08 con `pip-audit 2.10.1` è risultata pulita e ha generato uno
SBOM CycloneDX 1.4 di 24 componenti. Il candidate locale `0.1.0-8` è stato costruito
correttamente ma non installato sul target. ADR 0061 registra la scelta.

Il formato di provenienza è ora implementato da `scripts/release-provenance.py`: richiede
un worktree pulito, crea un archivio dal commit, copia `.deb`, lock ed evidenze Python,
inventaria control e payload Debian senza estrazione e collega tutto con una Statement
in-toto v1/SLSA Provenance v1. Registra anche backend dichiarati e versioni esatte dei
tool Debian/Python, ma nessun dato dell'operatore. La verifica offline ricalcola ogni hash
e riferimento. ADR 0062 precisa che il local builder non è isolato, non rivendica livelli
SLSA e la Statement non autentica nulla finché non è firmata. La revisione sorgente
prodotta in quella fase era `0.1.0-9`. ADR 0063 aggiunge
`requirements-release.lock` per frontend,
backend, scanner e transitivi; `scripts/build-release-candidate.sh` crea un virtualenv
effimero, neutralizza la configurazione pip locale e collega suite, audit, build senza
isolamento dinamico, generazione e verifica. La provenienza incorpora entrambi i lock e
rifiuta versioni effettive divergenti. La pipeline reale sul commit
`10272fa6134df40c0794faafe433d6c3c56bef91` ha superato 812 test, audit pulito di 24
dipendenze, build `amd64` e verifica offline; package, Statement e inventario di 1.203
entry sono registrati in `docs/RELEASE_CANDIDATE_0.1.0-9.md`. Questa è cronologia
storica: stato e task correnti sono riportati nella sezione conclusiva di questo
riepilogo.

Il primo sottoblocco signing è implementato senza segreti: `scripts/release-signing.py`
genera `SHA256SUMS` canonico dopo una verifica di provenienza e verifica SSHSIG usando
identità/namespace fissi, `allowed_signers` e lista revoche, ricalcolando poi insieme
esatto dei file e digest. Il candidate builder prepara automaticamente il manifest.
Test effimeri Ed25519 coprono successo, tampering, file extra, namespace errato, chiave
revocata, symlink e redazione errori. ADR 0064 e `docs/RELEASE_SIGNING.md` sono normativi.
Il relativo gate esterno richiede di eseguire con intervento umano la cerimonia offline,
portare nel repository
la sola chiave pubblica verificata e la revocation list, firmare il manifest reale e
registrare fingerprint/evidenze; non generare né copiare una chiave privata nel workspace.

Su richiesta del maintainer è disponibile anche `scripts/deploy-apt-package.py`: data una
root assoluta `reprepro`, accetta soltanto un bundle SSHSIG valido, confronta il
fingerprint completo con `SignWith`, esegue `includedeb` senza shell e verifica firma
`InRelease`, indice e package. È idempotente per la stessa versione verificata e redige
gli errori. Con `--pages-root` e `--public-url` prepara inoltre una staging verificata e
sincronizza soltanto `dists/`, `pool/` e materiale client pubblico verso GitHub Pages;
`publish/` può essere esclusivamente un symlink leaf assoluto e non deve mai ricevere lo
stato interno di `reprepro`. ADR 0065, ADR 0092 e
`docs/APT_REPOSITORY_DEPLOYMENT.md` sono normativi. Non creare chiavi private come
scorciatoia e non eseguire automaticamente commit/push del worktree Pages.

Il 2026-10-13 la chiave APT Ed25519
`2B3CFA6779E395C0CDA208B7AE7A30DC2F970ACF` è stata provisionata fuori Git e il bundle
firmato `0.1.0-13` è stato materializzato nel solo canale `bookworm-testing`: seconda
esecuzione idempotente, `gpgv`, checksum e client APT reale sono verdi. Il worktree Pages
è pubblicato come `fdcea87` su `https://paolotreu-lsilastem.github.io/apt/`: deployment
GitHub `built`, confronto CDN byte-per-byte, `gpgv` e `apt update` HTTPS reali sono verdi.
Il backup portabile locale
`var/wireguard-system-apt-key-backup-2026-10-13.tar` ha SHA-256
`f8a47fdb857d19596c67f24e3760edcf9311d1f115537375badcae9506550380`: import e rifiuto
della passphrase vuota sono verificati, ma servono ancora copie fisiche offline. Non
promuovere a `bookworm` prima del GO. P-018 è chiuso dal package keyring e dal drill R24;
la chiave corrente scade il 2028-10-12 e ogni rinnovo/rotazione production deve essere
distribuito prima della scadenza seguendo la finestra di overlap provata.

Decisione utente 2026-10-13: le private SSHSIG R06 sono state copiate sotto `tmp/` sul
filesystem WSL. Il maintainer ha rifiutato esplicitamente una nuova generazione offline e
richiede di continuare a usare queste chiavi per release e upgrade. `tmp/` è ignorata da
Git e i permessi sono ristretti; nessun segreto è stato committato o stampato. Non
riaprire la decisione senza richiesta dell'utente, ma non descrivere più la custodia come
esclusivamente air-gapped dopo tale data. P-019 e `docs/USER_DECISIONS.md` registrano il
rischio residuo accettato.

Il primo sottoblocco upgrade M4.4 è definito da ADR 0066 e `docs/UPGRADE.md`. Il package
storico incorporava schema dati e un solo predecessor (`0.1.0-8 -> 0.1.0-9`);
`scripts/upgrade-preflight.py`, installato anche sotto `/usr/lib/wireguard-system`,
confronta package, stato dpkg, architettura e `meta.json` senza scrivere. Ricevuta firmata,
guard monouso pre-unpack, gate operativi, freeze dei writer e resume di successo sono ora
implementati; restano recovery/rollback dei failure point e drill reali consecutivi.

Il protocollo della ricevuta è ora implementato nello stesso `upgrade-preflight.py`:
prepara JSON canonico `0600` legato a machine-id hashato, candidate, stato dpkg, schema,
UUID e hash dei bundle, con durata default due ore e massimo quattro. La verifica SSHSIG
usa principal `upgrade-operator@wireguard-system`, namespace separato, allowlist e revoche,
poi ricalcola tutto sul target. ADR 0067 e `docs/UPGRADE.md` sono normativi. Test effimeri
coprono successo, tampering, expiry, altro host, revoca, canonicalizzazione e overwrite.
Il guard monouso è ora implementato: `--verify-authorization --arm-upgrade` scrive sotto
`/var/lib/wireguard-system-upgrade` un marker root-only canonico legato alla ricevuta;
il `preinst` del candidate lo valida e lo consuma atomicamente prima dell'unpack,
conservando un tombstone per negare replay. Installazioni pulite restano escluse dal gate.
ADR 0068 e `docs/UPGRADE.md` sono normativi.

I controlli operativi read-only sono ora integrati nell'arming: storage privato, assenza
di restore e job pendenti, health reconciler riuscita entro dieci minuti e budget disco
con riserve chiuse. Il verifier inventaria senza importare l'app e accetta ownership del
service user sui file privati. ADR 0069 registra formule e limiti. Il prossimo task deve
coprire recovery e rollback dei failure point rimasti; fino al relativo drill il percorso
di upgrade resta pre-release e non autorizzato per la produzione.

ADR 0070 aggiunge una precondizione distinta: prima dell'arming tutti i documenti rete
devono avere desired state `stopped` e il registry privilegiato v2 root-only deve essere
canonico e vuoto. L'operatore usa UI/API e attende il reconciler; il verifier non esegue
cleanup host alternativo.

ADR 0071 implementa il freeze: l'arming ferma unità web/reconciler/health/helper con argv
fissi, ripete i gate e ripristina il set originariamente attivo su errore; il `preinst`
nega writer riattivati. Il resume dopo successo è ora implementato dal finalizer
incorporato nel package: usa `active_units`, verifica il set ripartito e scrive una
ricevuta root-only idempotente come definito da ADR 0072. ADR 0073 serializza inoltre
arming, consumo e finalizzazione sul medesimo lock root-only persistente. ADR 0074 aggiunge
`--cancel-armed-upgrade`: prima del consumo ritira il marker con tombstone monouso,
ripristina esattamente i writer e completa una ricevuta ritentabile. Il classificatore
root-only `--recovery-status` di ADR 0075 distingue ora, senza scritture, claim hard-link
incompleto, predecessor/candidate configurato o incompleto, divergenza package e schema.
ADR 0076 implementa `--resume-consumed-predecessor`: trattiene anche il lock dpkg,
ricontrolla predecessor e schema, ripristina il set esatto e attesta il successo sotto
`predecessor-resumed/`. ADR 0077 aggiunge `--resume-configured-candidate`, che richiede il
candidate esatto in stato `installed` e produce la stessa receipt `finalized` del
`postinst`. Il prossimo task deve progettare il repair/rollback degli stati package
incompleti. ADR 0078 separa ora `unpacked`/`half-configured`, `half-installed` e stati
trigger per entrambi i lati dell'arco. ADR 0079 implementa
`--repair-candidate-configuration` per la sola prima classe candidate: scrive
`candidate-repair`, verifica la disponibilità del lock frontend e cede tutti i lock dpkg
prima del comando nativo, poi ricontrolla e finalizza. Il prossimo task deve trattare il
predecessor configurabile oppure definire la reinstallazione attestata; trigger, restore
e rollback post-unpack restano fail-closed.

ADR 0080 porta request e marker di upgrade alla versione 2: preparazione e verifica
richiedono `--rollback-package`, validano il `.deb` come package/versione/architettura/
schema del predecessor installato e ne legano lo SHA-256 alla firma e al marker consumato.
Questo è soltanto il prerequisito attestato: nessun executor usa ancora il package. Il
prossimo task deve definire intenzione durevole, lock handoff e invocazione dpkg per il
rollback/reinstall, oppure continuare a fallire chiuso.

ADR 0081 aggiunge il recovery protocol package v1. Il control field è obbligatorio per
candidate e rollback; il `preinst` del predecessor riconosce `install`/`upgrade` non
ordinari solo con una singola `rollback-intent` root-only coerente con marker consumato,
package hash e writer quiescenti. Il finalizer riconosce la stessa intenzione durante
configure e non riavvia unità né scrive `finalized`.

ADR 0082 implementa `--rollback-predecessor`: tiene aperto l'inode del `.deb` attestato,
verifica la disponibilità del frontend, crea/valida `rollback-intent` e cede tutti i lock
dpkg e quello transazionale al comando nativo, poi richiede il predecessor `installed` e
completa la receipt `predecessor-resumed`. Retry dopo errore dpkg, completamento senza receipt e
resume fallito non riscrivono l'intenzione. Recovery status e selettore validano anche
intenzioni completate, corrotte od orfane. Reinstallazione candidate, restore e drill
reali con due package consecutivi restano aperti nel percorso M4.4.

ADR 0083 implementa `--repair-candidate-triggers` soltanto per `triggers-pending`, con
intenzione `candidate-trigger-repair`, handoff frontend e argv package-scoped
`dpkg --triggers-only wireguard-system`; dopo l'handoff ricontrolla stato `installed` e
usa la receipt `finalized`. Retry dopo errore o completamento senza receipt sono
idempotenti. `triggers-awaited` viene ora classificato separatamente come dipendenza
esterna e resta manuale/fail-closed: non usare `dpkg --configure --pending`, perché
muterebbe package estranei. Il prossimo task non bloccato è la reinstallazione attestata
del candidate oppure la progettazione del restore post-migrazione; il drill reale resta
obbligatorio.

ADR 0084 conserva durante l'arming la request firmata già verificata sotto
`verified-authorization/<authorization_sha256>.json`, canonica, root-only e single-link.
Il digest già presente nel marker collega così in modo durevole anche lo SHA-256 del
candidate, senza cambiare marker v2 o recovery protocol v1 che devono restare leggibili
dal predecessor. La copia è idempotente nei retry, resta disponibile dopo un errore di
quiesce e non è obbligatoria per le transazioni legacy già consumate. Il prossimo task è
il handshake dei maintainer script e l'executor di reinstallazione candidate: deve
richiedere questa copia, validare l'artefatto pinned e mantenere i writer congelati.

ADR 0085 implementa il handshake dei maintainer script per la reinstallazione candidate.
Il `preinst` ammette la stessa versione soltanto con una singola intenzione
`candidate-reinstall-intent` per stato iniziale `half-installed`, marker consumato e
request persistita coerenti; ricontrolla SHA-256 candidate, arco, architettura, schema e
writer quiescenti. Il finalizer ripete la catena, nega intenzioni rollback concorrenti e
non ripristina servizi né scrive `finalized`. Il dispatch preserva la reinstallazione del
predecessor già usata dal rollback quando l'intenzione candidate non esiste. Nessun
executor era incluso in quel gate; artefatto pinned, lock handoff e resume sono aggiunti
separatamente da ADR 0086.

ADR 0086 implementa ora `--reinstall-candidate <deb>`. L'executor richiede inizialmente il
candidate `half-installed`, apre il `.deb` con `O_NOFOLLOW`, ne passa a dpkg il path
`/proc/self/fd` e ne confronta SHA-256 e metadati con la request persistita. Trattiene il
descriptor, verifica il lock frontend, pubblica/riusa `candidate-reinstall-intent`, cede
tutti i lock dpkg e quello transazionale ai maintainer script e finalizza soltanto dopo
stato `installed`, schema e architettura esatti. Retry da stati intermedi o da installazione completata senza receipt
sono idempotenti; recovery status espone le due classificazioni dedicate. Il prossimo
blocco aperto è `triggers-awaited` confinato oppure rollback con restore verificato; segue
il drill reale fra due package consecutivi.

ADR 0087 implementa `--rollback-with-restore`: pinna bundle e identity, verifica UUID e
SHA-256 contro `verified-authorization`, installa il predecessor senza resume e invoca il
restore con descriptor accessibili anche al sottoprocesso `age`. Le ricevute durevoli
`rollback-restore-intent` e `rollback-restored` rendono il retry idempotente; solo dopo
package/schema verificati viene riusato `predecessor-resumed` per l'esatto set di writer.
Il recovery protocol v1 resta limitato a schema uguale. Restano aperti l'executor confinato
per `triggers-awaited` e il drill reale tra due package consecutivi.

ADR 0088 chiude il recovery candidate `triggers-awaited`. L'executor inventaria l'intero
grafo dpkg, calcola la chiusura dei package attesi, nega stati trigger estranei e persiste
identità/versioni/trigger in `candidate-awaited-trigger-repair`. Usa esclusivamente
`dpkg --triggers-only --pending` dopo il precheck e l'handoff del frontend, preservando il
rilevamento cicli; retry e crash dopo completamento sono idempotenti. Il codice dei recovery post-unpack è
ora completo; resta obbligatorio il drill reale tra due package consecutivi prima di
chiudere il percorso upgrade M4.4.

Il 2026-10-08 `vrt-debian1.lsinet.it` è tornato raggiungibile, ma il primo inventario
read-only aveva trovato il package non registrato in dpkg, dati/configurazione e unità
residui, due istanze helper fallite e systemd `degraded`. Questa è evidenza storica:
`R01` ha poi inventariato lo stato e `R03` ha ricostruito la baseline.

Le evidenze `R01` hanno rieseguito il 2026-10-12 un inventario autoritativo, sempre senza
mutazioni. Il
package `0.1.0-5` è ora registrato e integro; servizi principali attivi, dati e registry
vuoto sono coerenti, mentre le due vecchie istanze helper fallite mantengono systemd
`degraded`. Non sono presenti WireGuard, VRF o nftables gestiti e forwarding vale `0`.
`docs/LAB_BASELINE_RECOVERY.md` registra hash redatti, artefatti da preservare e piano di
rollback. `R01` è chiusa; i vincoli documentati hanno governato la successiva R03.

`R02` ha assegnato la revisione univoca `0.1.0-10` e usa il valore
canonico `upgrade-from: none`: il package può essere installato da zero, ma il preflight
rifiuta ogni upgrade in ingresso. `0.1.0-9` resta storico/non pubblicabile; l'arco allora
pianificato era `0.1.0-10 → 0.1.0-11`, poi sostituito da ADR 0090. ADR 0089 resta la
decisione che introduce il sentinel. La pipeline sul commit
pulito `6dab5a8b02d57908caee8a0a5ca578332454041b` ha prodotto e verificato bundle,
`.deb`, audit, SBOM e provenienza; hash e limiti sono in
`docs/RELEASE_CANDIDATE_0.1.0-10.md`. `R02` è chiusa.

Durante `R03`, recovery set e preflight sono riusciti dopo avere aggiunto atomicamente il
recipient pubblico mancante all'environment. Remove senza purge ha preservato tutti gli
hash, ma dpkg ha invocato `preinst install OLD NEW` e `0.1.0-10` ha negato prima
dell'unpack. Il rollback a `0.1.0-5` è riuscito senza variazioni di dati o rete. ADR 0090
definisce la prima correzione: `0.1.0-11` resta clean-install-only ma accetta la forma dpkg
per lo stato `config-files`. Il test successivo ha però rilevato `P-013`: l'`umask 077`
della pipeline rende alcune directory site-packages non attraversabili da `wg-portal`.
Il package ha fallito nel postinst; remove senza purge e reinstallazione pulita di
`0.1.0-5` hanno ripristinato dpkg, servizi e hash. Non reinstallare `0.1.0-10` o
`0.1.0-11`. ADR 0091 corregge P-013: il builder normalizza tutte le directory del package
a `0755` e i file regolari di site-packages a `0644`; la provenienza ricalcola
l'inventario dal `.deb` e rifiuta mode o contenuti incoerenti. La pipeline normativa dal
commit pulito `f290ad9092ac05e06a17c3eb9ec9eb243d10c866` ha prodotto `0.1.0-12`: 1.005
test, audit di 24 dipendenze pulito, SBOM di 24 componenti e 1.240 entry payload
conformi. Hash e limiti sono in `docs/RELEASE_CANDIDATE_0.1.0-12.md`.

R03 è conclusa: `0.1.0-12` è installato e integro, systemd è `running` senza failure,
web/helper/reconciler/health timer/Caddy sono attivi e readiness Unix/HTTPS è verde.
Hash persistenti e digest dati coincidono, audit e recovery sono verificati, registry v2
è vuoto e non esistono WireGuard, VRF, nftables o forwarding residui. Due tentativi hanno
eseguito rollback integro per errori fail-closed del solo harness (`env -i` davanti a
`doctor` e parsing del bullet `●` di systemd); P-014 li registra come problema operativo
risolto. Recovery set, package rollback e identity offline restano confinati per il
successivo arco di upgrade R07.

R04 e M4.3 sono concluse. L'arresto controllato del reconciler ha prodotto
`RECONCILER_STALE` dopo la soglia reale di 600 secondi senza autoriparazione; il restart
esplicito ha prodotto quattro cicli sani. Un socket inesistente confinato al solo
reconciler ha prodotto tre failure con backoff 2/4 secondi e `RECONCILER_FAILED`, mentre
helper reale e web sono rimasti attivi; rimosso il drop-in runtime, due cicli sani hanno
ripristinato health e timer. Unix/HTTPS, namespace journald, hash, audit, registry/rete e
cleanup sono verdi. Il primo override `Environment=` era inefficace per precedenza
dell'`EnvironmentFile`; P-015 e il runbook prescrivono ora l'override temporaneo di
`ExecStart`. Le evidenze redatte root-only restano sul laboratorio.

R05 è conclusa. La pipeline normativa dal commit pulito
`a7e3bacea1f3a2507d2cc20142ccf81876adac68` ha prodotto `0.1.0-13`: 1.006 test, audit di
24 dipendenze pulito, SBOM di 24 componenti e inventario di 1.241 entry. Il `.deb` ha
SHA-256 `96e4714546b682230274ceff85297c6041d9b6a2f40d166e17945aa6f7a2e3e6` e dichiara
soltanto `0.1.0-12` come predecessor. Alla chiusura di R05 il bundle era verificato ma
non firmato né installato; evidenze e hash completi sono in
`docs/RELEASE_CANDIDATE_0.1.0-13.md`. R06–R08 hanno successivamente aggiunto firma,
upgrade reale e failure pre-unpack senza renderlo ancora pubblicabile.

R06 è conclusa. Il 2026-10-13 l'operatore ha generato in ambiente air-gapped chiavi
Ed25519 distinte per release e upgrade, entrambe con passphrase e due backup cifrati
byte-verificati su supporti separati. I fingerprint sono rispettivamente
`SHA256:6KitBJHvrhPyWHGfu8Np+6l4nETVr5RD95lYSapb4rg` e
`SHA256:eK6dmIh0lnDw0YV22nDFDW3Rki82G6TvzPx7Kkpv1dc`. Le firme reali di `0.1.0-12` e
`0.1.0-13` passano il verifier completo; namespace errato, revoca e tampering sono
rifiutati. Solo materiale pubblico vive sotto `release/`; verbale e limiti sono in
`docs/RELEASE_SIGNING_CEREMONY_2026-10-13.md`.

R07 è conclusa. Il recovery set `1a54bde7-749e-48f9-9159-c21da49dd861` è stato
verificato air-gapped, la request `f0ee25f6…486` firmata con la chiave upgrade e il guard
monouso consumato. `0.1.0-13` è installato sul laboratorio; ricevute consumed/finalized,
dpkg, unità, health Unix/HTTPS, audit, hash persistenti e rete sono verdi. P-016 registra
e risolve l'incompatibilità ABI del verifier Kali 3.13 tramite runtime Python 3.11
manifestato e builder network-free. Evidenze complete in
`docs/UPGRADE_DRILL_R07_2026-10-13.md`. L'authorization R07 è già consumata e non va
riutilizzata.

R08 è conclusa. Firma malformata, artefatto e stato divergenti sono stati rifiutati live;
una reinstallazione non autorizzata di `0.1.0-13` si è fermata nel `preinst` prima
dell'unpack lasciando dpkg, hash, receipt e unità invariati. Fault injection deterministica
copre scadenza/host, writer/rete/spazio, cancellazione e i crash prima e dopo l'unlink del
marker. Il digest del `preinst` testato coincide con package e installazione. Evidenze in
`docs/UPGRADE_FAILURE_DRILL_R08_2026-10-13.md`. Il prossimo task vincolante è R09; il
server resta sano su `0.1.0-13` e le ricevute R07 non vanno alterate.

R09 è conclusa sul candidate firmato e immutabile `0.1.0-14`. Il vero
`--repair-candidate-configuration` ha ceduto correttamente i lock al figlio dpkg e il
finalizer ha validato lo storico `predecessor-resumed`, avanzando fino al fault systemd
deliberato: P-020 e P-021 sono risolti. Tre interruzioni reali hanno inoltre mostrato che
dpkg conserva `0.1.0-13 half-installed` durante l'estrazione e passa poi direttamente a
`0.1.0-14 unpacked`; il ramo candidate `half-installed` resta difensivo e non viene
rivendicato come test live. Il cleanup ha aperto P-022/R11: i maintainer script contano
globalmente anche gli intent terminali storici. ADR 0095 richiede area attiva e storia
validata separate; la bind view confinata usata per ripristinare il laboratorio non è una
procedura supportata. Il server è sano su `0.1.0-13`, recovery status è
`no_pending_transaction`, i cinque writer sono attivi e nessun dpkg reale ha ricevuto
`--force-*`. Evidenze in `docs/UPGRADE_RECOVERY_DRILL_R09_2026-10-14.md` e sotto
`/root/wg-r09-20261013T140000Z`. Questo era lo stato di ingresso del successivo R10.

R10 è conclusa in due snapshot mount-namespace/overlay indipendenti della baseline reale.
Un derivato esclusivamente di laboratorio di `0.1.0-14`, con payload applicativo
identico ma control archive strumentato, ha prodotto gli stati dpkg reali
`triggers-pending` e `triggers-awaited`. Il repair pending ha conservato intent e writer
fermi dopo un fault di resume, poi ha completato il retry e il no-op. Il repair awaited ha
rifiutato una closure contenente un package estraneo, quindi ha chiuso soltanto candidate
e consumer previsto. P-024 registra il primo preflight fermato prima dell'arming perché
il tmpfs da 1.536 MiB era inferiore al gate; a 3.072 MiB entrambi i run sono verdi. Il
server persistente resta su `0.1.0-13`, `no_pending_transaction`, con cinque writer attivi
e nessun overlay residuo. Evidenze in
`docs/UPGRADE_TRIGGER_DRILL_R10_2026-10-14.md` e log root-only sotto
`/root/wg-r10/evidence`. Le request R10 non devono essere riutilizzate. Il prossimo task
vincolante è R11, iniziando dalla remediation P-022/ADR 0095 prima del rollback reale.

R11 è conclusa. La remediation P-022/ADR 0095 è implementata per la revisione
`0.1.0-15`, che accetta esclusivamente `0.1.0-14`: prima di dpkg l'executor valida e
sposta gli intent terminali legacy in `candidate-reinstall-intent-history/` o
`rollback-intent-history/`, poi rimuove le directory attive vuote affinché il predecessor
immutabile veda una sola transazione corrente. Dopo la receipt archivia anche l'intent
corrente. Rename interrotto e layout già migrato sono idempotenti; recovery status e
finalizer validano marker, request e terminale e rifiutano orfani, duplicati e corruzioni.
La suite upgrade dedicata conta 188 test verdi. Il candidate `0.1.0-15` è stato costruito
dal commit pulito `0b06c4e`: 1.028 test verdi, audit pulito, inventario e provenance
verificati; package SHA-256 `10f3c78215cfb4c143b75e80839b2730c1e3138da3fcdfc6e3a68f981546a7d0`.
Il bundle è firmato e l'upgrade reale `0.1.0-14 → 0.1.0-15` è verde.

Il primo tentativo live R11 ha portato correttamente il server da `0.1.0-13` a
`0.1.0-14` e poi a `0.1.0-15`, con due authorization firmate, recovery set verificati,
stato autorevole byte-identico e tutti i controlli verdi. Poiché `0.1.0-15` ha creato la
receipt `finalized`, il rollback è intenzionalmente non più selezionabile: alterare la
receipt o creare un intent a mano non è ammesso. P-025 registra il problema dell'harness.
Il candidate `0.1.0-16` con predecessor esclusivo `0.1.0-15` è stato costruito dal
commit pulito `3d0da50`: 1.028 test verdi, audit pulito, inventario e provenance
verificati; package SHA-256 `1fd6a0eca62afb997312638117726dc5f37efc4544af4af61cd91f93ce2c71d1`.
Il bundle è stato firmato. Il fault controllato sul socket helper ha lasciato il candidate
`half-configured`; `--rollback-with-restore` ha reinstallato `0.1.0-15`, ripristinato il
set `9c7f296f-2d7a-4269-878c-03984fc90d20`, ripreso i cinque writer, eliminato identity e
mask e migrato byte-identici i quattro intent legacy più quello corrente nello storico.
Il controllo terminale ha aperto P-026: `recovery-status` validava le receipt di restore
solo contro l'intent attivo, già archiviato correttamente, e il timer health risulta quindi
fallito. La correzione e la regressione sono nel commit `06a3b37`; il candidate firmato
`0.1.0-17` con predecessor esclusivo `0.1.0-15` ha completato pipeline, audit, bundle
verification e upgrade reale. Package SHA-256:
`2ecfbd13ac6eeba46ba984ad21a01b175701f9c47e99987cb57a9ee81fe8a4c4`.
`recovery-status` restituisce `no_pending_transaction`, il timer health e i cinque writer
sono verdi, dati e segreti coincidono con il recovery set e il retry restore è un no-op.
P-022, P-025 e P-026 sono chiusi senza rimuovere receipt o intent. Il target è rimasto su
`0.1.0-17`; il prossimo task vincolante è R12, consolidamento documentale M4.4. Evidenze
complete in `docs/UPGRADE_ROLLBACK_DRILL_R11_2026-10-14.md` e log root-only sotto
`/root/wg-r11-20261014T153500Z`.

R12 e M4.4 sono concluse. `docs/M4_4_CLOSURE.md` collega R01–R12 alle rispettive
evidenze, separa gli artefatti storici dal candidate tecnico `0.1.0-17` e dichiara il
limite fondamentale: tutti gli archi osservati usano schema dati 1 e provano soltanto una
migrazione no-op, non compatibilità cross-schema. Installazione, matrice upgrade, stato
laboratorio, supply chain e rischio P-019 sono allineati. Nessun TODO M4.4 resta implicito;
il prossimo task vincolante è R13, drill compromissione e revoca delle credenziali API.

## Regole invarianti

- Storage applicativo solo file; niente SQL o servizi dati obbligatori.
- Multi-tenant fail-closed; autorizzazione backend per singolo oggetto.
- Niente comandi shell costruiti da dati utente e niente Flask come root.
- Niente traffico Internet via VPN; client-to-client solo nella stessa rete.
- ID immutabili e opachi; nomi non diventano path o nomi interfaccia senza mapping.
- Scritture atomiche, lock, revisioni, schema versionato e audit per ogni mutazione.
- Segreti mai in Git/log/URL; test non devono richiedere segreti reali.
- L'API pubblica è un adattatore del service layer: non accede direttamente a repository,
  coda, helper o host. Contratto OpenAPI, test di compatibilità e test RBAC/IDOR devono
  cambiare insieme agli endpoint; token e payload sensibili non entrano in log o audit.
- Ogni mutazione e negazione di sicurezza deve produrre un audit redatto. Non accettare
  testo libero o payload richiesta nel record: usare codici stabili e nomi campo.
- `admin/admin` è solo bootstrap loopback con cambio obbligatorio.
- Ogni modifica aggiorna roadmap e documenti se cambia una decisione.
- `CHANGELOG.md` è grow-only: non modificare o eliminare voci esistenti. Inserire in alto
  ogni nuova modifica importante o osservabile, incluse quelle richieste manualmente
  dall'utente; correggere errori storici mediante una nuova voce.
- Quando un'unità è realmente chiusa e non richiede una decisione, azione o risposta del
  maintainer, creare autonomamente il commit di chiusura. Se serve il suo intervento,
  fermarsi prima del commit. Il messaggio deve coprire il cambiamento in modo esaustivo ma
  conciso, evitando sia descrizioni vaghe sia resoconti prolissi.
- Ogni scelta che richiede una risposta dell'utente deve essere registrata come singola
  riga in `docs/USER_DECISIONS.md`, con motivazione, soluzione consigliata e relativa
  giustificazione, oltre alla data di richiesta. La raccomandazione deve essere concreta,
  dichiarare i trade-off rilevanti e restare distinta dall'esito. Non dedurre una risposta
  dal silenzio. Alla risposta, spostare la riga tra le decisioni chiuse e registrare data
  ed esito esplicito senza riscrivere retroattivamente la raccomandazione.
- Prima di implementare un task corposo, dividerlo in incrementi verificabili e fermarsi
  a un gate coerente.
- Al termine di ogni esecuzione riportare due stime percentuali motivate: lavoro residuo
  per una prima versione utilizzabile e lavoro residuo per la realizzazione totale della
  roadmap. Aggiungere sempre una forchetta del numero di passaggi Codex ancora prevedibili
  e i principali blocchi che la compongono. Aggiornare le stime in base ai gate verificati,
  senza falsa precisione o decrementi automatici scollegati dai task rimanenti.
- L'ambiente di sviluppo dichiarato è Windows 11 Pro con WSL Debian. Non interpretare
  come bug applicativo l'indisponibilità di systemd, nftables o letture kernel in una WSL
  non configurata per tali capacità; i test unitari devono restare non privilegiati. Il
  target di produzione e della release rimane Debian nativo con systemd e Caddy.
- Il target di integrazione intranet fornito dal maintainer è `root@vrt-debian1.lsinet.it`, Debian
  12. Lo stato e le regole d'uso sono in `docs/LOCAL_TEST_ENVIRONMENT.md`; non salvare
  chiavi SSH o altri segreti nel repository. Usarlo per smoke test privilegiati che WSL
  non può eseguire, dopo controlli read-only e senza riutilizzarlo come produzione.
- Per test end-to-end è autorizzato usare `vrt-debian1.lsinet.it` come hub e la WSL Debian corrente
  come client WireGuard; l'utente locale dispone di `sudo`. Inventariare e ripristinare
  entrambi gli host, senza creare default route o persistere chiavi di test nel repository.

## Workflow per il prossimo agente

Controllare `git status`, rileggere changelog e registro decisioni (in particolare prima
di iniziare un task API), eseguire
`./scripts/check.sh`, scegliere il primo TODO non bloccato, scrivere test prima/durante
l'implementazione e non allargare lo scope della milestone. Registrare le decisioni
architetturali in `docs/decisions/NNNN-titolo.md` e le scelte richieste all'utente nel
registro canonico. Se cambia un formato persistito, fornire migrazione e fixture
precedente. Prima di un commit richiesto, verificare che changelog, roadmap e
documentazione descrivano correttamente gli effetti osservabili inclusi nel commit.
