# Drill R13 — compromissione e revoca delle credenziali API

Data: 2026-10-14  
Stato: superato

## Scopo

Il drill verifica che la copia di un bearer token non conservi autorità dopo rotazione o
revoca. La prova attraversa le route Flask reali, repository JSON, hash Argon2id, chiavi
client cifrate, idempotency store, coda job, rivalidazione worker, rate limit persistente
e catena audit HMAC.

L'account sotto test è limitato al ruolo `manager` di una sola rete e al permesso separato
`client.config:read`; la credenziale sensibile dura 12 ore. Il processo privilegiato non
viene contattato: una sentinella rende il test fallito se il job revocato raggiunge
l'helper.

## Procedura riproducibile

```bash
.venv/bin/pytest -q tests/test_api_v1.py \
  -k compromised_api_credential_rotation_and_revocation_drill
```

La prova crea in una directory temporanea un client con chiave cifrata e un service
account scoped, poi esegue in ordine:

1. lettura della rete, download della configurazione e accodamento di `network.stop` con
   il token iniziale;
2. copia del token come credenziale simulata compromessa e rotazione amministrativa;
3. riuso del vecchio token su lettura e download sensibile;
4. consumo del job già accodato dopo la rotazione;
5. download con la nuova credenziale, successiva revoca e nuovo tentativo;
6. verifica della catena audit e ricerca dei token/configurazione nei file persistiti.

## Risultati

| Controllo | Risultato |
|---|---|
| Lettura scoped prima della rotazione | `200` |
| Download configurazione prima della rotazione | `200`, attachment e `Cache-Control: no-store` |
| Job creato dalla credenziale iniziale | `202 queued` con ID persistente |
| Vecchio token dopo la rotazione | `401 AUTHENTICATION_REQUIRED` uniforme |
| Download sensibile col vecchio token | `401 AUTHENTICATION_REQUIRED`, nessun plaintext |
| Abuso ripetuto del vecchio token | `429 RATE_LIMITED` con `Retry-After` |
| Job in coda dopo la rotazione | `failed/JOB_AUTHORIZATION_REVOKED` |
| Chiamate al helper per il job revocato | zero |
| Nuovo token prima della revoca | download `200`, contenuto identico e `no-store` |
| Nuovo token dopo la revoca | `401 AUTHENTICATION_REQUIRED` |
| Stato terminale | account `revoked`, credenziale attiva nulla, job terminale `failed` |
| Audit | catena HMAC valida; create, rotate, revoke, download e negazioni presenti |
| Persistenza segreti | nessun token nei JSON/JSONL; nessuna configurazione nell'audit |

## Cleanup e limiti

Non rimangono job `queued`/`running` né credenziali attive. Tutto lo stato del drill è
confinato alla directory temporanea pytest, eliminata dal runner; nessuna interfaccia,
regola host o configurazione WireGuard viene mutata.

Questa prova chiude R13, non R14: HTTPS, allowlist amministrativa, header spoofing, limiti
del reverse proxy e mTLS opzionale appartengono al successivo drill Caddy.
