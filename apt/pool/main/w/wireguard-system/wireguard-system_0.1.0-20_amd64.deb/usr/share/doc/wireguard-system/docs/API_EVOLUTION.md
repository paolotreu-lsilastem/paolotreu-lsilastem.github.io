# Evoluzione e migrazione del contratto API

Questa guida governa il contratto pubblico OpenAPI, i client remoti e il rollback. La
fonte normativa corrente resta `docs/openapi/v1.json`; la baseline
`docs/openapi/v1.compatibility.json` è congelata e rappresenta il minimo che ogni server
v1 successivo deve continuare a offrire.

## Classificazione delle modifiche

| Modifica | Stessa major v1 | Azione |
|---|---|---|
| Nuova operazione o nuovo path | Compatibile | Implementare server-first, documentare e sincronizzare la copia packaged |
| Parametro o proprietà di input nuovi e opzionali | Compatibile | Il default deve conservare il comportamento precedente |
| Campo di risposta aggiuntivo | Compatibile con cautela | I client devono ignorare campi sconosciuti; aggiornare esempi e test |
| Descrizione, esempio o `deprecated: true` | Compatibile | Non cambiare contemporaneamente il comportamento dell'operazione |
| Rimozione/rinomina di path, metodo, parametro, campo o status già promesso | Breaking | Nuova major e coesistenza con v1 |
| Nuovo input obbligatorio, body opzionale reso obbligatorio o vincolo ristretto | Breaking | Nuova major |
| Cambio di `operationId`, sicurezza, media type o schema di una risposta esistente | Breaking | Nuova major |
| Cambio semantico non visibile nello schema | Presunto breaking | Nuova major oppure prova formale che il comportamento precedente resta valido |

Il gate è deliberatamente conservativo. Il fatto che una modifica passi il confronto
strutturale non sostituisce inventario Flask, conformance runtime, RBAC, esempi e review
semantica.

## Deprecazione senza rottura

Una deprecazione non modifica status, payload, autorizzazione o significato della risorsa.
La sequenza obbligatoria è:

1. pubblicare e collaudare l'alternativa mentre l'operazione storica resta invariata;
2. impostare `deprecated: true`, indicare alternativa e finestra nella descrizione OpenAPI;
3. restituire sull'operazione storica gli header illustrativi seguenti, sostituendo date e
   URL con valori approvati per la release;
4. mantenere vecchia e nuova operazione per l'intera release stabile successiva;
5. rimuovere l'operazione soltanto in una nuova major e mai riscrivendo la baseline v1.

```http
Deprecation: @1798761600
Sunset: Fri, 01 Jan 2027 00:00:00 GMT
Link: <https://wg.example.invalid/docs/deprecations/example>; rel="deprecation"; type="text/html"
Link: </api/v2/example>; rel="successor-version"
```

`Deprecation` usa la data Structured Fields e `Sunset` una HTTP-date. Il primo segue
[RFC 9745](https://www.rfc-editor.org/rfc/rfc9745.html), il secondo
[RFC 8594](https://www.rfc-editor.org/rfc/rfc8594.html). Il valore `Sunset` non può
precedere `Deprecation`. Nessuna operazione v1 è attualmente deprecata: il blocco è un
modello, non una promessa di data o di endpoint v2.

“Una release stabile successiva” significa che se la release N annuncia la deprecazione,
N+1 deve ancora servire entrambe le operazioni. La prima rimozione tecnicamente possibile
è quindi una release seguente della nuova major; la data concreta di sunset è una decisione
di release e deve essere registrata prima di impostare gli header.

## Migrazione dei client

Il rollout è server-first:

1. il server pubblica la funzionalità additiva e il nuovo OpenAPI;
2. il client scarica `/api/v1/openapi.json` e verifica la presenza dell'`operationId`
   richiesto, senza dedurre capacità dalla sola versione del package;
3. il client mantiene vecchio e nuovo percorso dietro una scelta reversibile;
4. si prova il nuovo percorso su un ambiente amministrativo allowlisted;
5. si abilita gradualmente il nuovo percorso e si osservano endpoint, errori e rate limit;
6. il fallback viene rimosso soltanto dopo la finestra di coesistenza.

Un client non deve fallire per proprietà di risposta sconosciute. Deve invece trattare
come incompatibile l'assenza di un'operazione o di un media type richiesto e tornare al
percorso precedente senza tentare mutazioni alternative automaticamente.

## Introduzione di una major

Una v2 non sostituisce i file v1. Richiede almeno:

- prefisso `/api/v2`, documento `v2.json`, copia packaged e baseline v2 separati;
- inventario route, conformance, esempi e compatibility check dedicati;
- threat review per cambi di autenticazione, autorizzazione o segreti;
- v1 e v2 attive in parallelo durante la finestra di migrazione;
- metriche per `operationId` prive di token, body e identificatori sensibili;
- procedura client di ritorno a v1 prima di qualunque arresto di v2.

Cambiare `info.version` del documento v1 in `2.x` è intenzionalmente rifiutato dal gate:
non costituisce una migrazione, ma la perdita del contratto v1.

## Rollback

- Se soltanto il server additivo è stato distribuito e nessun client usa la nuova
  capacità, il package può tornare alla release precedente con il normale protocollo di
  rollback autorizzato.
- Dopo l'adozione client, disabilitare prima la nuova capacità lato client e verificare il
  fallback; solo dopo si può arretrare il server.
- Se il rilascio cambia anche lo schema dati, usare backup/restore e l'executor di upgrade:
  la compatibilità HTTP non autorizza un downgrade dello storage.
- Durante una deprecazione o una major parallela, il rollback non deve rimuovere il
  percorso ancora usato dai client. In assenza di fallback verificato il rollback è
  bloccato.
- Non rigenerare mai `v1.compatibility.json` per rendere verde un rollback o una modifica
  breaking. La baseline nuova nasce soltanto per una major distinta prima della sua prima
  pubblicazione.

## Gate e drill ripetibile

Dopo una modifica compatibile:

```bash
.venv/bin/python scripts/openapi-contract.py sync
.venv/bin/python scripts/openapi-contract.py check
.venv/bin/python scripts/openapi-contract.py drill
./scripts/check.sh
```

`drill` lavora esclusivamente in memoria: aggiunge un parametro query opzionale e deve
ottenere `ACCEPTED`, poi rimuove `GET /api/v1/tenants` e deve ottenere `REJECTED` con
`operation removed`. Il test automatico confronta inoltre i byte di contratto e baseline
prima/dopo, prova una deprecazione metadata-only e verifica che il cambio major sia
rifiutato dal lane v1.

Il rilascio è negato se copia packaged e sorgente divergono, se il checker segnala una
rottura, se gli esempi non validano o se implementazione e inventario OpenAPI non
coincidono. Queste regole non autorizzano l'esposizione Internet, che resta fuori scope
della v1.
