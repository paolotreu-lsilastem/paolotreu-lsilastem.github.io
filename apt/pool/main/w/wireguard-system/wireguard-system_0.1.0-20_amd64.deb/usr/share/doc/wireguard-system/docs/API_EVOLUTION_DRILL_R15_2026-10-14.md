# Drill R15 — evoluzione del contratto API

Data: 2026-10-14

## Scopo

Verificare che il lane OpenAPI v1 accetti un'estensione additiva, neghi una rottura e non
modifichi né contratto né baseline. La policy operativa provata è pubblicata in
`docs/API_EVOLUTION.md` e formalizzata da ADR 0097.

## Prova

Comando:

```bash
.venv/bin/python scripts/openapi-contract.py check
.venv/bin/python scripts/openapi-contract.py drill
```

Esito osservato:

```text
OpenAPI v1 packaged copy and compatibility surface are valid
additive optional query parameter: ACCEPTED
removed operation: REJECTED (operation removed: GET /api/v1/tenants)
OpenAPI compatibility drill passed without modifying contract artifacts
```

Il caso additivo aggiunge in memoria un parametro query opzionale a
`GET /api/v1/tenants`. Il caso breaking rimuove la stessa operazione. Test separati
confermano che `deprecated: true` non rompe la major, un nuovo input required viene negato
e cambiare `info.version` da `1.x` a `2.x` viene rifiutato dal lane v1.

## Integrità prima/dopo

| Artefatto | SHA-256 prima e dopo |
|---|---|
| `docs/openapi/v1.json` | `63adec2c4934bb52bb41d91888fd95dde1b0beefd6b209e95d3d404b18b2b006` |
| `docs/openapi/v1.compatibility.json` | `983a7b87eddd13905a49c3df23b4091c5b779a337e0351c6d30b0399776cee8a` |
| copia packaged `openapi-v1.json` | `63adec2c4934bb52bb41d91888fd95dde1b0beefd6b209e95d3d404b18b2b006` |

La copia packaged è byte-identica alla fonte. Il comando `drill` è inserito nel quality
gate e una regressione ripete il confronto byte-per-byte, quindi non può diventare un
meccanismo implicito di aggiornamento della baseline.

## Esito

Deprecazione, finestra di coesistenza, nuova major parallela, migrazione client e rollback
sono definiti senza deprecare oggi alcuna operazione. M4.6 e R15 sono chiusi; esposizione
Internet e nuova major restano fuori scope della v1.
