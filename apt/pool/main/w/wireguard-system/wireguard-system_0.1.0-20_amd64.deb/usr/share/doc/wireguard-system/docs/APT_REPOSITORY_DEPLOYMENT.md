# Pubblicazione in una repository APT

Questo documento definisce il deploy di un package verificato in una repository APT
esistente gestita da `reprepro`. Il tool riceve come primo argomento la root assoluta
della repository e può esportarne la sola proiezione pubblica verso GitHub Pages. Non
crea chiavi o configurazioni e non esegue `git commit`/`push`.

La root `reprepro` e la cartella web sono obbligatoriamente separate: `conf/`, `db/`,
`logs/` e `lists/` non devono mai finire nel sito. L'export copia soltanto `dists/`,
`pool/`, keyring pubblica, fingerprint, source deb822 e pagina d'installazione.

## Due domini di fiducia obbligatori

La pubblicazione attraversa due firme indipendenti:

1. la firma SSHSIG offline `SHA256SUMS.sig` autentica bundle, `.deb`, sorgente,
   provenienza, lock, audit e SBOM mediante `release-allowed-signers` e revoche;
2. la firma OpenPGP configurata da `SignWith` autentica l'indice APT `InRelease` ai
   client mediante una keyring pubblica dedicata e un fingerprint completo atteso.

Il primo controllo impedisce di pubblicare un package non approvato dalla release
ceremony. Il secondo impedisce che il client APT accetti indici sostituiti. Uno non
sostituisce l'altro. `scripts/deploy-apt-package.py` fallisce prima di modificare la
repository se il bundle non supera la verifica SSHSIG o se la configurazione non usa
esattamente il fingerprint richiesto.

## Prerequisiti della repository

Installare gli strumenti sul nodo di pubblicazione:

```bash
sudo apt install --yes reprepro gnupg gpgv
```

La root deve già esistere, essere indicata con path assoluto, non attraversare symlink,
appartenere a root o all'utente effettivo e non essere scrivibile da gruppo/altri. Anche
la keyring pubblica deve essere un file regolare non scrivibile da gruppo/altri. Il file
`ROOT/conf/distributions` deve contenere un solo paragrafo per il codename scelto, abilitare
l'architettura del package e impostare il fingerprint completo:

```text
Codename: bookworm
Suite: stable
Architectures: amd64
Components: main
SignWith: 0123456789ABCDEFFEDCBA987654321001234567
Origin: WireGuard System
Label: WireGuard System
Description: WireGuard System packages
```

La chiave privata OpenPGP della repository non è un argomento del tool. `reprepro` la
trova tramite la propria configurazione GnuPG e `gpg-agent`; il wrapper non passa passphrase
su CLI, ambiente, stdin o log. La keyring fornita al wrapper contiene soltanto la chiave
pubblica attesa. Custodia, backup, rotazione e revoca della chiave APT sono responsabilità
dell'operatore della repository e restano separate dalla chiave SSHSIG offline.

La chiave corrente ha fingerprint
`2B3C FA67 79E3 95C0 CDA2 08B7 AE7A 30DC 2F97 0ACF` e scade il
`2028-10-12T13:28:05Z`. La scadenza non obbliga a cambiare chiave: può essere estesa
prima del termine mantenendo lo stesso fingerprint. I client devono però ricevere la
certificazione pubblica aggiornata mentre quella precedente è ancora valida. R23 ha
introdotto il package indipendente `wireguard-system-archive-keyring 2026.10.15-1`; R24
lo ha costruito, firmato e collaudato insieme al candidate finale. Il canale testing
pubblicato resta storico finché R25 non autorizza la promozione.

### Package keyring versionato

`packaging/apt-keyring/` contiene soltanto la chiave pubblica, i fingerprint ammessi, la
versione indipendente e un source deb822 di esempio. Il builder seguente verifica che i
fingerprint OpenPGP coincidano, produce un package `Architecture: all` senza maintainer
script e normalizza mode e timestamp:

```bash
./packaging/apt-keyring/build-package.sh
dpkg-deb --info dist/wireguard-system-archive-keyring_2026.10.15-1_all.deb
```

Il bootstrap iniziale resta manuale perché un repository non può autenticare da solo la
propria prima chiave. Dopo avere confrontato il fingerprint tramite un canale indipendente,
installare insieme package keyring e applicazione. Gli aggiornamenti successivi della
keyring arrivano via APT senza dipendere dal lifecycle protetto del package applicativo.

### Provisioning una tantum della chiave APT

La postazione corrente non contiene automaticamente una chiave privata APT. Crearne una
dedicata, protetta da passphrase e distinta dalle chiavi SSHSIG release/upgrade. Il comando
seguente apre `pinentry`: la passphrase resta fra operatore e `gpg-agent` e non va copiata
in shell history, file `.env` o repository.

```bash
install -d -m 700 var/apt-gnupg var/apt-repository/conf var/apt-public
GNUPGHOME="$PWD/var/apt-gnupg" \
  gpg --quick-generate-key "WireGuard System APT Archive" ed25519 sign 2y
GNUPGHOME="$PWD/var/apt-gnupg" \
  gpg --list-keys --with-fingerprint "WireGuard System APT Archive"
```

Annotare il fingerprint primario completo mostrato, verificarlo su un secondo terminale e
usarlo come `SignWith`. Esportare poi soltanto la chiave pubblica:

```bash
GNUPGHOME="$PWD/var/apt-gnupg" \
  gpg --output var/apt-public/wireguard-system-archive-keyring.gpg \
  --export FINGERPRINT_COMPLETO
chmod 600 var/apt-public/wireguard-system-archive-keyring.gpg
```

Scrivere `var/apt-repository/conf/distributions` usando il paragrafo precedente e il
fingerprint reale. `var/` è ignorata da Git; eseguire un backup cifrato separato della
chiave privata prima della prima pubblicazione. La sua rotazione è un'operazione esplicita
che richiede una finestra con entrambe le chiavi distribuite ai client.

## Deploy

Dopo la firma offline del bundle:

```bash
.venv/bin/python scripts/deploy-apt-package.py /srv/apt/wireguard-system \
  --bundle dist/releases/0.1.0-18 \
  --distribution bookworm \
  --release-allowed-signers /etc/wireguard-system/release/allowed_signers \
  --release-revoked-keys /etc/wireguard-system/release/revoked_keys \
  --repository-keyring /usr/share/keyrings/wireguard-system-archive.gpg \
  --repository-fingerprint 0123456789ABCDEFFEDCBA987654321001234567
```

Il comando:

- verifica firma SSHSIG, checksum e provenienza del bundle;
- accetta un `.deb` applicativo e, opzionalmente, il solo package
  `wireguard-system-archive-keyring` con architettura `all`;
- valida root, permessi, codename, architettura e `SignWith`;
- se la stessa versione è già presente e verificata, termina senza mutazioni;
- pubblica la keyring prima dell'applicazione ed esegue
  `reprepro --basedir ROOT --waitforlock 0 includedeb` senza shell;
- se una firma interrotta ha già registrato esattamente il package nel database privato,
  il retry esegue unicamente `reprepro export` e riconverge sugli indici firmati;
- verifica con `gpgv` che `InRelease` abbia una sola firma valida del fingerprint atteso;
- collega hash di `InRelease`, indice `Packages`, record del package e file nel `pool/`.

## Export verso GitHub Pages

Il link locale supportato può essere creato esattamente come segue; deve essere un symlink
leaf assoluto, appartenere all'utente effettivo e risolvere a una directory non scrivibile
da gruppo/altri:

```bash
ln --symbolic /home/paul/repos/paolotreu-lsilastem.github.io/apt/ publish
```

Con la root privata già configurata, il deploy e l'export si eseguono insieme. Il
candidate tecnico usa il canale `bookworm-testing`; `bookworm` resta riservato alla
release che supererà il gate finale. Per la postazione corrente l'URL pubblico è
`https://paolotreu-lsilastem.github.io/apt`:

```bash
GNUPGHOME="$PWD/var/apt-gnupg" \
  .venv/bin/python scripts/deploy-apt-package.py \
  "$PWD/var/apt-repository" \
  --bundle dist/releases/0.1.0-13 \
  --distribution bookworm-testing \
  --release-allowed-signers release/allowed_signers \
  --release-revoked-keys release/revoked_keys \
  --repository-keyring var/apt-public/wireguard-system-archive-keyring.gpg \
  --repository-fingerprint FINGERPRINT_COMPLETO \
  --pages-root publish \
  --public-url https://paolotreu-lsilastem.github.io/apt
```

Prima della sincronizzazione il tool costruisce una staging directory privata e ripete la
verifica OpenPGP/hash fino al `.deb`. Il file
`wireguard-system-pages-manifest.json` delimita i file gestiti: un file gestito modificato
a mano causa un rifiuto, mentre file estranei nella cartella `apt/` sono preservati. Non
vengono mai esportati `conf/`, `db/`, `logs/`, `lists/` o chiavi private.

Controllare quindi il secondo worktree e pubblicarlo esplicitamente:

```bash
git -C /home/paul/repos/paolotreu-lsilastem.github.io status --short -- apt
git -C /home/paul/repos/paolotreu-lsilastem.github.io diff --stat -- apt
git -C /home/paul/repos/paolotreu-lsilastem.github.io add -- apt
git -C /home/paul/repos/paolotreu-lsilastem.github.io commit -m "Publish WireGuard System APT repository"
git -C /home/paul/repos/paolotreu-lsilastem.github.io push origin main
```

Il symlink locale `publish` è ignorato dal repository applicativo. Il tool non invoca Git
e non esegue upload: questo mantiene revisionabile il delta del sito prima della sua
esposizione pubblica.

### Stato pubblicato corrente

Il commit Pages `68a190f` è stato pubblicato il 2026-10-14 su
`https://paolotreu-lsilastem.github.io/apt/`. Il deployment GitHub Pages
`38608994266` è terminato con successo. I download HTTPS di `InRelease`, indice e package
sono stati verificati dopo la propagazione; `gpgv` accetta la firma del fingerprint atteso
e il package remoto ha SHA-256
`2ecfbd13ac6eeba46ba984ad21a01b175701f9c47e99987cb57a9ee81fe8a4c4`.

Un `apt update` reale in una root temporanea non privilegiata ha scaricato `InRelease` e
`Packages` via HTTPS e propone `wireguard-system 0.1.0-17` con priorità 500 dalla suite
`bookworm-testing`. Questa è evidenza tecnica per installazioni pulite e test controllati,
non promozione al canale stabile. Gli host sul precedente `0.1.0-13` pubblico non devono
tentare un upgrade diretto: il candidate dichiara esclusivamente `0.1.0-15` come
predecessor supportato.

Il collaudo locale reale, separato dalla suite non privilegiata, crea package, chiave e
repository effimeri sotto la directory temporanea e li elimina a fine prova:

```bash
WG_PORTAL_RUN_APT_INTEGRATION=1 \
  .venv/bin/pytest -q tests/test_apt_repository_deployment.py
```

Il 2026-10-08 il round-trip è stato eseguito su WSL Debian 12 con `reprepro 5.3.1`:
creazione di package/repository/chiave effimeri, prima inclusione, verifica completa e
seconda esecuzione idempotente sono riuscite. Nessuna chiave di test è stata conservata.

Errori CLI sono deliberatamente redatti. Se `reprepro` termina con errore o il controllo
post-deploy fallisce, considerare la repository potenzialmente modificata: non cancellare
file manualmente, bloccare la pubblicazione web, conservare le evidenze operative e usare
i comandi di verifica/riesportazione di `reprepro` secondo il runbook dell'archivio.

## Configurazione dei client

Distribuire la chiave pubblica attraverso un canale autenticato e usare sempre una keyring
dedicata, mai il trust store globale. Esempio deb822 equivalente a `signed-by=`:

```text
Types: deb
URIs: https://packages.example.invalid/wireguard-system
Suites: bookworm
Components: main
Signed-By: /usr/share/keyrings/wireguard-system-archive.gpg
```

Non usare `trusted=yes`, `allow-insecure=yes` o downgrade a una repository unsigned. HTTPS
resta richiesto per distribuire in sicurezza configurazione iniziale e chiave pubblica,
anche se gli indici APT sono firmati.

Per il repository Pages, scaricare e verificare il fingerprint della keyring prima di
installarla; quindi usare il source già generato:

```bash
curl --fail --silent --show-error --location --remote-name \
  https://paolotreu-lsilastem.github.io/apt/wireguard-system-archive-keyring.gpg
gpg --show-keys --with-fingerprint wireguard-system-archive-keyring.gpg
sudo install -o root -g root -m 0644 wireguard-system-archive-keyring.gpg \
  /usr/share/keyrings/wireguard-system-archive-keyring.gpg
curl --fail --silent --show-error --location --remote-name \
  https://paolotreu-lsilastem.github.io/apt/wireguard-system.sources
sudo install -o root -g root -m 0644 wireguard-system.sources \
  /etc/apt/sources.list.d/wireguard-system.sources
sudo apt update
sudo apt install wireguard-system
```

Il fingerprint atteso deve provenire anche da un canale del maintainer indipendente dal
sito Pages. Il file scaricato non diventa affidabile soltanto perché è servito in HTTPS.

## Rinnovo e rotazione della chiave APT

Controllare la scadenza almeno a ogni release e attivare l'operazione fra sei e tre mesi
prima del termine. Un rinnovo ordinario estende la stessa chiave, conserva il fingerprint
e richiede di riesportare la keyring pubblica. Una rotazione completa crea invece una
seconda chiave: la keyring distribuita deve contenere vecchia e nuova chiave durante una
finestra di sovrapposizione, prima di firmare gli indici esclusivamente con la nuova.

Mai attendere la scadenza: dopo quel momento i client con la vecchia keyring possono
rifiutare `apt update`, impedendo proprio l'aggiornamento del trust. Compromissione o
perdita della chiave richiedono revoca, stop della pubblicazione e recovery tramite un
canale indipendente; non si aggirano con `trusted=yes`.

Il backup della chiave privata APT deve essere cifrato, verificato e conservato su almeno
due supporti offline separati. La copia online resta protetta da passphrase e accessibile
soltanto all'account di pubblicazione.

Il backup corrente è preparato localmente come
`var/wireguard-system-apt-key-backup-2026-10-13.tar`, protetto dalla passphrase della
chiave, con SHA-256
`f8a47fdb857d19596c67f24e3760edcf9311d1f115537375badcae9506550380`. Il fingerprint è
stato verificato dopo import in un keyring temporaneo e una passphrase vuota è stata
rifiutata. Il file non è una copia offline finché non viene trasferito e ricontrollato su
supporti fisicamente separati; non deve essere committato né caricato sul sito.

## Limiti correnti

- Il tool esporta una repository statica per GitHub Pages, ma commit, push, disponibilità
  CDN e rollback della repository del sito restano operazioni Git esplicite.
- La cerimonia reale SSHSIG e il provisioning della chiave OpenPGP APT non sono eseguiti
  automaticamente.
- Il candidate tecnico `0.1.0-17` resta nel canale testing. Il candidate finale
  `0.1.0-18` è costruito e firmato, ma la pubblicazione stabile resta subordinata a R25
  e al gate `GO`.
- P-018 è chiuso: R24 ha pubblicato in isolamento prima una keyring A, poi A+B, ha
  cambiato la firma repository a B e infine distribuito B soltanto, con `apt update`
  verde in ogni fase. Ogni rotazione production deve ripetere lo stesso ordine.
- `reprepro` non conserva più versioni dello stesso package nello stesso indice; rollback
  e upgrade supportati devono seguire il gate upgrade M4.4.
