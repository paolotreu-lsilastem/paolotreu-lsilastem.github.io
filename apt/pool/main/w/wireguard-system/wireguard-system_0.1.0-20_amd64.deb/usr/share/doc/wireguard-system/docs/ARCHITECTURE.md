# Architettura

## Componenti

```text
Browser ---------HTTPS---+
Automazione remota ------+--> Caddy --> Flask UI/API (utente non privilegiato)
                                          | service layer + RBAC
                                          | JSON repository + lock + audit
                                          | job queue persistente
                                          v socket Unix, protocollo ristretto
                                privileged helper / systemd
                                          |
                                      wg, ip, nft
```

La UI espone route HTML sotto lo stesso origin; l'automazione remota usa l'API pubblica
versionata `/api/v1`. Entrambi gli adattatori chiamano il medesimo service layer e le
policy RBAC, indipendenti dal trasporto. CORS è disabilitato per default. Il repository
file-based è l'unica fonte dello stato desiderato; lo stato runtime viene letto dal
kernel/WireGuard e mai scambiato per stato desiderato.

La UI eredita da una shell Jinja comune e carica un solo stylesheet packaged dallo stesso
origin; non usa JavaScript né CDN. Il context processor proietta ruoli, navigazione e nomi
degli scope assegnati, redigendo riferimenti non risolvibili. Questa proiezione riduce ciò
che viene mostrato ma non concede autorità: ogni futura route gestionale deve continuare
a chiamare service layer e `PolicyEngine`. Errori di routing UI usano una pagina redatta
con request ID; sotto `/api/` lo stesso confine restituisce invece Problem Details JSON.

Il blueprint gestionale chiama direttamente i service applicativi, mai gli endpoint HTTP
API e mai il repository. Le view tenant usano read model redatti, UUID create stabile per
retry e revisione update per CAS; il successo segue Post/Redirect/Get. Una negazione UI
viene auditata e resta indistinguibile da una risorsa inesistente.

`docs/openapi/v1.json` è il contratto normativo OpenAPI 3.1 dell'adattatore remoto. Le
proiezioni API sono definite separatamente dagli schemi storage per escludere hash,
envelope cifrati e dettagli host. Paginazione a cursore, Problem Details, ETag e chiavi di
idempotenza sono parte del confine; la presenza di un path nel contratto non autorizza
l'accesso diretto a repository, job queue o helper.

La sola route anonima dell'API è `GET /api/v1/openapi.json`: restituisce la copia
byte-identica inclusa nel pacchetto e non abilita UI o esecuzione interattiva. La baseline
strutturale v1 è congelata separatamente; il quality gate consente nuove operazioni
additive ma blocca rimozioni, cambi di autenticazione, parametri richiesti aggiuntivi e
indebolimenti delle risposte. Inventario route, risposte seeded ed esempi sono verificati
automaticamente contro il documento.

Un probe read-only campiona periodicamente `wg show <interface> dump` e produce snapshot
runtime di indirizzi, endpoint, ultimo handshake e contatori. Un presence tracker confronta i
campioni e mantiene una finestra continua stimata per `online_since`. Questa telemetria
non entra nella configurazione desiderata e un probe fallito genera stato `unknown`, mai
`offline`.

M3.3 collega questo flusso all'API con un `TelemetryService`: prima autorizza la rete,
poi richiede un campione fresco al helper, verifica registry/VRF/interfaccia e associa i
peer ai client attivi mediante fingerprint soltanto in memoria. Un `PresenceTracker`
aggiorna cache JSON atomiche per client e conserva la continuità stimata solo tra campioni
entro la soglia; la cache non influenza reconciler, RBAC o desired state.

M3.13 introduce `DashboardService` come proiezione applicativa separata dai documenti
canonici. L’inventario applica RBAC prima di contare tenant, reti e client; lo snapshot
della rete selezionata riusa `TelemetryService`, associa i peer ai soli metadati client
allowlistati e rappresenta i client non attivi come non osservabili. La view non accede
direttamente allo storage. Il polling di una singola rete evita un probe per ogni rete e
mantiene costante il carico privilegiato di ciascun ciclo browser.

Il completamento di M3.13 estende `TelemetryService` con un campionamento bulk: tutti gli
ID richiesti vengono risolti e autorizzati prima dell’unica chiamata helper, il probe
viene validato una volta e ogni rete viene correlata separatamente. Una correlazione
fallita produce `actual_state=unknown` soltanto per quella rete; una rete è `running` o
`stopped` esclusivamente dopo una verifica completa. `DashboardService` proietta poi
conteggi e stati di tutte le reti autorizzate, mantenendo i dettagli peer limitati alla
rete selezionata.

M4.3 separa liveness e readiness. `/healthz` non tocca dipendenze; `/readyz` usa un
`ReadinessService` read-only che controlla data schema, journal restore, keyring, helper
privilegiato/capability e salute persistita del reconciler. Quest'ultimo pubblica dopo ogni
ciclo un riepilogo derivato atomico; il lettore verifica freschezza, fallimenti consecutivi
e anzianità dei job outstanding senza lock in scrittura o chiamate privilegiate. Il
risultato redatto viene memorizzato brevemente per singolo
worker Gunicorn: nessun dettaglio host o path attraversa l'endpoint e un guasto recuperabile
non forza il riavvio di un processo ancora vivo. ADR 0057 registra il contratto HTTP e
ADR 0060 quello del reconciler.

Il logging operativo M4.3 attraversa un confine distinto dall'audit. `JsonLineLogger`
accetta solo eventi e campi registrati: web usa endpoint simbolici e request ID canonici,
reconciler usa conteggi, helper usa codici. Non vengono inoltrati oggetti richiesta,
eccezioni o dizionari arbitrari. Gli eventi sono JSON line su stderr per journald; ADR 0058
registra schema e motivazione.

Le unità systemd instradano questi eventi nel namespace journald `wg-portal`. Il namespace
ha storage, quota e retention indipendenti dal journal host; identificatori e campo
`WG_PORTAL_COMPONENT` consentono filtri indicizzati. I rate limit possono perdere
telemetria operativa sotto tempesta senza toccare i record audit persistiti nel data tree.
ADR 0059 registra il confine.

Il primo gate supply-chain M4.4 prende `requirements-prod.lock` come inventario normativo
delle librerie Python distribuite. `pip-audit` legge direttamente tutte le entry pinned e
hashate senza usare il virtualenv come sorgente; report advisory e SBOM CycloneDX devono
avere lo stesso numero di componenti del lock. Un manifest separato lega lock e output
tramite SHA-256. ADR 0061 registra failure policy e limiti del perimetro.

La provenienza del candidate usa una Statement in-toto v1 con predicate SLSA Provenance
v1. Package e archivio Git sono subject; commit, lock e backend sono materiali; audit,
SBOM e inventario Debian sono byproduct. Il generatore pubblica una nuova directory di
versione soltanto dopo verifica offline di tutti gli hash. Il builder locale è dichiarato
non isolato e la Statement è ancora non firmata: ADR 0062 vieta di interpretarla come
autenticazione o come rivendicazione di un livello SLSA.

ADR 0063 chiude la risoluzione dinamica dei tool Python: un secondo lock hashato copre
frontend, backend, scanner e transitivi. Un orchestratore clean-tree crea un virtualenv
effimero da `/usr/bin/python3`, neutralizza config e indici pip locali e usa lo stesso
interprete per audit, build senza isolamento e provenienza. Il lock della toolchain entra
nei materiali attestati; l'host locale resta fuori da un isolamento riproducibile forte.

La firma M4.4 usa SSHSIG Ed25519 sopra un `SHA256SUMS` canonico dell'intero bundle. Il
namespace `release@wireguard-system` separa queste firme dagli usi SSH e l'identità
omonima è autorizzata esclusivamente da un file `allowed_signers`; una lista separata
nega le chiavi revocate. Il verifier controlla prima insieme dei file e digest, poi firma
e policy, infine la semantica della provenienza. La chiave privata non appartiene al
sistema distribuito né alla workstation di build: ADR 0064 registra il confine.

Il probe scopre prima le interfacce tramite `wg show interfaces`, valida ogni nome e usa
un argv assoluto senza shell per il relativo dump. Chiave privata e preshared key vengono
scartate; lo snapshot serializzato sostituisce la chiave pubblica peer con un fingerprint.
Controlli separati leggono sysfs/procfs e output JSON di `ip`/`nft`; un errore resta
`unavailable` o `error` e non viene convertito in uno stato runtime sano.

Le chiavi private persistite attraversano un servizio envelope separato: AES-256-GCM usa
una master key attiva caricata da un keyring esterno al data tree e AAD derivata dagli UUID
canonici di risorsa, tenant e rete. Le vecchie master key restano disponibili soltanto per
decifrare durante una rotazione; un rewrap compare-and-swap porta ogni documento alla
chiave attiva senza cambiare il materiale WireGuard.

Il compiler è una funzione pura: riceve documenti canonici e la chiave privata già
decifrata in memoria, verifica che la chiave pubblica derivata coincida e restituisce
testo WireGuard UTF-8 con LF e newline finale. I peer server sono ordinati per IP numerico
e UUID. Nomi e descrizioni non vengono renderizzati; hook, DNS e `SaveConfig` non fanno
parte del file. Interfacce e configurazioni sono applicate dalle operazioni tipizzate del
helper; il firewall rimane una milestone separata.

Il helper usa socket activation systemd in modalità una connessione/un processo. Il socket
`/run/wg-portal/helper.sock` è root:`wg-portal` `0660`; dopo `connect`, il client verifica
che il peer sia UID 0 e il helper confronta l'UID peer con l'utente di servizio configurato,
entrambi tramite `SO_PEERCRED`. Ogni connessione trasporta un solo JSON ASCII terminato da
newline, con dimensione massima e schema chiuso. Il protocollo espone probe e mutazioni
WireGuard tipizzate su risorse registrate; nessun comando, argv, path o nome unità
arbitrario attraversa il confine privilegiato.

L'adattatore API implementato risolve una credenziale macchina in un
`Principal` con assegnazioni esplicite, quindi chiama esclusivamente use case autorizzati.
Le credenziali non sono mai
salvate in chiaro: il repository conserva solo identificatore pubblico, hash del segreto,
metadati di scadenza e revoca. Ogni richiesta porta un request ID; idempotency key ed
`ETag` rendono sicuri retry e aggiornamenti concorrenti. I service mutanti gestiscono
tenant, utenti, service account, reti e client e usano uno store idempotency persistente
con digest, ID preallocato e risposta redatta; lock separati serializzano vincoli globali,
allocazioni e protezione dell'ultimo superadmin. Le operazioni live
accodano un job e restituiscono `202`, mentre il worker rivalida identità e autorizzazioni prima di
applicarlo. Proiezioni, cursori, telemetria e mutazioni sono isolati in service dedicati.
Dettagli e decisioni approvate sono in `docs/API.md`, `docs/USER_DECISIONS.md` e negli ADR.

## Principi

- Separazione privilegi: Flask non gira come root. Il helper accetta solo operazioni
  tipizzate su ID già validati, non comandi né path arbitrari.
- Desired/actual state: un reconciler serializza le operazioni per rete e rende le
  operazioni ripetibili.
- Atomicità: file temporaneo nella stessa directory, `fsync`, rename atomico, `fsync`
  directory; lock durante read-modify-write.
- Immutabilità identificatori: UUID opachi; nomi modificabili e mai usati come path.
- Dependency rule: `web/api -> services -> domain/repository`; soltanto `engine` conosce
  il sistema operativo.

## Struttura applicativa prevista

```text
wg_portal/
  web/          blueprint UI e adattatore JSON `/api/v1`
  domain/       entità, enum, invarianti
  services/     use case e autorizzazione
  repository/   JSON, lock, migrazioni
  engine/       compiler, probe, helper client, reconciler
  security/     auth, CSRF, rate limit, secret envelope
```

Le milestone M1–M2.4 implementano factory Flask, configurazione, repository atomico e
versionato, dominio, autenticazione, RBAC, audit concatenato con HMAC, probe e custodia
delle chiavi, compiler deterministico e canale privilegiato ristretto. M2.5 ha introdotto
job persistenti, worker, applicazione tipizzata e convergenza di sistema. Un lock globale
impedisce recovery concorrente con il worker; i job automatici usano l'UUID nullo
riservato e possono soltanto riconciliare. Il servizio periodico confronta indirizzo,
porta, fwmark e peer con lo stato canonico, crea job solo sul drift e applica backoff
esponenziale quando probe o convergenza falliscono.
Il confronto e gli snapshot escludono gli endpoint peer appresi a runtime, che cambiano
dopo un handshake e non costituiscono configurazione canonica; indirizzi, porte, peer e
route consentite restano invece verificati.
La superficie API read-only e la telemetria appartengono a M3.3 e sono implementate;
M3.4 ha completato le primitive e le mutazioni tenant, utenti, service account, reti e
client. M3.5 collega le azioni rete API alla coda: lo stato desiderato
e il marker crash-safe sono committati sotto il lock del worker, mentre l'identità job
include service account e credenziale per la rivalidazione al consumo. Lo stesso lock e
un marker sul client coordinano le transizioni che cambiano peer su reti running con un
job `network.sync`; le altre azioni restano sincrone. Una policy condivisa limita i job
non terminali globalmente e per identità/tenant/rete sotto un lock di capacità dedicato;
il rifiuto avviene prima della patch canonica. M3.6 aggiunge un servizio separato per il
download API: rivalida account/credenziale sotto lock, decifra una sola chiave client e
passa il materiale in memoria al compiler deterministico. Pubblicazione del contratto e
UI gestionale restano nella milestone M3.

M4.2 aggiunge recovery set cifrati separati, staging e promozione coordinata crash-safe.
Le migrazioni restore non modificano il bundle autenticato: una registry packaged esige
una catena completa `N → N+1`, copia l'albero estratto in un sibling privato, applica e
sincronizza ogni passaggio e genera il manifest della copia corrente. Solo dopo la
validazione semantica questa copia entra nella stessa transazione di data, environment e
keyring; versioni future e catene incomplete falliscono chiuse.

## Deployment target

Gunicorn su socket Unix, Caddy come reverse proxy HTTPS, directory dati fuori dal
checkout, unità systemd dedicate e policy sudo/polkit minima. Le configurazioni generate
vanno in una directory privata gestita dal helper; `/etc/wireguard` non viene scritto dal
processo web.

La release 1 viene distribuita come pacchetto Debian nativo. Il pacchetto installa unità
systemd, utenze e directory con permessi espliciti e una configurazione Caddy di
riferimento. Un'immagine container non fa parte della matrice di supporto della v1.
Poiché Debian 12 non offre le versioni applicative richieste, le dipendenze Python sono
incorporate in `/usr/lib/wireguard-system/site-packages` da un lockfile con hash. Launcher Python
shell-free fissano il percorso d’import e impediscono che directory correnti o variabili
ereditate sostituiscano moduli del pacchetto.

M2.6 usa una VRF e una tabella di routing per rete, con identificatori kernel derivati da
un'allocazione numerica persistita nel registry root-owned. Una tabella nftables dedicata
intercetta il percorso associato: il kernel presenta il master VRF come `iifname` nei
hook input/forward, la slave WireGuard come `oifname` nel forward e attraversa output sia
sul master sia sulla slave. La policy consente input verso l'IP hub, output dall'IP hub e
forwarding intra-rete; LAN, Internet e attraversamento tra VRF vengono negati. Questa
scelta mantiene il helper limitato a `CAP_NET_ADMIN`, mentre namespace dinamici
richiederebbero `CAP_SYS_ADMIN`. L'acceptance M2.6 reale è completata e la capability
versionata abilita l'overlap soltanto sul percorso verificato.

Le primitive Linux M2.6 non eseguono shell: creano/collegano VRF con argv fissi di `ip` e
caricano la policy nft tramite stdin. La verifica usa JSON macchina, controlla tabella
VRF, stato `UP`, master dell'interfaccia e tutte le chain/regole; ignora esclusivamente
metadati nft e handle assegnati dal kernel. Il forwarding IPv4 deve risultare esattamente
abilitato, altrimenti l'isolamento non è considerato convergente.

L'executor privilegiato tratta WireGuard, VRF e nftables come un'unica transazione
compensata. In creazione lascia l'interfaccia WireGuard down finché VRF e policy non sono
installate; l'ordine è prepare, VRF, attach, firewall, activate, verify e infine registry.
Stop e sostituzione rimuovono prima l'interfaccia e poi firewall/VRF. Prima di cancellare
risorse l'executor ne verifica l'identità nel registry; collisioni non gestite restano
intatte. Se una compensazione non riconverge allo stato precedente, l'errore stabile è
`ROLLBACK_FAILED` e non viene dichiarato successo parziale.

Il probe del helper unisce la telemetria WireGuard alla vista del registry root-owned.
Per ogni rete gestita restituisce esclusivamente identità, piano non sensibile e stato
isolamento `ok`, `drift` o `legacy`; non restituisce chiavi né output dei comandi. Il
reconciler accetta solo forme canoniche e correla per UUID rete e interfaccia. Una rete
running senza entry verificata, una rete stopped ancora registrata o qualunque drift
VRF/nftables genera un job di reconcile. Duplicati, campi inattesi o probe incompleti
invalidano l'intero ciclo senza mutazioni.

Il helper pubblica `per-network-vrf-v1` soltanto insieme all'executor isolato e al probe
del registry. È il contratto minimo che abilita nel dominio CIDR uguali tra tenant
diversi. Il reconciler richiede la stessa capability a ogni ciclo, rendendo fail-closed
un aggiornamento parziale o il collegamento accidentale a un helper legacy.
