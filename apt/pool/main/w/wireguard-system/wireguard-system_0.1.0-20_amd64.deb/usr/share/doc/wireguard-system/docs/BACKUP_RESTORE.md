# Backup, restore e migrazioni

Questo documento definisce il contratto di recovery M4.2. Gli incrementi correnti
implementano inventario, manifest, costruzione cifrata in streaming e il comando offline
`backup-create`, la verifica offline `backup-verify` e il preflight semantico
`restore-preflight`. Il comando root-only `restore-apply` orchestra anche la promozione
live ed è stato collaudato end-to-end su Debian 12. Usarlo soltanto durante una finestra
di recovery controllata seguendo `OPERATIONS.md`; metriche, prove e limiti del collaudo
sono in `DISASTER_RECOVERY_DRILL.md`.

## Recovery set v1

Un punto di ripristino è una coppia indivisibile di bundle con lo stesso
`backup_set_id`:

| Bundle | Contenuto | Esclusioni principali |
|---|---|---|
| `data` | documenti canonici, job, audit attivo/archiviato e idempotenza API | lock, indici, presence, rate limit, file generati e backup precedenti |
| `secrets` | environment production e master keyring esterno | chiavi SSH, chiave privata del destinatario backup, configurazioni client in chiaro |

I due artefatti devono essere compressi e cifrati separatamente. Non sono validi da soli:
un restore deve riceverli entrambi, verificare che `backup_set_id` coincida e rifiutare
bundle duplicati, incompleti o di versioni future. Il registry privilegiato
`/var/lib/wg-portal-helper/registry.json` non viene ripristinato: descrive risorse host
effettive, non lo stato canonico, e su un host nuovo sarebbe obsoleto. Dopo il restore il
reconciler ricostruisce lo stato host dai documenti verificati.

Il file `backup-manifest-v1.schema.json`, incluso nelle risorse Python, descrive il
manifest interno. Ogni manifest contiene UUID canonici di set e bundle, tipo, versione
applicativa, timestamp UTC, modalità di consistenza `offline`, versione schema dati,
conteggio e byte totali, più path relativo, mode, dimensione e SHA-256 di ogni file. I
path sono ordinati e univoci; path assoluti, traversal, symlink, device e permessi fuori
dalla allowlist prevista per il tipo di bundle bloccano la creazione.

## Stato incluso nel bundle dati

La allowlist v1 comprende:

- `meta.json`;
- `users/`, `service-accounts/`, `api-credentials/`, `tenants/` e `jobs/`;
- `audit/active/` e `audit/archive/`, inclusi stream di integrità e manifest;
- `runtime/idempotency/`, perché un retry dopo restore non deve duplicare mutazioni.

Sono ricostruibili e quindi esclusi `runtime/indexes/`, `runtime/presence/`, i rate limit,
`runtime/generated/` e tutti i lock. Una directory `backups/` nel data tree è vietata.
Un file non classificato provoca errore invece di essere ignorato: quando nasce un nuovo
formato persistente, la policy di recovery deve essere aggiornata esplicitamente.

Il percorso di destinazione deve essere esterno a `WG_PORTAL_DATA_DIR`; collocare il
backup sotto il tree sorgente causerebbe ricorsione e renderebbe ambiguo il ciclo di vita.

## Cifratura age/X25519

La decisione approvata usa esclusivamente recipient X25519 nativi `age`. Il server
conosce `WG_PORTAL_BACKUP_RECIPIENT`, installa `/usr/bin/age` e non contiene la identity
privata corrispondente. La identity viene generata su una postazione offline, conservata
in almeno due copie sotto controllo separato e fornita soltanto alla postazione isolata
che esegue verify o restore. Non è previsto fallback a passphrase.

`AgeEncryptor` valida la forma del recipient e invoca il binario assoluto con argv fisso,
ambiente minimo e senza shell. Riceve plaintext solo come stream, scrive un temporaneo
ciphertext `0600` nella directory di destinazione, ne sincronizza i dati e lo pubblica
senza sovrascrivere file esistenti. Errori, timeout o chunk non validi eliminano il
temporaneo.

Il costruttore del bundle scrive `manifest.json` come primo membro, seguito esattamente
dai file ordinati del manifest. Non aggiunge directory, link o metadati dell'host: UID e
GID sono zero, nomi owner vuoti, mode espliciti e timestamp uguale a `created_at`. Ogni
fonte viene riaperta con `O_NOFOLLOW`; inode, mode, dimensione, timestamp e SHA-256 devono
restare coerenti con l'inventario durante la lettura. Environment e keyring devono essere
file distinti, senza hard link, fuori dal data tree; il primo ammette `0600`/`0640`, il
secondo soltanto `0600`. Il comando create compone queste primitive; il risultato resta
un candidato finché il comando verify offline non ne completa la prova crittografica.

## Consistenza e creazione pianificata

Il formato v1 accetta solo backup offline. Il comando corrente si esegue come root:

```bash
install -d -o root -g root -m 0700 /srv/wg-portal-recovery
wg-portal backup-create \
  --environment-file /etc/wg-portal/wg-portal.env \
  --output-dir /srv/wg-portal-recovery
```

Il recipient viene letto da `WG_PORTAL_BACKUP_RECIPIENT`; `--recipient age1...` è
disponibile per una scelta pubblica esplicita. La directory deve esistere, trovarsi fuori
dal data tree, non essere un symlink e non essere scrivibile da gruppo/altri. Il comando
non sovrascrive output esistente e restituisce UUID del set e path dei due bundle.

`backup-create`:

1. registra quali unità applicative sono attive, ferma socket web, web service,
   reconciler, helper socket e istanze helper, impedendo nuovi writer senza interrompere
   le altre virtual host eventualmente servite da Caddy;
2. verifica che le unità e le istanze helper siano realmente quiescenti;
3. inventariare con `lstat`/`O_NOFOLLOW`, mode privati e hash stabile prima/dopo lettura;
4. validare documenti, catene audit e possibilità di aprire il keyring;
5. produrre i due stream compressi direttamente verso il cifratore, senza archivio
   plaintext persistente;
6. pubblicare ciascun ciphertext soltanto dopo il successo di `age` e sincronizzare file
   e directory di destinazione; la decifratura di prova resta compito di verify offline;
7. riavvia soltanto le unità che risultavano attive prima dell'operazione, anche dopo un
   errore; un fallimento di restart viene riportato come errore operativo prioritario.

La validazione apre inoltre ogni envelope di rete e client con il keyring selezionato. Se
la creazione del secondo bundle fallisce, anche il primo viene eliminato: non viene mai
restituito intenzionalmente un recovery set monco.

## Verifica offline

Copiare i due ciphertext e una delle identity offline su una postazione isolata con
`age`; la identity deve essere un singolo file X25519 nativo `0600`. Eseguire:

```bash
wg-portal backup-verify \
  --data-bundle ./wg-portal-...-data.tar.gz.age \
  --secrets-bundle ./wg-portal-...-secrets.tar.gz.age \
  --identity ./wg-portal-recovery-identity.txt
```

Il comando non carica l'environment applicativo, non richiede root, non estrae file e non
scrive plaintext. Consuma entrambi gli stream fino alla conclusione dell'autenticazione
`age`; impone di default 12 GiB per ciphertext, 10 GiB espansi complessivi, 1 GiB per file
e 2 MiB per manifest. Rifiuta metadata tar non normalizzati, sparse/link/device, membri
fuori manifest, ordine o mode diversi, timestamp incoerenti, checksum errati, schema dati
non supportato e coppie con set ID, bundle ID, versione o epoca differenti.

Una verifica riuscita prova autenticità, integrità e struttura del recovery set. La
validazione semantica completa richiede anche il preflight seguente; le migrazioni
forward-only restano escluse dal flusso corrente.

Snapshot filesystem consistenti potranno essere aggiunti in una versione successiva con
un nuovo valore di `consistency`; non sono dedotti automaticamente dal tipo di filesystem.

## Preflight di restore disponibile

Il preflight richiede che `--target-data-dir` coincida con `WG_PORTAL_DATA_DIR` contenuto
nel recovery set. Può puntare a un data dir esistente: il comando non lo apre in scrittura.
La directory padre deve esistere, non essere un symlink e non essere scrivibile da
gruppo/altri.

```bash
wg-portal restore-preflight \
  --data-bundle ./wg-portal-...-data.tar.gz.age \
  --secrets-bundle ./wg-portal-...-secrets.tar.gz.age \
  --identity ./wg-portal-recovery-identity.txt \
  --target-data-dir /var/lib/wg-portal
```

`restore-preflight` non carica l’environment live e non richiede root. Decifra entrambi i
bundle in un sibling temporaneo `0700` sullo stesso filesystem del target, poi verifica:

- coppia, manifest, limiti, metadata, size e SHA-256 come `backup-verify`;
- insieme secrets esatto, sintassi e allowlist delle variabili, modalità production,
  segreti minimi, recipient e path assoluti/coerenti;
- schema del meta-documento e di tutti i documenti, path canonici e relazioni tra tenant,
  reti, client, assegnazioni e credenziali API;
- regole IPv4/rete/client, collisioni statiche, interfacce derivate, presenza di almeno un
  superadmin attivo e corrispondenza tra chiavi WireGuard pubbliche e private;
- schema e path canonico dell’idempotenza, catene HMAC audit e decifrabilità di tutti gli
  envelope privati con il keyring staged.

Lo staging viene eliminato sia dopo il successo sia dopo un errore; l’output ricorda
esplicitamente che nessun dato live è cambiato. Il plaintext non deve quindi essere
conservato per diagnosi da questo comando.

## Applicazione del restore

Il restore non sovrascrive mai direttamente lo stato live. Il flusso decifra in
una directory root-owned temporanea sullo stesso filesystem, impone limiti a numero e
dimensione espansa, rifiuta link e path non manifestati, verifica ogni SHA-256 e valida
schemi, scope canonici, audit e key envelope. Solo dopo il preflight completo
sposta lo stato corrente in una directory di rollback e promuove lo staging con rename.

Il ripristino richiede servizi fermi, data dir di destinazione vuoto oppure un flag
esplicito di sostituzione, coppia `data`/`secrets` dello stesso set e versione supportata.
Al termine ricostruisce gli indici, esegue `doctor` e `audit-verify`, prova la decifratura
degli envelope e lascia le reti `stopped` finché l’operatore non autorizza il reconcile.
Un fallimento esegue il rollback quando possibile, elimina il plaintext staged confinato
e non riavvia i servizi; journal o file di rollback necessari a un recovery crash-safe
restano disponibili finché lo stato non viene risolto.

Se il target esiste, Linux `renameat2(RENAME_EXCHANGE)` scambia
in una sola operazione lo staging sibling e il live; la copia precedente viene conservata
in un sibling privato fino al commit e ripristinata atomicamente per qualsiasi eccezione.
Un data dir non vuoto richiede sempre `replace` esplicito. Kernel e filesystem privi di
exchange falliscono chiusi, senza una sequenza di rename non atomica. Per un target
inesistente basta invece un singolo rename atomico.

Il data tree dispone ora anche di un journal sibling `0600`, pubblicato e aggiornato
atomicamente prima di ogni mutazione. Registra fase, path confinati e identità device/inode
dei tree vecchio e nuovo. `recover_pending_restore` riconosce quindi anche gli arresti tra
exchange, rename del rollback e cleanup: prima della decisione `commit_pending` ripristina
sempre lo stato precedente; dopo tale decisione termina il commit. Stati ambigui o inode
inattesi falliscono chiusi e mantengono il journal. Una nuova transazione è vietata finché
quella pendente non viene recuperata.

La fase interna `RestorePreparer` rende ora lo staging semanticamente inerte prima della
promozione. Verifica la catena audit, marca `failed` con codice stabile
`RESTORE_INTERRUPTED` tutti i job `queued` o `running`, forza ogni rete a `stopped` e
incrementa le revisioni interessate. Registra un evento audit per ogni mutazione e un
riepilogo finale, aggiorna `meta.json`, ricostruisce l’indice con lo stesso timestamp UTC,
riverifica l’audit e rimuove i lock ricostruibili. La ripetizione non incrementa di nuovo
le revisioni di job già terminali o reti già ferme. I lock non regolari, collegati o
directory non sicure bloccano la preparazione.

Il comando è disponibile, mentre il collaudo reale rimane il gate per dichiararlo
supportato in produzione.

Poiché data tree, environment e keyring possono trovarsi su filesystem diversi, lo
staging non tenta rename
cross-device: copia invece ciascun secret già verificato in un candidato sibling del file
live. Il target deve esistere, avere path assoluto canonico, essere regolare, non symlink o
hard link e trovarsi in un parent non scrivibile da gruppo/altri. Il candidato eredita UID,
GID e mode del target host, viene sincronizzato insieme al parent e non sostituisce il live.
Un errore elimina i candidati precedenti; il workspace ne mantiene la proprietà e impedisce
detach o promozione del solo data tree finché non vengono ripuliti.

Il journal v2 include ora per ciascun candidato il tipo, i path target/candidato e le
identità device/inode vecchia e nuova. La promozione interna scambia prima keyring, poi
environment e infine il data tree, sincronizzando ogni parent; soltanto dopo tutti gli
exchange passa a `promoted`. Prima della decisione durevole `commit_pending`, recovery
riporta ogni risorsa allo stato vecchio anche se il processo si è arrestato fra due
exchange. Dopo la decisione conserva tutte le risorse nuove e completa esclusivamente il
cleanup. Il riconoscimento avviene per identità, non per contenuto o nome euristico;
combinazioni ambigue mantengono il journal e falliscono chiuse. Journal v1 eventualmente
rimasti da una versione precedente continuano a essere interpretati come transazioni del
solo data tree.

`RestoreApplier` compone il flusso completo esposto dalla CLI. Richiede root, UUID del recovery
set atteso e consenso `replace`; recupera eventuali journal pendenti soltanto dopo aver
fermato writer e reti gestite. Per una nuova applicazione decifra e valida prima in staging,
forza reti/job allo stato inerte e poi, dentro il quiesce, materializza i candidati, svuota
il registry host e avvia la promozione coordinata. Prima di `commit_pending` rilegge
environment e keyring live, verifica documenti/envelope/audit, confronta l’indice con una
ricostruzione deterministica, conferma che tutte le reti siano `stopped` ed esegue i check
host. Registra infine `restore.apply` nell’audit recuperato.

Se una fase nel quiesce fallisce, il rollback transazionale ripristina i file precedenti ma
le unità restano intenzionalmente ferme: un errore di recovery non deve riattivare writer su
uno stato che richiede ispezione. Soltanto un successo completo riavvia le unità che erano
attive.

Eseguire prima `backup-verify` e `restore-preflight`, annotando il `backup_set_id` mostrato.
Durante una finestra di recovery isolata, copiare temporaneamente la identity sul server
con mode `0600`, quindi eseguire come root:

```bash
wg-portal restore-apply \
  --data-bundle /srv/wg-portal-recovery/wg-portal-...-data.tar.gz.age \
  --secrets-bundle /srv/wg-portal-recovery/wg-portal-...-secrets.tar.gz.age \
  --identity /run/wg-portal-recovery-identity.txt \
  --target-data-dir /var/lib/wg-portal \
  --environment-file /etc/wg-portal/wg-portal.env \
  --confirm-backup-set-id 00000000-0000-4000-8000-000000000000 \
  --replace
```

Omettere `--replace` soltanto quando il target non esiste o è vuoto. L'UUID deve essere
copiato dall'esito della verifica, non dedotto dal nome file. L'output non include path
sensibili. In caso di errore, non riavviare automaticamente le unità: conservare journal e
rollback, eseguire diagnosi read-only e seguire il runbook. In caso di successo verificare
`doctor`, `audit-verify` e lo stato dei servizi, poi eliminare in modo sicuro la copia
temporanea della identity. Le reti restano `stopped` e devono essere riattivate una alla
volta soltanto dopo verifica esplicita.

La base implementata usa `RestoreWorkspace`: crea un sibling temporaneo
`0700` sullo stesso filesystem del data dir e contiene radici separate `data/` e
`secrets/`. Ogni file nasce con `O_EXCL|O_NOFOLLOW`, viene scritto con limite esatto,
verificato contro SHA-256 e mode del manifest, sincronizzato e rimosso se incompleto. Il
target live non viene aperto in scrittura. Uscire dal workspace lo elimina automaticamente;
solo un `detach` esplicito può consegnarlo alla fase di promozione. Il preflight
collega ora decifratura, staging e validazione; non usa `detach` e non promuove contenuti.
`RestorePromotion` aggiunge una transazione distinta: il context manager committa soltanto
all’uscita riuscita e altrimenti ripristina il tree precedente; uscire dal workspace con
una transazione irrisolta provoca comunque rollback automatico.

## Migrazioni

Le migrazioni sono forward-only e mai applicate dentro il bundle originale. Restore
valida prima il formato sorgente, crea una nuova copia di lavoro e applica una versione
alla volta preservando identità e scope. Versioni future o passaggi mancanti sono
rifiutati. Prima della promozione viene generato un nuovo manifest e il bundle originale
resta immutato come rollback fino alla conclusione verificata del drill.

`DataMigrationRegistry` pianifica l'intera catena prima dell'estrazione semantica. La
copia di lavoro è un sibling privato dell'albero estratto: ogni passaggio deve portare
esattamente da `N` a `N+1`, dopodiché directory, file, link, mode e versione vengono
ricontrollati e sincronizzati. L'albero sorgente estratto resta separato fino alla
promozione; errori eliminano la sola copia migrata e il workspace confinato.

Il manifest autenticato continua a descrivere il bundle sorgente. Dopo la migrazione ne
viene costruito uno distinto, in memoria, con hash e inventario della copia corrente; è
questo manifest che guida la validazione semantica. Preflight e restore riportano la
versione di partenza. Lo schema dati corrente è ancora v1 e non esistono formati legacy
rilasciati: la catena packaged è quindi vuota. Quando nascerà v2, la release dovrà
registrare esplicitamente il passaggio v1→v2 e aggiungere fixture del bundle v1.

## Minacce e controlli

- Furto storage: cifratura autenticata `age` obbligatoria e identity di recovery fuori dal
  server.
- Compromissione server: sul server resta soltanto il destinatario pubblico, mai la chiave
  privata capace di decifrare i backup.
- Archive traversal/symlink race: path allowlistati, `lstat`, `O_NOFOLLOW`, staging privato
  e divieto di link o file speciali.
- Backup parziale o mix di epoche: coppia vincolata da `backup_set_id`, servizi fermi,
  manifest con hash e verifica post-creazione.
- Rollback malevolo: timestamp e versione sono evidenze, non autorità; l’operatore deve
  approvare il punto di ripristino e il drill registra l’esito fuori dal bundle.
- Bomba di decompressione: limiti prima dell’estrazione e conteggi manifest fail-closed.
- Perdita chiave di recovery: almeno due copie offline controllate e restore drill
  periodico; nessuna recovery backdoor nel prodotto.

La scelta del cifratore è registrata nell'ADR 0048 e come decisione chiusa in
`USER_DECISIONS.md`.
