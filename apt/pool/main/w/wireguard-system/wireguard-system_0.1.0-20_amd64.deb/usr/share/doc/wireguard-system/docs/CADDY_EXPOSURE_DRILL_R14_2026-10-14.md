# Drill R14 — policy di esposizione Caddy

Data: 2026-10-14

Target: `root@vrt-debian1.lsinet.it`, Debian 12 amd64, Caddy 2.6.2

Candidate installato: `wireguard-system 0.1.0-17`

## Scopo e confine

Il drill verifica il confine client → Caddy → socket Unix: TLS, allowlist basata
sull'indirizzo sorgente reale, resistenza agli header forwarded falsificati, limite dei
body e configurazione mTLS opzionale. Non autorizza l'esposizione Internet, non modifica
l'allowlist live e non abilita mTLS sul laboratorio.

La configurazione live iniziale e finale ha SHA-256
`fca04114b9123690215604d32ad0fd0186f067f96b00302a24b1ee09586969a2`. Consente
`127.0.0.1/32`, `::1/128` e la sorgente amministrativa storica
`192.168.185.15/32`; la workstation corrente arriva via `192.168.200.1` e rimane quindi
correttamente negata. L'accesso di bootstrap continua a essere possibile tramite tunnel
SSH verso il loopback, senza ampliare i CIDR.

## Risultati reali

| Controllo | Origine / stimolo | Esito |
|---|---|---|
| HTTPS consentito | `127.0.0.1` allowlisted, hostname reale, CA interna esplicitamente fidata | HTTP/2 `200`, `ssl_verify_result=0`, HSTS presente |
| HTTPS negato | `192.168.185.17`, indirizzo LAN del server non allowlisted | HTTP/2 `403`, `ssl_verify_result=0` |
| Redirect cleartext | porta 80, hostname reale | `308` verso HTTPS |
| Spoof allowlist | origine negata con `X-Forwarded-For: 192.168.185.15` | ancora `403` |
| Header verso Flask | origine loopback con XFF pubblico e proto/host ostili, request ID controllato | API `401`; audit registra `source_ip=127.0.0.1`, non il valore falsificato |
| Limite applicativo live | form da 1.048.577 byte attraverso Caddy corrente | rifiutato, ma inizialmente trasformato in `500`: P-029 |
| Limite Caddy candidato | proxy temporaneo solo `127.0.0.1:18080`, 999.999 / 1.000.001 byte | sotto limite raggiunge Flask (`400` CSRF), sopra limite `413` |
| Variante mTLS | `caddy adapt` e `caddy validate` con CA leggibile sul target | valida; client certificate `require_and_verify` e strict SNI attivi |

La richiesta API ostile ha prodotto intenzionalmente un solo record append-only
`api.authentication/denied` con `AUTHENTICATION_REQUIRED`; non ha creato utenti, token,
job o risorse di rete. `wg-portal audit-verify` conferma entrambe le giornate della catena.

## Problema trovato e correzione

P-029 era causato dall'ordine degli hook: `CSRFProtect` può leggere e rifiutare un body
prima del hook che crea il request ID. L'`after_request` tentava quindi di emettere un log
rigoroso con ID nullo, trasformando il `413` in `500`.

La correzione crea un UUID di correlazione anche per i rifiuti avvenuti prima dei normali
hook e usa sempre un ID non nullo nel log. Un test con body da 1 MiB + 1 verifica insieme
status `413`, pagina redatta, header `X-Request-ID` e JSON log valido. La configurazione
Caddy di riferimento applica inoltre `max_size 1MB`, così il proxy rifiuta in anticipo i
body oltre 1.000.000 byte; il limite Flask da 1 MiB resta una seconda difesa.

## mTLS opzionale

`packaging/caddy/wg-portal-mtls.caddy.example` è un'alternativa completa al file base,
non un file da caricare insieme a esso. Richiede un certificato client verificato per
l'intero origin, UI compresa, e conserva allowlist, limite body, header sovrascritti,
HSTS e socket Unix. La CA client deve essere dedicata; la CA TLS interna del laboratorio
è stata usata soltanto per validare la sintassi e non è una configurazione consigliata.

mTLS non sostituisce bearer/sessione, RBAC o allowlist e non giustifica CIDR pubblici.
Prima del reload l'operatore deve conservare accesso SSH/console, eseguire `caddy validate`
e provare un certificato client da una seconda sessione. La procedura completa è in
`docs/OPERATIONS.md`.

## Stato finale

- Caddy, `wg-portal-web.socket` e `wg-portal-web.service` sono attivi;
- nessuna unità systemd è fallita;
- non restano listener sulla porta temporanea 18080 né file temporanei R14;
- i soli listener applicativi di rete restano Caddy 80/443; Gunicorn resta sul socket;
- Caddyfile live invariato byte-per-byte e catena audit valida;
- esposizione Internet ancora vietata nella v1.

R14 è chiuso. Il passo successivo vincolante è R15.
