# Modello dati file-based

## Layout canonico

```text
data/
  meta.json
  users/<uuid>.json
  service-accounts/<uuid>.json
  api-credentials/<credential-uuid>.json   # hash Argon2id, mai secret in chiaro
  tenants/<uuid>/tenant.json
  tenants/<uuid>/networks/<uuid>/network.json
  tenants/<uuid>/networks/<uuid>/clients/<uuid>.json
  jobs/<yyyy-mm>/<uuid>.json
  audit/active/<yyyy-mm-dd>.jsonl
  audit/archive/<yyyy-mm-dd>.jsonl.gz
  runtime/locks/*.lock
  runtime/idempotency/service_account/<account-uuid>/<key-uuid>.json
  runtime/presence/<network-uuid>.json
  runtime/reconciler-health.json
  runtime/auth-rate-limits/<sha256>.json
  runtime/generated/...
```

Directory 0700, file contenenti dati/segreti 0600. I file sono indicizzati per UUID; ogni
documento canonico modificabile include `schema_version`, `id`, `revision`, `created_at`,
`updated_at`. Gli eventi audit append-only includono invece `schema_version`, `id` e
`occurred_at` e non hanno revisione. I timestamp sono UTC RFC 3339. Le relazioni salvano
UUID, non path.

## Contratti v1

| Documento | Stato e relazioni principali | Dati sensibili |
|---|---|---|
| `user` | stato account e assegnazioni discriminate per ruolo/scope | hash Argon2id |
| `tenant` | identità, slug e lifecycle | nessuno |
| `network` | tenant, desired state, IPv4, endpoint, porta e identità WireGuard | private key cifrata |
| `client` | tenant/rete, lifecycle, IP stabile, reservation, identità WireGuard e keepalive | private key cifrata |
| `job` | attore, operazione, risorsa, avanzamento ed errore redatto | nessun payload richiesta |
| `audit` | attore, azione, esito, risorsa e nomi dei campi cambiati | metadati minimizzati |
| `service_account` | stato, assegnazioni RBAC, permessi, UUID della credenziale attiva e marker opaco dell'ultima mutazione API | nessun secret |
| `api_credential` | identità proprietaria, scadenza e UUID pubblico | hash Argon2id del secret |
| `idempotency` | identità API, operazione, digest, ID preallocato, stato e risposta redatta | nessun token o payload richiesta |

M3.2 separa l'identità `service_account` dalla credenziale `api_credential`. Il secret è
mostrato una sola volta e non entra mai in JSON, indici, audit o backup; soltanto il suo
hash Argon2id viene persistito. `active_credential_id` è l'autorità: rotazione e revoca lo
aggiornano con compare-and-swap, rendendo immediatamente inerti i record non puntati.
Scadenza massima 90 giorni, ridotta a 24 ore con `client.config:read`. Gli indici derivati
non possono autorizzare una richiesta.

M3.4 introduce record idempotency schema v1 scoped all'identità macchina e alla chiave
UUID. La revisione 1 è `pending` e contiene digest SHA-256 canonico e ID risorsa
preallocato; la revisione 2 è `completed` e aggiunge soltanto status 2xx, header
`ETag`/`Location` allowlistati e body redatto. Payload richiesta e bearer token non sono
persistiti. La stessa chiave con operazione o digest diversi è un conflitto; un pending
viene rieseguito sotto lo stesso lock e con lo stesso ID. I completed sono eliminati dopo
24 ore; i pending restano finché un operatore li riconcilia. Cleanup lazy e comando di
manutenzione condividono un lock globale; quota per identità e riserva disco impediscono
nuove allocazioni prima della saturazione.

Per create/rotate di credenziali, il risultato completato è deliberatamente redatto e un
replay restituisce `CREDENTIAL_RECOVERY_REQUIRED`: il plaintext one-time non è mai
persistito. `last_api_mutation_id`, omesso dalle proiezioni, associa atomicamente l'effetto
alla mutazione sotto lock per service account. Consente il recovery esatto di revoke e il
rilevamento sicuro di un token create/rotate già emesso ma non più riproducibile.

La creazione rete M3.4 usa l'UUID idempotente come identità canonica e per derivare un
nome interfaccia Linux non controllabile dall'utente. La coppia WireGuard è casuale: la
pubblica resta nel documento e la privata entra immediatamente in un envelope AES-256-GCM
legato tramite AAD a tipo risorsa, tenant e rete. Create non persiste copie in chiaro e
non produce documenti parziali. CIDR e hub sono immutabili; archive conserva documento,
chiave e client per impedire riuso accidentale di identità o indirizzi.

La creazione client M3.4 usa analogamente l'UUID idempotente e genera la coppia WireGuard
all'interno del service layer. La privata entra subito in un envelope legato tramite AAD
a client, tenant e rete; la risposta espone soltanto la fingerprint della pubblica. Il
record nasce `pending/reserved`. Revoca e archiviazione conservano la reservation;
soltanto l'azione auditata `release-ip`, ammessa dopo revoke/archive, la porta a
`released`. Nome e descrizione sono gli unici campi patchabili direttamente.

Gli schemi Draft 2020-12 sono caricati dalle risorse del pacchetto tramite tipo e versione.
Rifiutano proprietà sconosciute. Validazioni tra file o semantiche, come unicità, subnet
RFC1918, appartenenza degli IP e transizioni, sono applicate dal dominio e repository.

## Coerenza e concorrenza

Il repository non promette transazioni multi-file. Ogni use case crea prima un journal/job
e applica una sequenza idempotente. Il campo `revision` abilita optimistic concurrency; i
lock per risorsa serializzano processi locali. Indici derivati possono essere ricostruiti
scansionando i file canonici.

Il repository espone create/get/list, patch compare-and-swap e cancellazione fisica
revisionata per i soli servizi che la policy autorizzerà. Una patch non può modificare
ID, versione, data di creazione o scope tenant/rete. I path vengono ricalcolati dal
contenuto a ogni lettura per rilevare documenti collocati sotto uno scope errato.

`runtime/indexes/documents-v1.json` elenca tipo, ID, path, revisione e scope ed è
interamente ricostruibile. Può essere obsoleto e non partecipa mai a decisioni RBAC. Le
migrazioni sono forward-only, avanzano una versione alla volta, preservano l'identità e
validano il risultato. Durante il restore l'intera catena viene verificata prima della
mutazione live, applicata a una copia sibling privata e descritta da un nuovo manifest;
bundle e albero estratto sorgente non vengono riscritti. Solo la copia migrata e validata
può attraversare la promozione con servizi e mutazioni fermi.

I bucket `runtime/auth-rate-limits` e `runtime/api-rate-limits` contengono soltanto
timestamp recenti; IP, username e identificatore credenziale sono presenti unicamente
nell'input di una SHA-256 usata come nome file. Sono cache di sicurezza effimere,
condivise tra processi e cancellabili soltanto a servizio fermo o tramite una futura
procedura amministrativa esplicita.

Ogni write: valida JSON Schema, preserva l'ultima versione valida, scrive un temporaneo
nella stessa directory, forza i buffer su disco e usa `os.replace`. Un backup consistente
richiede sospensione mutazioni o snapshot filesystem; copiare mentre si scrive non basta.
Gli output backup devono restare fuori dal data tree.

Il recovery set v1 è composto da due bundle separati `data` e `secrets` con lo stesso
`backup_set_id`. Il manifest interno registra path, mode, dimensione e SHA-256. Lo stato
canonico, i job, l’audit e l’idempotenza sono inclusi; lock, indici, presence, rate limit,
file generati e registry helper sono esclusi. Il contratto completo è in
`BACKUP_RESTORE.md` e ADR 0047.

## Segreti

Password: solo hash Argon2id. Chiavi pubbliche: JSON ordinario. Chiavi private client e
server: envelope AES-256-GCM v1 con nonce casuale da 96 bit; la master key è fornita da
credenziale systemd, file root-only esterno al data tree o KMS. La AAD lega il ciphertext
alla versione e agli UUID della risorsa. La conservazione cifrata consente download
successivi della configurazione soltanto dopo una nuova verifica autorizzativa.
Audit/log contengono fingerprint, mai chiavi.

M3.6 non introduce documenti persistenti per il download. Il service account e la sua
`api_credential` vengono riletti sotto il lock di lifecycle; `created_at` ed `expires_at`
devono descrivere una durata non superiore a 24 ore quando è presente
`client.config:read`. Profilo compilato e chiave decifrata sono valori effimeri in memoria
e non entrano in job, idempotency store, cache o file derivati.

L'implementazione M2.2 usa un file keyring JSON separato con una sola chiave `active` e
zero o più chiavi `retired`, tutte da 256 bit. Il file deve essere regolare, non un
symlink, e non concedere permessi a gruppo o altri. Ogni envelope registra il relativo
`key_id`; la rotazione aggiunge prima una nuova master key e il rewrap atomico e
revisionato ricifra poi i documenti. Le chiavi ritirate non si eliminano finché il rewrap,
i backup e il relativo periodo di conservazione non sono stati verificati.

L'audit usa JSONL nativo con rotazione giornaliera. I file restano operativi per 30
giorni, quindi possono essere compressi con gzip per export o backup; ogni copia gestita
dal sistema deve essere eliminata definitivamente al compimento di 3 mesi. Manifest e checksum
permettono di verificare integrità e completezza degli archivi.

Per ogni `<giorno>.jsonl` esiste `<giorno>.integrity.jsonl`: ciascuna riga contiene ID e
SHA-256 dell'evento, HMAC precedente e HMAC corrente. La catena include data, HMAC
precedente e byte canonici dell'evento, così rileva modifica, rimozione e riordino. La
chiave non è persistita nel data tree. Un append interrotto tra i due stream è rilevato e
blocca ulteriori scritture finché un operatore non esegue recovery; non viene riparato in
modo implicito.

Poiché non esistono transazioni tra audit e documenti distinti, le mutazioni critiche
registrano un evento `*_requested` prima dell'effetto e un evento finale dopo: un intent
senza esito segnala un'operazione da riconciliare dopo un crash.

I job live usano l'UUID della richiesta come chiave di idempotenza. Un retry con identici
attore, operazione e scope restituisce il documento esistente; un riuso differente è un
conflitto auditato. Le transizioni sono compare-and-swap: `queued -> running ->
succeeded|failed`, il progresso non regredisce e soltanto il successo raggiunge 100. Al
riavvio, ogni job ancora `running` viene chiuso da attore di sistema con codice
`WORKER_INTERRUPTED`; i job `queued` restano disponibili per una nuova invocazione worker.

Nel contratto job v1 l'attore è un one-of backward-compatible. I documenti originari e i
job UI usano `actor_user_id`; il valore nullo
`00000000-0000-0000-0000-000000000000` è riservato all'attore di sistema per il solo
`network.reconcile`. I nuovi job API usano invece la coppia
`actor_service_account_id`/`actor_credential_id`: non contengono token o hash e permettono
al worker di negare una credenziale ruotata, revocata o scaduta. La forma mista o
incompleta è rifiutata dallo schema. L'estensione è additiva e i file legacy non vengono
riscritti.

Il worker ricarica al consumo attore, rete e client canonici: il job non incorpora copie
di configurazioni o chiavi e non congela l'autorizzazione osservata all'enqueue. Progresso
e riepiloghi sono stringhe predefinite; gli errori persistono solo codice allowlistato e
messaggio pubblico redatto. L'UUID del job viene riusato come request ID del helper.

Per le azioni API l'UUID job è preallocato dallo store idempotency ed è distinto dalla
chiave HTTP. Start/stop persistono nel documento rete `last_api_mutation_id` insieme al
nuovo `desired_state`; il campo è interno e non appare nelle proiezioni. Consente di
riconoscere il retry esatto se il processo cade prima della creazione del job.

Le azioni lifecycle client salvano lo stesso marker interno quando cambiano stato o
reservation. Se una transizione aggiunge o rimuove un peer su rete running, il marker
permette di completare in retry l'enqueue del job `network.sync` senza ripetere la patch.
Transizioni senza effetto host non creano job e restituiscono direttamente la proiezione
client revisionata.

La capacità della coda deriva dai documenti job canonici e conta soltanto stati
`queued`/`running`. Un lock `runtime/locks/job-queue-capacity.lock` serializza scan e
create per job ID differenti. I default sono 1000 globali, 25 per attore, 100 per tenant
e 10 per rete; i terminali restano nello storico ma non consumano quota. Il retry dello
stesso UUID viene riconosciuto prima del conteggio.

Dopo 30 giorni entrambi gli stream sono compressi in `audit/archive/` e accompagnati da
un manifest con conteggio, HMAC finale e checksum dei file. Al compimento di tre mesi
calendario i tre file sono eliminati. Un export è un `tar.gz` con i file nativi verificati
e non contiene la chiave HMAC.

## Stato di presenza client

I documenti `runtime/presence/<client-uuid>.json` sono cache ricostruibili e non fonte di configurazione.

`runtime/reconciler-health.json` è uno stato derivato `0600`, aggiornato atomicamente dopo
ogni ciclo. Contiene solo versione, timestamp UTC, esito, fallimenti consecutivi e
contatori del report; non contiene ID, nomi, path o errori. È escluso dai backup e può
essere ricostruito dal primo ciclo successivo, mentre assenza o corruzione rendono il
controllo health negativo.
Per ogni client contengono: stato stimato, endpoint osservato, ultimo handshake, contatori
RX/TX, istante del campione e `online_since_estimated`. Non contengono chiavi private;
la chiave pubblica usata per correlare il peer resta nel record client canonico. Un
riavvio conserva la stima soltanto se il nuovo campione è coerente con la finestra
precedente, altrimenti lo stato diventa `unknown` fino a nuova evidenza.

M3.3 implementa questi record con schema `presence-v1`: identità tenant/rete/client,
istante osservato, stato, endpoint, ultimo handshake, contatori e
`online_since_estimated`. Ogni aggiornamento usa lock e rename atomico; un record con
identità diversa, campi extra o timestamp non valido non viene riparato implicitamente e
fa degradare lo snapshot a `unknown`.

Il parser M2.1 produce DTO immutabili in memoria. Endpoint runtime IPv4 o IPv6, ultimo
handshake UTC, byte RX/TX, AllowedIPs e keepalive derivano dal dump macchina. Le chiavi
private e preshared non entrano mai nel DTO; la chiave pubblica peer serve alla
correlazione con il client canonico, ma nelle serializzazioni diagnostiche viene sostituita
da un fingerprint SHA-256 completo. La UI potrà mostrarne una forma abbreviata senza
usarla per decisioni di sicurezza.

Gli schemi iniziali si trovano in `src/wg_portal/schemas/`. L'introduzione di ogni nuova
versione deve includere migrazione avanti, backup e test di compatibilità. La motivazione
dei contratti v1 è in `docs/decisions/0001-persistent-contracts-v1.md`; concorrenza,
indici e migrazioni sono motivati in
`docs/decisions/0002-repository-concurrency-and-indexes.md`.

## Configurazioni derivate

I file WireGuard compilati non sono documenti canonici e non introducono una nuova fonte
di verità. Sono derivati in modo deterministico da rete, client attivi e chiavi decifrate
soltanto in memoria. Il server usa indirizzo hub con prefisso della rete e un peer per
client attivo, ciascuno con `AllowedIPs = <IP>/32`; il client usa indirizzo `/32` e route
del solo CIDR VPN. Eventuali copie temporanee appartengono a `runtime/generated`, devono
essere `0600` e saranno gestite dal helper/reconciler con cancellazione e rollback.

## Registry privilegiato host

`/var/lib/wg-portal-helper/registry.json` non appartiene al data tree applicativo e non è
scrivibile dalla UI. Systemd crea la directory root-only `0700`; il file è `0600`, atomico
e protetto da lock. La struttura v2 associa ogni network UUID a tenant UUID, nome
interfaccia, stato `active`, SHA-256 della configurazione applicata, ultimo request ID,
timestamp e identità di isolamento opzionale. Quest'ultima contiene soltanto modalità
`vrf`, route table, CIDR e indirizzo hub verificati; nomi VRF/nft sono derivati. Non
contiene configurazioni, chiavi o path forniti dal chiamante. È la fonte
privilegiata per stabilire quali interfacce il helper può aggiornare o rimuovere; JSON non
canonico, collisioni, symlink, ownership o permessi inattesi bloccano le mutazioni.

All'avvio il helper migra atomicamente il formato v1 a v2, conservando le reti esistenti
con `isolation: null`: non deduce una VRF da un digest privo di indirizzamento. Un apply
futuro potrà promuovere la riga solo dopo avere creato e verificato l'isolamento. Versioni
sconosciute, identità discordanti e route table duplicate vengono rifiutate senza
riscrivere il file.

Le configurazioni attive non sono persistite dal helper. Per sync e rollback l'executor
legge configurazione e indirizzo correnti dal kernel, li valida e li mantiene soltanto in
memoria fino al termine dell'operazione. Il solo legame durevole con l'actual state resta
il digest nel registry privilegiato; una divergenza richiede reconcile esplicito.
