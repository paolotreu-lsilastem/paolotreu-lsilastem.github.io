# Disaster-recovery drill

## Esito corrente

Il drill M4.2 è stato completato il 2026-10-08 su `vrt-debian1`, Debian 12 Bookworm,
usando il pacchetto candidate `wireguard-system 0.1.0-5` costruito dal commit `1665f26`.
Il pacchetto aveva SHA-256
`573ab3c30a0b08a57627959325ba7675521401cfe6e20a7aeb37d6e78319f747`.

Il target partiva da `0.1.0-4`, con socket web, servizio web, reconciler e socket helper
attivi, nessuna interfaccia WireGuard e registry privilegiato vuoto. L'upgrade ha
preservato byte-per-byte environment, master keyring e data tree.

## Sequenza verificata

1. Una identity X25519 effimera è stata generata sulla WSL; sul server è stato configurato
   soltanto il recipient pubblico e l'environment originale è stato custodito in `/run`.
2. `backup-create` ha fermato e ripristinato i writer, producendo due bundle `0600` dello
   stesso set in 3 secondi.
3. I ciphertext copiati sulla WSL hanno mantenuto gli stessi SHA-256 del server.
   `backup-verify` e `restore-preflight` sono passati; target e staging locali sono rimasti
   assenti dopo il cleanup.
4. `restore-apply` senza `--replace` e con UUID intenzionalmente errato ha restituito
   errore redatto. In entrambi i casi servizi e marker post-backup sono rimasti invariati.
5. Il restore confermato ha promosso data, environment e keyring, eliminato il marker
   creato dopo il backup, lasciato tutte le reti recuperate ferme e riportato attive le
   quattro unità in 3 secondi. Doctor, audit, socket Unix e Caddy HTTPS/HSTS sono risultati
   sani; non erano presenti interfacce o residui restore.
6. Un secondo restore ha iniettato un check host finale negativo dopo la promozione. La
   transazione ha ripristinato byte-per-byte data tree, environment e keyring, eliminato
   journal/staging e lasciato tutte le unità inattive. Il riavvio manuale previsto dal
   runbook ha ripristinato entrambe le health route.
7. Environment originale, owner e mode sono stati ripristinati. Identity privata, bundle,
   script di fault injection e pacchetti temporanei sono stati eliminati; il candidate
   `0.1.0-5` è rimasto installato.

## RPO e RTO osservati

- **RPO del punto verificato: zero rispetto alla conclusione del backup.** Il marker creato
  dopo il checkpoint non è ricomparso. In esercizio l'RPO massimo equivale invece all'età
  dell'ultimo recovery set completo e verificato; il prodotto non promette un intervallo
  senza una frequenza di backup definita dall'operatore.
- **RTO del restore: 3 secondi**, misurati dall'avvio di `restore-apply` al ritorno `active`
  delle quattro unità sul dataset di laboratorio. Non include preparazione operatore,
  trasferimento dei bundle, verify/preflight offline o diagnosi di un eventuale errore.
- **Finestra di backup osservata: 3 secondi**, inclusi quiesce, costruzione dei due bundle
  e ripristino delle unità precedentemente attive.

## Limiti e criterio di riuso

Il dataset conteneva 24 file host, quattro file inclusi nel bundle dati, un utente e
nessuna rete o job canonico; i conteggi del restore erano quindi zero per reti fermate,
job interrotti e risorse host rimosse. I casi non-zero restano coperti dai test automatici,
ma i tempi osservati non vanno estrapolati a installazioni grandi o con molte VPN attive.

Ogni release che modifica formato persistente, manifest, cifratura, journal, ordine di
quiesce/promozione o unità systemd deve ripetere il drill. Registrare dimensione del set,
numero di reti/job/client, filesystem, durata di backup, verify, preflight e restore,
nonché l'esito di rollback, audit, health e cleanup.
