# Verbale R24 — build, firma e trust APT del candidate finale

Data: 2026-10-15  
Esito: **PASS**  
Candidate: `wireguard-system 0.1.0-18` per Debian 12 Bookworm `amd64`  
Keyring: `wireguard-system-archive-keyring 2026.10.15-1` (`all`)

## Identità del sorgente

Il tag annotato `v0.1.0-18-rc1-freeze` e la provenienza indicano entrambi il commit:

```text
680a21a40ba8c053126ced4ebfbb3291c822719a
```

La pipeline ha rifiutato modifiche al sorgente e ha costruito dal tree pulito congelato.
Le modifiche documentali che registrano questo verbale sono successive e non sono state
incluse negli artefatti.

## Gate di build

`scripts/build-release-candidate.sh` ha completato sul commit congelato:

- Ruff, Mypy e controllo OpenAPI;
- 1.081 test superati e una sola integrazione APT opt-in saltata nel gate ordinario;
- copertura complessiva 84%;
- audit Python senza vulnerabilità note sulle 24 dipendenze production hash-locked;
- SBOM CycloneDX, manifest di sicurezza, inventario Debian e provenienza in-toto/SLSA;
- build dei due package e archivio sorgente.

L'integrazione APT opt-in è stata poi eseguita separatamente con `reprepro` e chiave
effimera: `1 passed`.

## Artefatti autenticati

Il maintainer ha firmato offline `SHA256SUMS` nel namespace
`release@wireguard-system`. Il verificatore locale ha accettato firma SSHSIG, policy di
revoca, manifest, checksum e provenienza.

| Artefatto | SHA-256 |
|---|---|
| `SHA256SUMS` | `3a4af172e8f44bac9fa70edc4c4b822c48381cb59736ab5b0e30e75ab30c02c8` |
| `SHA256SUMS.sig` | `fc5777f8c687fb8f1a39ea1235de9dc64464e067e943c2d3d150d5f8c69cfb58` |
| `provenance.intoto.json` | `f5f667c5a0bcb758a22ef7029331e7939839f2948a34e56b5b18d062269133ec` |
| `wireguard-system_0.1.0-18_amd64.deb` | `0bd76106ddb0d71f73b1c1e38af51f2a8c258b5d4188e63e4f6cab16d4f2989f` |
| `wireguard-system-archive-keyring_2026.10.15-1_all.deb` | `f55a2132e4f8c48cfd759c68b214d44db91934f01f86311c31dcd2615fcf2dc9` |

Il manifest contiene dieci file e `sha256sum --check SHA256SUMS`, eseguito dalla root
del bundle, li ha verificati tutti. Il package applicativo dichiara Python `>= 3.11` e
`<< 3.12`, schema dati 1, predecessor esclusivo `0.1.0-17` e recovery protocol 1.

## Collaudo repository e lifecycle della keyring

Il drill isolato sotto `/tmp` non ha modificato sistema installato, repository pubblica
o chiavi reali. Ha verificato:

1. pubblicazione del bundle realmente firmato in una repository `reprepro` temporanea;
2. presenza APT delle versioni `0.1.0-18` e `2026.10.15-1`;
3. seconda pubblicazione idempotente e verifica completa di `InRelease`, indici,
   checksum e file nel pool;
4. contenuto del package production keyring uguale al fingerprint atteso
   `2B3CFA6779E395C0CDA208B7AE7A30DC2F970ACF`;
5. bootstrap con chiave effimera A, aggiornamento via APT a un package contenente A+B,
   cambio della firma repository alla chiave B, aggiornamento a un package contenente
   soltanto B e nuovo `apt update` riuscito.

La sequenza conferma che rinnovo e rotazione possono essere distribuiti prima del cambio
di firma. La chiave production non è stata ruotata e nessuna chiave privata è entrata nel
bundle. P-018 è chiuso.

## Problemi operativi osservati

- P-042: il primo controllo checksum era stato invocato dalla directory errata; il retry
  con `cd` esplicito ha verificato tutti gli artefatti.
- P-043: il sandbox ristretto impediva l'avvio di `gpg-agent`; lo stesso test isolato,
  eseguito con accesso ai normali socket di processo, è passato senza installare software.

Nessuno dei due è un difetto del prodotto o ha modificato artefatti/repository reali.

## Limiti e passaggio successivo

R24 non autorizza ancora la pubblicazione stabile. L'installazione privilegiata, il
bootstrap, UI/API, WireGuard multi-client e isolamento, backup/restore, upgrade reale da
`0.1.0-17`, remove/reinstall e cleanup sul target Debian pulito appartengono a R25.
La v1 resta priva di audit indipendente per il waiver R19 e conserva i rischi P-005 e
P-019 dichiarati.

