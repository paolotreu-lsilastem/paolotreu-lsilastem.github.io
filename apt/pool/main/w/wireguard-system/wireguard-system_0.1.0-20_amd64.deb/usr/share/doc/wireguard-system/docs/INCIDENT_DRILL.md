# Drill incidenti M4.3

## Stato

Completato il 2026-10-12 sul laboratorio isolato `vrt-debian1`. Il target esegue
`0.1.0-12`; staleness, failure helper confinato, recupero, Unix/HTTPS, separazione
journald e cleanup sono stati verificati realmente. Tutte le evidenze sono `Superato` e
M4.3 è chiusa. Il verbale storico del 2026-10-08, quando nessuna modifica remota era stata
eseguita perché il target non era risolvibile, non descrive più lo stato corrente.

## Prerequisiti

- host Debian 12 isolato e autorizzato, raggiungibile come root;
- candidate `.deb` con SHA-256 registrato nel verbale;
- backup coerente verificato e hash pre-upgrade di environment, keyring e documenti
  canonici, senza riportarne il contenuto;
- registry helper vuoto e nessuna interfaccia/VRF/tabella nftables di test residua;
- nessuna rete o job production; Caddy di laboratorio e accesso console/SSH alternativo;
- orari UTC sincronizzati e directory evidenze privata.

## Sequenza obbligatoria

1. Inventario read-only: versione, unità, socket, timer, WireGuard, forwarding, registry,
   `/healthz`, `/readyz`, `doctor`, `helper-probe`, `audit-verify` e namespace journal.
2. Conferma del candidate installato dalla baseline R03; confronto hash e permessi di
   environment, keyring e storage. Non reinstallare senza motivo. `systemd-analyze
   verify` deve essere pulito.
3. Verifica del primo ciclo: file health `0600`, CLI `OK`, readiness con check
   `reconciler=OK`, timer attivo ed evento JSON nel namespace.
4. Arresto controllato del solo reconciler, senza reti attive. Attendere la soglia reale e
   verificare `RECONCILER_STALE`, exit code CLI non zero e timer fallito senza restart.
5. Riavvio esplicito del reconciler; osservare due cicli riusciti e ritorno automatico a
   `OK`, senza modificare il file health manualmente.
6. Con registry vuoto, applicare al solo reconciler un drop-in systemd runtime che azzeri
   e ridefinisca `ExecStart`, anteponendo
   `/usr/bin/env WG_PORTAL_HELPER_SOCKET=/run/wg-portal/r04-missing-helper.sock`. Un semplice
   `Environment=` non sovrascrive il valore dell'`EnvironmentFile` e non costituisce una
   valida iniezione. Verificare codici redatti, backoff e soglia `RECONCILER_FAILED`;
   rimuovere il drop-in esatto, eseguire daemon-reload e confermare recupero su ciclo
   riuscito. Il socket helper reale e il web non devono essere fermati o riconfigurati.
7. Verificare separatamente percorso Unix e HTTPS Caddy, query del namespace journald e
   assenza di eventi nel journal globale attesi come applicativi.
8. Eseguire la raccolta evidenze del runbook, revisionarla e distruggerla soltanto secondo
   la policy del laboratorio.
9. Cleanup: unità tutte attive, timer sano, registry vuoto, nessuna interfaccia/VRF/tabella
   residua, forwarding invariato, hash persistenti uguali e audit verificato.

Il caso backlog stale è coperto deterministicamente dalla suite automatica. Un drill host
può aggiungerlo solo tramite job di laboratorio creati dai servizi applicativi, mai
editando o copiando documenti JSON a mano.

## Evidenze da compilare

| Evidenza | Esito | Riferimento redatto |
|---|---|---|
| Versione e SHA-256 candidate | Superato | `0.1.0-12`; `.deb` `4b993ef0…269` |
| Hash persistenti pre/post uguali | Superato | environment, keyring, meta, registry e Caddy invariati; digest R04 `bcf73f82…814a` |
| Unit file e hardening verificati | Superato | dpkg integro; `systemd-analyze verify` pulito |
| Primo ciclo e timer sani | Superato | health `0600`; CLI/readiness `OK`; timer attivo |
| Rilevamento `RECONCILER_STALE` | Superato | 12:41:25 UTC, exit 1; readiness 503, liveness 200 |
| Recupero dopo restart esplicito | Superato | quattro cicli sani dal 12:42:15 UTC; timer tornato `success` |
| Rilevamento `RECONCILER_FAILED` | Superato | tre cicli falliti alle 12:45:31/:33/:37 UTC; exit 1 e readiness 503 |
| Recupero helper e backoff | Superato | backoff 2/4 s; due cicli sani dopo cleanup alle 12:46:24/:55 UTC |
| Health Unix e HTTPS | Superato | liveness/readiness 200 su socket e Caddy dopo il recupero |
| Namespace journald separato | Superato | 35 record applicativi nel namespace, zero nel journal globale |
| Cleanup e audit finali | Superato | systemd `running`, audit valido, registry/rete vuoti, forwarding `0` |

## Esecuzione e limiti osservati

La baseline è stata acquisita alle 12:30:30 UTC e il controllo finale alle 12:49:15 UTC.
Il reconciler è rimasto fermo dalla 12:31:12 fino al rilevamento stale; il timer ha
fallito senza riavviarlo. Dopo il restart esplicito, il file health è tornato sano senza
essere modificato manualmente.

Il primo tentativo di failure injection ha prodotto un ciclo sano e si è fermato
fail-closed: `Environment=` non aveva precedenza sull'`EnvironmentFile`. Il secondo
tentativo ha usato il solo override `ExecStart` sopra documentato e ha dimostrato soglia
e backoff. Nessun dato, secret, socket helper reale o risorsa rete è stato modificato.
P-015 registra questo limite operativo del runbook.

Le evidenze redatte restano sul laboratorio in
`/var/tmp/wg-portal-incident-20261012T123030Z`, directory `0700` root e cinque file `0600`
root, circa 19 KiB. La revisione non ha trovato indicatori di password, chiavi private,
token, cookie o header di autorizzazione. Non sono state esportate nel repository e non
vanno eliminate fuori dalla policy di conservazione delle evidenze.

Gli SHA-256 sono:

- `doctor.txt`: `f3fcc1b7be4a47482e2e10a35f0ae0fbd637f59e54abad0308173b779932c5f8`;
- `drill-summary.txt`: `71c459ac1c3f7ac5687e674386ce3d103c8ec0f9920fe7fc5ecfac08b2529c5e`;
- `helper-probe.json`: `26a9c077683e270b0eef59ca9d7359ec5797ed465e7c5e9a7a02377ed6c813d7`;
- `journal.txt`: `84b4e5531d64b9f44b829d905a612a7a852874c266d59d1ece98e85007889613`;
- `systemd-status.txt`: `0a9b79385944cc228d950fb4a72b7c9774c2bdd7af5e91b2fece30c672beeafb`.

## Criterio di chiusura

M4.3 è chiusa perché tutte le righe sono `Superato`, il tentativo di iniezione inefficace
è descritto, il cleanup è confermato e roadmap, changelog, handoff e questo verbale
riportano il candidate `0.1.0-12` e lo stesso esito.
