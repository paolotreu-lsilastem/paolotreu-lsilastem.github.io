# Runbook incidenti operativi

Questo runbook è la procedura M4.3 per diagnosticare il portale, il reconciler, il helper,
WireGuard e il percorso HTTPS. È destinato a operatori root della macchina server. Le
azioni iniziali sono esclusivamente read-only; ogni mutazione richiede causa identificata,
backup coerente e una decisione umana esplicita.

## Regole inderogabili

- Non mostrare, copiare o allegare environment, keyring, configurazioni client, chiavi
  WireGuard, cookie, token o header di autenticazione.
- Non cancellare journal restore, staging, rollback, registry helper, lock o file JSON per
  far scomparire un errore.
- Non usare `wg-quick`, `ip`, `wg` o `nft` manualmente sulle risorse gestite: il helper e
  il reconciler sono gli unici writer host autorizzati.
- Non aggirare `/readyz`, capability, RBAC, allowlist Caddy o controllo peer credential.
- Non creare restart loop. Un riavvio è una misura successiva alla diagnosi, non una
  diagnosi, e può applicare lo stato desiderato pendente.
- Conservare evidenze con permessi `0700`/`0600`, revisionarle prima dell’esportazione e
  trasferirle solo attraverso il canale amministrativo approvato.

## Severità e obiettivi

| Livello | Criterio | Prima risposta |
|---|---|---|
| SEV-1 | sospetta esposizione di chiavi/token, isolamento cross-tenant violato, traffico Internet instradato o perdita dati | bloccare l’esposizione esterna, preservare evidenze e avviare escalation sicurezza; non tentare riparazioni di rete manuali |
| SEV-2 | control plane non ready, reconciler fermo, helper indisponibile, più reti non convergenti | triage entro 15 minuti, sospendere nuove mutazioni amministrative e identificare il componente |
| SEV-3 | singola rete/client degradato, dashboard stale, log/timer degradati senza perdita di controllo | raccogliere evidenze e correggere nella finestra operativa |

La chiusura richiede causa identificata, probe nuovamente sani, assenza di risorse residue,
audit verificato e annotazione di orari, comandi ed esiti. Un ritorno temporaneo a HTTP
`200` non è da solo una root cause analysis.

## Triage iniziale read-only

Eseguire nell’ordine, senza stampare file di configurazione:

```bash
date --utc --iso-8601=seconds
systemctl --failed --no-pager
systemctl status --no-pager wg-portal-web.service wg-portal-reconciler.service
systemctl status --no-pager wg-portal-helper.socket wg-portal-reconciler-health.timer
curl --fail --unix-socket /run/wg-portal/web.sock http://localhost/healthz
curl --silent --show-error --unix-socket /run/wg-portal/web.sock http://localhost/readyz
runuser -u wg-portal -- /usr/bin/wg-portal reconciler-health
runuser -u wg-portal -- /usr/bin/wg-portal doctor
runuser -u wg-portal -- /usr/bin/wg-portal helper-probe --json
journalctl --namespace=wg-portal --since '-15 minutes' --no-pager -o short-iso
```

Interpretare separatamente i livelli:

1. `/healthz` prova soltanto che Gunicorn/Flask risponde.
2. `/readyz` individua la dipendenza non pronta con codici redatti.
3. `reconciler-health` prova freschezza dei cicli e backlog senza chiamare il helper.
4. `helper-probe` osserva prerequisiti host e stato WireGuard senza mutazioni.
5. Dashboard e audit definiscono lo scope applicativo; il journal spiega il processo.

## Matrice dei codici readiness

| Codice | Significato operativo | Verifiche sicure | Azione successiva |
|---|---|---|---|
| `STORAGE_UNSAFE` | data dir o `meta.json` è linkato, non regolare o troppo permissivo | `namei -l /var/lib/wg-portal/meta.json`; `stat -c '%U:%G %a %F %h' /var/lib/wg-portal /var/lib/wg-portal/meta.json` | sospendere mutazioni; correggere ownership/mode solo dopo avere escluso sostituzioni o link ostili |
| `STORAGE_UNAVAILABLE` | storage o metadata non sono leggibili/validi | spazio e inode con `df -h /var/lib/wg-portal` e `df -i /var/lib/wg-portal`; journal web | ripristinare filesystem/permessi; se i dati sono corrotti seguire il restore verificato |
| `STORAGE_SCHEMA_UNSUPPORTED` | schema dati non coincide con quello del binario | confrontare versione pacchetto e backup disponibili, senza modificare `meta.json` | usare upgrade/migrazione supportata; mai retrocedere o editare la versione a mano |
| `RECOVERY_STATE_INVALID` | journal restore presente ma non autenticabile/valido | `stat` del journal sibling e journal delle unità; non leggerlo né cancellarlo | quiesce e recovery secondo `BACKUP_RESTORE.md`; escalation se l’origine non è nota |
| `RECOVERY_PENDING` | transazione restore interrotta richiede recovery | controllare unità ferme e log del comando restore | completare recovery con la procedura M4.2; non avviare servizi prima dell’esito |
| `KEYRING_NOT_CONFIGURED` | production non indica il keyring esterno | verificare presenza della variabile per nome, senza stamparne il valore | correggere l’environment tramite procedura di deploy e rivalidare prima dell’avvio |
| `KEYRING_UNAVAILABLE` | keyring assente, non privato, corrotto o illeggibile | `namei -l /etc/wg-portal/master-keyring.json`; `stat -c '%U:%G %a %F %h'` sul file | ripristinare il secret dal recovery set coerente; non crearne uno nuovo su dati esistenti |
| `HELPER_UNAVAILABLE` | socket non raggiungibile o timeout | stato socket/istanze helper e `helper-probe`; verificare `/run/wg-portal/helper.sock` senza aprirlo con tool generici | correggere unità/socket dopo la causa; non eseguire Flask come root |
| `HELPER_REJECTED` | helper ha risposto con rifiuto autenticato | cercare `helper.process.failed` nel namespace e verificare UID/gruppi/unità installate | riallineare package e unità; non allargare `SocketMode` o gruppo |
| `HELPER_RESPONSE_INVALID` | risposta helper non rispetta il protocollo chiuso | confrontare versione package, launcher e unità; journal helper | trattare come incompatibilità/corruzione e reinstallare lo stesso candidate verificato |
| `HELPER_CAPABILITY_MISSING` | manca `per-network-vrf-v1` | `helper-probe --json`, versione package e hash dell’artefatto approvato | bloccare overlap e mutazioni; aggiornare insieme web, reconciler e helper |
| `HELPER_HOST_UNHEALTHY` | un prerequisito host è `error`/`unavailable` | leggere i check redatti del probe, stato kernel/systemd/nftables | correggere il prerequisito; non forzare lo stato rete a `running` |
| `RECONCILER_STATE_MISSING` | nessun ciclo ha ancora pubblicato health | stato e journal reconciler, età dall’avvio | attendere un ciclo solo se il servizio è appena partito; altrimenti trattare come processo guasto |
| `RECONCILER_STATE_INVALID` | file derivato non è privato, regolare o valido | `stat` del solo file health e journal reconciler; non editarlo | correggere la causa del writer; un nuovo ciclo sano lo sostituisce atomicamente |
| `RECONCILER_STALE` | ultimo ciclo oltre soglia | stato servizio, timestamp journal, clock host e backoff configurato | risolvere blocco/clock/dipendenza; riavviare solo dopo avere compreso lo stato desiderato pendente |
| `RECONCILER_FAILED` | fallimenti consecutivi hanno raggiunto la soglia | ultimi `reconciler.cycle.completed`, `helper-probe`, coda job dalla UI/API | correggere il codice stabile ricorrente e osservare un ciclo riuscito |
| `RECONCILER_BACKLOG_STALE` | job `queued`/`running` non cambia oltre soglia | elenco job scoped UI/API, stato worker/reconciler e relativo journal | evitare nuovi job; risolvere lock, helper o capacità senza cancellare documenti |
| `RECONCILER_BACKLOG_UNAVAILABLE` | la scansione read-only dei job non è affidabile | permessi/forma delle partizioni job, spazio filesystem e journal | trattare come problema storage; non rinominare o rimuovere job manualmente |

`NOT_REQUIRED` e `OK` non sono errori. `NOT_REQUIRED` è ammesso soltanto fuori dalla
configurazione production.

## Matrice dei codici di processo

Questi codici compaiono negli eventi JSON allowlistati del namespace `wg-portal`:

| Evento/codice | Interpretazione | Risposta |
|---|---|---|
| `reconciler.process.failed` / `KEYRING_NOT_CONFIGURED` | il processo continuo non può essere costruito in sicurezza | ripristinare configurazione/keyring; non usare un keyring nuovo |
| `reconciler.process.failed` / `RECONCILER_INITIALIZATION_FAILED` | app factory o dipendenza persistente non inizializzabile | correlare con readiness, versione e permessi; evitare restart ripetuti |
| `reconciler.process.failed` / `RECONCILER_RUNTIME_FAILED` | errore non esposto durante loop o persistenza health | preservare journal e verificare filesystem/helper; escalation applicativa |
| `helper.process.failed` / `ROOT_REQUIRED` | helper avviato fuori dall’unità privilegiata prevista | verificare unità/launcher; non aggiungere sudo al web |
| `helper.process.failed` / `INVALID_TIMEOUT` | configurazione timeout helper non valida | ripristinare il valore vendor approvato |
| `helper.process.failed` / `ALLOWED_USER_NOT_FOUND` | identità `wg-portal` assente | riparare installazione package/account di sistema |
| `helper.process.failed` / `REGISTRY_UNAVAILABLE` | registry root-owned assente, insicuro o invalido | sospendere mutazioni; verificare directory e recovery, senza ricrearlo a mano |
| `helper.process.failed` / `REQUEST_REJECTED` | peer credential, protocollo o payload rifiutato | correlare unità chiamante e versioni; non rilassare autenticazione o schema |
| `http.request.failed` / `UNHANDLED_EXCEPTION` | errore web inatteso redatto | usare request ID e timestamp nel journal; non abilitare traceback/debug in production |
| `http.request.failed` / `CSRF_REJECTED` | sessione/form non presenta token valido | verificare flusso UI, cookie HTTPS e proxy; non disabilitare CSRF |

## Sintomi senza codice readiness

| Sintomo | Diagnosi iniziale | Azione sicura |
|---|---|---|
| HTTPS non raggiungibile ma socket Unix sano | `systemctl status caddy`; `caddy validate --config /etc/caddy/Caddyfile`; certificato, DNS e allowlist | correggere Caddy/DNS senza esporre Gunicorn su TCP pubblico |
| Anche `/healthz` Unix fallisce | stato socket/web, spazio, journal e unità installata | correggere processo/socket; non cambiare ownership del socket fuori dal modello package |
| Una sola rete è `unknown`/`drift` | telemetria scoped, job rete e helper probe | usare start/stop/sync/reconcile gestiti dopo diagnosi; niente comandi host manuali |
| Client senza handshake ma rete sana | chiave pubblica, stato client, endpoint e UDP esterno; mai stampare chiave privata | rigenerare/scaricare configurazione solo con flusso autenticato e auditato |
| Traffico client-to-client assente | peer attivi, route `/32`, VRF e policy nft dal probe | reconcile gestito; SEV-1 se compare comunicazione cross-tenant o Internet |
| Journal namespace assente | `systemctl status systemd-journald@wg-portal.service`; `systemd-analyze cat-config systemd/journald@wg-portal.conf` | ripristinare drop-in package; non modificare quota del journal globale |
| Timer health fallito | `systemctl status wg-portal-reconciler-health.service`; eseguire CLI come `wg-portal` | risolvere il codice restituito; il timer non deve diventare un autoriparatore |

## Raccolta evidenze locale

Creare una directory con nome esplicito sostituendo il timestamp, senza automazioni che
possano scegliere un path inatteso:

```bash
install -d -m 0700 /var/tmp/wg-portal-incident-YYYYMMDDTHHMMSSZ
systemctl status --no-pager wg-portal-web.service wg-portal-reconciler.service \
  wg-portal-helper.socket wg-portal-reconciler-health.service \
  > /var/tmp/wg-portal-incident-YYYYMMDDTHHMMSSZ/systemd-status.txt
journalctl --namespace=wg-portal --since '-30 minutes' --no-pager -o short-iso \
  > /var/tmp/wg-portal-incident-YYYYMMDDTHHMMSSZ/journal.txt
runuser -u wg-portal -- /usr/bin/wg-portal doctor \
  > /var/tmp/wg-portal-incident-YYYYMMDDTHHMMSSZ/doctor.txt
runuser -u wg-portal -- /usr/bin/wg-portal helper-probe --json \
  > /var/tmp/wg-portal-incident-YYYYMMDDTHHMMSSZ/helper-probe.json
chmod 0600 /var/tmp/wg-portal-incident-YYYYMMDDTHHMMSSZ/*
```

Non includere `/etc/wg-portal`, `/var/lib/wg-portal`, `/var/lib/wg-portal-helper`, output
di `wg show all dump`, configurazioni WireGuard o header HTTP. Prima di comprimere o
esportare, revisionare manualmente ogni file. Audit e backup hanno procedure dedicate e
non vanno copiati nel bundle diagnostico.

## Ripristino controllato ed exit criteria

1. Registrare causa, scope, primo/ultimo timestamp e versione package.
2. Correggere una sola dipendenza alla volta seguendo il documento proprietario:
   `OPERATIONS.md`, `BACKUP_RESTORE.md` o `DISASTER_RECOVERY_DRILL.md`.
3. Se serve un riavvio, verificare prima job e desired state; riavviare soltanto l’unità
   interessata e osservare almeno due cicli reconciler.
4. Verificare `/healthz`, `/readyz`, `reconciler-health`, `helper-probe`, dashboard scoped e
   `wg-portal audit-verify`.
5. Confermare che registry/interfacce/VRF/nftables non contengano residui estranei e che
   `ip_forward` sia tornato alla policy host approvata.
6. Chiudere soltanto dopo avere conservato evidenze redatte, aggiornato il ticket e creato
   remediation/test se l’incidente ha rivelato un gap.

## Drill periodico

Il protocollo e il registro delle prove sono in `INCIDENT_DRILL.md`. Il drill deve usare
un host isolato, nessuna rete production e cleanup verificato. Arrestare componenti o
iniettare guasti non è autorizzato da questo documento su host diversi dal laboratorio
esplicitamente approvato.

Il drill M4.3 è stato superato sul laboratorio il 2026-10-12. Per simulare un helper
irraggiungibile nel solo reconciler, il drop-in runtime deve azzerare e ridefinire
`ExecStart` anteponendo `/usr/bin/env WG_PORTAL_HELPER_SOCKET=<socket-inesistente>`.
`Environment=` da solo non prevale sul valore omonimo dell'`EnvironmentFile`. Non copiare
l'environment in un file temporaneo e rimuovere sempre l'esatto drop-in dopo la prova.
