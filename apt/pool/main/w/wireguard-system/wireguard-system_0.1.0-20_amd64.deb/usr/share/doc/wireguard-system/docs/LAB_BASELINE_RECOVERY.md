# Inventario e piano di ripristino della baseline Debian

## Scopo e stato

Questo documento conserva evidenza e piano di `R01`. L'inventario iniziale è stato
raccolto il 2026-10-12 tramite SSH su `vrt-debian1.lsinet.it` esclusivamente con comandi
read-only. In quella fase non furono eseguiti installazioni, rimozioni, restart, reset di
unità, modifiche di rete o letture in chiaro di environment, keyring e documenti
sensibili. `R03` ha poi applicato il piano ed è chiusa; l'esito è registrato in fondo.

I vincoli seguenti restano il verbale storico della baseline precedente e del percorso di
recovery; non autorizzano nuove mutazioni fuori dalle unità successive della roadmap.

## Inventario redatto

### Host e package

| Controllo | Stato osservato |
|---|---|
| Host | Debian 12 Bookworm `amd64`, kernel `6.1.0-30-amd64`, VMware |
| Tempo | `Europe/Rome`, NTP sincronizzato, RTC non locale |
| Package | `wireguard-system 0.1.0-5` registrato da dpkg come `installed` |
| Integrità dpkg | `dpkg -V wireguard-system` e `dpkg --audit` senza output |
| Repository APT | Nessuna versione remota candidata; sola versione installata `0.1.0-5` |
| Rollback locale | `dist/wireguard-system_0.1.0-5_amd64.deb`, SHA-256 `573ab3c30a0b08a57627959325ba7675521401cfe6e20a7aeb37d6e78319f747` |
| Filesystem root | 19 GiB, 2,4 GiB liberi, 87% utilizzato; inode liberi sufficienti |

Il controllo del 2026-10-08 che non trovava il package resta un'evidenza storica, ma non
descrive più lo stato attuale. Non è stata eseguita alcuna mutazione durante il nuovo
inventario e non è possibile attribuire retroattivamente il cambiamento.

### systemd e servizi

`systemctl is-system-running` restituisce `degraded`. Le sole unità fallite sono due
istanze socket-activated del helper, terminate con exit code `1` il 2026-10-05:

- `wg-portal-helper@34-290472-0.service`;
- `wg-portal-helper@35-290472-0.service`.

Il journal non conserva più eventi per quelle due invocation ID, quindi la causa esatta
non è ricostruibile. Le istanze coincidono temporalmente con i precedenti test negativi
del helper, ma questa correlazione non viene trattata come prova. Lo stato fallito è
storia systemd residua, non un processo ancora in esecuzione.

Sono attivi e senza restart automatici osservati:

- `wg-portal-web.socket` e `wg-portal-web.service`;
- `wg-portal-helper.socket`;
- `wg-portal-reconciler.service`;
- `caddy.service`.

Il package `0.1.0-5` non contiene ancora
`wg-portal-reconciler-health.timer` e la relativa unità service; entrambe risultano
`not-found`, coerentemente con l'età del package. Gli unit file presenti sono payload
dpkg integri sotto `/lib/systemd/system`, alias dello stesso filesystem esposto anche da
`/usr/lib/systemd/system`. Non sono presenti drop-in del portale.

### Dati, configurazione e registry

| Oggetto | Metadati e contenuto redatto |
|---|---|
| `/var/lib/wg-portal` | directory `0700 wg-portal:wg-portal`, circa 80 KiB |
| `/etc/wg-portal` | directory `0750 root:wg-portal`, circa 12 KiB |
| Environment | file `0640 root:wg-portal`, SHA-256 `2541a4c20f3e0b1efe26a4e62895197c47f5ebe685d915e94d6bc7317889abcf` |
| Master keyring | file `0600 wg-portal:wg-portal`, SHA-256 `c353dea8681d864e57d04d1433fb0c02377fa0686f9e88812f743d1207d00bb6` |
| Meta storage | schema dati `1`, SHA-256 `e1f736b0f499d63f46b092a29b8fa555b3db600e1350b6bdb62e7d6acd21d87f` |
| Registry helper | formato v2, directory `0700 root:root`, file `0600 root:root`, zero reti, SHA-256 `571bb8f03c7fffff060975bf63455c80bb54d47e7c30dfc30b7ab5f1ebdd7d72` |
| Dataset | un utente; zero tenant, reti, client, job, service account e credenziali API |
| Audit | coppia JSONL/integrity del 2026-10-08 presente con mode `0600` |
| Stato upgrade | `/var/lib/wireguard-system-upgrade` assente |

Sono stati letti soltanto nomi delle variabili, metadati, conteggi e hash. Nessun valore
dell'environment, secret, hash password, contenuto audit o chiave è stato riportato.

`/etc/caddy/Caddyfile` è un file regolare di 472 byte, `0644 root:root`, SHA-256
`fca04114b9123690215604d32ad0fd0186f067f96b00302a24b1ee09586969a2`. Il contenuto non è
stato acquisito. Prima di `R03` l'hash dovrà comunque essere ricalcolato e usato come
baseline immediata.

### Rete e isolamento

- nessuna interfaccia WireGuard e nessuna VRF sono presenti;
- il registry privilegiato contiene zero reti;
- non sono presenti tabelle nftables;
- `net.ipv4.ip_forward=0`;
- le sole interfacce sono loopback e la NIC ordinaria del laboratorio;
- non sono presenti porte UDP WireGuard nel range gestito;
- Caddy ascolta sulle porte 80/443 previste e SSH sulla 22;
- la regola kernel priority `1000` per `[l3mdev-table]` è presente, mentre il modulo
  `vrf` è caricato con zero utilizzatori e non esiste alcun link VRF.

La regola `l3mdev` è una regola kernel generica installata col supporto VRF e, senza
interfacce VRF, non seleziona traffico del portale. Non deve essere cancellata a mano:
`R03` verifica soltanto che non esistano link o route table gestite residue.

### Artefatti da preservare o ignorare

Devono essere preservati senza modificarli durante `R03`:

- data tree, environment, keyring e Caddyfile live;
- `/root/wg-portal-prepackage-20261008`, evidenza storica pre-package;
- manifest hash storici sotto `/root/wg-portal-pre*`;
- il checkout di sviluppo `/opt/wireguard-system-dev`, di proprietà dell'utente del
  laboratorio e non del package;
- servizi estranei osservati, inclusi SSH e Mosquitto.

Le directory private systemd sotto `/tmp` appartengono ai servizi attivi e non sono
residui da eliminare. Lo spazio occupato dal progetto è piccolo; i 3,5 GiB sotto
`/usr/local` sono estranei e non possono essere usati come bersaglio di cleanup.

## Piano vincolante per R03

### 1. Prerequisiti locali

1. `R02` deve essere chiusa con package predecessor nuovo, bundle e SHA-256 registrati.
2. Il worktree deve essere pulito e il quality gate del commit package deve essere verde.
3. Conservare il `.deb` `0.1.0-5` sopra identificato come rollback e ricontrollarne
   l'hash prima del trasferimento.
4. Preparare sulla WSL una identity `age` esclusivamente di laboratorio; trasferire al
   server soltanto il recipient pubblico. La identity privata resta fuori dal server e
   dal repository.
5. Verificare accesso SSH alternativo e che nessuna rete o job sia stata aggiunta dopo
   questo inventario.

### 2. Baseline immediata e recovery set

Prima di qualsiasi mutazione:

1. ripetere package, unità fallite, link, route, forwarding, nftables, registry e spazio;
2. ricalcolare hash e metadata di environment, keyring, data tree canonico e Caddyfile;
3. creare con `backup-create` un recovery set cifrato in una directory root-only esterna
   al data tree;
4. trasferire i due bundle sulla WSL, eseguire `backup-verify` e `restore-preflight` con
   la identity offline e registrare `backup_set_id` e SHA-256;
5. fermarsi senza modificare package o unità se verifica o preflight non sono verdi.

Se l'environment inventariato non contiene ancora `WG_PORTAL_BACKUP_RECIPIENT`, oppure
la relativa identity privata non è più disponibile, `R03` deve prima aggiungere o ruotare
**soltanto** quel recipient pubblico con scrittura atomica, owner/mode invariati e servizi
quiescenti. Registrare hash precedente e successivo senza stampare altri valori; l'hash
successivo diventa la baseline immediata dell'environment per tutti i confronti seguenti.
Questa eccezione controllata risolve `P-011` e non autorizza modifiche ad altre variabili.

Il recovery set applicativo non sostituisce la copia separata del Caddyfile e degli hash
dei file package-owned. Nessun plaintext di backup deve essere scritto su disco.

### 3. Sostituzione conservativa del package

Il nuovo predecessor non deve essere installato come upgrade diretto da `0.1.0-5`: quel
vecchio package non contiene gli handshake di recovery correnti e non costituisce l'arco
consecutivo che verrà collaudato. La sequenza prevista è:

1. quiesce verificato dei soli servizi `wg-portal`, registrando quali erano attivi;
2. rimozione **senza purge** di `wireguard-system 0.1.0-5`;
3. verifica immediata che data tree, environment, keyring e Caddyfile esistano ancora e
   mantengano hash, owner e mode;
4. installazione pulita del predecessor prodotto da `R02`;
5. `systemd-analyze verify` delle nuove unità e avvio delle sole unità previste;
6. verifica di dpkg, doctor, audit, health/readiness, helper, socket Unix e HTTPS;
7. reset delle sole due istanze helper fallite già inventariate, dopo avere confermato
   che non esistano nuovi failure; nessun reset globale di systemd;
8. confronto finale degli hash persistenti e inventario rete/registry/firewall.

Non eseguire `purge`, non cancellare file in `/etc`, `/var`, `/root`, `/opt` o `/tmp`, non
scaricare il modulo VRF e non rimuovere manualmente la regola `l3mdev`.

### 4. Condizioni di rollback

Interrompere l'installazione e avviare rollback se uno dei seguenti controlli fallisce:

- package incompleto o dpkg non coerente;
- variazione non prevista di environment, keyring, data tree o Caddyfile;
- registry non vuoto o comparsa di interfacce/VRF/tabelle nftables;
- unità nuove non verificabili, helper non autenticabile o readiness non sana;
- audit non verificabile o bootstrap utente non più leggibile.

Il rollback reinstalla esclusivamente il `.deb` `0.1.0-5` hash-verificato. Il recovery set
viene applicato soltanto se i dati o i secrets sono realmente divergenti; una semplice
reinstallazione del package non giustifica un restore. Se serve `restore-apply`, seguire
il runbook M4.2, lasciare le reti ferme e non riavviare manualmente servizi dopo un errore.

## Criteri di chiusura R03

La baseline sarà nota soltanto quando:

- dpkg registra il nuovo predecessor e non segnala file alterati o package incompleti;
- systemd è `running`, senza istanze helper fallite;
- timer health, web, reconciler, helper e Caddy sono nello stato documentato;
- data, environment, keyring e Caddyfile coincidono con la baseline immediata;
- registry è vuoto e non esistono WireGuard, VRF o tabelle nftables gestite;
- forwarding resta `0`, audit e health sono verdi;
- recovery set verificato, log redatti e cleanup sono registrati in
  `LOCAL_TEST_ENVIRONMENT.md`.

## Esito R03 — 2026-10-12

Tutti i criteri sono soddisfatti con `wireguard-system 0.1.0-12`:

- dpkg installato, audit e verifica file senza output;
- systemd `running`, nessuna unità fallita, socket web/helper, reconciler, health timer e
  Caddy attivi e abilitati come previsto;
- doctor, audit, helper, reconciler health e readiness Unix/HTTPS verdi;
- environment, keyring, meta, registry e Caddyfile con hash invariati; digest dati
  canonico invariato;
- registry versione 2 con zero reti, nessun link WireGuard/VRF, nessuna tabella nftables,
  nessuna porta WireGuard e forwarding ancora `0`;
- recovery set nuovamente verificato offline; nessun restore necessario;
- le due failure helper storiche sono state resettate soltanto dopo aver escluso nuove
  failure; gli artefatti recovery/rollback restano confinati e intenzionalmente
  conservati per il successivo arco di upgrade R07.

Due tentativi intermedi hanno eseguito rollback completo a `0.1.0-5` per errori del solo
harness: PATH cancellato davanti a `doctor` e parsing della colonna decorativa `●` di
systemd. Dati, configurazione e rete sono rimasti invariati in entrambi i casi. P-014
registra l'incidente operativo.
