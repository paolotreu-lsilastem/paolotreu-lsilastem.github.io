# Ambiente di integrazione locale

Questo file descrive infrastruttura di sviluppo autorizzata dal maintainer. Non contiene
credenziali e non rende la macchina parte del prodotto o della matrice di produzione.

## Host disponibile

- destinazione SSH: `root@vrt-debian1.lsinet.it`;
- sistema verificato il 2026-09-25: Debian 12 Bookworm, Python 3.11.2, systemd attivo;
- scopo: smoke test privilegiati e integration test Linux non eseguibili in WSL;
- checkout isolato: `/opt/wireguard-system-dev`;
- dati bootstrap di test: `/opt/wireguard-system-dev/var/lib/wg-portal`;
- keyring di test: `/opt/wireguard-system-dev/var/secrets/master-keyring.json`.

La macchina è raggiungibile tramite la configurazione SSH dell'utente di sviluppo. Non
salvare né copiare chiavi SSH nel checkout. Eseguire sempre prima un inventario read-only;
non modificare servizi o dati estranei al progetto.

## Topologia end-to-end autorizzata

Per i test delle milestone M2.5–M2.6 è autorizzata questa topologia:

- hub/server WireGuard: `vrt-debian1.lsinet.it` via SSH come root;
- peer client WireGuard: la macchina di sviluppo corrente, Windows 11 Pro con WSL Debian;
- l'utente di sviluppo locale dispone di `sudo` per installare WireGuard e creare il peer.

Prima di installare o mutare rete su entrambi i lati, acquisire stato iniziale di package,
link, route, forwarding e firewall. Usare nomi interfaccia e subnet dedicati al progetto,
evitare default route e LAN, predisporre cleanup anche in caso di errore e verificare a
fine prova che interfacce, route, processi e regole temporanee siano stati rimossi. Non
salvare password sudo, chiavi SSH o chiavi WireGuard reali nel repository o nei log.

## Stato autoritativo del 2026-10-12

L'inventario `R01` esclusivamente read-only ha corretto lo stato operativo senza
cancellare le evidenze storiche sotto. Il package `wireguard-system 0.1.0-5` risulta
installato e integro secondo dpkg; web, reconciler, socket helper e Caddy sono attivi.
systemd è `degraded` soltanto per due vecchie istanze helper fallite del 2026-10-05, i cui
eventi non sono più disponibili nel journal. Il package non contiene ancora le unità
health introdotte successivamente.

Data tree, environment, keyring e registry hanno owner/mode attesi. Il dataset contiene
un utente e nessun tenant, rete, client, job o service account; il registry contiene zero
reti. Non esistono link WireGuard o VRF né tabelle nftables, e forwarding resta `0`.
La regola kernel generica `l3mdev` è presente col modulo VRF caricato ma senza utilizzatori:
non deve essere rimossa manualmente. Il filesystem ha 2,4 GiB liberi, pari al 13%.

Inventario redatto, hash, target da preservare, sequenza di sostituzione package e
rollback sono definiti in `LAB_BASELINE_RECOVERY.md`. Nessuna mutazione, installazione o
pulizia è autorizzata prima della chiusura di `R02`; `R03` dovrà applicare soltanto quel
piano.

Il tentativo R03 del 2026-10-12 ha prodotto e verificato offline il recovery set
`ac8dcc18-41ab-41f5-8fd8-e5b77a80f070`; i ciphertext hanno SHA-256 `26f00c…ddba` ed
`e87b52…35e3`. Il recipient pubblico mancante è stato aggiunto atomicamente
all'environment, il cui nuovo hash baseline è `7e9141…8d24`; l'identity resta soltanto
nella directory privata temporanea della WSL. `0.1.0-10` ha negato prima dell'unpack la
forma dpkg `install OLD NEW`. `0.1.0-11` l'ha accettata, ma il postinst ha rilevato mode
non attraversabili nel payload Python. In entrambi i casi è stato eseguito rollback; dopo
remove senza purge e reinstallazione pulita finale, `0.1.0-5` è nuovamente `installed`,
dpkg è coerente, web/helper socket, reconciler e Caddy sono attivi, hash persistenti e
digest dati `bdc3e8…0298` coincidono e non esistono risorse WireGuard/VRF/nftables.
Recovery set, package e identity non vengono rimossi finché R03 non è conclusa.

La pipeline normativa locale ha successivamente prodotto dal commit pulito `f290ad9` il
candidate corretto `0.1.0-12`, con audit pulito e inventario di 1.240 entry conforme al
contratto dei mode. Il bundle è verificato ma non firmato.

R05 ha prodotto localmente dal commit `a7e3bac` il candidate consecutivo `0.1.0-13`, con
audit pulito, SBOM e inventario di 1.241 entry. Alla chiusura di R05 non era stato
trasferito sul laboratorio, allora intenzionalmente fermo su `0.1.0-12`.

R06 è stata completata il 2026-10-13: entrambi i bundle hanno firma release verificata e
la policy upgrade pubblica è provisionata. Alla sua chiusura nessun package o segreto era
stato trasferito su `vrt-debian1` e il target restava su `0.1.0-12`.

R07 è stata completata il 2026-10-13. Il target esegue ora `0.1.0-13`; recovery set
`1a54bde7-749e-48f9-9159-c21da49dd861`, firme release e authorization upgrade sono stati
verificati air-gapped. Guard consumato e receipt finalizzata condividono digest
`f0ee25f6…486`. Dpkg, systemd, doctor, audit, helper, reconciler, Unix/HTTPS, hash
persistenti e rete sono verdi; `armed.json` è assente. Gli artefatti root-only sotto
`/root/wg-r07-20261013T101500Z` e le ricevute restano disponibili per R08–R11. Nessuna
chiave privata è entrata nel server. Verbale: `UPGRADE_DRILL_R07_2026-10-13.md`.

R08 è stata completata il 2026-10-13 senza downgrade né nuova firma offline. Firma
troncata, artefatto errato e replay/stato divergente sono stati rifiutati sul target; una
reinstallazione reale dello stesso candidate senza intent si è fermata nel `preinst`
prima dell'unpack. Dpkg, servizi, hash persistenti e receipt R07 sono rimasti invariati.
I crash ai due lati dell'unlink del marker, l'annullamento e i gate di clock, host,
writer, rete e spazio sono coperti da fault test deterministici collegati al medesimo
digest `preinst` installato. Health Unix/HTTPS con CA interna, audit e rete sono verdi;
restano 2.427.551.744 byte. Verbale: `UPGRADE_FAILURE_DRILL_R08_2026-10-13.md`.

## Stato corrente dopo R14 — 2026-10-14

R09 e R10 hanno collaudato su dpkg reale recovery di configurazione/reinstallazione e
trigger pending/awaited, inclusi retry, closure esatta e rifiuti fail-closed. R11 ha poi
fermato `0.1.0-16` in `half-configured`, reinstallato `0.1.0-15` dall'artefatto pinned e
ripristinato il recovery set autorizzato prima di riprendere i cinque writer originari.
P-022 e P-025 sono chiusi; P-026, emerso soltanto nel controllo terminale, è stato
corretto e verificato dal candidate firmato `0.1.0-17`.

Il target esegue ora `wireguard-system 0.1.0-17`. `dpkg --audit`, verifica package,
systemd, doctor, audit, helper, reconciler, timer, liveness/readiness Unix e HTTPS sono
verdi; `recovery-status` restituisce `no_pending_transaction`. Registry v2 è vuoto, non
esistono interfacce WireGuard/VRF, listener UDP gestiti o nftables del portale e
forwarding resta `0`. Il retry del rollback con restore concluso è un no-op; identity
temporanee, mask e directory intent attiva sono assenti. Evidenze e log sono descritti in
`UPGRADE_RECOVERY_DRILL_R09_2026-10-14.md`,
`UPGRADE_TRIGGER_DRILL_R10_2026-10-14.md` e
`UPGRADE_ROLLBACK_DRILL_R11_2026-10-14.md`; gli artefatti root-only R11 restano sotto
`/root/wg-r11-20261014T153500Z`.

Tutti gli archi osservati usano schema dati 1. Il risultato prova una migrazione no-op e
non autorizza upgrade futuri tra schema diversi. Il server resta un laboratorio, non una
installazione production.

### Verifica read-only R22 — 2026-10-15

R22 ha riconfermato senza mutazioni `wireguard-system 0.1.0-17`, dpkg integro, systemd
`running` e web/socket helper/reconciler/health timer/Caddy attivi. Doctor e i due giorni
audit sono verdi; il classificatore upgrade restituisce `no_pending_transaction`, helper
e reconciler sono sani e health/readiness Unix rispondono `ok`/`ready`.

Il registry root-owned mantiene SHA-256
`571bb8f03c7fffff060975bf63455c80bb54d47e7c30dfc30b7ab5f1ebdd7d72` ed è vuoto;
non risultano link WireGuard, VRF o tabelle `wgp_`, mentre forwarding resta `0`. Il socket
helper accetta l'utente `wg-portal` e rifiuta root e `nobody` con exit `1`. `dpkg -V` e
`systemd-analyze verify` non producono errori. Il helper conserva esclusivamente
`CAP_NET_ADMIN`; web e reconciler non hanno capability. Owner e mode di data tree,
registry, environment, keyring e socket coincidono con il contratto package.

Tre tentativi intermedi P-036–P-038 si sono fermati rispettivamente su quoting SSH,
frontend recovery errato e nome template systemd non interrogabile. Non hanno avviato
unità, modificato file o creato risorse di rete; i retry corretti sono verdi.

R14 ha lasciato il target su `0.1.0-17` senza modificare il Caddyfile live, il cui hash
resta `fca04114…69a2`. Caddy 2.6.2 ha verificato via HTTP/2 e CA interna il loopback
allowlisted (`200`) e l'indirizzo LAN non allowlisted (`403`); uno XFF falso non ha
superato il diniego e l'audit applicativo ha ricevuto l'indirizzo reale sovrascritto dal
proxy. La workstation corrente arriva via `192.168.200.1`, non tramite la vecchia sorgente
allowlisted `192.168.185.15`: non è stata ampliata la policy e resta disponibile il tunnel
SSH verso loopback. Il listener Caddy temporaneo usato per provare `max_size 1MB` e tutti i
file R14 sono rimossi; servizi, audit e listener finali sono verdi. Verbale:
`CADDY_EXPOSURE_DRILL_R14_2026-10-14.md`.

`R03` è stata completata il 2026-10-12. Due tentativi intermedi hanno effettuato rollback
automatico e integro a `0.1.0-5`: il primo perché l'harness aveva anteposto `env -i` a
`doctor`, cancellando `/usr/sbin` dal PATH; il secondo perché leggeva il bullet decorativo
`●` come nome di una unità fallita. La stessa invocazione PATH falliva anche sulla
baseline, mentre il comando documentato era verde; nessun difetto è stato attribuito al
candidate.

Il tentativo finale ha installato `0.1.0-12`. Dpkg è integro, systemd è `running` senza
unità fallite e web, helper, reconciler, health timer e Caddy sono attivi. Doctor, audit,
helper probe, reconciler health e readiness Unix/HTTPS sono verdi; il namespace journal
dedicato contiene eventi redatti di web e reconciler. Hash persistenti e digest dati
`260a2b…c0d2` coincidono prima/dopo, registry v2 è vuoto e non esistono WireGuard, VRF,
nftables, porte UDP gestite o forwarding. Il filesystem conserva 2,3 GiB liberi.
Recovery set, rollback package e identity locale `0600` furono conservati per R07;
nessun plaintext è stato creato. R07 ha prodotto un nuovo recovery set immediato.

`R04` è stata completata il 2026-10-12. Il reconciler fermato intenzionalmente è diventato
stale dopo i 600 secondi reali senza restart automatico; il riavvio esplicito ha prodotto
quattro cicli sani. L'override temporaneo del solo `ExecStart` verso un socket helper
inesistente ha prodotto tre failure con backoff 2/4 secondi e `RECONCILER_FAILED`; web e
helper reale sono rimasti attivi. Dopo la rimozione esatta del drop-in runtime sono stati
osservati due cicli sani e systemd è tornato `running`. Un primo `Environment=` era
inefficace per la precedenza dell'`EnvironmentFile` e non ha causato guasti: P-015 e il
runbook registrano la correzione.

Health/readiness Unix e HTTPS, timer, audit, hash persistenti, registry e rete sono verdi;
forwarding resta `0` e il journal globale non contiene eventi applicativi. Le evidenze
redatte sono conservate root-only in
`/var/tmp/wg-portal-incident-20261012T123030Z`; M4.3 è chiusa.

## Stato predisposto storico

Dal 2026-10-08 è installato il pacchetto candidate `wireguard-system 0.1.0-5`, che ha
sostituito gli artefatti manuali conservati sotto `/root/wg-portal-prepackage-20261008/`.
WireGuard, Caddy, helper, reconciler e Gunicorn sono attivi; l’applicazione è raggiungibile
soltanto tramite il Caddy di laboratorio e l’allowlist `192.168.185.15/32` più loopback.
Il certificato è emesso dalla CA interna Caddy del laboratorio, non da una CA production.

Il bootstrap conserva l’account di test `admin/admin` con cambio obbligatorio: dalla rete
il login è negato, mentre via tunnel SSH porta soltanto a `/change-password`. IPv4
forwarding resta disabilitato e non sono presenti interfacce WireGuard residue.

## Evidenze correnti

- quality gate remoto: 311 test superati, copertura 88%;
- `doctor`: tutti i prerequisiti disponibili usando il data dir di test;
- `host-probe`: tutti i controlli `ok`, salvo il warning atteso per `ip_forward=0`;
- `helper-probe`: successo come utente `wg-portal`;
- accesso helper negato come root e come `nobody`;
- `systemd-analyze verify`: nessun errore dopo l'installazione dell'entry point;
- `systemd-analyze security`: esposizione complessiva `4.5 OK`.
- nuovo registry `/var/lib/wg-portal-helper/registry.json` verificato root:`root` `0600`
  dentro directory `0700`, inizialmente vuoto;
- 40 test mirati a protocollo, registry e unità superati sul target;
  `systemd-analyze verify` nuovamente pulito e mutazione `network.stop` rifiutata con
  `MUTATION_HANDLER_UNAVAILABLE`;
- nessuna interfaccia WireGuard presente dopo lo smoke test M2.5.
- il 2026-09-26 l'executor reale ha creato `wgtm25` su `10.254.253.0/30`, verificato un
  retry idempotente e rimosso subito la rete; registry, interfacce e route sono tornati
  vuoti e `ip_forward` è rimasto `0`. Le chiavi effimere sono esistite solo in memoria.
- worker, CLI e app factory hanno superato 19 test mirati anche sul target Debian; il test
  non ha accodato job né mutato la rete e il registry privilegiato è rimasto vuoto.
- il 2026-09-27 il recovery M2.5 ha applicato `wgprc15` su `10.254.252.0/30`, ne ha
  simulato la perdita eliminando il link fuori banda, l'ha ricreata dalla configurazione
  verificata e infine fermata. Interfaccia, chiave effimera e script temporaneo sono stati
  rimossi; registry nuovamente vuoto e `ip_forward` ancora `0`.
- il 2026-10-03 il reconciler drift-aware ha applicato l'interfaccia temporanea `wgdr17`
  su `10.254.251.1/30`: modifiche fuori banda alla porta e all'indirizzo sono state
  entrambe rilevate e riparate dal helper, e il probe ha restituito il CIDR canonico.
  La nuova unità reconciler ha superato `systemd-analyze verify`; il processo non
  privilegiato ha prodotto cicli sani (`probe_failed=False`) ed è terminato su `SIGTERM`.
  Al termine non restavano interfacce, istanze helper, chiavi o script temporanei; il
  registry era vuoto e `ip_forward` ancora `0`.
- il 2026-10-03 il test end-to-end ha collegato l'hub `wge2eh` sulla VM al client
  `wge2ec` nella WSL tramite `10.254.250.0/30` e UDP `51997`: handshake e ICMP hanno
  funzionato in entrambe le direzioni. Dopo l'eliminazione fuori banda dell'hub, il
  traffico si è interrotto come previsto; la ricreazione tramite helper ha prodotto un
  nuovo handshake e ripristinato entrambi i versi. Il test ha inoltre scoperto e corretto
  lo stop dopo un endpoint peer appreso dinamicamente; la regressione è stata riprovata
  sul target reale. Interfacce, route dedicate, record registry, script e chiavi effimere
  sono stati rimossi da entrambi gli host; `ip_forward` remoto è rimasto `0`.
- il 2026-10-03 la policy nftables pura del primo incremento M2.6 è stata passata via
  stdin a `nft --check` sul target Debian con esito positivo, senza applicare regole o
  modificare interfacce. L'overlap cross-tenant resta disabilitato fino al completamento
  di registry, executor e test negativi reali.
- il 2026-10-03 il registry helper vuoto del target è stato migrato realmente da v1 a v2
  tramite l'avvio socket-activated. Due probe consecutivi hanno verificato idempotenza,
  file ancora root:`root` `0600`, nessuna interfaccia creata e `ip_forward` invariato a
  `0`.
- il 2026-10-05 le primitive host M2.6 hanno creato la VRF temporanea `wgv59998`, una
  interfaccia dummy collegata e la tabella `wgp_59998`, con forwarding abilitato soltanto
  per la durata del test. La verifica semantica ha accettato lo stato canonico e rilevato
  una regola nft estranea iniettata fuori banda. VRF, interfaccia, ruleset e script sono
  stati rimossi e `ip_forward` è tornato a `0`. Un primo tentativo, bloccato
  dall'allowlist per il path non canonico di `ip`, non aveva creato risorse e ha portato
  all'unificazione su `/usr/bin/ip`.
- il 2026-10-05 l'executor transazionale M2.6 è stato provato attraverso il socket reale
  del helper con rete temporanea `wgiso26`, `10.254.248.0/30`, UDP `51996`, VRF
  `wgv47161` e tabella nft `wgp_47161`. Il primo apply ha creato tutte le risorse, il
  secondo è risultato idempotente, una regola nft estranea è stata rilevata e riparata
  mediante sostituzione completa, quindi stop ha rimosso interfaccia, VRF, firewall e
  record. Il registry finale era vuoto e `ip_forward` è stato ripristinato a `0`.
- il 2026-10-05 il probe isolamento integrato con reconciler è stato provato sulla rete
  temporanea `wgprb26`, `10.254.247.0/30`, UDP `51995`, VRF `wgv52344` e tabella
  `wgp_52344`. Il probe iniziale ha restituito `ok`, una regola nft estranea ha prodotto
  `drift`, l'apply ha ripristinato `ok` e lo stop ha svuotato `managed_networks`. Un primo
  tentativo come root è stato rifiutato correttamente da `SO_PEERCRED` prima di creare
  risorse; il test valido è stato eseguito come `wg-portal`. Alla fine non restavano
  interfacce, VRF, tabelle, script o chiavi temporanee; registry vuoto e forwarding `0`.
- il 2026-10-05 due tenant temporanei sono stati attivati con lo stesso CIDR
  `10.254.246.0/29`, hub `10.254.246.1` e porte UDP `51993`/`51994`. Due client in
  namespace distinti raggiungevano ciascuno il proprio hub; i ping A→client B e B→client
  A sono falliti come richiesto. Il probe esponeva `per-network-vrf-v1` e attestava le
  VRF `wgv56855`/`wgv22009`. Un primo tentativo si era fermato su una route connessa già
  presente, senza residui; il retry corretto è riuscito. Namespace, veth, WireGuard, VRF,
  nftables, richieste e chiavi effimere sono stati rimossi; registry vuoto e forwarding
  ripristinato a `0`.
- il 2026-10-05 l'acceptance finale M2.6 ha attivato due VPN con CIDR identico
  `10.254.245.0/29`, tre client in namespace (due nella rete A, uno nella B) e destinazioni
  LAN/WAN simulate. I client A comunicavano in entrambi i versi via hub; i tentativi tra
  reti sovrapposte e verso `192.0.2.2`/`203.0.113.2` fallivano anche configurando il client
  con `AllowedIPs = 0.0.0.0/0`. La revoca live di A1 ha mantenuto invariato l'ifindex e
  operativi A2 e B1. Il primo tentativo ha evidenziato che nftables osserva il master VRF
  come ingresso forward: la policy e i test sono stati corretti, quindi l'intera matrice
  è passata. Cleanup verificato: registry v2 vuoto, nessuna interfaccia/VRF/tabella/
  namespace o script residuo e `ip_forward` ripristinato a `0`.
- il 2026-10-08 M4.1 ha installato Caddy e il `.deb`, verificato upgrade intermedi fino a
  `0.1.0-4` con environment, keyring e storage invariati, quindi eseguito remove/reinstall
  con gli stessi hash. Socket helper `0660 root:wg-portal` e web `0660 wg-portal:caddy`,
  doctor, audit, health Unix e HTTPS sono risultati sani. HTTP reindirizza a HTTPS, HSTS
  è presente, richieste fuori allowlist ricevono `403`, un `X-Forwarded-For` falsificato
  non abilita il bootstrap e il tunnel loopback porta al cambio password. Non sono
  rimasti override o probe diagnostici; il Caddyfile Debian originale è nel backup sopra.
- il 2026-10-08 il disaster-recovery drill M4.2 ha aggiornato il target al candidate
  `0.1.0-5`, preservando gli hash di environment, keyring e data tree. Un recovery set
  `age` effimero è stato creato in 3 secondi, copiato e verificato byte-per-byte sulla WSL,
  quindi ha superato verify e preflight offline. I rifiuti senza `--replace` e con UUID
  errato non hanno fermato i servizi; il restore corretto ha rimosso un marker post-backup
  e riportato le quattro unità attive in 3 secondi. Un check finale intenzionalmente
  fallito ha verificato rollback byte-per-byte e unità ferme, seguiti da riavvio manuale,
  doctor, audit e health Unix/HTTPS sani. Identity, bundle, script e pacchetti temporanei
  sono stati rimossi; environment/keyring sono tornati agli hash iniziali, registry e
  interfacce sono vuoti. Il dataset conteneva un utente ma nessuna rete o job.
- il 2026-10-08 il candidate locale è stato aggiornato a `0.1.0-7`; il deploy è stato
  rinviato perché `vrt-debian1` e `vrt-debian1.lsinet.it` non risultavano
  risolvibili né dal WSL né dal resolver Windows. Nessuna connessione o modifica remota è
  avvenuta. Il pacchetto contiene health persistente, timer, namespace journald, runbook
  e protocollo di drill, ma il relativo upgrade reale resta da riprovare quando il nome
  intranet tornerà risolvibile.
- il 2026-10-08 è stato costruito localmente il candidate `0.1.0-8` dopo un audit pulito
  di tutte le 24 dipendenze Python e la generazione dello SBOM. Il pacchetto non è stato
  trasferito o installato sul target; il blocco DNS precedente resta invariato.
- il 2026-10-08 un nuovo inventario esclusivamente read-only ha risolto e raggiunto il
  target come Debian 12.9. `dpkg-query` non ha trovato `wireguard-system`, mentre data dir,
  environment e unit file erano ancora presenti; due istanze transient helper risultavano
  failed e systemd `degraded`. Non sono stati eseguiti cleanup, installazioni o restart. Il
  drill M4.3 richiedeva allora il ripristino documentato di una baseline nota, poi
  completato con R03 e R04.

## Regole di riuso

Prima di ogni deploy verificare host, sistema e assenza di collisioni. Sincronizzare il
checkout escludendo almeno `.git`, `.venv`, `.env`, `var`, cache e coverage; non usare
`--delete` finché non è stato verificato il path remoto esatto. Conservare dati e segreti
del target fuori dalla sincronizzazione. Dopo cambiamenti al protocollo o alle unità,
rieseguire quality gate, `systemd-analyze verify`, probe positivo come `wg-portal` e test
negativi con un UID non autorizzato. Ogni interfaccia o regola firewall temporanea deve
avere cleanup esplicito e va verificata come rimossa a fine test.
