# Chiusura M4.4 — supply chain, firma e upgrade

Data: 2026-10-14  
Stato: conclusa come candidate tecnico; non approvata per produzione

## Esito

M4.4 è chiusa sul candidate firmato `wireguard-system 0.1.0-17 amd64`, costruito dal
commit `06a3b37c59706e9a8484cc15104c38d9b321e896`. Il package ha SHA-256
`2ecfbd13ac6eeba46ba984ad21a01b175701f9c47e99987cb57a9ee81fe8a4c4` e accetta
esclusivamente l'arco `0.1.0-15 → 0.1.0-17`. Pipeline, inventario, audit Python, SBOM,
provenienza, firma SSHSIG, authorization host-bound, upgrade, failure, recovery,
rollback/restore, health e cleanup dispongono tutti di evidenza reale o automatica
rintracciabile sotto.

La chiusura non equivale al `GO` v1. `0.1.0-17` è un artefatto tecnico di laboratorio:
non è il candidate finale congelato di R24, non ha ricevuto audit indipendente e non deve
essere pubblicato sul canale stabile.

## Matrice dei gate e delle evidenze

| Gate | Risultato verificato | Evidenza normativa |
|---|---|---|
| R01 — inventario | Host, dpkg, servizi, dati, segreti, registry e rete inventariati read-only; piano di rollback definito | `docs/LAB_BASELINE_RECOVERY.md`; `docs/LOCAL_TEST_ENVIRONMENT.md` |
| R02 — lineage predecessor | `0.1.0-9` congelato come storico; revisioni successive univoche, bundle/audit/SBOM/provenienza verificati | `docs/RELEASE_CANDIDATE_0.1.0-10.md`; `docs/SUPPLY_CHAIN.md` |
| R03 — baseline Debian | `0.1.0-12` installato con dpkg/systemd/health/audit/hash/rete verdi e rollback dei tentativi falliti integro | `docs/LAB_BASELINE_RECOVERY.md`; `docs/RELEASE_CANDIDATE_0.1.0-12.md` |
| R04 — incidenti M4.3 | Staleness, helper failure, recovery, journald, Unix/HTTPS e cleanup reali superati | `docs/INCIDENT_DRILL.md` |
| R05 — candidate consecutivo | Coppia `0.1.0-12 → 0.1.0-13` immutabile, inventariata e costruita dal commit attestato | `docs/RELEASE_CANDIDATE_0.1.0-13.md`; `docs/SUPPLY_CHAIN.md` |
| R06 — trust e firma | Trust release/upgrade separato, firme SSHSIG e prove negative reali; solo materiale pubblico in Git | `docs/RELEASE_SIGNING_CEREMONY_2026-10-13.md`; `docs/RELEASE_SIGNING.md` |
| R07 — happy path | Authorization firmata e monouso; upgrade reale `0.1.0-12 → 0.1.0-13`, writer, hash e cleanup verdi | `docs/UPGRADE_DRILL_R07_2026-10-13.md` |
| R08 — failure pre-unpack | Firma, host, hash, stato, spazio, cancel e crash del claim negati o recuperati senza unpack ambiguo | `docs/UPGRADE_FAILURE_DRILL_R08_2026-10-13.md` |
| R09 — recovery dpkg | `unpacked`, `half-configured`, reinstallazione, lock handoff, retry e stati reali dpkg verificati | `docs/UPGRADE_RECOVERY_DRILL_R09_2026-10-14.md` |
| R10 — trigger | `triggers-pending`/`triggers-awaited`, closure esatta, retry e package estraneo verificati su dpkg reale | `docs/UPGRADE_TRIGGER_DRILL_R10_2026-10-14.md` |
| R11 — rollback/restore | Fault `half-configured`, predecessor pinned, restore autorizzato, cinque writer, P-026 corretto, health e no-op verdi | `docs/UPGRADE_ROLLBACK_DRILL_R11_2026-10-14.md`; `docs/RELEASE_CANDIDATE_0.1.0-17.md` |
| R12 — consolidamento | Matrice, runbook, guida installazione, stato laboratorio, handoff, roadmap e changelog allineati; quality gate verde | questo documento; `docs/UPGRADE.md`; `INSTALL.md`; `docs/ROADMAP.md` |

I verbali conservano intenzionalmente il passo successivo noto al momento in cui furono
scritti. Le sezioni “stato successivo” e questa matrice forniscono lo stato corrente senza
riscrivere retroattivamente l'evidenza storica.

## Catena degli artefatti tecnici

| Revisione | Ruolo nell'evidenza | Stato |
|---|---|---|
| `0.1.0-9` | primo bundle storico | non pubblicabile; precede il recovery corrente |
| `0.1.0-10` | lineage univoca R02 | rifiutato per remove/reinstall |
| `0.1.0-11` | correzione preinst | rifiutato per mode payload |
| `0.1.0-12` | baseline clean-install R03 e predecessor R07 | firmato per i drill, storico |
| `0.1.0-13` | candidate consecutivo R05/R07/R08 | firmato per i drill, storico |
| `0.1.0-14` | recovery R09 e derivato confinato R10 | evidenza tecnica intermedia |
| `0.1.0-15` | migrazione intent e baseline R11 | predecessor del candidate corrente |
| `0.1.0-16` | fault e rollback/restore R11 | firmato ma rifiutato per P-026 |
| `0.1.0-17` | correzione P-026 e stato terminale | candidate tecnico corrente, installato nel laboratorio |

Ogni revisione mantiene identità e artefatti immutabili. Un difetto produce una nuova
revisione; non si ricostruisce lo stesso numero da sorgenti differenti.

## Limite di schema

Tutti gli archi R07–R11 hanno `data_schema_version=1` sia nel predecessor sia nel
candidate. Le prove dimostrano:

- conservazione byte-identica dello stato quando non serve trasformarlo;
- esecuzione della migrazione no-op;
- rifiuto fail-closed di schema/arco/artefatto diversi;
- restore e rollback quando lo schema autorizzato resta identico.

Dimostrano preservazione, non compatibilità cross-schema. Un futuro schema 2 richiederà una
nuova coppia consecutiva, una migrazione forward-only, fixture dello schema precedente e
drill dedicati; non può ereditare automaticamente lo stato “verificato” di M4.4.

## Stato del laboratorio al gate

`vrt-debian1.lsinet.it` esegue `0.1.0-17`. Dpkg è coerente, i cinque writer sono attivi,
il timer health conclude con successo, Caddy serve liveness/readiness HTTPS 200 con HSTS
e `recovery-status` restituisce `no_pending_transaction`. Dati e segreti coincidono con
il manifest pre-upgrade. Registry e rete gestita sono vuoti; forwarding resta disabilitato.
Identity recovery temporanee, mask e directory intent attive sono assenti. Lo storico
grow-only di authorization, intent e receipt resta presente e validato.

## Lavoro esplicitamente rinviato

Non esistono TODO impliciti dentro M4.4. Restano aperti soltanto task nominati nella
roadmap:

- R13–R15: sicurezza operativa e compatibilità delle API pubbliche;
- R16–R17: manuali amministratore e operatore;
- R18–R23: freeze, audit indipendente, remediation e chiusura documentale;
- R24: candidate finale, firma e lifecycle della keyring APT, incluso P-018;
- R25: acceptance completa e decisione `GO`.

Restano inoltre espliciti il rischio di custodia P-019, l'assenza di audit indipendente
P-005, il limite cross-schema P-006 e l'impossibilità di garantire “sicurezza assoluta”
P-007. Nessuno di questi viene reinterpretato come chiuso da M4.4.

## Verifica repository

Alla chiusura R12 `./scripts/check.sh` è verde: lint, type-check, contratto OpenAPI e
1.030 test superati; una sola integrazione APT resta opt-in e la copertura complessiva è
84%. Il test documentale richiede tutte le righe della matrice, il limite schema 1/no-op,
il riferimento a R13–R25 e lo stato non-production del candidate.
