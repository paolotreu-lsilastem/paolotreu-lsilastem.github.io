# Osservabilità operativa

Questo documento definisce il contratto M4.3 per liveness, readiness, log e diagnosi.
Probe HTTP, logging applicativo strutturato, policy journald e health persistente del
reconciler sono implementati; il drill reale M4.3 è superato e il runbook resta la
procedura operativa normativa.

## Endpoint HTTP

Entrambi gli endpoint sono anonimi perché destinati al monitoraggio locale, ma in
produzione attraversano lo stesso socket Unix e la stessa allowlist Caddy di UI e API.
Non devono essere esposti tramite listener applicativi aggiuntivi.

### `GET /healthz`

È una liveness minimale. Restituisce `200` quando il processo Flask è in grado di servire
una risposta e non interroga filesystem, keyring, helper o host. Il body stabile è:

```json
{"status":"ok","version":"0.1.0"}
```

Usarla soltanto per rilevare un processo bloccato o non raggiungibile. Non autorizza
traffico applicativo e non prova che le operazioni WireGuard siano disponibili.

### `GET /readyz`

È la readiness del control plane. Restituisce `200` con `status=ready` soltanto quando
tutti i controlli sono sani; altrimenti restituisce `503` e `status=not_ready`. I risultati
sono memorizzati in ciascun worker per 5 secondi di default, configurabili tra 1 e 60 con
`WG_PORTAL_READINESS_CACHE_SECONDS`, per limitare le chiamate al helper privilegiato.

I controlli, sempre read-only, sono:

| Nome | Condizione richiesta |
|---|---|
| `storage` | data dir reale e privato, `meta.json` valido, schema dati corrente |
| `recovery` | nessun journal restore pendente o invalido |
| `keyring` | keyring configurato leggibile, valido e protetto; `NOT_REQUIRED` solo fuori dalla configurazione production |
| `helper` | socket autenticato, probe riuscito, nessun check host `error`/`unavailable` e capability VRF corrente |
| `reconciler` | ciclo recente, fallimenti consecutivi sotto soglia e nessun job outstanding troppo vecchio |

Il body contiene soltanto nome, stato e codice stabile. Path, eccezioni, output dei
comandi, configurazioni, chiavi, tenant e reti non vengono restituiti. I codici di errore
correnti sono:

- `STORAGE_UNSAFE`, `STORAGE_UNAVAILABLE`, `STORAGE_SCHEMA_UNSUPPORTED`;
- `RECOVERY_STATE_INVALID`, `RECOVERY_PENDING`;
- `KEYRING_NOT_CONFIGURED`, `KEYRING_UNAVAILABLE`;
- `HELPER_UNAVAILABLE`, `HELPER_REJECTED`, `HELPER_RESPONSE_INVALID`,
  `HELPER_CAPABILITY_MISSING`, `HELPER_HOST_UNHEALTHY`;
- `RECONCILER_STATE_MISSING`, `RECONCILER_STATE_INVALID`, `RECONCILER_STALE`,
  `RECONCILER_FAILED`, `RECONCILER_BACKLOG_STALE`, `RECONCILER_BACKLOG_UNAVAILABLE`.

Un warning del probe host non rende da solo il servizio non ready; `error` e `unavailable`
sì. Il drift di una singola rete gestita non abbatte la readiness globale: resta compito
del reconciler e della telemetria scoped.

## Verifica operativa

Sul server, il test diretto del socket applicativo evita DNS e TLS ma attraversa Gunicorn:

```bash
curl --fail --unix-socket /run/wg-portal/web.sock http://localhost/healthz
curl --fail --unix-socket /run/wg-portal/web.sock http://localhost/readyz
sudo -u wg-portal /usr/bin/wg-portal reconciler-health
systemctl status wg-portal-reconciler-health.timer
```

Il controllo esterno deve attraversare Caddy e usare il nome reale:

```bash
curl --fail --proto '=https' https://vpn.example.invalid/healthz
curl --fail --proto '=https' https://vpn.example.invalid/readyz
```

Un `503` non va aggirato riavviando ripetutamente il servizio. Annotare il codice redatto,
controllare unità e journal, eseguire `wg-portal doctor` e il probe helper, quindi seguire
`INCIDENT_RUNBOOK.md`. `RECOVERY_PENDING` richiede la procedura di recovery:
non cancellare journal, staging o rollback manualmente.

## Logging operativo JSON line

Web, reconciler e helper scrivono su stderr una JSON line per evento applicativo. Lo
schema comune contiene `timestamp` UTC, `level`, `component` ed `event`; ogni evento
ammette poi un insieme chiuso di campi tipizzati:

- `http.request.completed` e `http.request.failed`: UUID request, metodo normalizzato,
  endpoint Flask simbolico, stato e durata intera in millisecondi; il fallimento aggiunge
  soltanto un codice stabile;
- `reconciler.cycle.completed`: esito, conteggi del ciclo, contesa e fallimento probe;
- `reconciler.process.failed` e `helper.process.failed`: solo codice stabile.

Non esiste un campo messaggio libero. Sono vietati query string, URI concreta, IP client,
header, cookie, token, body, username, nomi tenant/rete/client, materiale crittografico,
path, output comandi, testo eccezioni e traceback. I test verificano che campi sconosciuti
e path grezzi vengano rifiutati senza produrre output. Gli errori web inattesi restituiscono
una pagina/Problem Details redatta e vengono registrati come `UNHANDLED_EXCEPTION`.

`WG_PORTAL_LOG_LEVEL` accetta `DEBUG`, `INFO`, `WARNING` o `ERROR` e vale per i processi
applicativi. Il default è `INFO`; non usare `DEBUG` come soluzione permanente a un
incidente. Il log operativo non sostituisce l'audit HMAC: serve a disponibilità e diagnosi,
mentre l'audit registra azioni di sicurezza e mutazioni con retention separata.

Le unità usano il namespace `wg-portal`, non quello globale. Il pacchetto limita il
namespace a 256 MiB persistenti, 64 MiB runtime, file di durata massima giornaliera e
retention massima 30 giorni. La quota può abbreviare la conservazione: il journal non è
un archivio di compliance. Il rate limit è 30 secondi con burst 1000 per web, 120 per
reconciler e 20 per ogni processo helper, oltre al limite namespace di 2000 per servizio.

Esempi di consultazione locale, senza esportare il journal:

```bash
journalctl --namespace=wg-portal -u wg-portal-web.service --since today -o cat
journalctl --namespace=wg-portal -u wg-portal-reconciler.service --since today -o cat
journalctl --namespace=wg-portal -u 'wg-portal-helper@*.service' --since today -o cat
```

Gli override locali appartengono a `/etc/systemd/journald@wg-portal.conf.d/`; non
modificare il drop-in sotto `/usr/lib`. Dopo una variazione validata riavviare
`systemd-journald@wg-portal.service` e poi le unità del portale. Non usare `journalctl
--vacuum-*` sul journal globale per gestire questo namespace.

## Vincoli per i prossimi incrementi

- La correlazione usa gli UUID già propagati in `X-Request-ID`; input non canonici vengono
  sostituiti, non registrati.
- Rate limit e retention dei log operativi restano distinti dalla catena audit firmata e
dalla sua retention già approvata.

## Health persistente del reconciler

Ogni ciclo pubblica atomicamente `runtime/reconciler-health.json`, un artefatto derivato
`0600` che contiene soltanto timestamp, esito, fallimenti consecutivi e contatori. Non è
incluso nei backup. Il comando `reconciler-health` lo legge senza creare lock, scansiona
i job con aperture `O_NOFOLLOW` e non invoca helper, systemd o strumenti di rete.

I default segnalano stato stale dopo 600 secondi, tre fallimenti consecutivi o un job
`queued`/`running` invariato da oltre 300 secondi. Le variabili
`WG_PORTAL_RECONCILER_STALE_SECONDS`, `WG_PORTAL_RECONCILER_FAILURE_THRESHOLD` e
`WG_PORTAL_RECONCILER_BACKLOG_MAX_AGE_SECONDS` modificano le soglie; la staleness deve
restare superiore sia all'intervallo sia al backoff massimo del reconciler. Il timer
`wg-portal-reconciler-health.timer` esegue il controllo ogni minuto e rende visibile il
fallimento in systemd, ma non riavvia né ripara automaticamente alcunché.
- I probe non effettueranno riparazioni, scritture canoniche o mutazioni host.
