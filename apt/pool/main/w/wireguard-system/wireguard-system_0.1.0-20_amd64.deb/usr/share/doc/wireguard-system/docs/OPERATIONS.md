# Operazioni (baseline)

## Bootstrap

`scripts/bootstrap.sh` crea `.venv`, installa il progetto in editable mode, inizializza il
data tree configurato e crea l'account bootstrap se assente. È idempotente e non avvia né
configura WireGuard. Crea inoltre, se assente, il keyring master di sviluppo configurato.
In produzione usare percorsi assoluti, data dir separato dal checkout e keyring separato
anche dal data tree.

La procedura completa per prerequisiti, configurazione `.env`, primo accesso e verifica è
in [`INSTALL.md`](../INSTALL.md). Finché M4.1 non è completata, quella procedura è
esplicitamente limitata a sviluppo e valutazione e non autorizza l’esposizione in rete del
server Flask.

## Ambiente WSL di sviluppo

Il progetto viene sviluppato anche su Windows 11 Pro dentro WSL Debian. Test, lint,
repository e compilazione delle configurazioni devono funzionare senza privilegi. Il
probe reale può invece segnalare `unavailable` per systemd, nftables, `ip` o WireGuard se
WSL non espone la relativa capacità o il processo non ha permessi: è un risultato
diagnostico esplicito, non va aggirato avviando Flask come root. I test di isolamento con
namespace e il deployment restano riferiti a Debian nativo.

## Doctor

`wg-portal doctor` controlla Python, directory dati e presenza di `wg`, `wg-quick`, `ip`,
`systemctl`, `nft` e `age`. I probe completi sono disponibili separatamente:

```bash
wg-portal host-probe
wg-portal host-probe --json
```

Il comando non modifica lo stato. Controlla eseguibili, modulo WireGuard, forwarding
IPv4, systemd, leggibilità nftables, link e telemetria peer. Un esito `unavailable` può
indicare permessi di lettura insufficienti e produce exit code non zero; non va risolto
eseguendo Flask come root. L'accesso ristretto è disponibile tramite il helper M2.4.

## Helper privilegiato

M2.4 include unità di riferimento in `packaging/systemd/` per socket activation. Il
pacchetto M4.1 dovrà creare l'utente/gruppo `wg-portal`, installare l'eseguibile come
`/usr/bin/wg-portal-helper`, copiare le unità e abilitare soltanto il socket:

```bash
systemctl enable --now wg-portal-helper.socket
wg-portal helper-probe --json
```

Il processo web usa `WG_PORTAL_HELPER_SOCKET`, che in produzione deve essere assoluto e
vale `/run/wg-portal/helper.sock` per default. Il socket è root:`wg-portal` `0660`; non
aggiungere Caddy o utenti interattivi al gruppo. Ogni connessione avvia un processo root
effimero, autenticato tramite credenziali kernel, con timeout e hardening systemd. In M2.4
il helper offre il probe read-only. M2.5 aggiunge gli envelope tipizzati di apply/stop e
il relativo executor con validazione semantica, snapshot e rollback.

L'executor è ora collegato: una apply crea l'interfaccia con `ip`, passa la configurazione
filtrata a `wg setconf` via stdin e verifica configurazione, indirizzo e porta osservati.
Una apply successiva con digest diverso usa `wg syncconf`; stop elimina soltanto
l'interfaccia esattamente associata nel registry. Il cambio dell'indirizzo hub live viene
rifiutato con `ADDRESS_CHANGE_REQUIRES_RESTART` e sarà orchestrato come stop/start dal
worker. Gli errori tentano rollback dallo snapshot kernel mantenuto in memoria;
`ROLLBACK_FAILED` o `RECONCILIATION_REQUIRED` richiedono ispezione prima di nuovi tentativi.
Nessun file WireGuard contenente chiavi private viene scritto dal helper.

## Worker dei job di rete

Per consumare al massimo un job queued usare:

```bash
wg-portal worker-once
```

Il comando richiede data dir, secret audit, master keyring e socket helper configurati
come il servizio web. Restituisce `0` se non c'è lavoro o se il job riesce, `1` se il job
termina failed e `2` se il keyring non è configurato. Stampa soltanto UUID, stato e codice
errore stabile. Ogni invocazione rivalida l'autorizzazione dell'attore e usa optimistic
concurrency. Resta utile per diagnosi e consumo mirato della coda; per l'esecuzione
continua usare esclusivamente il reconciler gestito, non loop artigianali.

Per una convergenza completa one-shot dopo manutenzione, crash o riavvio host usare:

```bash
wg-portal reconcile-once
```

Il comando recupera i job `running` rimasti interrotti, crea o riusa un job di sistema
persistente per ogni rete e applica il relativo desired state. `worker-once` e
`reconcile-once` condividono un lock globale: se un altro processo sta lavorando, il
reconciler termina con `contended` e codice non zero senza alterare i job. Un risultato
failed richiede l'ispezione del codice redatto nel job e dell'audit; non avviare loop
artigianali.

La coda conta i job `queued` e `running` e applica questi default: 1000 globali, 25 per
identità, 100 per tenant e 10 per rete. Sono configurabili rispettivamente con
`WG_PORTAL_JOB_MAX_OUTSTANDING_GLOBAL`,
`WG_PORTAL_JOB_MAX_OUTSTANDING_PER_IDENTITY`,
`WG_PORTAL_JOB_MAX_OUTSTANDING_PER_TENANT` e
`WG_PORTAL_JOB_MAX_OUTSTANDING_PER_NETWORK`; non alzarli senza verificare spazio disco e
tempo massimo di smaltimento. `WG_PORTAL_JOB_RETRY_AFTER_SECONDS` vale 30 e controlla
l'header restituito al chiamante. Su `QUEUE_CAPACITY_EXCEEDED`, attendere almeno
`Retry-After`, applicare jitter e riusare la stessa `Idempotency-Key`. Non cancellare job
o lock manualmente per liberare capacità: diagnosticare worker/helper e lasciare che i
job raggiungano uno stato terminale.

Il servizio continuo supportato usa:

```bash
systemctl enable --now wg-portal-reconciler.service
```

Parte con un ciclo immediato, poi attende `WG_PORTAL_RECONCILE_INTERVAL_SECONDS` dopo un
ciclo sano. Errori di probe, job o contesa usano backoff esponenziale da
`WG_PORTAL_RECONCILE_BACKOFF_INITIAL_SECONDS` fino a
`WG_PORTAL_RECONCILE_BACKOFF_MAX_SECONDS`. I default sono rispettivamente 30, 2 e 300
secondi. Un probe WireGuard incompleto non genera stop: il ciclo fallisce, non crea job e
ritenta con backoff. L'unità gira senza privilegi come `wg-portal`; non eseguirla come root.

Systemd crea `/var/lib/wg-portal-helper` root-only e il helper vi mantiene il registry
minimo delle interfacce applicate. Non spostarlo nel data tree della UI, non modificarlo a
mano e non inserirvi configurazioni WireGuard. In caso di permessi, symlink o JSON non
validi il helper fallisce in chiusura; seguire la futura procedura di recovery anziché
cancellare il file.

Il primo avvio del helper M2.6 migra automaticamente il registry v1 a v2 mediante replace
atomico. Le entry esistenti restano valide ma hanno isolamento nullo finché un apply
verificato non registra la VRF; non aggiungere a mano route table o CIDR. Una versione
futura/sconosciuta non viene migrata né riscritta.

Un apply M2.6 restituisce successo solo dopo aver verificato insieme WireGuard, VRF e
nftables e aver persistito il piano. Un retry identico è no-op; drift di isolamento causa
la sostituzione dell'intero insieme. Non rimuovere manualmente una VRF o una tabella nft
se il registry la dichiara attiva: eseguire apply/reconcile. `ROLLBACK_FAILED` richiede
ispezione manuale di interfaccia, VRF, tabella nft e registry prima di un nuovo tentativo;
non cancellare il registry per forzare il recupero.

Il risultato `probe` include `managed_networks`: `ok` indica che il piano registry è
stato verificato sul kernel, `drift` richiede apply/reconcile e `legacy` richiede upgrade
tramite apply. Il reconciler tratta come errore l'assenza del campo o forme duplicate e
non programma job su un'osservazione ambigua. Le chiamate al socket devono essere eseguite
come utente di controllo `wg-portal`; anche root viene rifiutato da `SO_PEERCRED` se non è
l'UID configurato nel servizio.

La capability `per-network-vrf-v1` deve essere presente nel probe prima di consentire
nuove reti cross-tenant sovrapposte. Non sostituirla con una variabile d'ambiente o un
override manuale. La sua assenza dopo un aggiornamento indica componenti non allineati:
completare il deploy di web, worker e helper prima di riprendere le mutazioni.

Nel ruleset atteso il traffico ricevuto dalla slave WireGuard compare nei hook
`input`/`forward` con `iifname` pari al master `wgv<TABELLA>`; nel forward l'uscita verso
i peer resta la slave WireGuard. Non sostituire questi matcher con la sola interfaccia
WireGuard: impedirebbe il traffico client-to-client e lascerebbe l'input senza il filtro
specifico. La verifica JSON del helper rileva automaticamente una policy precedente o
alterata come drift e richiede apply/reconcile.

Su WSL, `helper-probe` può non essere eseguibile finché systemd e le unità non sono
installati nella distribuzione. Usare `host-probe` per lo sviluppo non privilegiato; lo
smoke test del socket reale è obbligatorio sul target Debian. `systemd-analyze verify`
richiede che `/usr/bin/wg-portal-helper` sia già installato.

Il target intranet attualmente autorizzato per questi test è descritto in
`docs/LOCAL_TEST_ENVIRONMENT.md`. Non copiare mai nel repository chiavi SSH, token o
configurazioni private della macchina.

## Credenziali API

Le route API accettano i token creati dal service di lifecycle. Un superadmin crea la
prima identità globale da **Accessi API** nella UI, usa il token one-time per creare
identità scoped via API e revoca poi l'identità bootstrap. La UI consente inoltre elenco,
dettaglio, rotazione e revoca senza accedere direttamente allo storage.
Il token one-time non è recuperabile: conservarlo
nel secret manager dell'integrazione al momento della creazione. Non copiare mai token in
file `.env`, comandi shell, ticket o log; in caso di perdita ruotare la credenziale, in
caso di sospetta compromissione revocare l'intera identità.

I limiti predefiniti sono 120 richieste per credenziale+IP e 600 per IP in 60 secondi,
configurabili con `WG_PORTAL_API_CREDENTIAL_LIMIT`, `WG_PORTAL_API_IP_LIMIT` e
`WG_PORTAL_API_WINDOW_SECONDS`. Ridurli dopo aver misurato le automazioni, non disabilitarli.
I bucket sotto `runtime/api-rate-limits` sono effimeri ma condivisi tra processi; una
pulizia manuale richiede servizio fermo. Una credenziale con `client.config:read` non può
superare 24 ore, tutte le altre 90 giorni.

Il download sensibile è limitato a
`GET /api/v1/clients/<uuid>/configuration`: usare un service account dedicato, con il solo
scope necessario e permesso `client.config:read`. Non salvare il profilo in log, output
CI o artifact generici; scriverlo direttamente nel secret store o nel file WireGuard
`0600` della destinazione. Le risposte negano cache e non supportano export bulk. Dopo il
provisioning revocare l'identità o ruotare la credenziale breve; un 404 può indicare sia
risorsa invisibile sia permesso/stato/credenziale non più validi e non va aggirato.

`WG_PORTAL_PRESENCE_THRESHOLD_SECONDS` configura la soglia globale della presenza client
fra 30 e 86400 secondi; il default approvato è 180. La cache derivata si trova sotto
`runtime/presence` e non va modificata a servizio attivo. Può essere eliminata a servizio
fermo senza perdere configurazioni: il successivo campione affidabile la ricostruisce e
fa ripartire la stima “online dal”.

## Liveness e readiness

`GET /healthz` verifica soltanto che il processo web risponda. `GET /readyz` effettua i
controlli read-only di storage/schema, recovery, keyring, helper privilegiato e stato
persistito del reconciler e restituisce
`503` con codici redatti se il control plane non può operare in sicurezza. Il risultato è
in cache per 5 secondi per worker; modificare l'intervallo con
`WG_PORTAL_READINESS_CACHE_SECONDS` soltanto tra 1 e 60 secondi.

Verificare prima il socket Unix e poi il percorso HTTPS Caddy:

```bash
curl --fail --unix-socket /run/wg-portal/web.sock http://localhost/readyz
curl --fail --proto '=https' https://vpn.example.invalid/readyz
sudo -u wg-portal /usr/bin/wg-portal reconciler-health
systemctl status wg-portal-reconciler-health.timer
```

Il reconciler aggiorna `runtime/reconciler-health.json` dopo ogni ciclo. Il controllo
fallisce per stato mancante/invalido, ultimo ciclo oltre 600 secondi, almeno tre fallimenti
consecutivi o job outstanding invariato oltre 300 secondi. Le soglie sono configurabili
con `WG_PORTAL_RECONCILER_STALE_SECONDS`, `WG_PORTAL_RECONCILER_FAILURE_THRESHOLD` e
`WG_PORTAL_RECONCILER_BACKLOG_MAX_AGE_SECONDS`; la prima deve superare intervallo e
backoff massimo. Il comando e il timer sono solo lettura e non vanno trasformati in
autoriparazioni o restart automatici.

La semantica completa, i codici e la distinzione da audit/log sono definiti in
`docs/OBSERVABILITY.md`; triage, matrice codici ed escalation sono in
`docs/INCIDENT_RUNBOOK.md`. Non configurare systemd per riavviare il servizio a ogni `503`:
il processo può essere vivo mentre attende il ripristino sicuro di una dipendenza.

I processi applicativi scrivono JSON line su stderr, raccolto da journald. Il default
`WG_PORTAL_LOG_LEVEL=INFO` registra richieste web redatte, cicli reconciler e soli errori
stabili del helper. Non abilitare access log Gunicorn: includerebbero URI concrete e
duplicherebbero eventi meno sicuri. Per correlare un errore usare `X-Request-ID` e cercare
il relativo UUID nel journal; non aggiungere temporaneamente header o body al logger.

Gli eventi sono nel namespace dedicato e limitato, non nel journal globale:

```bash
journalctl --namespace=wg-portal --since today -o cat
journalctl --namespace=wg-portal -u wg-portal-web.service -p warning..alert
```

Il default vendor conserva al massimo 30 giorni e 256 MiB persistenti, con fallback
runtime da 64 MiB e rotazione massima giornaliera. Quote e rate limit possono abbreviare
la disponibilità dei log; non usarli come sostituto dell'audit. Personalizzazioni locali
vanno in `/etc/systemd/journald@wg-portal.conf.d/` e devono mantenere un limite finito.

## Reverse proxy

Caddy è il reverse proxy supportato ufficialmente. Il riferimento versionato è
`packaging/caddy/wg-portal.caddy.example`: prima dell’uso si devono sostituire il dominio
riservato e i CIDR RFC1918 di esempio con l’allowlist amministrativa reale. La policy
nega con `403` sia UI sia API fuori allowlist, termina TLS e inoltra soltanto al socket
Unix `/run/wg-portal/web.sock`. Configurazioni con proxy differenti non fanno parte della
matrice di supporto della versione 1.

`wg-portal-web.socket` crea il socket come `wg-portal:caddy` con modo `0660` e passa il
file descriptor 3 a Gunicorn; non esiste un listener TCP applicativo. Caddy sovrascrive
`X-Forwarded-For`, `X-Forwarded-Proto` e `X-Forwarded-Host`. Il processo accetta il primo
header come indirizzo effettivo soltanto con `WG_PORTAL_TRUST_UNIX_PROXY=true`; il default
è `false` e una richiesta senza peer riconoscibile diventa `unknown`. Non abilitare questa
opzione per sostituire il socket con un bind TCP. Caddy rifiuta body oltre `1MB`
(1.000.000 byte) prima del proxy; il limite Flask da 1 MiB resta una seconda difesa e
deve rispondere `413`, mai `500`. Gunicorn non produce access log HTTP per evitare query
o identificatori nel journal.

Il servizio web gira come `wg-portal`, senza capability, con filesystem protetto e sole
famiglie `AF_UNIX`, `AF_INET` e `AF_INET6`; le ultime due servono alla risoluzione degli
endpoint configurati, non all’ascolto. Il modello è coperto da test strutturali e dal
check di caricamento Gunicorn. Installazione, upgrade, remove/reinstall, ownership dei
socket, HTTPS Caddy, bootstrap via tunnel e diniego fuori allowlist sono stati collaudati
su Debian 12; M4.1 è chiusa.

La variante `packaging/caddy/wg-portal-mtls.caddy.example` sostituisce, non affianca, il
file base quando si vuole richiedere mTLS. Protegge l'intero origin: anche ogni browser UI
deve presentare un certificato client. Preparare una CA client dedicata fuori dal server,
installare sul server soltanto il certificato CA come
`/etc/caddy/wg-portal-admin-client-ca.pem` e non copiare mai la chiave CA privata. Ogni
integrazione deve avere chiave e certificato propri, con durata breve; per poter revocare
una singola integrazione senza sostituire tutte le altre, usare una CA intermedia dedicata
per integrazione e rimuoverla dal trust bundle al momento della revoca.

Prima dell'attivazione mantenere una sessione SSH/console aperta e verificare:

```bash
caddy validate --adapter caddyfile --config /etc/caddy/Caddyfile
curl --fail --cert client.pem --key client-key.pem \
  --proto '=https' https://wg.example.invalid/healthz
```

Una prova senza `--cert/--key` deve fallire durante TLS. Solo dopo entrambe le prove si
può eseguire `systemctl reload caddy`; in caso di errore ripristinare il Caddyfile dalla
sessione già aperta. mTLS non sostituisce allowlist, autenticazione applicativa o RBAC e
non autorizza mai l'aggiunta di CIDR Internet nella v1. Evidenze del drill:
`docs/CADDY_EXPOSURE_DRILL_R14_2026-10-14.md`.

`packaging/config/wg-portal.env.example` usa intenzionalmente `CHANGE_ME` per entrambi i
segreti: copiato senza modifiche, il servizio production rifiuta l’avvio. Il pacchetto
genera valori distinti al primo configure; in installazioni manuali generarne due di
almeno 32 byte. Non inserire mai i valori nel pacchetto o nel repository.

## API pubblica (in sviluppo)

L'API `/api/v1` è registrata nell'app Flask e sarà servita esclusivamente da Caddy e
Gunicorn insieme alla UI; non è
previsto un processo privilegiato o un listener diretto separato. Prima di abilitarla un
operatore deve verificare le decisioni in `docs/USER_DECISIONS.md`, configurare la policy
approvata di accesso dalle reti amministrative, generare una credenziale per ciascuna
integrazione e provarne scadenza,
rotazione e revoca. Sono disponibili letture scoped, telemetria e create/update di tenant
e utenti con RBAC object-level; le altre mutazioni e il provisioning operativo delle
credenziali restano chiusi. La retention approvata è applicata automaticamente; i record
`pending` non devono essere rimossi manualmente senza aver riconciliato la risorsa
preallocata.

Eseguire periodicamente:

```bash
wg-portal idempotency-maintain
```

Il comando elimina i soli record `completed` vecchi almeno 24 ore e conta i `pending`
senza modificarli. Anche una nuova chiave avvia il cleanup sotto lock. La quota predefinita
è 1000 record per identità e la riserva disco è 256 MiB; configurarle con
`WG_PORTAL_IDEMPOTENCY_MAX_RECORDS_PER_IDENTITY` e
`WG_PORTAL_IDEMPOTENCY_MIN_FREE_BYTES`.
Credenziali condivise tra sistemi o inserite in URL sono vietate.

Il runbook di rilascio deve verificare contratto OpenAPI, rate limit per token e IP, quote
dei job, redazione dei log e accesso cross-tenant negativo attraverso Caddy HTTPS. Ogni
incidente su una credenziale richiede revoca immediata, verifica dei job queued associati,
ispezione dell'audit e rotazione delle credenziali correlate. L'apertura a Internet non è
consentita prima del penetration test e del drill di revoca previsti dalla roadmap.

Prima di una release API eseguire anche:

```bash
.venv/bin/python scripts/openapi-contract.py check
curl --fail --proto '=https' https://wg.example.invalid/api/v1/openapi.json
```

Il primo comando verifica copia packaged e compatibilità con la baseline v1; il secondo
va eseguito sull'hostname effettivo sostituendo il dominio riservato dell'esempio e deve
raggiungere Caddy, non Gunicorn direttamente. Una console Swagger/ReDoc non deve essere
pubblicata in produzione.

## Distribuzione

La versione 1 supporta ufficialmente un pacchetto Debian integrato con systemd e Caddy.
La distribuzione in container è rinviata: concedere a un container i privilegi necessari
per gestire WireGuard e il firewall dell'host allargherebbe la superficie operativa e la
matrice di test.

Il candidate si costruisce con `packaging/debian/build-package.sh`. Le dipendenze runtime
non vengono risolte durante l’installazione: `requirements-prod.lock` fissa versioni e
hash, il builder accetta solo wheel binarie e installa il payload in
`/usr/lib/wireguard-system/site-packages`. I launcher `/usr/bin/wg-portal*` non eseguono shell,
ignorano `PYTHONHOME` e `PYTHONPATH` ereditati e avviano Python con safe-path. Debian 12
fornisce Python 3.11 ma Flask/Gunicorn troppo vecchi per la baseline, perciò il payload
privato è parte del confine di compatibilità.

Per il build destinato alla pubblicazione usare soltanto
`./scripts/build-release-candidate.sh` da un commit pulito. Il comando esegue suite,
audit, SBOM, build, provenienza e verifica con frontend/backend installati da
`requirements-release.lock` in un virtualenv effimero. Ignora configurazioni pip locali,
accetta sole wheel hashate e rifiuta output preesistenti. Package, sorgente, i due lock,
evidenze Python e inventario Debian confluiscono in `dist/releases/<versione>/` e sono
collegati dalla Statement in-toto/SLSA. La verifica locale non sostituisce la firma: fino
al relativo gate il bundle è soltanto una dichiarazione non autenticata. Dettagli e
remediation sono in `docs/SUPPLY_CHAIN.md`.

Il termine della pipeline crea `SHA256SUMS` ma non firma online. L'operatore trasferisce
il bundle completo alla postazione offline, ne ricontrolla gli hash, firma il manifest nel
namespace SSHSIG dedicato e riporta soltanto `SHA256SUMS.sig`. Prima della pubblicazione
`scripts/release-signing.py verify` deve accettare firma, allowlist, revocation list,
insieme esatto dei file, hash e provenienza. Custodia, rotazione, compromissione e
pubblicazione atomica sono definite in `docs/RELEASE_SIGNING.md`.

La pubblicazione APT locale usa `scripts/deploy-apt-package.py` soltanto dopo la firma
SSHSIG. Il wrapper valida una root `reprepro` esistente, richiede `SignWith` uguale al
fingerprint completo fornito e verifica `InRelease`, `Packages` e file nel pool dopo
`includedeb`. La procedura normativa e la configurazione client sono in
`docs/APT_REPOSITORY_DEPLOYMENT.md`; non usare repository unsigned o `trusted=yes`.
L'export GitHub Pages deve passare dallo stesso comando con `--pages-root` e non deve mai
copiare `conf/`, `db/`, `logs/` o `lists/`; commit e push del sito restano un gate umano.

Al primo `configure`, `postinst` crea `wg-portal`, `/var/lib/wg-portal` `0700` e
`/etc/wg-portal` `0750`; genera environment root-owned `0640` e keyring service-owned
`0600`, inizializza lo storage e abilita i socket. Su upgrade l’environment è preservato
byte per byte e ne vengono ripristinati soltanto owner/mode sicuri; keyring e bootstrap
sono idempotenti. Remove e purge fermano le unità ma non cancellano dati, audit, ambiente,
keyring o utente: la rimozione definitiva richiede backup verificato e comando manuale
esplicito. Il Caddyfile resta un esempio non attivato finché l’operatore non configura
hostname e allowlist.

Il pacchetto dipende da `age >= 1.1`. Generare la identity X25519 su una postazione
offline, mai sul server applicativo:

```bash
umask 077
age-keygen -o wg-portal-recovery-identity.txt
age-keygen -y wg-portal-recovery-identity.txt
```

Conservare almeno due copie offline protette della identity e inserire soltanto il
recipient pubblico prodotto dal secondo comando come
`WG_PORTAL_BACKUP_RECIPIENT=age1...` in `/etc/wg-portal/wg-portal.env`. Non trasferire la
identity al server per prove ordinarie: solo un restore reale, in una finestra isolata,
può usarne una copia temporanea `0600`, da eliminare subito dopo la verifica finale.

## Backup baseline

Non usare una copia live come backup consistente. Il contratto M4.2 e la cifratura
`age`/X25519 sono definiti in `BACKUP_RESTORE.md`. `wg-portal backup-create` crea la coppia
cifrata dopo avere fermato e verificato i writer systemd, quindi ripristina soltanto le
unità prima attive. Deve essere eseguito come root verso una directory privata esterna al
data tree. Trasferire la coppia su un host isolato e usare `wg-portal backup-verify` con
una identity offline `0600`; il comando autentica entrambi gli stream senza estrarli né
caricare l'environment production. Eseguire poi `wg-portal restore-preflight` con gli
stessi bundle, identity e `--target-data-dir /var/lib/wg-portal`: il plaintext viene
estratto soltanto in uno staging privato, validato semanticamente e sempre eliminato,
senza modificare il data dir live.

Per applicare il set, annotare l'UUID restituito dalla verifica, isolare l'host da accessi
amministrativi concorrenti e copiare temporaneamente la identity in `/run` con mode `0600`.
Eseguire come root:

```bash
wg-portal restore-apply \
  --data-bundle /srv/wg-portal-recovery/wg-portal-...-data.tar.gz.age \
  --secrets-bundle /srv/wg-portal-recovery/wg-portal-...-secrets.tar.gz.age \
  --identity /run/wg-portal-recovery-identity.txt \
  --target-data-dir /var/lib/wg-portal \
  --environment-file /etc/wg-portal/wg-portal.env \
  --confirm-backup-set-id SET-UUID-VERIFICATO \
  --replace
```

`--replace` è il consenso esplicito richiesto per un data dir non vuoto. Il comando ferma
i writer e tutte le reti nel registry, promuove data, environment e keyring, quindi
riavvia soltanto le unità originariamente attive. Un errore lascia intenzionalmente i
servizi fermi e non espone dettagli sensibili: non forzare il restart, conservare journal
e rollback e raccogliere diagnostica read-only. Dopo il successo eseguire `wg-portal
doctor` e `wg-portal audit-verify`, controllare le unità, eliminare la identity temporanea
e avviare esplicitamente una rete alla volta; tutte le reti recuperate restano `stopped`.
La procedura ha superato il drill Debian M4.2 descritto in
`DISASTER_RECOVERY_DRILL.md`; RPO e RTO operativi dipendono comunque da frequenza dei
backup, dimensione del dataset, storage e numero di reti gestite.

## Keyring master e rotazione

Inizializzare il keyring in un percorso protetto esterno al data tree:

```bash
wg-portal keyring-init --path /etc/wg-portal/secrets/master-keyring.json
```

Configurare lo stesso percorso assoluto in `WG_PORTAL_MASTER_KEY_FILE`. Il file nasce
`0600`; proprietario, directory padre e backup devono essere accessibili soltanto
all'identità del servizio autorizzata. Non includerlo nello stesso archivio dei documenti
cifrati. In produzione la configurazione viene completata dal packaging systemd M4.1.

Per ruotare e poi ricifrare gli envelope:

```bash
wg-portal keyring-rotate
wg-portal keyring-rewrap
wg-portal keyring-rewrap
```

Il secondo rewrap deve riportare zero modifiche. Verificare audit, leggibilità delle
configurazioni e backup prima di considerare conclusa la cerimonia. Non rimuovere le
chiavi `retired` manualmente: devono restare finché ogni envelope e ogni backup ancora in
retention è stato ricifrato o è scaduto. La rotazione della coppia di un client in M2.2
aggiorna solo lo stato desiderato; sarà applicata live dal reconciler M2.5.

## Audit, rotazione ed export

Configurare `WG_PORTAL_AUDIT_HMAC_KEY` con almeno 32 byte casuali e custodirla fuori dal
data tree e dai backup dei record. Se non è impostata, viene derivata con separazione di
dominio da `WG_PORTAL_SECRET_KEY`: è sicuro crittograficamente, ma lega la verifica degli
audit alla rotazione del secret sessione. Conservare quindi le vecchie chiavi finché
esistono archivi che devono essere verificati.

Eseguire giornalmente, da timer systemd della futura distribuzione Debian:

```bash
wg-portal audit-verify
wg-portal audit-maintain
```

`audit-maintain` comprime le giornate con almeno 30 giorni e cancella gli archivi al
compimento di tre mesi calendario. Prima di cancellare verifica sempre HMAC, conteggi e
checksum; in caso di anomalia fallisce senza procedere. Le azioni di archiviazione e
cancellazione generano nuovi eventi audit nella giornata corrente.

Per creare un export nativo compresso già verificato:

```bash
wg-portal audit-export --start 2026-08-01 --end 2026-08-31 \
  --output /percorso-protetto/audit-2026-08.tar.gz
```

La destinazione non viene sovrascritta e nasce con permessi `0600`. Il bundle contiene
eventi e catene, oltre ai manifest per le giornate già archiviate, ma non la chiave HMAC.
Un export fuori dal data tree non può essere eliminato automaticamente: l'operatore deve
includerlo nella stessa scadenza di tre mesi e nella procedura di backup sicuro.
