# Manuale utente e operatore

Questo manuale descrive l’uso quotidiano del portale WireGuard System attraverso la sola
interfaccia web. Non richiede accesso alla shell, conoscenza dei file JSON o uso delle API.
Installazione, recovery e manutenzione del server sono trattati nel
[manuale amministratore](ADMIN_GUIDE.md).

La versione v1 supporta IPv4 privati RFC1918 e reti da `/16` a `/30`. Ogni rete è una
VPN a stella indipendente: i client raggiungono gli altri client della stessa rete
attraverso l’hub, ma non ricevono instradamento Internet dal portale.

## Accesso e regole di sicurezza

Aprire esclusivamente l’indirizzo HTTPS comunicato dall’amministratore. Il certificato
deve risultare valido; non ignorare avvisi del browser. La v1 è destinata a una rete di
amministrazione intranet protetta da allowlist, non all’esposizione diretta su Internet.

L’account iniziale `admin` / `admin` serve soltanto al bootstrap locale. Al primo accesso
il portale obbliga a sostituire la password. Anche gli account creati in seguito devono
cambiare la password iniziale al primo login. La nuova password deve avere almeno 14
caratteri e non deve contenere lo username.

Usare un account personale, non condividere password o configurazioni client e terminare
la sessione con **Esci**. Non lasciare aperti download WireGuard o pagine contenenti dati
operativi su postazioni non presidiate. Ogni operazione importante è registrata
nell’audit log con utente, ambito, esito e identificativo richiesta.

## Ruoli e ambiti visibili

| Ruolo | Ambito | Può fare | Non può fare |
|---|---|---|---|
| `superadmin` | Tutti i tenant e tutte le reti | Gestire tenant, utenti, reti, client, operazioni, audit e accessi API | Non supera conferme, revisioni o controlli di stato |
| `admin` | Uno o più tenant assegnati | Vedere il tenant; gestirne utenti, reti e client; avviare e fermare le reti | Creare/modificare tenant, assegnare `superadmin`, vedere ambiti estranei |
| `manager` | Una o più reti assegnate | Gestire la configurazione, i client e il lifecycle delle proprie reti | Creare reti, amministrare utenti/tenant, vedere altre reti |

Un utente può avere più assegnazioni. La navigazione mostra soltanto le funzioni
pertinenti, ma l’autorizzazione viene ricontrollata su ogni richiesta. Una risorsa fuori
ambito risponde come inesistente (`404`) per non rivelarne la presenza.

## Orientarsi nel portale

La barra di navigazione può contenere:

- **Dashboard**, per inventario, stato runtime e presenza dei client;
- **Tenant**, visibile agli utenti che amministrano tenant;
- **Utenti**, visibile a superadmin e admin di tenant;
- **Reti** e **Client**, per configurazione e lifecycle;
- **Operazioni**, per seguire i job asincroni;
- **Audit**, per ricostruire azioni ed errori;
- **Accessi API**, riservato al superadmin.

I badge distinguono stato configurato, stato desiderato e stato osservato sull’host. Non
considerare una modifica conclusa finché un eventuale monitor operazione non mostra
**succeeded**.

## Workflow superadmin

### Creare e modificare un tenant

1. Aprire **Tenant** e scegliere **Crea tenant**.
2. Inserire nome, slug univoco e descrizione, quindi salvare.
3. Dal dettaglio usare **Modifica tenant** per cambiare metadati o stato.

Un tenant `suspended` resta consultabile ma non può ospitare nuove operazioni operative.
L’archiviazione è una scelta terminale di gestione: verificare prima che le reti siano
ferme e che non servano più.

### Creare utenti e assegnare i ruoli

1. Aprire **Utenti** e scegliere **Crea utente**.
2. Inserire username e una password iniziale temporanea di almeno 14 caratteri.
3. Selezionare almeno un ruolo: globale, per tenant o per singola rete.
4. Consegnare la password iniziale attraverso un canale separato e chiedere il cambio al
   primo accesso.

Un superadmin può assegnare tutti i ruoli. Un admin può amministrare soltanto assegnazioni
dei propri tenant; gli ambiti esterni già presenti vengono conservati e non sono
modificabili. Disabilitare un account quando l’accesso deve cessare. Non riutilizzare lo
stesso account per persone diverse.

### Creare una rete

1. Aprire **Reti**, scegliere **Crea rete** e selezionare il tenant.
2. Inserire nome, CIDR RFC1918, indirizzo hub ed endpoint raggiungibile dai client.
3. Lasciare la porta su **automatic** salvo un requisito preciso. In modalità manuale è
   ammesso soltanto l’intervallo UDP `51820–51999`.
4. Scegliere **Anteprima**. Controllare indirizzi utilizzabili, porta e assenza di
   collisioni, poi confermare la creazione.

Nel medesimo tenant le subnet non possono sovrapporsi. Fra tenant la sovrapposizione è
ammessa perché l’host applica isolamento L3 per rete. Una porta non può collidere sullo
stesso endpoint/IP.

## Workflow admin di tenant

Un admin vede soltanto i tenant assegnati, ma può ripetere per essi il workflow di rete e
client descritto in questo manuale. Può inoltre creare o modificare utenti limitatamente
ai propri tenant. Non può modificare lo stato del tenant né accedere a una rete di un
altro tenant, anche conoscendone l’identificativo.

Prima di intervenire, controllare nella testata il nome tenant/rete. Se l’utente appartiene
a più tenant, usare il filtro tenant nell’elenco reti per ridurre il rischio operativo.

## Workflow manager di rete

Il manager apre **Reti** e vede esclusivamente le reti assegnate. Può modificarne nome e
descrizione; endpoint e porta si modificano soltanto a rete ferma. Non può creare una
nuova rete o archiviarla.

Per l’attività ordinaria:

1. controllare dashboard e ultimo esito delle operazioni;
2. creare o aggiornare i client necessari;
3. applicare le azioni client con conferma esplicita;
4. avviare, sincronizzare o fermare la rete dal riquadro **Azioni rete**;
5. attendere sempre l’esito terminale del job.

## Lifecycle della rete

Una rete nuova è `active` ma desiderata `stopped`. Il dettaglio mostra solo le azioni
valide per lo stato e il ruolo correnti:

| Azione | Quando usarla | Effetto atteso |
|---|---|---|
| **Avvia rete** | Rete attiva e ferma | Imposta `running` e accoda la creazione/configurazione host |
| **Ferma rete** | Rete desiderata `running` | Imposta `stopped` e accoda la rimozione delle risorse host |
| **Sincronizza rete** | Rete `running`, dopo modifiche ai peer | Riapplica configurazione e peer salvati |
| **Riconcilia rete** | Stato host dubbio o dopo interruzione | Riallinea l’host allo stato desiderato corrente |

Ogni azione apre una pagina di conferma. Dopo la conferma compare il monitor del job.
Non inviare una seconda azione sulla stessa rete mentre la prima è `queued` o `running`.
Per modificare endpoint, porta o lifecycle fermare prima la rete e attendere il successo
del relativo job.

## Creazione e lifecycle dei client

Dal dettaglio rete scegliere **Gestisci client** e **Crea client**. Il nome identifica la
macchina o la persona; la descrizione dovrebbe indicare proprietario e scopo. Con
assegnazione automatica il portale sceglie il primo indirizzo libero. In modalità manuale
l’indirizzo deve essere utilizzabile, appartenere alla subnet e non essere già riservato.

L’indirizzo resta permanentemente riservato al client finché non viene eseguito
**Rilascia IP**. Modificare nome o descrizione non cambia indirizzo o chiavi.

| Stato corrente | Azioni disponibili | Significato operativo |
|---|---|---|
| `pending` | Attiva, disabilita, revoca, archivia | Configurazione creata ma peer non ancora ammesso |
| `active` | Disabilita, revoca, archivia | Peer autorizzato nella rete |
| `disabled` | Attiva, revoca, archivia | Sospensione reversibile; IP ancora riservato |
| `revoked` | Archivia, rilascia IP | Credenziale definitivamente non più autorizzabile |
| `archived` | Rilascia IP | Record storico non operativo |

Usare **Disabilita** per una sospensione temporanea e **Revoca** quando la configurazione
può essere compromessa, persa o non deve tornare valida. **Archivia** rimuove il client
dal flusso operativo ma mantiene la prenotazione. **Rilascia IP** libera l’indirizzo per
un futuro client ed è opportuno soltanto quando non serve più correlare il vecchio peer.

Se la rete è ferma, il cambio client viene salvato immediatamente. Se è in esecuzione e
cambia l’insieme dei peer, il portale accoda un job `network.sync` e mostra la finestra di
attesa.

## Download della configurazione WireGuard

Il download è disponibile per client `pending`, `active` o `disabled`, purché tenant e
rete siano attivi. Aprire il dettaglio client, scegliere **Scarica configurazione** e
reinserire la propria password. Il controllo limita i tentativi ripetuti.

Il file `.conf` contiene la chiave privata del client e va trattato come una credenziale:

- salvarlo soltanto sulla macchina destinataria o su un supporto protetto;
- non inviarlo in ticket, chat o e-mail non cifrate;
- importarlo nel client WireGuard e rimuovere eventuali copie temporanee;
- revocare subito il client se il file può essere stato copiato da terzi.

Il portale vieta la cache della risposta con la direttiva `no-store`, ma non può
cancellare download, backup o cronologia gestiti dal dispositivo dell’utente.

## Operazioni asincrone e finestra di attesa

Le modifiche che interessano l’host diventano job. Il monitor si aggiorna automaticamente:

| Stato | Cosa significa | Cosa fare |
|---|---|---|
| `queued` | In attesa del worker | Attendere; non ripetere l’azione |
| `running` | Applicazione in corso | Lasciare aperto il monitor o ritrovarlo in **Operazioni** |
| `succeeded` | Host e richiesta hanno completato il flusso | Tornare alla rete/dashboard e verificare lo stato osservato |
| `failed` | Operazione terminata senza successo | Annotare ID job e codice, seguire il messaggio e consultare l’audit |

Chiudere la finestra non annulla il job. La pagina **Operazioni** consente di riaprirlo.
Se un job resta non terminale, non fabbricare nuove richieste: contattare l’amministratore
con ID job, ora e rete.

I codici più comuni indicano:

- `JOB_AUTHORIZATION_REVOKED`: ruolo, account o ambito non è più valido;
- `JOB_RESOURCE_UNAVAILABLE`: tenant o rete non è più disponibile;
- `NETWORK_STATE_CONFLICT`: lo stato è cambiato; ricaricare prima di riprovare;
- `NETWORK_KEY_UNAVAILABLE` o `NETWORK_CONFIGURATION_INVALID`: serve verifica
  amministrativa di chiavi/configurazione;
- `HELPER_UNAVAILABLE` o `HELPER_OPERATION_FAILED`: problema del servizio host;
- `WORKER_INTERRUPTED`: usare **Riconcilia rete** dopo la verifica amministrativa;
- `WORKER_INTERNAL_ERROR`: fornire ID job e identificativo richiesta all’amministratore.

## Dashboard e presenza client

La dashboard aggiorna automaticamente inventario e telemetria ogni cinque secondi. Il
selettore rete e la tabella rispettano sempre l’ambito del ruolo. Per ogni rete confrontare:

- **desiderato**, cioè `running` o `stopped` richiesto dal portale;
- **effettivo**, cioè lo stato osservato sull’host;
- client totali/attivi e conteggi `online`, `stale`, `offline`, `never_seen`, `unknown`.

Per ogni client vengono mostrati IP VPN assegnato, endpoint pubblico osservato, ultimo
handshake, traffico e **online dal**. WireGuard non mantiene una sessione con inizio certo:
“online dal” è una stima continua basata sulle osservazioni del portale, non una prova di
connessione ininterrotta. `unknown` indica telemetria non affidabile o non disponibile e
non deve essere interpretato come offline. `never_seen` indica che non è mai stato
osservato un handshake valido; `stale` che l’ultimo è oltre la soglia configurata.

## Messaggi d’errore e comportamento sicuro

| Risposta o messaggio | Significato | Azione dell’operatore |
|---|---|---|
| `400` richiesta non valida | Pagina vecchia, campi duplicati o richiesta alterata | Tornare all’elenco e riaprire il form |
| `403` operazione non autorizzata | Re-autenticazione sensibile rifiutata | Verificare password; non insistere |
| `404` risorsa non trovata | Risorsa assente oppure fuori ambito | Verificare tenant/rete e chiedere l’assegnazione corretta |
| `409` conflitto | Revisione o stato cambiato in un’altra sessione | Ricaricare, rileggere lo stato e ripetere consapevolmente |
| `422` dati non validi | Valore o conferma non conforme | Correggere soltanto i campi indicati |
| `429` troppi tentativi/coda piena | Limite di sicurezza o capacità raggiunto | Attendere il tempo indicato senza inviare richieste in parallelo |
| `503` servizio non disponibile | Storage, chiavi, helper o altro componente essenziale non sano | Fermarsi e coinvolgere l’amministratore |

Le pagine di errore espongono un identificativo richiesta. Comunicarlo insieme a data,
ora, username, tenant/rete e ID job; non allegare password, token o file `.conf`.

## Checklist di fine intervento

Prima di considerare conclusa una modifica:

1. verificare che ogni job correlato sia `succeeded`;
2. confrontare stato desiderato ed effettivo in dashboard;
3. controllare presenza e IP dei client interessati senza confondere `unknown` con
   `offline`;
4. consultare l’audit se l’esito non è quello atteso;
5. rimuovere copie temporanee delle configurazioni scaricate;
6. terminare la sessione con **Esci**.

Per guasti del servizio, chiavi non disponibili o recovery, passare la gestione a un
amministratore seguendo il [runbook incidenti](INCIDENT_RUNBOOK.md). Non modificare i file
JSON e non eseguire comandi host per aggirare un errore mostrato dalla UI.
