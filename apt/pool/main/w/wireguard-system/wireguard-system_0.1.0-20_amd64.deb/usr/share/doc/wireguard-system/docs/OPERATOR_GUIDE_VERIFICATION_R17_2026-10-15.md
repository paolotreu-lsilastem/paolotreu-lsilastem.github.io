# Verifica manuale operatore R17 — 2026-10-15

## Esito

**PASS.** Il manuale utente/operatore copre i tre ruoli e il workflow UI senza richiedere
shell o conoscenza dello storage. Lo scenario isolato ha completato bootstrap, scope,
lifecycle, job e download usando Python 3.11 e le dipendenze del candidate tecnico
`wireguard-system 0.1.0-17` installato su `vrt-debian1.lsinet.it`.

R17 ha scoperto P-031: avvio, arresto, sync e reconcile erano presenti nell’engine e
nelle API ma non nella UI. Il sorgente corrente aggiunge pagine di conferma scoped,
optimistic concurrency, backpressure e redirect al monitor asincrono. Come P-030, questa
correzione non è contenuta nel package già costruito `0.1.0-17`: il drill sul laboratorio
ha quindi sovrapposto temporaneamente il sorgente corrente al runtime e alle dipendenze
del package. La correzione entrerà soltanto nel candidate finale dopo freeze e audit; non
viene attribuita retroattivamente a `0.1.0-17`.

## Perimetro e isolamento

- host: `vrt-debian1.lsinet.it`, Debian 12 amd64;
- package installato: `wireguard-system 0.1.0-17`, stato dpkg `installed`;
- runtime: Python `3.11.2` e dipendenze da
  `/usr/lib/wireguard-system/site-packages`;
- overlay sorgente: archivio temporaneo SHA-256
  `d89ed6ab2af16cbaca4a975c38ba0ebaeb4d4274f034c0e28f215739f0c34e91`;
- esecuzione: utente non privilegiato `wg-portal`;
- dati, audit, keyring e sessioni del drill: directory creata da
  `TemporaryDirectory`, eliminata automaticamente;
- helper: soltanto probe read-only implicito della dashboard; nessuna operazione
  `network.apply` o `network.stop` inviata all’host;
- job: portati a stato terminale dal `JobService` sul repository temporaneo, senza worker
  o rete WireGuard reali.

L’overlay e il relativo archivio sono stati rimossi da `/tmp`. Dopo il drill web service,
helper socket e reconciler risultavano attivi. Nessun documento canonico sotto tenant,
reti, client, utenti, job o audit live risultava modificato nella finestra del test; i
soli file runtime aggiornati erano health e lock del reconciler già attivo.

## Scenario eseguito

Lo script riproducibile è `scripts/operator-role-drill.py`. Non contiene password reali,
non usa `/var/lib/wg-portal` e fallisce al primo risultato inatteso.

### Superadmin

1. login bootstrap `admin` / `admin` da client loopback isolato;
2. cambio obbligatorio della password;
3. creazione UI di due tenant;
4. creazione UI, con anteprima, di due reti aventi lo stesso CIDR in tenant diversi;
5. creazione UI di un admin tenant e un manager rete;
6. dashboard globale con entrambi gli ambiti.

Esito: `OK superadmin: bootstrap, tenant, reti sovrapposte fra tenant e utenti`.

### Admin tenant

1. primo login e cambio password obbligatorio;
2. elenco limitato al tenant assegnato;
3. accesso diretto alla rete dell’altro tenant negato con `404` uniforme;
4. creazione e attivazione sincrona di un client a rete ferma;
5. download della configurazione dopo re-autenticazione;
6. presenza delle sezioni `[Interface]` e `[Peer]` e header `Cache-Control: no-store`.

Esito: `OK admin: scope tenant, IDOR, creazione/attivazione e download client`.

### Manager rete

1. primo login e cambio password obbligatorio;
2. dashboard limitata alla sola rete assegnata e navigazione tenant/utenti assente;
3. creazione rete e accesso alla rete estranea negati con `404`;
4. avvio rete dalla nuova UI P-031, redirect al monitor e job `succeeded`;
5. creazione e attivazione di un secondo client con rete `running`;
6. accodamento del conseguente `network.sync`, esito terminale e lista client completa.

Esito: `OK manager: scope rete, avvio monitorato, client live e job asincrono`.

Inventario finale temporaneo: due tenant, due reti, due client e tutti i job terminali
con successo. Cleanup: `OK cleanup: dati e chiavi erano confinati nella directory
temporanea`.

## Verifiche automatiche

I test dedicati controllano:

- visibilità e disponibilità delle azioni rete per stato;
- conferma esplicita, CSRF, form chiuso, IDOR e optimistic concurrency;
- ownership utente del job UI e assenza di credential ID API;
- redirect al monitor e messaggi terminali;
- sezioni obbligatorie del manuale e risoluzione di ogni link locale;
- assenza di procedure shell nel manuale operatore;
- eseguibilità e confinamento temporaneo dello script di drill.

Il quality gate completo e il conteggio finale sono registrati nella chiusura R17 della
[roadmap](ROADMAP.md). Il prossimo gate vincolante è R18: freeze del sorgente finale,
dossier per l’audit e review interna.

Risultato finale di `scripts/check.sh`: lint e type check verdi, contratto OpenAPI
compatibile, **1048 test passati e 1 test d’integrazione APT saltato esplicitamente**
perché richiede l’opt-in con tool esterni.
