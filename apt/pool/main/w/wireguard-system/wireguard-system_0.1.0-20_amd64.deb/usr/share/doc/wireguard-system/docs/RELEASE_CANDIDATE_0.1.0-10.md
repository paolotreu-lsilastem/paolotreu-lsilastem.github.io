# Evidenze predecessor candidate `0.1.0-10`

> **NON USARE COME BASELINE REMOVE/REINSTALL.** R03 ha dimostrato che dpkg invoca
> `preinst install OLD NEW` dopo una rimozione senza purge; questo candidate lo rifiuta
> prima dell'unpack. Il bundle resta immutabile come evidenza del comportamento
> fail-closed, ma la correzione ha una nuova revisione.

## Esito

La pipeline normativa `scripts/build-release-candidate.sh` è stata completata il
2026-10-12 dal commit pulito
`6dab5a8b02d57908caee8a0a5ca578332454041b`. Tutti i gate previsti prima della firma
sono riusciti:

- lint Ruff, type-check mypy e compatibilità OpenAPI;
- 1.003 test superati, 1 integrazione APT opt-in non eseguita e copertura complessiva
  del codice applicativo pari all'84%;
- toolchain effimera installata da `requirements-release.lock` con hash obbligatori;
- audit `clean` di 24 dipendenze runtime con `pip-audit 2.10.1` e SBOM CycloneDX di 24
  componenti;
- build del package Debian `wireguard-system` versione `0.1.0-10`, architettura `amd64`;
- generazione e verifica offline della Statement in-toto/SLSA, del bundle sorgente e di
  tutti i file referenziati.

La prova è stata eseguita su Debian 12 `amd64` in WSL2, kernel
`6.6.87.2-microsoft-standard-WSL2`, con `/usr/bin/python3` 3.11.2. Il timestamp sorgente
deriva dal commit del `2026-10-12T11:02:43+02:00`; l'audit è stato generato alle
`2026-10-12T09:07:17.596955Z`.

## Identità e contratto

Il package dichiara:

```text
Package: wireguard-system
Version: 0.1.0-10
Architecture: amd64
X-WireGuard-System-Data-Schema: 1
X-WireGuard-System-Upgrade-From: none
X-WireGuard-System-Recovery-Protocol: 1
```

`upgrade-from: none` rende questa revisione installabile soltanto da zero: il preflight
rifiuta qualunque upgrade in ingresso. Il package serve come predecessor corrente per il
futuro arco `0.1.0-10 → 0.1.0-11`; non prova ancora tale upgrade.

La Statement contiene 2 subject, 5 materiali risolti, 6 dipendenze del builder e 4
byproduct. L'inventario Debian descrive 1.236 entry del payload.

## SHA-256

| Artefatto | SHA-256 |
|---|---|
| `wireguard-system_0.1.0-10_amd64.deb` | `76296a306e88dd7f6808feec28c6fc6c72e3878fc1203f7ac9ecc6213a8ac652` |
| `wireguard-system-0.1.0-source.tar.gz` | `296164f891521aaef6b5174afdd8d533a0891c4787cea75c8410227cfb2d7de3` |
| `provenance.intoto.json` | `87483271eaa65e0aee19e6084c462b104ee28de13d35f63875f224189fe241eb` |
| `debian-package-inventory.json` | `af90ca032362e84801357d43dfd65d2677e2b6efd7edb93b4619dcb67dc37638` |
| `materials/requirements-prod.lock` | `83a7c1fed4cfedf6ae14d21ce98395676cb59673a2966a8edb66f7461a98a28f` |
| `materials/requirements-release.lock` | `520249e643a25e31330d796710678671af4c6cbe255da9fee400c2f274d05e4c` |
| `security/manifest.json` | `481b752eb38d12288982304a3ccd584b8fcc2a08814181b252c05c7557b97294` |
| `security/python-audit.json` | `82a195448eb5d207856233111106256d337d8882f9b3dafe94a759ea8ae5bde1` |
| `security/python-sbom.cdx.json` | `004c3309dd2c79a2057d9eb99c22535919e05450f9b8465f62ff48afe26a65f5` |
| `SHA256SUMS` | `4c7962ec03fabfd3094912b2f83af089d847a3cd3ee1e030b35bcc3ddda23316` |

Il `.deb` nel bundle è byte-identico al package esterno e condivide lo stesso hash.

## Limiti e prossimo gate

Questa evidenza dimostra coerenza interna con il commit e i lock dichiarati. Non dimostra
autenticità del produttore, non è una riproduzione indipendente e non attribuisce un
livello SLSA. `SHA256SUMS` non ha ancora una firma reale: il bundle resta non pubblicabile
fino alla cerimonia offline. Prima di quel gate, `R03` può usarlo esclusivamente nel
laboratorio isolato per ricostruire la baseline pulita prevista dal piano di recupero.
