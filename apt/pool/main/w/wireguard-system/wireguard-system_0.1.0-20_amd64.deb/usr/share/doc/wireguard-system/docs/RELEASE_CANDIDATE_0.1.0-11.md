# Evidenze candidate rifiutato `0.1.0-11`

> **STORICO — NON INSTALLARE.** La pipeline locale è integra, ma il test Debian reale ha
> rilevato directory Python non leggibili dall'utente `wg-portal`. Il package ha superato
> `preinst` ed è stato unpacked, poi `postinst` ha fallito chiuso prima
> dell'inizializzazione. R03 ha ripristinato `0.1.0-5` e tutti gli hash della baseline.

## Identità

- commit sorgente: `1d3f3fa0abe351e652dfa67f9dfb9f9bf0c913d2`;
- package: `wireguard-system 0.1.0-11 amd64`;
- contratto: `X-WireGuard-System-Upgrade-From: none`;
- pipeline: 1.004 test superati, 1 integrazione APT opt-in non eseguita, audit di 24
  dipendenze pulito e bundle verificato;
- inventario Debian: 1.238 entry.

## SHA-256

| Artefatto | SHA-256 |
|---|---|
| `wireguard-system_0.1.0-11_amd64.deb` | `95a0fc3ac91c9b7ff54b70ef5005dbdeea74d0f0f20b6cca64f31c8061b9d5f8` |
| `wireguard-system-0.1.0-source.tar.gz` | `8fb14798ec155d1647821cccca403f9678fa826662cf461c72322edabf12d0fb` |
| `provenance.intoto.json` | `363af5981d3b94938c606d07e49b40c9c4d81d5ea3d0c5d819e136090415d1e6` |
| `debian-package-inventory.json` | `8de67f6f2fca96993616a54e2dc2d857285e63e2ac8fb01c7dd7a2dd7a533284` |
| `SHA256SUMS` | `f4c0b1219fb6109c09169c2a700b1f68ee9ae5c8bfd8e921cb9ef1aad88216ec` |

Il bundle resta immutabile come evidenza di `P-013`; non deve essere firmato, pubblicato
o ricostruito. La nuova revisione dovrà normalizzare e testare i mode dell'intero payload
prima di tornare sul laboratorio.
