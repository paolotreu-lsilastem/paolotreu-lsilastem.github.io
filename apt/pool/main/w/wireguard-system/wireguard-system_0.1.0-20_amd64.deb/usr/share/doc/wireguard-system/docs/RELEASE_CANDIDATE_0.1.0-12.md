# Evidenze candidate corretto `0.1.0-12`

> **CANDIDATE NON FIRMATO — NON USARE IN PRODUZIONE.** Il bundle ha completato la
> pipeline locale, il payload rispetta il contratto ADR 0091 e l'installazione controllata
> R03 sul laboratorio Debian è riuscita. Restano firma e gate successivi della roadmap.

## Identità

- commit sorgente: `f290ad9092ac05e06a17c3eb9ec9eb243d10c866`;
- package: `wireguard-system 0.1.0-12 amd64`;
- contratto: `X-WireGuard-System-Upgrade-From: none`;
- schema dati: `1`;
- protocollo recovery: `1`;
- pipeline: 1.005 test superati, 1 integrazione APT opt-in non eseguita, copertura 84%,
  audit di 24 dipendenze pulito e SBOM di 24 componenti;
- inventario Debian: 1.240 entry.

## Verifica P-013

Il package è stato costruito dalla pipeline sotto `umask 077`. L'inventario ricalcolato
dal `.deb` non contiene directory con mode diverso da `0755` né file regolari sotto
`usr/lib/wireguard-system/site-packages` con mode diverso da `0644`. Il verifier ha
confrontato integralmente tale inventario con `debian-package-inventory.json`.

## Collaudo Debian R03

Il package è installato su `vrt-debian1` tramite remove senza purge di `0.1.0-5` e clean
install. Dpkg e unit file sono integri; systemd è `running`, readiness Unix/HTTPS, doctor,
helper, reconciler health e audit sono verdi. Environment, keyring, meta, registry,
Caddyfile e digest dati coincidono con la baseline. Registry v2 e rete sono vuoti,
forwarding resta `0`.

Due tentativi precedenti hanno attivato correttamente il rollback per falsi negativi
dell'harness: PATH azzerato per `doctor` e parsing del bullet systemd. Il tentativo
etichettato conclusivo ha superato tutti i gate e ha resettato soltanto le due failure
helper storiche dopo aver escluso nuove failure. Nessun restore dei dati è stato
necessario.

## Drill incidenti R04

Il 2026-10-12 lo stesso package ha superato il drill M4.3 reale: staleness a 600 secondi,
tre failure helper confinate con backoff 2/4 secondi, recupero su cicli successivi,
readiness Unix/HTTPS, separazione journald e cleanup completo. Hash persistenti, audit,
registry vuoto e assenza di risorse rete sono rimasti invariati. Il risultato non cambia
il limite del candidate: resta non firmato e non pubblicabile.

## SHA-256

| Artefatto | SHA-256 |
|---|---|
| `wireguard-system_0.1.0-12_amd64.deb` | `4b993ef06306a037fef9786dff5ecc1ecbabb76a1bdad354ccae8238b7f60269` |
| `wireguard-system-0.1.0-source.tar.gz` | `31fca99e81b0702e8bb63897bf206c6e19e3f974cec94c1e9ed5aad908cafd24` |
| `provenance.intoto.json` | `339eb59f07de2da1587f5f657fa6fb1d169a7e972c89e9ed42b200dd0609b4e0` |
| `debian-package-inventory.json` | `59a13a04ea8dc2f7dacdd0c1aa9561a597f658b0ea3995de818ceff63d07148c` |
| `SHA256SUMS` | `6a68d14ee806c456da59951c8d558348db6e4eda4372d60b648295934a014772` |

## Limiti

La verifica stabilisce integrità interna, lineage e conformità del payload, non
autenticità: `SHA256SUMS` non è ancora firmato. Il build locale self-hosted
non è una riproduzione indipendente. Il candidate è immutabile e non pubblicabile. Firma,
upgrade reale e pubblicazione restano gate separati della roadmap.
