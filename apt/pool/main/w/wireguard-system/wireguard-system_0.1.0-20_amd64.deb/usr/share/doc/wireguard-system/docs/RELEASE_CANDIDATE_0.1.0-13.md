# Evidenze candidate consecutivo `0.1.0-13`

> **CANDIDATE FIRMATO, NON APPROVATO PER PRODUZIONE.** Il bundle ha completato pipeline,
> firma R06, happy path R07 e failure point pre-unpack/consumo R08 sull'arco
> `0.1.0-12 → 0.1.0-13`. Recovery, audit e pubblicazione restano gate separati.

## Identità

- commit sorgente: `a7e3bacea1f3a2507d2cc20142ccf81876adac68`;
- package: `wireguard-system 0.1.0-13 amd64`;
- contratto: `X-WireGuard-System-Upgrade-From: 0.1.0-12`;
- schema dati: `1`;
- protocollo recovery: `1`;
- pipeline: 1.006 test superati, 1 integrazione APT opt-in non eseguita, copertura 84%,
  audit di 24 dipendenze pulito e SBOM di 24 componenti;
- inventario Debian: 1.241 entry, composto da 1.016 file, 224 directory e 1 symlink.

Il verifier indipendente ha ricalcolato package, inventario, materiali, manifest e
provenienza dal bundle. Il controllo Debian conferma nome, versione, architettura, schema,
predecessor e protocollo recovery incorporati nel `.deb`.

## Lineage consecutiva R05

Il predecessor `0.1.0-12` deriva dal commit immutabile
`f290ad9092ac05e06a17c3eb9ec9eb243d10c866`, è installato nel laboratorio ed espone il
protocollo recovery corrente. Il nuovo candidate deriva dal commit sopra indicato e
ammette esclusivamente tale versione come ingresso. Versioni diverse, incluso un reinstall
dello stesso candidate fuori dal recovery attestato, restano negate fail-closed.

Questa coppia soddisfa il requisito R05 di due package consecutivi e byte-identificati.
Non dimostra ancora che l'arco sia operativamente supportato: R07–R08 sono verdi, ma i
drill recovery e rollback R09–R11 devono precedere ogni dichiarazione di supporto.

## SHA-256

| Artefatto | SHA-256 |
|---|---|
| `wireguard-system_0.1.0-13_amd64.deb` | `96e4714546b682230274ceff85297c6041d9b6a2f40d166e17945aa6f7a2e3e6` |
| `wireguard-system-0.1.0-source.tar.gz` | `69b737a038d9d684ba005496f6ec7c72ce9a388561be87c2424ae743cfe6ce08` |
| `provenance.intoto.json` | `c9b27229ba6575df58f9a832622dfc377c916888892d5002a0d950f323652168` |
| `debian-package-inventory.json` | `dddf2949e2b47a30405f630bd672ee2193a31fab6ec4798809e774b3e2f30617` |
| `security/python-audit.json` | `82a195448eb5d207856233111106256d337d8882f9b3dafe94a759ea8ae5bde1` |
| `security/python-sbom.cdx.json` | `221da1d69563dcdd17f17d406b52f4662d07a86fcd0e33508ed11735eb0089d9` |
| `SHA256SUMS` | `b134eb906266c4a50cc8d9eb3160dd8ee8c74ca364878ae14e89319cc1068148` |

## Limiti

Alla chiusura di R05 la verifica stabiliva integrità interna, lineage e conformità, ma
non ancora autenticità o comportamento reale. R06 ha successivamente aggiunto la firma
SSHSIG, R07 ha installato il bundle sul laboratorio con authorization monouso e R08 ha
provato i failure point fino al consumo. Il build non è una riproduzione indipendente:
resta locale e self-hosted. Il candidate non è pubblicabile; i recovery drill restano
aperti. La prima esecuzione dell'orchestratore R05 si era
fermata prima di creare artefatti per indisponibilità DNS del sandbox; la riesecuzione
autorizzata con accesso di rete partì da output assenti ed è quella qui documentata.
