# Evidenze candidate recovery `0.1.0-15`

> **CANDIDATE FIRMATO E INSTALLATO IN LABORATORIO, NON APPROVATO PER PRODUZIONE.** Il
> bundle ha completato pipeline, firma SSHSIG e upgrade reale `0.1.0-14 → 0.1.0-15`.
> Il rollback con restore viene collaudato sull'arco consecutivo `0.1.0-15 → 0.1.0-16`;
> cleanup R11 e gate successivi restano obbligatori.

## Identità

- commit sorgente: `0b06c4e1d9255bfb85fe864254fc6520bde22f55`;
- package: `wireguard-system 0.1.0-15 amd64`;
- contratto: `X-WireGuard-System-Upgrade-From: 0.1.0-14`;
- schema dati: `1`;
- protocollo recovery: `1`;
- pipeline: 1.028 test superati, 1 integrazione APT opt-in non eseguita, copertura 84%,
  audit di 24 dipendenze pulito e SBOM di 24 componenti;
- inventario Debian: 1.251 entry, composto da 1.026 file, 224 directory e 1 symlink.

Il verifier ha ricalcolato package, inventario, materiali, manifest e provenienza dal
bundle. Il controllo Debian conferma nome, versione, architettura, schema, predecessor e
protocollo recovery incorporati nel `.deb`.

## Scopo R11

Il candidate separa gli intent terminali di rollback e reinstallazione candidate dalle
directory attive lette dai maintainer script immutabili. La migrazione valida il legame
con marker, autorizzazione e receipt, usa un rename atomico, rimuove la directory attiva
quando resta vuota ed è ritentabile dopo un'interruzione. Recovery status e finalizer
rifiutano storico orfano, duplicato, corrotto o associato al terminale errato.

La suite automatica copre la compatibilità col predecessor e i retry, ma non sostituisce
il drill privilegiato: P-022 rimane aperto finché il laboratorio non completa upgrade,
rollback attestato, restore degli stessi bundle autorizzati, ripresa dei soli writer
originari e verifica del cleanup senza bind view.

## SHA-256

| Artefatto | SHA-256 |
|---|---|
| `wireguard-system_0.1.0-15_amd64.deb` | `10f3c78215cfb4c143b75e80839b2730c1e3138da3fcdfc6e3a68f981546a7d0` |
| `wireguard-system-0.1.0-source.tar.gz` | `e874b2bb556be469cbf9407aaa576477e4b588814026ae3330cc617f1a264c02` |
| `provenance.intoto.json` | `25596651eb94c07b46691dbafce44964ebf74b4cda3cb43350f9c5a0de4f466a` |
| `debian-package-inventory.json` | `d64f6b26d5c6e9b7c02adb65751d127e3c77800441a40b8a7b849b5d8d4c898d` |
| `security/manifest.json` | `bd9d635263b8f913b879c051386f68af32e8ce09a7fbff986284d637f06bd431` |
| `security/python-audit.json` | `82a195448eb5d207856233111106256d337d8882f9b3dafe94a759ea8ae5bde1` |
| `security/python-sbom.cdx.json` | `143627d3cdcad8b57abd5519e663a0a82f8832c8bc94a6efa8275c3273f7b29f` |
| `SHA256SUMS` | `9c9869fd3aecbccd7da30221d26bd158333d15c72039861ccd5bdf4c529c03c4` |

## Limiti

Il build è locale e self-hosted, non una riproduzione indipendente. `SHA256SUMS.sig` non
esisteva al momento del build; la successiva firma SSHSIG ha SHA-256
`68379c8795fb1295e6058002c61012b47225ca0fd55a0fc372b2a93703423c28` ed è stata
verificata prima dell'installazione reale. Il 2026-10-14 l'arco `0.1.0-14 → 0.1.0-15`
è terminato sano con receipt `finalized`: prova l'happy path, non il rollback R11. La
revisione consecutiva `0.1.0-16` è quindi riservata per il fault pre-finalizzazione.
La chiave privata corrente è presente anche sulla workstation di sviluppo per decisione
esplicita del maintainer; la firma prova il possesso della chiave accettata, non una
custodia esclusivamente air-gapped. Il candidate non deve essere pubblicato né dichiarato
supportato prima della chiusura di R11 e dei gate successivi della roadmap.
