# Evidenze candidate recovery `0.1.0-16`

> **CANDIDATE FIRMATO E COLLAUDATO, RIFIUTATO COME CHIUSURA R11.** Il bundle ha
> completato pipeline, firma e drill reale `0.1.0-15 → 0.1.0-16`. Fault, rollback,
> restore e migrazione degli intent sono riusciti; il controllo terminale ha però
> rilevato P-026, corretto nella revisione successiva. Non approvato per produzione.

## Identità

- commit sorgente: `3d0da508e5c9b384288552a4547efeb48b1d7b16`;
- package: `wireguard-system 0.1.0-16 amd64`;
- contratto: `X-WireGuard-System-Upgrade-From: 0.1.0-15`;
- schema dati: `1`;
- protocollo recovery: `1`;
- pipeline: 1.028 test superati, 1 integrazione APT opt-in non eseguita, copertura 84%,
  audit di 24 dipendenze pulito e SBOM di 24 componenti;
- inventario Debian: 1.252 entry, composto da 1.027 file, 224 directory e 1 symlink.

Il verifier ha ricalcolato package, inventario, materiali, manifest e provenienza dal
bundle. Il controllo Debian conferma nome, versione, architettura, schema, predecessor e
protocollo recovery incorporati nel `.deb`.

## Scopo R11

Il candidate contiene la remediation che separa gli intent terminali dalle directory
attive lette dai maintainer script. Il laboratorio parte da `0.1.0-15`, introduce un fault
controllato dopo il consumo dell'authorization e prima della receipt `finalized`, quindi
deve usare esclusivamente l'executor attestato per reinstallare il predecessor immutabile,
ripristinare il recovery set autorizzato e riprendere i soli writer originari.

Il drill del 2026-10-14 ha prodotto `half-configured` tramite mask temporaneo del solo
socket helper, reinstallato `0.1.0-15`, ripristinato il recovery set
`9c7f296f-2d7a-4269-878c-03984fc90d20`, ripreso i cinque writer e rimosso identity,
mask e directory attiva. I quattro intent legacy sono stati migrati byte per byte e
l'intent corrente archiviato. Il successivo `recovery-status` ha tuttavia fallito chiuso:
validava le receipt di restore contro il solo intent attivo anziché quello storico ormai
terminale. P-026 registra il difetto; `0.1.0-17` deve chiuderlo prima di R11.

## SHA-256

| Artefatto | SHA-256 |
|---|---|
| `wireguard-system_0.1.0-16_amd64.deb` | `1fd6a0eca62afb997312638117726dc5f37efc4544af4af61cd91f93ce2c71d1` |
| `wireguard-system-0.1.0-source.tar.gz` | `b6c8d5b9fa28ce7b547d5da35eb8528ccf1872bb558d6dee5bf9b665755c15f7` |
| `provenance.intoto.json` | `c041406e4a5e5789b53b26776b6fa1ef15bf230780dba170ae26fdeebb5e2a3b` |
| `debian-package-inventory.json` | `e30db33e509bc72a5e8a2193034ab79bfb63ca1c7c531b7dd0b084fa4ccaca85` |
| `security/manifest.json` | `a61132a41df5982fdec09a3106e73b1362565ba7d1ecd6c8d917a04756f0d50e` |
| `security/python-audit.json` | `82a195448eb5d207856233111106256d337d8882f9b3dafe94a759ea8ae5bde1` |
| `security/python-sbom.cdx.json` | `b405559d1669f25a13aca24d09c7c006b206292727b0759c1c7018ecb8737f6e` |
| `SHA256SUMS` | `9ba01837a18267a2cd040263f4a9a6585c77ff6a6b775bf98fe5fc29c234e8ba` |

## Limiti

Il build è locale e self-hosted, non una riproduzione indipendente. Il tempo di test
maggiore del consueto è compatibile con carichi CPU concorrenti dichiarati dal
maintainer e non ha modificato risultati o artefatti. La firma SSHSIG verificata ha
SHA-256 `f1887f6f351b41b396c52e79cd8e650c3e226e8b54c5de9a5bd32fe677773a68`.
La chiave privata corrente è presente anche sulla workstation di sviluppo per decisione
esplicita del maintainer; la firma prova il possesso della chiave accettata, non una
custodia esclusivamente air-gapped. Il candidate è rifiutato per P-026 e non deve essere
pubblicato né dichiarato supportato.
