# Evidenze candidate recovery `0.1.0-17`

> **CANDIDATE FIRMATO E VERIFICATO IN LABORATORIO, NON APPROVATO PER PRODUZIONE.** Il
> bundle ha completato pipeline, firma SSHSIG e upgrade reale da `0.1.0-15`; corregge
> P-026 e chiude il controllo terminale R11. I gate successivi restano obbligatori.

## Identità

- commit sorgente: `06a3b37c59706e9a8484cc15104c38d9b321e896`;
- package: `wireguard-system 0.1.0-17 amd64`;
- contratto: `X-WireGuard-System-Upgrade-From: 0.1.0-15`;
- schema dati: `1`;
- protocollo recovery: `1`;
- pipeline: 1.028 test superati, 1 integrazione APT opt-in non eseguita, copertura 84%,
  audit di 24 dipendenze pulito e SBOM di 24 componenti;
- inventario Debian: 1.254 entry, composto da 1.029 file, 224 directory e 1 symlink.

Il verifier ha ricalcolato package, inventario, materiali, manifest e provenienza dal
bundle. Il controllo Debian conferma nome, versione, architettura, schema, predecessor e
protocollo recovery incorporati nel `.deb`.

## Scopo R11

Il rollback/restore eseguito con `0.1.0-16` ha reinstallato `0.1.0-15`, ripristinato il
recovery set attestato, ripreso i cinque writer e archiviato gli intent senza modificarne
i byte. Ha anche esposto P-026: il classificatore terminale richiedeva ancora l'intent
attivo quando validava le receipt di restore, benché `predecessor-resumed` lo avesse già
spostato nello storico secondo ADR 0095.

ADR 0096 consente il legame con l'intent storico dello stesso digest solo dopo la sua
validazione completa contro marker e receipt terminale. Duplicati, orfani, intent non
terminali, receipt corrotte e digest discordanti restano fail-closed. La regressione
automatica riproduce il ciclo completo e richiede `no_pending_transaction` dopo il
cleanup. Il laboratorio ha confermato classificatore, health timer, idempotenza e stato
operativo senza rimuovere o riscrivere lo storico. Il verbale completo è in
`docs/UPGRADE_ROLLBACK_DRILL_R11_2026-10-14.md`.

## SHA-256

| Artefatto | SHA-256 |
|---|---|
| `wireguard-system_0.1.0-17_amd64.deb` | `2ecfbd13ac6eeba46ba984ad21a01b175701f9c47e99987cb57a9ee81fe8a4c4` |
| `wireguard-system-0.1.0-source.tar.gz` | `1651e1c5519362b6a4b4b337597a79c13c9bbb0310628a75c9a9f09b53ce6ba2` |
| `provenance.intoto.json` | `2c9a72a0a4fd23260aa22d25dbd78f3be56dfe6b1bf199c9f646b756ab21ef1c` |
| `debian-package-inventory.json` | `79ab27fe5b761a0627aba408e2606ec628f23831767e3d63a5d57c8f484e498a` |
| `security/manifest.json` | `3c3bc693c6e4e83d6c988f99d269ad54af1b288430003d823b7d4feab950aa04` |
| `security/python-audit.json` | `82a195448eb5d207856233111106256d337d8882f9b3dafe94a759ea8ae5bde1` |
| `security/python-sbom.cdx.json` | `22aee68d832c160b02464474eb1f27f377870fc4d6ef6af071ae8d43d9b10bcd` |
| `SHA256SUMS` | `9ebace085e85f6d02f1b437064584fea8ac67dca8e2ffd8a179ee9be36b1a7df` |

## Limiti

Il build è locale e self-hosted, non una riproduzione indipendente. La firma SSHSIG
verificata ha SHA-256
`e404430408b883860254959cefbbdffee53e4997919c02870a6b5a59ec74cfa9`.
La chiave privata corrente è presente anche sulla workstation di sviluppo per decisione
esplicita del maintainer; la firma prova il possesso della chiave accettata, non una
custodia esclusivamente air-gapped. Il candidate è installato e sano nel laboratorio ma
non deve essere pubblicato né dichiarato production-ready prima dei gate successivi.
