# Evidenze release candidate `0.1.0-9`

> **STORICO — NON PUBBLICABILE.** Questo bundle identifica soltanto il commit
> `10272fa6134df40c0794faafe433d6c3c56bef91`, precede il recovery completo degli
> ADR 0066–0088 e non rappresenta il codice corrente. Non rigenerare né firmare la stessa
> versione da un commit differente.

## Esito

La pipeline `scripts/build-release-candidate.sh` è stata completata il 2026-10-08 dal
commit pulito `10272fa6134df40c0794faafe433d6c3c56bef91`. Tutti i gate previsti prima della
firma sono riusciti:

- lint Ruff, type-check mypy e compatibilità OpenAPI;
- 812 test superati con copertura complessiva del codice applicativo pari all'84%;
- installazione della toolchain effimera da `requirements-release.lock` con hash
  obbligatori e sole wheel;
- audit `clean` di 24 dipendenze runtime con `pip-audit 2.10.1` e SBOM CycloneDX;
- build del package Debian `wireguard-system` versione `0.1.0-9`, architettura `amd64`;
- generazione atomica e verifica offline della Statement in-toto/SLSA e di tutti i file
  referenziati.

La prova è stata eseguita su Debian 12 `amd64` in WSL2, kernel
`6.6.87.2-microsoft-standard-WSL2`, con `/usr/bin/python3` 3.11.2. Il timestamp sorgente
derivato dal commit è `2026-10-08T20:11:06Z`; l'audit è stato generato alle
`2026-10-08T20:15:20.964946Z`.

## Identità e inventario

Il package dichiara:

```text
Package: wireguard-system
Version: 0.1.0-9
Architecture: amd64
Depends: python3 (>= 3.11), adduser, wireguard-tools, iproute2, nftables,
         age (>= 1.1), caddy (>= 2.6), systemd (>= 252)
```

La Statement contiene 2 subject, 5 materiali risolti, 6 dipendenze del builder e 4
byproduct. L'inventario Debian descrive 1.203 entry del payload.

## SHA-256

| Artefatto | SHA-256 |
|---|---|
| `wireguard-system_0.1.0-9_amd64.deb` | `98f49a3d0ea69d29863a958c51b5754337b58bdeeaf1eca9516e3422e1f1654b` |
| `wireguard-system-0.1.0-source.tar.gz` | `8ac7b9cb51eee62381f07f35d75de62a98dcba2b0247c4a3922b48302b61cb86` |
| `provenance.intoto.json` | `ca1c9141c21002ad988a62af6d92e7c7ac63b9b817724cab85418f051ba6ee81` |
| `debian-package-inventory.json` | `45cdc56778e0c47f94a053bea2e89322f29c18d3762248e34c67131fd8c67f3c` |
| `materials/requirements-prod.lock` | `83a7c1fed4cfedf6ae14d21ce98395676cb59673a2966a8edb66f7461a98a28f` |
| `materials/requirements-release.lock` | `520249e643a25e31330d796710678671af4c6cbe255da9fee400c2f274d05e4c` |
| `security/manifest.json` | `57c61c35e2adfee9639d7d4d8e63502514c48701f7a2cb0700b39779d9d3610f` |
| `security/python-audit.json` | `82a195448eb5d207856233111106256d337d8882f9b3dafe94a759ea8ae5bde1` |
| `security/python-sbom.cdx.json` | `2c8402ad011b305bba85835ec5b68663aeae24fe580f1e5bad305ff3f5442010` |
| `SHA256SUMS` | `3de467bec3c46a9e6d4c949fabb70c7e4eca938b16bb335b8ae14779281e1248` |

Il `.deb` nel bundle è byte-identico al package esterno e condivide lo stesso hash.

## Limiti e prossimo gate

Questa evidenza dimostra la coerenza interna del candidate con il commit e i lock
dichiarati. Non dimostra autenticità del produttore, non è una riproduzione indipendente
su un secondo builder e non attribuisce un livello SLSA. La Statement non firmata non
autentica il produttore: il candidate non è pubblicabile come release attendibile finché
il gate di signing offline e relativa verifica non è completato.

Il manifest canonico `SHA256SUMS` è stato preparato e ricontrollato sul bundle reale; non
è presente alcun `SHA256SUMS.sig` finché la cerimonia offline non viene eseguita.
