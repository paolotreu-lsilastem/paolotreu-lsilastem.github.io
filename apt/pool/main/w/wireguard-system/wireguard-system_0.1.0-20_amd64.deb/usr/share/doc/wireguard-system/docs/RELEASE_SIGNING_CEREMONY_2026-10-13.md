# Verbale cerimonia offline R06 — 2026-10-13

## Esito

`R06` è **superata**. Le chiavi private restano esclusivamente nella postazione
air-gapped e nelle due copie cifrate verificate; repository, workstation connessa,
server e log ricevono soltanto materiale pubblico e firme detached. Questo risultato
autentica i bundle di prova, ma non rende ancora supportato l'upgrade né autorizza una
pubblicazione di produzione.

## Ambiente dichiarato dall'operatore

La cerimonia è stata eseguita in uno stack interamente air-gapped VMware → Windows 11
Pro → Kali WSL, senza rete, cartelle condivise, clipboard o drag-and-drop. OpenSSH era
`10.2p1 Debian-5` con OpenSSL `3.5.5`. Il controllo `ssh-keygen -?` ha confermato il
supporto SSHSIG `-Y sign`/`verify`.

Sono state generate due chiavi Ed25519 separate con `ssh-keygen -a 100` e passphrase
distinte, mai comunicate o registrate nel progetto:

| Uso | Principal / namespace | Fingerprint SHA-256 |
|---|---|---|
| Release | `release@wireguard-system` / `release@wireguard-system` | `SHA256:6KitBJHvrhPyWHGfu8Np+6l4nETVr5RD95lYSapb4rg` |
| Upgrade | `upgrade-operator@wireguard-system` / `upgrade@wireguard-system` | `SHA256:eK6dmIh0lnDw0YV22nDFDW3Rki82G6TvzPx7Kkpv1dc` |

Entrambe le private hanno rifiutato la passphrase vuota. I self-test offline hanno
accettato ciascuna firma soltanto con principal, namespace e policy corretti; gli incroci
release/upgrade sono stati rifiutati. I fingerprint mostrati offline sono stati poi
ricalcolati dalla workstation connessa sui `.pub` importati, fornendo il secondo canale
di confronto.

## Bundle firmati

L'ingresso offline conteneva esclusivamente i bundle immutabili `0.1.0-12` e
`0.1.0-13`; l'archivio aveva SHA-256
`bf8dacb23114f098bb8bfbdc4f4c8b4274785748380ccd4e9af275085e4ae64e`. Prima della
firma, `sha256sum --check` ha verificato entrambi i manifest:

| Bundle | SHA-256 `SHA256SUMS` | SHA-256 `SHA256SUMS.sig` |
|---|---|---|
| `0.1.0-12` | `6a68d14ee806c456da59951c8d558348db6e4eda4372d60b648295934a014772` | `c1ceae76e69212a5ce2474fdac1d84cf655077cc9bf8a2d5f006f0a1ea0ccc5f` |
| `0.1.0-13` | `b134eb906266c4a50cc8d9eb3160dd8ee8c74ca364878ae14e89319cc1068148` | `4b5375c8161247bd1d852c5b76191da5d9ad980edf8a80fafdd70207e3560c19` |

Le due firme usano la chiave release e il namespace `release@wireguard-system`. La
workstation connessa ha verificato firma, checksum e provenienza di entrambi i bundle con
`scripts/release-signing.py`. Tre prove negative reali hanno rifiutato il namespace errato
`upgrade@wireguard-system`, la chiave release inserita nella revocation list e un `.deb`
alterato di un byte.

## Materiale pubblico e backup

L'archivio pubblico di ritorno aveva SHA-256
`b11bc6f85cebfe8edfbd5cd5e6e6d264609da3dd445ae330cc51cc56f45d1615`; struttura,
assenza di link, dimensioni e manifest interno sono stati verificati prima
dell'estrazione. Il repository pubblica:

- `release/release-key.pub`, `release/allowed_signers` e `release/revoked_keys`;
- la corrispondente policy separata sotto `release/upgrade/`;
- manifest firmati e firme detached sotto `release/manifests/` e
  `release/signatures/`.

`release/CEREMONY-PUBLIC-MANIFEST.sha256` conserva senza riscritture il manifest a nomi
piatti dell'export offline. `release/README.md` documenta la mappatura nei percorsi del
repository e la suite ne verifica tutte e sole le otto entry.

Le due chiavi private OpenSSH sono cifrate individualmente con passphrase. Il tentativo
di aggiungere un involucro GnuPG è stato interrotto senza produrre output utilizzabile
perché pinentry non attraversava lo stack WSL; non sono state adottate scorciatoie con
passphrase in CLI, file o ambiente. Sono state invece create due copie byte-identiche dei
file privati già cifrati su supporti rimovibili distinti. Entrambe hanno superato il
manifest SHA-256
`c542a99d6b48b835f5fcd2ee08008b14c07380766d0d495a120556a06e1672d6`, sono state
espulse e vengono conservate fisicamente separate. Passphrase e supporti non sono
descritti nel repository.

## Limiti e passo successivo

La firma stabilisce autenticità dei due bundle rispetto alla nuova root of trust, non
approvazione per produzione, freschezza di un mirror o correttezza dell'upgrade reale.
La chiave operativa non ha ancora autorizzato alcun host: `R07` deve generare sul target
la request breve legata a candidate, predecessor, recovery set e machine identity,
verificarla offline e firmarla con la chiave upgrade.

Stato successivo: R07 ha completato quel flusso e consumato una authorization host-bound;
vedere `docs/UPGRADE_DRILL_R07_2026-10-13.md`. Questa nota non modifica l'esito storico
della cerimonia R06.

## Aggiornamento di custodia successivo alla cerimonia

Il verbale sopra descrive correttamente l'istante R06, ma dal 2026-10-13 le chiavi private
sono presenti anche sulla workstation WSL connessa per decisione esplicita del maintainer.
P-019 e `docs/USER_DECISIONS.md` registrano il rischio residuo e il rifiuto di rigenerarle.
Le firme successive provano il possesso della chiave accettata, non una custodia rimasta
esclusivamente air-gapped. Nessuna private è entrata nel repository o nel server di test.
