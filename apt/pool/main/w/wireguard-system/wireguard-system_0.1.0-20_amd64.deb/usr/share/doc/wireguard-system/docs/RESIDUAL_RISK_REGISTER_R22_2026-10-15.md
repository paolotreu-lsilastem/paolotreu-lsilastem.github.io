# Registro dei rischi residui R22

Data di baseline: 2026-10-15

Questo registro non è una certificazione di sicurezza. Distingue rischi accettati,
blocker di rilascio e limiti dichiarati; nessuna voce viene considerata risolta per il
solo fatto di essere documentata.

| ID | Rischio o limite | Severità/stato | Trattamento e gate |
|---|---|---|---|
| RR-001 / P-005 | Nessun audit indipendente del confine privilegiato e delle superfici web/API | Alto, accettato dal maintainer per la v1 | Dichiarare sempre la v1 non auditata; mantenere dossier R18 e pianificare audit post-v1 prioritario |
| RR-002 / P-019 | Le chiavi private SSHSIG release/upgrade hanno copie sul filesystem WSL di sviluppo | Alto, accettato dal maintainer | Directory ignorata e permessi stretti; non dichiarare custodia esclusivamente air-gapped; non copiare chiavi su server, repository o log |
| RR-003 / P-018 | La keyring APT client non è ancora distribuibile e ruotabile via APT | Release blocker per il canale stabile | R23 documenta il lifecycle; R24 deve costruire e collaudare package keyring, rinnovo e rotazione sovrapposta prima della pubblicazione stabile |
| RR-004 / P-006 | Nessun upgrade cross-schema è dimostrato perché tutti gli archi usano schema dati 1 | Limite v1 accettato | Non dichiarare compatibilità cross-schema; ogni schema futuro richiede un nuovo arco reale con rollback |
| RR-005 / P-007 | La “sicurezza assoluta” non è dimostrabile | Vincolo permanente di assurance | Comunicare threat model, controlli, test e rischi; vietate affermazioni assolute o di certificazione |
| RR-006 | Bootstrap `admin/admin` noto pubblicamente | Alto se l'operatore espone la UI prima del cambio; mitigato dal prodotto | Solo loopback, `must_change_password`, cambio obbligatorio e Caddy non esposto prima della sostituzione; R25 deve verificarlo di nuovo |
| RR-007 | Il package testing `0.1.0-17` non incorpora i delta R16–R22 | Gate aperto, non difetto retroattivo del package | Non usare in produzione; R23 congela il commit e R24 costruisce/firma `0.1.0-18` da quel commit esatto |
| RR-008 | Supporto package limitato a Debian 12 Bookworm `amd64` e Python 3.11 | Limite v1 dichiarato | Debian precedenti/successive e altre architetture restano fuori matrice finché non collaudate |
| RR-009 | Esposizione Internet, IPv6, HA e container sono fuori scope | Limite v1 dichiarato | Deploy soltanto intranet dietro Caddy e allowlist; ogni estensione richiede threat review e nuova acceptance |
| RR-010 | Database vulnerabilità e stato delle dipendenze cambiano nel tempo | Rischio operativo continuo | R24 rigenera audit/SBOM dal lock; dopo il rilascio ripetere periodicamente la scansione e aggiornare tramite nuova release verificata |

Alla chiusura R22 non risultano finding interni critici/alti **non accettati** aperti. I
rischi alti RR-001, RR-002 e quello condizionale RR-006 rimangono espliciti; RR-003
impedisce il canale APT stabile fino alla chiusura R24.
