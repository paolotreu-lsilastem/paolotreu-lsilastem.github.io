# Roadmap eseguibile

## Baseline di chiusura v1 — 2026-10-09

Questa sezione e le unità `R01`–`R25` sono il denominatore stabile del lavoro residuo.
Sostituiscono le precedenti stime percentuali progressive, che aggregavano task di
dimensione diversa e non erano quindi attendibili.

Legenda: `[x]` concluso, `[ ]` TODO. Un'unità residua è conclusa soltanto quando sono
presenti risultato, verifiche, documentazione ed eventuali evidenze richieste e il tutto è
committato. Un "passaggio Codex" è una sessione focalizzata su una sola unità, conclusa
con il relativo commit; se l'unità si rivela troppo grande, ci si ferma e si revisiona
questa baseline prima di implementarne altre parti.

Regole di avanzamento:

- il piano residuo contiene **25 unità**, ognuna del peso fisso di **4 punti percentuali**;
- una percentuale diminuisce solo alla chiusura di un'unità, mai per lavoro parziale;
- i task completati di M0–M4.2 sono congelati e non si riaprono senza una regressione
  riproducibile registrata nella sezione problemi;
- bug, blocchi e limiti nuovi vengono prima aggiunti al registro in fondo a questo file,
  marcati con `⚠`, severità, impatto e unità di risoluzione; non generano lavoro implicito;
- un nuovo requisito modifica il denominatore soltanto con una revisione datata della
  baseline che spiega cosa è entrato, cosa è uscito e perché;
- fino alla chiusura di `R25` non si aggiungono feature v1 estranee alla specifica. IPv6,
  container, cancellazioni fisiche via API, esposizione Internet dell'API e alta
  disponibilità restano fuori scope;
- non avviare due unità che modificano lo stesso formato dati o la stessa identità di
  release.

### Stima stabile

| Traguardo | Stato al 2026-10-15 | Lavoro residuo | Stima |
|---|---|---:|---:|
| Prototipo funzionale da sorgente | Raggiunto: M0–M3 e core M4 sono implementati e testati | 0 unità | 0 passaggi |
| Laboratorio Debian nuovamente utilizzabile | Raggiunto: baseline e drill incidenti reali verdi | 0 unità | 0 passaggi |
| Candidate tecnico con upgrade e recovery collaudati | Raggiunto: M4.4 e R12 chiusi | 0 unità | 0 passaggi |
| Versione v1 completa e candidata al rilascio | Richiede `R25`; P-054 ha respinto `0.1.0-18` | **1 unità, 4% del piano di chiusura** | **2 passaggi Codex e 1 firma offline del maintainer** |

Avanzamento corrente: **24/25 unità chiuse; 1/25 residua (4%)**.

Le percentuali indicano esclusivamente il piano di chiusura residuo, non una pretesa di
misurare tutto il codice già scritto. Dopo ogni unità chiusa verranno riportati il numero
intero di unità mancanti e la percentuale residua in multipli di 4%. R19 è stato chiuso
con waiver esplicito, non con un audit: la stima assume che le verifiche compensative
interne rientrino nelle due unità di riserva `R20` e `R21`.

### Ordine vincolante

L'ordine di esecuzione è `R01` → `R25`. Non si sceglie più il TODO tecnicamente più
interessante: si esegue il primo ID aperto. Sono ammesse deviazioni soltanto per un blocco
esterno documentato o per un problema release-blocker aggiunto al registro. In entrambi i
casi la deviazione viene registrata qui prima di scrivere codice.

## M0 — Fondazioni (conclusa)

- [x] M0.1 Specifica funzionale, ruoli, lifecycle e criteri di accettazione.
- [x] M0.2 Architettura, modello dati, threat model e handoff AI.
- [x] M0.3 Packaging Python, requirements, bootstrap, app factory e doctor.
- [x] M0.4 Primitive JSON atomiche con lock e test unitari.
- [x] M0.5 Review umana delle decisioni iniziali e registrazione degli esiti.

Gate: `scripts/check.sh` verde; bootstrap ripetibile; nessuna mutazione WireGuard.

## M1 — Dominio, repository e autenticazione

- [x] M1.1 Schemi completi/versionati per user, tenant, network, client, job e audit.
- [x] M1.2 Repository CRUD, revision conflict, indici ricostruibili e migrazioni.
- [x] M1.3 Entità/validatori: IPv4 RFC1918 `/16`–`/30`, overlap, allocazione porte
  `51820–51999/UDP`, interfacce e lifecycle.
- [x] M1.4 Login/logout/cambio password forzato, sessioni, CSRF e rate limit.
- [x] M1.5 Policy RBAC centralizzata con matrice di test cross-tenant.
- [x] M1.6 Audit append-only redatto, rotazione giornaliera, retention 30 giorni,
  archivio nativo compresso ed eliminazione al compimento di 3 mesi.

Gate: coverage di branch >= 85% su domain/security/repository; security negative tests.

## M2 — Engine WireGuard sicuro

- [x] M2.1 Probe read-only di `wg`, `ip`, kernel module, forwarding, systemd e nftables;
  parser dell'output macchina con endpoint, handshake e contatori per peer; verifica
  collisioni porta anche sugli IP risultanti dalla risoluzione degli endpoint.
- [x] M2.2 Gestione cifrata delle chiavi, download successivi autorizzati e rotazione.
- [x] M2.3 Compiler deterministico server/client e golden tests.
- [x] M2.4 Helper privilegiato con protocollo ristretto e hardening systemd.
- [x] M2.5 Start/stop/sync/reconcile, rollback e job persistenti.
  - [x] Lifecycle job file-backed, idempotenza, RBAC, audit e recovery post-crash.
  - [x] Protocollo helper mutante tipizzato e registry root-owned.
  - [x] Apply/start/stop/sync con snapshot e rollback.
  - [x] Worker job-to-helper con rivalidazione RBAC, compiler e chiavi in memoria.
  - [x] Reconcile one-shot di sistema, recovery job/interfacce e mutua esclusione worker.
  - [x] Servizio reconciler systemd con polling/backoff e rilevamento drift fail-closed.
  - [x] Test end-to-end hub/client con handshake, traffico e recovery verificati.
- [x] M2.6 Firewall isolato, VRF per overlap cross-tenant e integration test.
  - [x] Piano puro VRF/nftables, allocazione deterministica e ADR di sicurezza.
  - [x] Registry v2 con identità VRF persistente e migrazione fail-closed.
  - [x] Apply/verify/stop/rollback atomici di WireGuard, VRF e nftables.
    - [x] Primitive host a argv fisso e verifica semantica VRF/nftables fail-closed.
    - [x] Transazione executor multi-risorsa e rollback per ogni failure point.
  - [x] Integrazione worker/reconciler e abilitazione overlap cross-tenant verificata.
    - [x] Probe registry/VRF/nftables, rilevamento drift reconciler ed errori worker.
    - [x] Capability versionata, validazione overlap e test negativo reale con CIDR uguali.
  - [x] Test multi-client, isolamento LAN/Internet e CIDR sovrapposti sul target Debian.

Gate: nessuna shell interpolation; test isolamento/revoca/rollback; threat review.

## M3 — API pubblica e UI gestionale

- [x] M3.0 Chiudere le decisioni su autenticazione, download sensibili, esposizione di
  rete e operazioni distruttive dell'API v1.
- [x] M3.1 Aggiornare il threat model e definire prima del codice il contratto OpenAPI
  3.1, inclusi versioning, errori e paginazione.
- [x] M3.2 Implementare identità macchina e credenziali file-backed con generazione
  sicura, hash, scadenza, rotazione e revoca; autenticazione e rate limit per token+IP.
- [x] M3.3 Esporre API read-only scoped per tenant, utenti, reti, client, job e
  telemetria, con paginazione e test negativi RBAC/IDOR cross-tenant.
  - [x] Autenticazione Bearer, Problem Details, request ID, proiezioni redatte e letture
    paginate per tenant, utenti, reti, client, job e service account.
  - [x] Cursori cifrati/scoped, query chiuse, rate limit, ETag, audit delle negazioni e
    test negativi RBAC/IDOR.
  - [x] Snapshot telemetrico scoped con correlazione peer-client, presenza stimata e
    semantica fail-closed `unknown` quando il runtime non è affidabile.
- [x] M3.4 Esporre le mutazioni CRUD consentite con schemi chiusi, audit,
  `ETag`/`If-Match` e `Idempotency-Key` persistente.
  - [x] Primitive idempotency crash-safe, parsing JSON rigoroso, precondizioni HTTP e
    create/update tenant superadmin-only.
  - [x] Create/update/disable di utenti e assegnazioni con protezioni multi-tenant e
    ultimo superadmin.
  - [x] Lifecycle API dei service account e risposta one-time protetta.
    - [x] Confermare la policy di retry delle risposte che contengono un token one-time;
      il registro decisioni raccomanda `409 CREDENTIAL_RECOVERY_REQUIRED` senza
      persistenza reversibile del secret.
    - [x] Esporre create/rotate/revoke dopo la decisione, mantenendo hash-only,
      optimistic concurrency, audit e recovery crash-safe.
  - [x] Create/update/archive di reti e lifecycle dei client, senza effetti host live.
    - [x] Create/update/archive delle reti con chiavi cifrate, allocazione porte,
      validazione conflitti/overlap, RBAC, ETag e idempotenza.
    - [x] Create/update/activate/disable/revoke/archive dei client e reservation IP.
  - [x] Retention completati a 24 ore, pending segnalati senza cancellazione automatica,
    quota configurabile per identità e riserva minima disco.
- [x] M3.5 Collegare le azioni live alla coda mediante `202 Accepted` e `Location` del
  job; aggiungere quote, backpressure e test di retry/recovery.
  - [x] Esporre start/stop/sync/reconcile rete con commit crash-safe dello stato
    desiderato, job persistente e rivalidazione di service account e credenziale.
  - [x] Collegare le mutazioni client live a job di sync/reconcile senza finestre di
    apply implicito.
  - [x] Applicare quote e backpressure per identità/tenant/rete, con errori e retry
    documentati.
- [x] M3.6 Implementare il download API delle configurazioni client con
  `client.config:read` negato per default, credenziale a vita breve, autorizzazione
  fresca, audit e `no-store`; vietare chiavi server ed export massivi.
- [x] M3.7 Pubblicare esempi e specifica OpenAPI, con test di conformità e compatibilità
  del contratto per ogni modifica.
- [x] M3.8 Design system accessibile, layout, error handling e navigazione scoped.
- [x] M3.9 CRUD tenant e utenti/assegnazioni.
  - [x] Elenco, dettaglio, creazione e modifica tenant HTML con RBAC, CSRF, audit,
    lifecycle e optimistic concurrency.
  - [x] Elenco, dettaglio, creazione e modifica utenti/assegnazioni multi-tenant HTML,
    con preservazione degli scope esterni, password iniziale non riproposta e blocco
    delle modifiche al proprio account.
- [x] M3.10 CRUD reti con preview indirizzamento e conflitti.
  - [x] Elenco e dettaglio scoped; creazione con anteprima read-only di CIDR, capacità,
    endpoint, porta automatica/manuale e conflitti, seguita da rivalidazione sotto lock.
  - [x] Modifica e archiviazione con optimistic concurrency, conferma esplicita e
    vincoli runtime; CIDR e hub restano immutabili nella v1.
- [x] M3.11 Lifecycle client e download configurazione protetto.
  - [x] Inventario scoped per rete, dettaglio redatto, create con IP stabile
    automatico/manuale e modifica revisionata dei soli metadati.
  - [x] Azioni activate/disable/revoke/archive/release-ip con job live, conferme e pagina
    scoped per monitorarne l’esito.
  - [x] Download della configurazione completa con riautenticazione, audit e `no-store`.
- [x] M3.12 Dialogo job live con errori azionabili e prevenzione doppio submit.
- [x] M3.13 Dashboard auto-refresh con IP VPN, endpoint osservato, traffico, ultimo
  handshake, stato di presenza e “online dal” esplicitamente stimati; keepalive client
  di 25 secondi e soglia online globale configurabile con default di 180 secondi.
  - [x] Inventario scoped e pannello della rete selezionata con fallback server-rendered,
    snapshot session-based, auto-refresh, pausa a pagina nascosta e backoff; un solo probe
    privilegiato per ciclo e nessun segreto nelle proiezioni.
  - [x] Stato runtime aggregato delle reti, aggiornamento dei conteggi senza reload e gate
    E2E/accessibilità del flusso dashboard completo.

Gate: E2E per ogni ruolo e identità macchina; contratto OpenAPI verificato; test di
scadenza/revoca credenziali, RBAC/IDOR, rate limit, idempotenza e Caddy HTTPS; test CSRF e
WCAG per la UI; nessun segreto in URL, log, audit o response cache.

## M4 — Operazioni e release 1.0

- [x] M4.1 Pacchetto Debian, unità systemd e configurazione Caddy; container fuori scope
  per la versione 1.
  - [x] Dipendenza e app factory Gunicorn verificate; unità web socket-activated non
    privilegiata, socket Unix `0660` condiviso solo con Caddy e hardening systemd.
  - [x] Trust degli header proxy opt-in per il solo peer Unix, ambiente production di
    riferimento e Caddy HTTPS con allowlist CIDR amministrativa e header sovrascritti.
  - [x] Costruire il pacchetto Debian con payload Python privato hash-locked, launcher
    shell-free, maintainer script, utente/directory e segreti generati una sola volta e
    preservati ad upgrade, remove e purge; build amd64 verificata byte-per-byte.
  - [x] Collaudare installazione/upgrade/rimozione puliti e flusso HTTPS Caddy reale su
    Debian nativo, inclusi permessi socket, bootstrap e accesso negato fuori allowlist.
- [x] M4.2 Backup/restore/migrazione e disaster recovery drill.
  - [x] Definire recovery set separato data/secrets, manifest v1, stato incluso/escluso,
    threat model, consistenza offline e primitive di inventario fail-closed.
  - [x] Confermare e integrare `age`/X25519 per cifratura autenticata streaming, senza
    plaintext su disco e senza identity privata sul server.
  - [x] Implementare create/verify con quiesce, validazione schema/audit/keyring e output
    crash-safe esterno al data tree.
    - [x] Inventariare environment/keyring con policy separate e costruire tar+gzip
      normalizzato direttamente nello stream `age`, rileggendo ogni fonte con
      `O_NOFOLLOW` e verificandone hash e stabilità.
    - [x] Esporre `backup-create` con quiesce systemd, validazione di documenti, audit,
      keyring/envelope e recovery set completo, ripristinando soltanto le unità prima attive.
    - [x] Aggiungere verify offline con identity esplicita, limiti e correlazione obbligatoria
      della coppia di bundle.
  - [x] Implementare preflight e restore atomico con rollback, limiti di estrazione,
    ricostruzione indici e reti ferme.
    - [x] Introdurre workspace sibling privato, target live immutato, staging file
      `O_EXCL`/`O_NOFOLLOW`, verifica size/hash e cleanup confinato automatico.
    - [x] Collegare la decifratura dei due bundle allo staging e completare il preflight
      semantico offline con cleanup automatico e target live immutato.
    - [x] Implementare la transazione del data tree con exchange atomico Linux, consenso
      esplicito alla sostituzione, rollback automatico e cleanup confinato post-commit.
    - [x] Aggiungere journal crash-safe con fasi monotone e identità device/inode, recovery
      deterministico di commit/rollback e blocco di nuove transazioni incomplete.
    - [x] Preparare lo staging in modo idempotente: interrompere job pendenti, forzare le
      reti a `stopped`, aggiornare audit/meta, ricostruire indici e rimuovere i lock.
    - [x] Coordinare pubblicazione dei secrets, stop host e controlli finali, mantenendo
      le reti ferme fino all’autorizzazione esplicita dell’operatore.
      - [x] Materializzare environment e keyring come candidati sibling sui filesystem di
        destinazione, preservando metadata host e senza modificare i file live.
      - [x] Estendere journal e recovery a exchange/rollback dei candidati secrets insieme
        al data tree, mantenendo compatibilità con journal v1 pendenti.
      - [x] Collegare internamente recovery pendente, quiesce, stop reti gestite,
        preparazione, promozione e verifiche post-promozione con rollback globale.
      - [x] Esporre il comando root-only `restore-apply` con conferma del set, consenso
        esplicito alla sostituzione, output redatto e test del contratto CLI.
  - [x] Collegare migrazioni forward-only al restore preservando il bundle originale.
  - [x] Eseguire disaster-recovery drill reale su host isolato e documentare RPO/RTO.

### Blocco A — laboratorio e lineage di release (M4.3/M4.4)

Già completati: endpoint liveness/readiness redatti, logging JSON allowlistato, namespace e
retention journald, health persistente del reconciler, timer systemd, runbook e matrice dei
codici. R01–R04 hanno inoltre ricostruito il laboratorio e chiuso il drill reale M4.3.

- [x] **R01 — Inventario forense read-only del laboratorio e piano di ripristino.**
  Stimare e registrare package/dpkg, unità, file residui, registry, interfacce, VRF,
  nftables, forwarding, dati e segreti di `vrt-debian1`, senza mutazioni. Produrre una
  procedura con target espliciti, rollback e confine dei dati da preservare. **Chiusura:**
  inventario redatto allegato alla documentazione del laboratorio e nessun elemento
  ignoto prima del cleanup. Dipendenze: nessuna. Stima: 1 passaggio.
- [x] **R02 — Correggere la lineage e produrre il nuovo predecessor.** Dichiarare
  `0.1.0-9` storico/non pubblicabile, assegnare al codice corrente una nuova revisione
  univoca proposta `0.1.0-10`, aggiornare matrice/metadati/test e costruire da commit
  pulito bundle, `.deb`, SBOM, audit e provenienza verificati. **Chiusura:** nessun package
  version identifica due sorgenti diverse e il bundle predecessor ha hash/evidenze
  complete. Dipendenze: `R01` soltanto per confermare l'architettura del target; nessuna
  mutazione remota. Stima: 1 passaggio.
- [x] **R03 — Ricostruire una baseline Debian nota.** Applicare soltanto il piano di
  `R01`, installare il predecessor prodotto da `R02`, verificare dpkg/systemd, health,
  audit, registry vuoto, assenza di risorse rete residue e hash dei dati preservati.
  **Chiusura:** checklist baseline interamente verde e rollback/cleanup verificati.
  Dipendenze: `R01`, `R02`. Stima: 1 passaggio.
- [x] **R04 — Eseguire il drill incidenti M4.3 reale.** Provare staleness reconciler,
  failure helper confinato, recupero, Unix/HTTPS, journald e cleanup secondo
  `INCIDENT_DRILL.md`. **Chiusura:** tutte le evidenze `Superato`, hash pre/post uguali,
  audit valido e M4.3 dichiarata chiusa. Dipendenze: `R03`. Stima: 1 passaggio.

### M4.4 — Supply chain, firma e upgrade

Già completati: audit dipendenze, SBOM CycloneDX, provenienza in-toto/SLSA, toolchain
hash-locked, bundle di release, SSHSIG/verifier, deploy APT fail-closed, preflight upgrade,
autorizzazione firmata, freeze dei writer e tutti gli executor di recovery descritti negli
ADR 0066–0088. Il candidate `0.1.0-9` resta evidenza storica non firmata e non rappresenta
il codice corrente: vedere `P-002` e `P-003`. `R02`, pur appartenendo a M4.4, è anticipata
nel blocco A perché serve a ricostruire la baseline del laboratorio.

- [x] **R05 — Produrre il candidate consecutivo.** Incrementare alla revisione proposta
  `0.1.0-13`, dichiarare esclusivamente `0.1.0-12` come predecessor, aggiornare i contratti
  incorporati e generare da commit pulito il secondo bundle verificato. **Chiusura:** due
  package consecutivi immutabili e byte-identificati, entrambi costruiti con il protocollo
  di recovery corrente. Dipendenze: `R02`, `R04`. Stima: 1 passaggio.
- [x] **R06 — Cerimonia offline e trust pubblico.** Con intervento dell'operatore,
  generare separatamente chiave release e chiave operativa upgrade, conservarne le private
  offline, verificare i fingerprint su due canali, pubblicare solo materiale pubblico e
  revoche, firmare i bundle di prova e collaudare verifier e rifiuti. **Chiusura:** firme
  reali valide, negative test reali e nessuna chiave privata nel repository, host o log.
  Dipendenze: `R05`; richiede operatore offline. Stima: 1 passaggio congiunto.
- [x] **R07 — Upgrade reale happy path.** Installare `0.1.0-12`, creare e verificare il
  recovery set, firmare l'autorizzazione, armare e aggiornare a `0.1.0-13`; registrare
  hash, receipt, unità ripristinate, health, audit e cleanup. **Chiusura:** esito verde
  ripetibile senza perdita o modifica inattesa dei dati. Dipendenze: `R03`, `R06`.
  Stima: 1 passaggio.
- [x] **R08 — Failure point prima e durante il consumo.** Collaudare rifiuti di firma,
  scadenza, artefatto/hash/host diversi, writer o rete attivi, spazio insufficiente,
  cancellazione dell'arming e crash attorno al marker monouso. **Chiusura:** ogni caso
  converge allo stato documentato senza unpack non autorizzato né writer lasciati in uno
  stato ambiguo. Dipendenze: `R07`. Stima: 1 passaggio.
- [x] **R09 — Recovery di configurazione e reinstallazione.** Indurre e recuperare stati
  `unpacked`, `half-configured` e installazione candidate interrotta prima/dopo il
  consumo, inclusi retry e handoff dei lock dpkg. Il drill reale ha confermato che dpkg
  conserva il predecessor `half-installed` fino al completamento dell'estrazione e passa
  poi al candidate `unpacked`: il ramo candidate `half-installed` resta difensivo e non
  viene dichiarato attivato live. **Chiusura:** classificazione, intent, receipt, resume
  unità e idempotenza corrispondono agli stati realmente osservabili; nessun dpkg reale
  ha ricevuto `--force-*`. Evidenze:
  `docs/UPGRADE_RECOVERY_DRILL_R09_2026-10-14.md`. Dipendenze: `R08`.
  Stima: 1 passaggio.
- [x] **R10 — Recovery dei trigger.** Provare `triggers-pending` e `triggers-awaited`,
  chiusura esatta del grafo, retry dopo interruzione e rifiuto in presenza di package
  estranei. **Chiusura:** dpkg torna coerente solo per il closure autorizzato e tutte le
  intenzioni/ricevute sono verificabili. Evidenze:
  `docs/UPGRADE_TRIGGER_DRILL_R10_2026-10-14.md`. Dipendenze: `R09`.
  Stima: 1 passaggio.
- [x] **R11 — Rollback attestato con restore.** Forzare il percorso di rollback al
  predecessor, reinstallarlo dall'artefatto pinned, ripristinare il recovery set attestato
  e riprendere esclusivamente i writer originali. **Chiusura:** dati e segreti coincidono
  con gli hash autorizzati, candidate assente, predecessor sano e cleanup completo.
  La remediation è installata e sana in `0.1.0-15`; il primo arco è terminato
  correttamente e non poteva quindi esercitare un rollback post-finalizzazione. La
  revisione `0.1.0-16` ha completato fault, rollback, restore e migrazione, esponendo
  P-026 nel controllo terminale. `0.1.0-17` firmato ha corretto il classificatore sullo
  storico reale: recovery status, health timer, hash, writer, HTTPS e retry no-op sono
  verdi senza alterare intent o receipt. Evidenze:
  `docs/UPGRADE_ROLLBACK_DRILL_R11_2026-10-14.md`. Dipendenze: `R10`.
  Stima: 1 passaggio.
- [x] **R12 — Consolidare le evidenze e chiudere M4.4.** Allineare verbali, matrice,
  runbook, handoff e changelog; dichiarare esplicitamente che l'arco v1 collaudato usa
  schema 1 e quindi verifica una migrazione no-op, non upgrade cross-schema. **Chiusura:**
  ogni gate M4.4 rinvia a un'evidenza reale e non rimangono TODO impliciti. Dipendenze:
  `R07`–`R11`. Evidenze: `docs/M4_4_CLOSURE.md`. Stima: 1 passaggio.

### M4.6 — Sicurezza operativa delle API pubbliche (conclusa)

- [x] **R13 — Drill compromissione e revoca credenziali API.** Creare un service account
  scoped, usare il token, simulare la compromissione, ruotare/revocare e verificare che
  vecchio token, job in coda e download sensibili siano negati uniformemente; controllare
  audit, rate limit e assenza di secret. **Chiusura:** verbale con casi positivi/negativi e
  cleanup. Dipendenze: `R04`. Evidenze: `docs/API_CREDENTIAL_COMPROMISE_DRILL.md` e
  `test_compromised_api_credential_rotation_and_revocation_drill`. Stima: 1 passaggio.
- [x] **R14 — Drill policy di esposizione Caddy.** Verificare HTTPS, allowlist delle reti
  amministrative, spoofing degli header, limiti request e configurazione mTLS opzionale;
  confermare che l'esposizione Internet resti vietata nella v1. **Chiusura:** test reale
  da origine ammessa e negata e configurazione/runbook coerenti. Dipendenze: `R04`.
  Evidenze: `docs/CADDY_EXPOSURE_DRILL_R14_2026-10-14.md`; P-029 trovato e risolto.
  Stima: 1 passaggio.
- [x] **R15 — Guida e drill di evoluzione del contratto API.** Formalizzare deprecazioni,
  compatibilità additiva, cambio major, finestra di migrazione client e rollback; provare
  il gate con una modifica additiva accettata e una breaking negata. **Chiusura:** guida
  pubblicata, esempi verificati e M4.6 chiusa. Dipendenze: `R13`, `R14`. Evidenze:
  `docs/API_EVOLUTION.md`, ADR 0097 e
  `docs/API_EVOLUTION_DRILL_R15_2026-10-14.md`. Stima: 1 passaggio.

### M4.5 — Documentazione e audit indipendente

- [x] **R16 — Manuale amministratore.** Coprire installazione, bootstrap, Caddy, tenant,
  RBAC, reti/client, chiavi, API, osservabilità, backup/restore, upgrade e incidenti con
  una procedura di collaudo dall'inizio alla fine. **Chiusura:** ogni comando e link
  verificato sul candidate tecnico. Dipendenze: `R12`, `R15`. Evidenze:
  `docs/ADMIN_GUIDE.md`, `docs/ADMIN_GUIDE_VERIFICATION_R16_2026-10-15.md`; P-030 trovato
  e risolto nel sorgente corrente. Stima: 1 passaggio.
- [x] **R17 — Manuale utente/operatore.** Coprire i tre ruoli, workflow UI, lifecycle,
  job asincroni, dashboard, download e messaggi d'errore senza richiedere conoscenza del
  codice. **Chiusura:** scenario completo superadmin/admin/manager rieseguito sul
  candidate tecnico. Dipendenze: `R16`. Evidenze: `docs/OPERATOR_GUIDE.md`,
  `docs/OPERATOR_GUIDE_VERIFICATION_R17_2026-10-15.md`; P-031 trovato e risolto nel
  sorgente corrente. Stima: 1 passaggio.
- [x] **R18 — Freeze sorgente finale, pacchetto di audit e review interna.** Riservare una
  revisione finale ancora inutilizzata senza costruirla, fissare commit e threat model,
  preparare inventario di codice/ADR/evidenze, superficie privilegiata, crypto, API,
  storage, supply chain e limiti; rieseguire gate e mappare ogni controllo a una prova.
  **Chiusura:** dossier riproducibile e commit final-candidate consegnabili a un revisore
  senza briefing orale. Dipendenze: `R17`. Evidenze:
  `docs/SECURITY_AUDIT_PACKAGE.md`, `docs/SECURITY_AUDIT_CONTROL_MATRIX.md` e
  `docs/SECURITY_AUDIT_FREEZE_R18_2026-10-15.md`; target
  `d09bce0741b6d458385d7e84dde5767642620f04`. P-028 e P-032–P-034 risolti; la revisione
  `0.1.0-18` è soltanto riservata. Stima: 1 passaggio.
- [x] **R19 — Audit di sicurezza indipendente, chiuso con waiver.** Il piano richiedeva
  che un revisore esterno valutasse almeno
  autenticazione/RBAC/IDOR, confine root helper, comandi host, file storage, chiavi,
  backup/restore, upgrade, Caddy/systemd e API; Codex importa e classifica il report senza
  reinterpretarlo. **Eccezione 2026-10-15:** nessun audit è stato eseguito; per vincoli
  di risorse e consegna il maintainer accetta P-005 e vieta di descrivere la v1 come
  auditata. Evidenze: `docs/SECURITY_AUDIT_WAIVER_R19_2026-10-15.md`, ADR 0099 e registro
  decisioni. Dipendenze: `R18`. L'audit resta debito post-v1 prioritario.
- [x] **R20 — Riserva remediation 1.** Risolvere finding critici/alti relativi a
  autenticazione, sessioni, RBAC, API e gestione dei segreti, oppure, se assenti,
  rieseguire e documentare i relativi test avversariali. **Chiusura:** finding chiusi o
  rischio residuo esplicitamente rifiutato dal gate. Dipendenze: `R19`. Evidenza:
  `docs/SECURITY_REMEDIATION_R20_2026-10-15.md`; P-035 trovato e risolto, 257 test
  avversariali verdi e nessun finding interno critico/alto noto residuo nello scope.
  Stima: 1 passaggio.
- [x] **R21 — Riserva remediation 2.** Risolvere finding critici/alti relativi a helper,
  WireGuard/VRF/nftables, storage, backup/restore, package e supply chain, oppure, se
  assenti, rieseguire e documentare i test avversariali. **Chiusura:** finding chiusi o
  rischio residuo esplicitamente rifiutato dal gate. Dipendenze: `R20`. Evidenza:
  `docs/SECURITY_REMEDIATION_R21_2026-10-15.md`; 463 test avversariali verdi, scansione
  aggiornata pulita di 24 dipendenze e nessun finding interno critico/alto noto nello
  scope. Stima: 1 passaggio.
- [x] **R22 — Regressione post-audit e rischi residui.** Eseguire suite completa e smoke
  privilegiati interessati, verificare che nessun fix allarghi scope o privilegi e
  pubblicare il registro dei rischi residui senza affermazioni di sicurezza assoluta.
  **Chiusura:** gate verde e nessun finding critico/alto aperto. Dipendenze: `R20`, `R21`.
  Evidenze: `docs/SECURITY_REGRESSION_R22_2026-10-15.md` e
  `docs/RESIDUAL_RISK_REGISTER_R22_2026-10-15.md`; nessun finding interno critico/alto
  non accettato resta aperto. Stima: 1 passaggio.
- [x] **R23 — Chiusura documentale M4.5.** Ottenere dal revisore la chiusura o review del
  delta delle remediation quando esiste un audit; con il waiver R19, attestare invece i
  controlli interni e dichiarare il rischio P-005. Allineare README, installazione,
  specifica, sicurezza,
  handoff, changelog e manuali; rimuovere affermazioni o istruzioni obsolete. **Chiusura:**
  audit, codice e documentazione identificano lo stesso commit final-candidate e la stessa
  matrice supportata. Dipendenze: `R22`. Evidenza:
  `docs/M4_5_CLOSURE_R23_2026-10-15.md`; freeze identificato dal tag annotato
  `v0.1.0-18-rc1-freeze`, P-039/P-040 risolti e P-005 dichiarato. Stima: 1 passaggio.

### M4.7 — Candidate finale e accettazione v1

- [x] **R24 — Build e firma del candidate finale congelato.** Senza modificare il commit
  approvato in `R23`, costruire da tree pulito la revisione già riservata, verificare
  SBOM/audit/provenienza e firmare offline bundle e repository APT di prova; collaudare
  anche distribuzione, rinnovo e rotazione sovrapposta della keyring client. **Chiusura:**
  artefatti immutabili riconducibili esattamente al commit auditato, trust APT aggiornabile
  prima della scadenza e verifica indipendente interamente verde. Dipendenze: `R23`;
  richiede operatore offline. Evidenza:
  `docs/FINAL_CANDIDATE_R24_2026-10-15.md`; bundle `0.1.0-18` firmato, verifica
  indipendente e drill APT/keyring A→A+B→B verdi. Stima: 1 passaggio.
- [ ] **R25 — Acceptance finale e go/no-go.** Su Debian pulito eseguire installazione,
  bootstrap, Caddy, UI per i tre ruoli, API, rete multi-client, isolamento, dashboard,
  backup/restore, upgrade dall'arco dichiarato, revoca, remove/reinstall e cleanup;
  rieseguire il quality gate locale. **Chiusura:** verbale unico con tutti i criteri verdi,
  nessun problema release-blocker aperto e decisione `GO`; solo allora la v1 è pronta al
  rilascio. Dipendenze: `R24`. Stima: 1 passaggio.
  - [x] Upgrade firmato `0.1.0-17 → 0.1.0-18`, bootstrap, UI per i tre ruoli, API,
    Caddy HTTPS, rete multi-client sovrapposta, isolamento, telemetria/dashboard,
    revoca live, backup/preflight/restore isolato e cleanup verificati.
  - [x] Costruire, firmare e provare `0.1.0-19`: upgrade reale `0.1.0-17 →
    0.1.0-19` riuscito e P-055 verificato (`292 → 0` bytecode), ma il retry
    remove/reinstall ha confermato che P-054 resta aperto prima dell'unpack.
  - [x] Diagnosticare gli argomenti dpkg effettivi: `preinst install 0.1.0-19
    0.1.0-19`, forma riservata da `deb-preinst(5)` a un package rimosso; il query stato
    di `0.1.0-19` era tardivo e non affidabile.
  - [ ] Costruire `0.1.0-20` con la correzione basata sul contratto argomenti, firmarlo
    e ripetere upgrade/remove/reinstall.
  - [ ] Rieseguire quality gate, produrre il verbale unico e decidere `GO` soltanto con
    P-054 chiuso e laboratorio pulito.

Gate finale: installazione e upgrade reali testati; restore verificato; firme e
provenienza verificate; waiver dell'audit indipendente dichiarato in ogni documento di
release; nessun finding critico/alto interno noto o problema release-blocker aperto;
documentazione coincidente con gli artefatti.

## Registro problemi, blocchi e limiti

Questa tabella è grow-only per gli elementi scoperti durante la chiusura. Un problema
risolto cambia stato ma non viene eliminato. Le unità di remediation già pianificate non
cambiano il denominatore; un problema che richiede nuove unità obbliga a revisionare
esplicitamente la baseline.

| ID | Evidenza e impatto | Severità | Stato | Unità di risoluzione |
|---|---|---|---|---|
| **⚠ P-001 — laboratorio Debian senza baseline nota** | L'inventario autoritativo del 2026-10-12 trova `wireguard-system 0.1.0-5` installato e integro, servizi principali attivi, due vecchie istanze helper fallite e systemd `degraded`; dati/configurazione sono coerenti e non esistono risorse WireGuard/VRF/nftables gestite. | **Release blocker** | Risolto in R03: `0.1.0-12` installato, systemd `running`, health/audit/hash/rete verificati e failure storiche resettate | `R03` |
| **⚠ P-002 — identità package `0.1.0-9` non più corrispondente a HEAD** | Il bundle documentato deriva dal commit `10272fa`, mentre il codice corrente contiene 26 commit successivi e `packaging/debian/revision` vale ancora `9`. Ricostruire oggi lo stesso numero assocerebbe sorgenti diverse alla stessa versione. | **Release blocker** | Risolto in `R02`: `0.1.0-9` è storico; `0.1.0-10` identifica univocamente il commit `6dab5a8` e ha bundle verificato | `R02` |
| **⚠ P-003 — predecessor storico privo del recovery completo corrente** | Il `0.1.0-9` documentato precede gli executor e handshake ADR 0066–0088; non può provare in modo credibile tutti i rollback del codice corrente. Servono due nuovi package consecutivi costruiti dopo tali modifiche. | **Release blocker** | Risolto in R05: la lineage tecnica è stata ricostruita; R07–R11 hanno poi completato happy path, failure, recovery e rollback/restore reali su revisioni consecutive | `R02`, `R03`, `R05` |
| **⚠ P-004 — materiale di firma reale assente** | Procedure e verifier esistono, ma non risultano eseguite la cerimonia SSHSIG release né la separata cerimonia della chiave operativa upgrade. Le chiavi private non devono mai entrare nel repository o nel server. | **Blocco esterno per M4.4/finale risolto** | Risolto: R06 ha separato trust release/upgrade e R24 ha acquisito e verificato la firma offline del bundle finale `0.1.0-18` | `R06`, `R24` |
| **⚠ P-005 — audit indipendente non eseguito** | Suite e review interne non sostituiscono una valutazione esterna del confine privilegiato e delle superfici web/API. | **Rischio residuo alto accettato per la v1** | Waiver esplicito del maintainer in R19 per indisponibilità di risorse e scadenza ravvicinata; la v1 deve essere dichiarata non auditata, R20–R22 applicano controlli compensativi interni e l'audit resta debito post-v1 prioritario | `R19`–`R23`, post-v1 |
| **⚠ P-006 — nessun arco cross-schema collaudabile nella v1 iniziale** | Predecessor e candidate usano schema dati 1. Il drill può dimostrare preservazione e migrazione no-op, non una futura migrazione a schema 2. Dichiarare supporto cross-schema sarebbe falso. | **Limite noto, non blocker v1** | Accettato per il primo rilascio; ogni futuro schema richiederà un nuovo arco | `R12`, roadmap post-v1 |
| **⚠ P-007 — “sicurezza assoluta” non verificabile** | Nessun sistema può fornire garanzia assoluta. La release deve invece dimostrare threat model, least privilege, fail-closed, test avversariali, audit indipendente e rischi residui espliciti. | **Vincolo di assurance** | Aperto fino al gate finale | `R18`–`R25` |
| **⚠ P-008 — documentazione di stato ancora centrata su `0.1.0-9`** | README, handoff e verbale candidate descrivono `0.1.0-9` come corrente. Aggiornarli prima di risolvere la lineage confonderebbe evidenza storica e nuovo package. | **Coerenza documentale** | Stato corrente risolto in `R02`; riallineamenti finali restano nei gate R12/R23 | `R02`, `R12`, `R23` |
| **⚠ P-009 — margine disco ridotto sul laboratorio** | Il filesystem unico è utilizzato all'88% e conserva 2,3 GiB liberi. I dati del portale sono piccoli e il gate upgrade dovrebbe rientrare, ma build, bundle o copie non confinate potrebbero consumare il margine. I 3,5 GiB sotto `/usr/local` sono estranei e non vanno ripuliti. | **Rischio operativo, non blocker corrente** | R08 conclusa con 2.427.551.744 byte liberi e senza cleanup estranei; ricontrollo obbligatorio per ogni drill successivo | `R07`, `R08` |
| **⚠ P-010 — test documentali rimasti legati alla roadmap sostituita** | Cinque test di upgrade e supply chain cercavano i vecchi micro-task rimossi dalla baseline eseguibile, pur essendo i relativi controlli incorporati nelle unità R02–R12 e R24. La suite falliva sulla forma del documento e non sul contratto applicativo. | **Regressione test, non prodotto** | Risolto: i test verificano ora i gate stabili R02–R12 e R24 | `R02` |
| **⚠ P-011 — recipient recovery assente dalla baseline del laboratorio** | Il primo `backup-create` di R03 è fallito chiuso e ha ripristinato tutti i servizi: l'environment `0.1.0-5` non contiene `WG_PORTAL_BACKUP_RECIPIENT` e l'identity effimera del drill precedente era stata eliminata. Senza un recipient corrente non è possibile produrre un recovery set verificabile. | **Blocco operativo R03** | Risolto in R03: aggiunto atomicamente il solo recipient pubblico e fissato il nuovo hash environment; recovery set verificato, identity confinata alla WSL | `R03` |
| **⚠ P-012 — clean install negata dopo remove senza purge** | Sul laboratorio dpkg ha invocato `preinst install 0.1.0-5 0.1.0-10` dallo stato `config-files`; il guard `none` ha negato prima dell'unpack. Il rollback hash-verificato a `0.1.0-5` ha ripristinato dpkg e unità senza variazioni di dati, keyring, registry, Caddy o rete. | **Release blocker R03** | Risolto e verificato sul laboratorio da `0.1.0-11`: con sentinel `none`, `install OLD NEW` è ammesso e il postinst segue il percorso fresh; il candidate è stato poi rifiutato per l'indipendente P-013 | `R03`, `R05` |
| **⚠ P-013 — payload Python non attraversabile dal service user** | `0.1.0-11` ha superato il nuovo preinst ed è stato unpacked, ma il postinst come `wg-portal` ha ricevuto `PermissionError`: l'`umask 077` della pipeline è propagato alle directory create da pip. Il primo downgrade ha ereditato i mode; remove senza purge più reinstall pulita di `0.1.0-5` ha ripristinato dpkg, servizi e tutti gli hash. | **Release blocker R03** | Risolto e verificato in R03: `0.1.0-12` ha payload conforme, postinst riuscito e processi non privilegiati sani; futuro arco `0.1.0-12 → 0.1.0-13` | `R03`, `R05` |
| **⚠ P-014 — falsi negativi dell'harness R03** | Due tentativi validi hanno attivato rollback perché l'harness cancellava il PATH davanti a `doctor` e interpretava il bullet `●` di `systemctl --failed` come nome unità. Entrambi i rollback hanno preservato hash e rete; i controlli documentati e la diagnostica separata hanno escluso difetti del candidate. | **Problema operativo, non prodotto** | Risolto in R03: usare l'invocazione doctor documentata e `systemctl --failed --plain`; tentativo etichettato finale interamente verde | `R03` |
| **⚠ P-015 — override helper inefficace con `Environment=`** | Il primo tentativo R04 ha aggiunto `Environment=WG_PORTAL_HELPER_SOCKET=...`, ma il valore dello stesso nome letto da `EnvironmentFile` ha prevalso: il reconciler ha usato il socket reale e prodotto un ciclo sano. Nessun guasto o mutazione dati/rete è avvenuto. | **Problema operativo, non prodotto** | Risolto in R04: il runbook azzera e ridefinisce temporaneamente `ExecStart` con `/usr/bin/env`, poi rimuove il drop-in runtime e verifica il ritorno al comando vendor | `R04` |
| **⚠ P-016 — verifier offline legato all'ABI Python del package** | La postazione Kali air-gapped usa Python 3.13 e non può importare l'estensione `rpds` CPython 3.11 inclusa nel package Debian 12. Il primo tentativo è fallito prima di leggere i bundle e nessuna request è stata firmata. | **Problema operativo R07** | Risolto in R07: runtime Python 3.11 separato e manifestato, preflight in user/mount namespace senza sudo e builder ripetibile network-free `build-offline-verifier-runtime.sh` | `R07` |
| **⚠ P-017 — chiave APT e pubblicazione Pages non ancora provisionate** | Il worktree GitHub Pages è collegato tramite `publish/` e l'export statico verificato è implementato, ma `0.1.0-13` non ha ancora superato il gate v1. Pubblicarlo come stabile confonderebbe candidate tecnico e release approvata. | **Blocco operativo per pubblicazione stabile, non per R09** | Risolto per testing: commit Pages `fdcea87`, firma, byte CDN e `apt update` HTTPS verificati. Il canale stabile resta correttamente subordinato ad audit/freeze/GO | `R24`, `R25` |
| **⚠ P-018 — keyring APT client non aggiornabile automaticamente** | La chiave APT scade il 2028-10-12 e può essere estesa mantenendo il fingerprint, ma i client testing installano oggi un file pubblico manuale. Senza un package/lifecycle della keyring, rinnovo o rotazione potrebbero non raggiungerli prima della scadenza e bloccare `apt update`. | **Release blocker per il canale stabile risolto** | R23 ha introdotto package separato, provenienza e deploy keyring-first; R24 ha verificato il package production e un lifecycle reale isolato A→A+B→B con `apt update` verde prima e dopo il cambio firma | `R23`, `R24` |
| **⚠ P-019 — chiavi SSHSIG copiate sul PC di sviluppo** | Le copie in `tmp/usb0`, `tmp/usb1` e `tmp/wg-keys.zip` risiedono sul filesystem WSL e non su mount USB. Nessun file è entrato in Git o nell'output, ma dal 2026-10-13 la custodia non è più esclusivamente air-gapped. | **Rischio residuo alto accettato dal maintainer** | Decisione chiusa: il maintainer rifiuta la rigenerazione e richiede di mantenere queste chiavi come trust release/upgrade. `tmp/` è ignorata e protetta; R23/R25 devono dichiarare il rischio senza affermazioni di custodia offline assoluta | `R23`, `R25` |
| **⚠ P-020 — executor trattiene il lock frontend durante dpkg** | R09 reale su `0.1.0-13` ha creato correttamente intent e stato `unpacked`, ma ogni retry è stato negato da dpkg perché `/var/lib/dpkg/lock-frontend` apparteneva al PID Python parent. I mock test codificavano erroneamente lo stesso comportamento. | **Release blocker R09** | Risolto in R09/ADR 0093: l'executor immutabile `0.1.0-14` ha ceduto i lock, il figlio dpkg ha raggiunto il postinst e solo il fault systemd successivo lo ha fermato | `R09` |
| **⚠ P-021 — finalizer confonde rollback conclusi con transazioni pendenti** | Dopo un rollback reale, il marker `consumed` resta correttamente come audit trail insieme a `predecessor-resumed`; il finalizer `0.1.0-13` ignorava soltanto `finalized`, vedeva più marker e bloccava il postinst successivo per ambiguità. | **Release blocker R09** | Risolto in R09/ADR 0094: il finalizer immutabile `0.1.0-14` ha validato lo storico terminale ed è avanzato fino al fault systemd deliberato | `R09` |
| **⚠ P-022 — maintainer script confonde intent terminali con quello corrente** | Il `preinst` richiede una sola entry globale in `rollback-intent/` o `candidate-reinstall-intent/`; intent storici integri con receipt terminale rendono quindi ambiguo un nuovo handoff. R09 ha dovuto usare una vista bind confinata per il solo cleanup del laboratorio, senza cancellare lo storico. | **Risolto nel drill R11** | `0.1.0-16` ha migrato byte-identici quattro intent legacy, lasciato una sola transazione attiva durante dpkg e archiviato anche quella corrente dopo `predecessor-resumed`; nessuna bind view o cancellazione | `R11` |
| **⚠ P-023 — candidate `half-installed` non osservabile nei fault dpkg provati** | Fallimento di entrambi i `postrm`, arresto al primo evento status-fd e arresto dopo `armed → consumed` hanno lasciato `0.1.0-13` `unpacked`/`half-installed`; dopo estrazione completa dpkg espone `0.1.0-14 unpacked`. Forzare manualmente la versione candidate avrebbe prodotto evidenza artificiale. | **Correzione del modello di test, non prodotto** | Risolto in R09: documentati gli stati reali, verificati configuration repair e reinstallazione attestata del predecessor; il ramo candidate reinstall resta difensivo, coperto da test ma non rivendicato come attivato live | `R09` |
| **⚠ P-024 — overlay R10 sottodimensionato rispetto al gate di spazio** | Il primo run aveva tmpfs da 1.536 MiB, insufficiente alla somma fail-closed di headroom root, espansione package e headroom dati; il preflight si è fermato prima dell'arming e non ha consumato la request. | **Problema operativo, non prodotto** | Risolto in R10 portando il tmpfs effimero a 3.072 MiB dopo aver verificato circa 14 GiB disponibili; entrambi gli scenari successivi sono verdi e l'host è invariato | `R10` |
| **⚠ P-025 — primo arco R11 finalizzato prima del rollback** | L'upgrade reale `0.1.0-14 → 0.1.0-15` è terminato sano e ha creato `finalized`; il protocollo ha quindi rifiutato correttamente di trattarlo come recovery pendente. Rimuovere receipt o fabbricare intent avrebbe invalidato il drill. | **Problema operativo risolto in R11** | L'arco `0.1.0-15 → 0.1.0-16` ha usato un fault controllato dopo il consumo e prima della finalizzazione, quindi il rollback con restore è stato eseguito soltanto tramite l'executor | `R11` |
| **⚠ P-026 — recovery status ignora l'intent rollback archiviato dopo restore** | Dopo rollback e restore riusciti, `predecessor-resumed` archivia correttamente l'intent corrente; il classificatore continuava però a richiedere quello attivo per validare `rollback-restore-intent` e `rollback-restored`, producendo un falso stato ambiguo e il fallimento del health timer. | **Release blocker R11 risolto** | ADR 0096 e `0.1.0-17` riconoscono l'intent storico solo dopo la validazione terminale; il drill reale restituisce `no_pending_transaction`, timer verde e retry restore no-op preservando tutti gli hash | `R11` |
| **⚠ P-027 — retry APT non riconverge dopo firma interrotta** | Durante la pubblicazione testing di `0.1.0-17`, l'annullamento di pinentry ha lasciato il package registrato nel database privato `reprepro`, mentre gli indici pubblici firmati sono rimasti validi e fermi a `0.1.0-13`; il retry tentava erroneamente una seconda inclusione. | **Problema operativo di pubblicazione, sito pubblico mai corrotto** | Risolto nel tool e coperto da regressione: dopo un `includedeb` fallito, il retry accetta soltanto una singola entry DB che coincide esattamente con codename, componente, architettura, nome e versione attesi, quindi riesegue `reprepro export` e la verifica completa | Pubblicazione testing post-`R12` |
| **⚠ P-028 — dipendenza Python non delimita l'ABI del package** | `0.1.0-17` incorpora estensioni native `cpython-311` ma dichiara soltanto `python3 (>= 3.11)`: Debian 13 con Python 3.13 può quindi soddisfare le dipendenze e installare un payload che non è importabile. Debian 11 è già esclusa da Python, systemd, Caddy e age troppo vecchi. | **Release blocker per dichiarare correttamente la piattaforma v1 risolto** | Il package finale `0.1.0-18` costruito in R24 dichiara e verifica `python3 (>= 3.11), python3 (<< 3.12)`; la matrice v1 resta Debian 12 Bookworm `amd64` e l'installazione privilegiata finale è il gate R25 | `R18`, `R24` |
| **⚠ P-029 — body oversize trasformato in errore 500** | Nel drill R14 un POST da 1 MiB + 1 è stato rifiutato da Flask prima del normale hook di osservabilità; il logger rigoroso ha ricevuto un request ID nullo e ha trasformato il `413` in `500`. Il body non è stato elaborato, ma status e correlazione erano errati. | **Bug web di sicurezza, risolto in R14** | L'after-request genera un UUID anche per rifiuti pre-hook e il log usa sempre un ID valido; regressione verifica `413`, risposta redatta, header e log. Caddy ora applica anche `max_size 1MB` prima di Gunicorn. | `R14` |
| **⚠ P-030 — nessun bootstrap operativo della prima identità API** | Le route service-account richiedono già un bearer token superadmin e la voce UI `Accessi API` non punta ad alcuna vista: su una nuova installazione non esiste quindi un percorso autorizzato per creare la prima identità macchina senza intervenire direttamente sui file. | **Release blocker scoperto in R16** | Risolto nel sorgente corrente: la UI superadmin espone create/list/detail/rotate/revoke, il bootstrap globale è esplicitamente transitorio, i token sono one-time e `no-store`; test coprono RBAC, rotazione/revoca, limite sensibile e assenza del bearer dallo storage. Entrerà nel candidate finale, senza attribuzione retroattiva a `0.1.0-17`. | `R16` |
| **⚠ P-031 — lifecycle rete disponibile via API ma assente dalla UI** | Il servizio e le API consentono avvio, arresto, sync e reconcile, ma il dettaglio rete espone soltanto modifica e gestione client. Un operatore UI non può quindi amministrare davvero la VPN senza ricorrere alle API, in contrasto con lo scope e con il percorso R17. | **Release blocker scoperto in R17** | Risolto nel sorgente corrente: dettaglio e pagine di conferma espongono soltanto le azioni valide, applicano scope, CSRF, revisione, backpressure e redirect al monitor job. Drill dei tre ruoli verde sul runtime `0.1.0-17` con overlay isolato; entrerà nel candidate finale senza attribuzione retroattiva al package corrente. | `R17` |
| **⚠ P-032 — riepilogo CSP non coerente con l'implementazione** | La premessa di `SECURITY.md` dichiarava una CSP con nonce, mentre il controllo reale e la sezione UI dello stesso documento ammettono soltanto script e stili statici same-origin con `script-src 'self'`. Il comportamento era corretto e coperto dai test, ma il briefing del revisore poteva creare un'aspettativa falsa. | **Incoerenza documentale, nessun impatto runtime** | Risolto in R18: il riepilogo descrive ora la policy same-origin effettiva; dossier e matrice richiedono comunque al revisore test XSS e confronto header/browser. | `R18` |
| **⚠ P-033 — lo scanner segreti del bundle audit riconosce le proprie firme** | Il primo tentativo su `80524a2` è fallito chiuso perché `prepare-audit-package.py` conteneva letteralmente gli stessi marker PEM/age cercati in tutti i blob. Nessun bundle è stato scritto, ma quel commit non è consegnabile al revisore. | **Blocco operativo R18 risolto, nessuna esposizione di segreti** | Risolto: lo scanner identifica marker all'inizio di una riga come nei file chiave, senza confonderli con firme incorporate nel sorgente; regressioni provano sorgente reale, fixture e chiave simulata. Il target sostitutivo consegnabile è `d09bce0`. | `R18` |
| **⚠ P-034 — conteggio route obsoleto nel dossier audit** | Il dossier del target `e84dda7` prescriveva 61 route Flask, ma l'enumerazione runtime ne rileva 63 applicative più la route statica; OpenAPI e test di conformità restano verdi. Il numero manuale era diventato obsoleto dopo le UI R16/R17 e rende quel target ambiguo per il revisore. | **Incoerenza documentale R18 risolta, nessun endpoint mancante** | Risolto nel target sostitutivo `d09bce0`: il dossier richiede l'elenco derivato dall'app del commit e il confronto con OpenAPI/RBAC/test, senza trasformare un conteggio manuale in contratto; una regressione vieta il vecchio valore. | `R18` |
| **⚠ P-035 — sessione browser non vincolata alla revisione utente** | Il loader rilegge account, stato e assegnazioni a ogni richiesta, ma il cookie firmato conserva soltanto l'ID. Un cambio password eseguito da un'altra sessione non revoca quindi i cookie già emessi, che possono restare validi fino alla scadenza configurata (30 minuti di default). | **Finding interno alto R20 risolto** | ID e revisione utente sono ora legati nel cookie; assenza, tipo errato o mismatch cancellano la sessione. Due browser concorrenti, cookie legacy/manomessi e nuova sessione sono coperti da regressione; ADR 0100. | `R20` |
| **⚠ P-036 — quoting del primo inventario R22 incompatibile con `set -u` remoto** | Il formato `${Package}` di `dpkg-query`, trasmesso senza quoting interno sufficiente attraverso SSH, è stato interpretato dalla shell remota e ha fermato il comando su variabile non definita prima dei controlli. Nessuna mutazione è stata eseguita. | **Problema operativo R22, non prodotto** | Risolto: il retry usa l'output standard di `dpkg-query`, senza espansioni shell, e conferma `wireguard-system 0.1.0-17` installato | `R22` |
| **⚠ P-037 — recovery status invocato dal frontend CLI errato** | Il secondo inventario R22 ha eseguito `wg-portal recovery-status`, ma il classificatore upgrade è installato separatamente come `/usr/lib/wireguard-system/upgrade-preflight --recovery-status`. Doctor e audit erano già verdi; il comando si è fermato prima dei controlli successivi e non ha mutato lo stato. | **Problema operativo R22, non prodotto** | Risolto usando l'entry point root-only documentato; classificazione `no_pending_transaction` e `next_action=none` | `R22` |
| **⚠ P-038 — proprietà systemd richieste sul nome template senza istanza** | Lo smoke R22 ha passato negazione UID, `dpkg -V` e `systemd-analyze verify`, poi `systemctl show wg-portal-helper@.service` è stato rifiutato perché un template non è un nome unità interrogabile. Nessun servizio è stato avviato o modificato. | **Problema operativo R22, non prodotto** | Risolto interrogando l'istanza sintetica inattiva `wg-portal-helper@r22.service`: unità caricata, root con il solo `CAP_NET_ADMIN`, hardening atteso e nessuna attivazione | `R22` |
| **⚠ P-039 — matrice audit con contratto sessione precedente a R20** | Il controllo SESS-01 dichiara ancora che il cookie contiene soltanto l'ID utente, mentre P-035/ADR 0100 hanno aggiunto la revisione canonica per invalidare le sessioni stale. Il runtime e i test sono corretti, ma il documento normativo è ambiguo. | **Incoerenza documentale R23 risolta** | Risolto: SESS-01 descrive ID+revisione, ADR 0004 rinvia esplicitamente all'emendamento ADR 0100 e la chiusura M4.5 distingue controlli interni da audit indipendente | `R23` |
| **⚠ P-040 — tooling della keyring APT assente dal commit da congelare** | P-018 richiede un trust client aggiornabile prima del canale stabile, ma il builder corrente produce soltanto `wireguard-system`; rinviare l'implementazione a R24 violerebbe il vincolo di costruire senza modificare il commit congelato in R23. | **Release blocker R23 risolto** | Risolto: sorgente e fingerprint della chiave pubblica, builder deterministico, package `all`, provenienza multi-package, deploy keyring-first, test e ADR 0101 entrano nel commit congelato; R24 costruirà e proverà senza modifiche | `R23`, `R24` |
| **⚠ P-041 — asserzioni documentali non avanzano oltre R22** | Il primo gate R23 ha 1.079 test verdi ma due failure: la regressione R22 tratta ancora `22/25` come stato corrente invece che evidenza storica, mentre il nuovo test R23 richiede una frase letterale diversa ma semanticamente equivalente. | **Regressione test documentali R23 risolta** | Risolto: il test R22 verifica la riga storica di chiusura e il test R23 la disclosure effettiva; contenuti e gate richiesti restano invariati | `R23` |
| **⚠ P-042 — checksum R24 verificato dalla directory errata** | Dopo la build riuscita, il primo comando manuale ha eseguito `sha256sum --check dist/releases/0.1.0-18/SHA256SUMS` dalla root: i path relativi del manifest non erano risolvibili e tutti gli artefatti risultavano falsamente assenti. Nessun file è stato modificato. | **Problema operativo R24 risolto, non prodotto** | Risolto rieseguendo il controllo dalla directory del bundle: tutti i dieci artefatti sono `OK`; il runbook offline deve mantenere il `cd` esplicito | `R24` |
| **⚠ P-043 — gpg-agent non avviabile nel sandbox del test APT reale** | Il primo avvio opt-in dell'integrazione `reprepro` ha trovato `gpg-agent` installato ma non ha potuto avviarlo nella home GnuPG temporanea, fermandosi prima di creare la chiave effimera e prima di qualsiasi mutazione del repository di prova. | **Problema operativo R24 risolto, non prodotto** | Il retry fuori dal sandbox ristretto, con home e repository interamente temporanei, ha superato il test opt-in e il successivo drill candidate/keyring senza installare componenti o modificare repository reali | `R24` |
| **⚠ P-044 — test R23 confonde evidenza storica e avanzamento corrente** | Dopo la chiusura R24, il test documentale R23 pretendeva ancora la frase di stato corrente `23/25` invece di verificare la riga storica immutabile della chiusura R23; contenuti R24 e candidate non sono coinvolti. | **Regressione test documentale R24 risolta, non prodotto** | Il test conserva ora l'evidenza R23 nella cronologia e richiede separatamente il nuovo avanzamento corrente R24; regressione mirata verde | `R24` |
| **⚠ P-045 — hostname del laboratorio non risolto all'avvio R25** | Il primo inventario SSH read-only del 2026-10-15 non ha avviato alcun comando remoto perché il resolver locale ha restituito `Name or service not known` per `vrt-debian1`. Nessuno stato locale o remoto è stato modificato. | **Problema operativo R25 risolto, non prodotto** | Il FQDN normativo `vrt-debian1.lsinet.it` risolve a `192.168.185.17`; il retry SSH e l'inventario read-only sono riusciti | `R25` |
| **⚠ P-046 — laboratorio R25 inizialmente degraded per istanza helper UID 0** | L'inventario iniziale trova una sola unità fallita `wg-portal-helper@5228-794095-0.service`; il nome indica una connessione dell'UID root, che per policy non è il peer autorizzato, mentre non risultano risorse WireGuard/VRF/nftables gestite. | **Anomalia operativa R25 risolta, non prodotto** | Journal conferma `REQUEST_REJECTED` fail-closed; il probe con UID `wg-portal` è sano, la sola failure storica è stata resettata e systemd è tornato `running` senza risorse rete residue | `R25` |
| **⚠ P-047 — primo preflight firmato R25 rifiutato prima dell'arming** | JSON e firma erano byte-identici e validi, ma il target non disponeva della policy pubblica nel path presunto; nessun marker era stato creato e non era iniziato alcun unpack. | **Problema operativo R25 risolto, non prodotto** | Verifier candidate e installato erano byte-identici; il preflight è passato usando la policy pubblica estratta dal bundle autenticato e confinata nella staging R25 | `R25` |
| **⚠ P-048 — runbook upgrade presume policy pubbliche già provisionate** | Il comando normativo usava `/etc/wireguard-system/upgrade/{allowed_signers,revoked_keys}`, ma il package non installa intenzionalmente trust operativo aggiornabile e il runbook non spiegava il provisioning dal bundle. | **Lacuna operativa/documentale R25 risolta** | `UPGRADE.md` documenta ora estrazione dal sorgente autenticato, hash/fingerprint, installazione root-only, sostituzione e revoca; il drill ha usato soltanto copie pubbliche in staging | `R25` |
| **⚠ P-049 — quoting dell'inventario pre-arming R25** | Il primo comando di quiete ha espanso `${Version}` nella shell SSH e si è fermato prima di audit, arming o mutazioni. | **Problema operativo R25 risolto, non prodotto** | Retry con output standard `dpkg-query`, senza placeholder attraversati da SSH; inventario e arming sono poi passati | `R25` |
| **⚠ P-050 — estrazione fingerprint keyring interrotta da quoting e home GnuPG assente** | La coda del primo smoke post-upgrade ha espanso `$1` di `awk`; root non aveva inoltre una home GnuPG. | **Problema operativo R25 risolto, non prodotto** | Retry con home GnuPG pubblica confinata: fingerprint esatto, package integro e assenza di risorse rete confermati | `R25` |
| **⚠ P-051 — primo apply del test rete R25 rifiutato prima di creare risorse** | Il primo harness multi-client si è fermato sulla richiesta helper `network.apply` della rete A perché la directory temporanea `0750 root:root` impediva al client non privilegiato di leggere la configurazione effimera; il cleanup automatico ha ripristinato `ip_forward`, registry, namespace e risorse host sono risultati vuoti. | **Problema operativo R25 risolto, non prodotto** | Directory temporanea mantenuta `0750` ma assegnata al gruppo `wg-portal`, file server `0640 root:wg-portal`; il retry conserva inoltre stdout/stderr redatti per diagnosi | `R25` |
| **⚠ P-052 — primi backup effimeri del restore drill R25 falliti chiusi** | Il primo `backup-create` aveva un file di output collocato per errore nella destinazione; corretto questo, il retry ha confermato un secondo vincolo intenzionale: il recipient passato a CLI non coincideva con quello dell'environment. In entrambi i casi marker e restore non erano iniziati, le identity effimere sono state eliminate e i writer sono ripartiti sani. | **Problema operativo R25 risolto, non prodotto** | Il drill usa ora una copia isolata coerente di data, environment e keyring con path e recipient effimeri concordanti; esegue la transazione reale fuori dallo stato live e mantiene trap, verifica servizi e nessuna identity sul server al termine | `R25` |
| **⚠ P-053 — restore drill fermato dopo preflight per nome marker errato** | Backup cifrato, verifica e preflight isolato erano verdi, ma l'harness cercava `/tmp/wg-r25-recovery-marker.py` mentre il file trasferito si chiamava `/tmp/r25-recovery-marker.py`; nessun marker o restore era iniziato e la trap ha eliminato l'identity effimera. | **Problema operativo R25 risolto, non prodotto** | Uniformare il nome dello script temporaneo trasferito e quello usato/eliminato dalla trap, quindi ripetere l'intero drill da una sandbox nuova | `R25` |
| **⚠ P-054 — reinstallazione dopo remove negata come upgrade** | Nel gate R25 `dpkg --remove wireguard-system` ha preservato correttamente dati e segreti, ma il successivo `dpkg -i` di `0.1.0-18` ha richiesto un'autorizzazione upgrade già consumata. Il candidato firmato `0.1.0-19` ha superato l'upgrade reale `0.1.0-17 → 0.1.0-19`, ma dopo remove ha ripetuto la negazione prima dell'unpack. Debug reale: `preinst install 0.1.0-19 0.1.0-19`; `deb-preinst(5)` riserva questa forma a un package rimosso, mentre il query interno vedeva uno stato già transizionato da dpkg. | **Release blocker R25 con causa radice identificata; nessuna perdita dati** | Laboratorio recuperato sano su `0.1.0-19` via purge/installazione pulita, hash invariati. `0.1.0-20` elimina il query tardivo e ammette soltanto la forma esatta `install` con old/new uguali al candidate; upgrade, rollback e recovery restano guardati. Restano build/firma e retry reali | `R25`, `0.1.0-20` |
| **⚠ P-055 — bytecode Python non gestito sopravvive al purge** | Il recovery del laboratorio dopo P-054 ha mostrato 292 file `.pyc` root-owned non inventariati da dpkg nel private `site-packages`; provengono da esecuzioni storiche senza `PYTHONDONTWRITEBYTECODE`, non alterano `dpkg -V`, ma lasciano directory e codice derivato dopo il purge. | **Igiene package R25 risolta** | Il `prerm` di `0.1.0-19` ha eliminato nel test reale tutti i 292 bytecode e dpkg non ha riportato directory non vuote; dati, environment, keyring e metadati sono rimasti invariati | `R25`, `0.1.0-19` |

## Storico revisioni della baseline residua

| Data | Baseline | Modifica | Motivo |
|---|---|---|---|
| 2026-10-15 | v1, 25 unità | Chiusa `R24`; 1 unità residua, denominatore invariato; P-004/P-018/P-028/P-042–P-044 risolti | Build e firma offline del candidate `0.1.0-18`, verifica indipendente, repository APT isolata e rotazione keyring A→A+B→B interamente verdi |
| 2026-10-15 | v1, 25 unità | Chiusa `R23`; 2 unità residue, denominatore invariato; P-039/P-040/P-041 risolti | Documentazione e matrice supportata allineate; package keyring aggiornabile e freeze tag verificabile entrano nel commit finale; gate con 1.081 test verdi e P-018 aperto solo per il drill reale R24 |
| 2026-10-15 | v1, 25 unità | Chiusa `R22`; 3 unità residue, denominatore invariato; P-036–P-038 risolti | Regressione locale, inventario e smoke privilegiati read-only confermano assenza di ampliamenti del confine root; pubblicato il registro dei rischi residui senza nascondere waiver, chiavi locali o blocker APT |
| 2026-10-15 | v1, 25 unità | Chiusa `R21`; 4 unità residue, denominatore invariato | Il secondo gate compensativo riesegue 463 test su helper/rete/storage/recovery/package e supply chain; la scansione aggiornata delle 24 dipendenze è pulita e non restano finding critici/alti interni noti nello scope |
| 2026-10-15 | v1, 25 unità | Chiusa `R20`; 5 unità residue, denominatore invariato; P-035 trovato e risolto | Il gate compensativo riesegue 257 test su auth/sessioni/RBAC/API/job/segreti; le sessioni sono ora revocate da ogni nuova revisione utente e non restano finding critici/alti interni noti nello scope |
| 2026-10-15 | v1, 25 unità | Chiusa amministrativamente `R19`; 6 unità residue, denominatore invariato; P-005 accettato | Il maintainer non dispone delle risorse per un audit esterno entro la consegna: nessun audit viene rivendicato, la v1 resta etichettata non auditata e R20/R21 eseguono controlli compensativi interni |
| 2026-10-15 | v1, 25 unità | Chiusa `R18`; 7 unità residue, denominatore invariato; P-028 e P-032–P-034 risolti | Freeze sul commit `d09bce0`, dossier/matrice autonomi, bundle audit deterministico verificato due volte, 1.056 test verdi e scansione pulita; `0.1.0-18` non costruita |
| 2026-10-15 | v1, 25 unità | Chiusa `R17`; 8 unità residue, denominatore invariato; P-031 trovato e risolto | Manuale operatore pubblicato; drill isolato superadmin/admin/manager verde sul runtime del candidate, con lifecycle rete ora interamente disponibile anche dalla UI |
| 2026-10-15 | v1, 25 unità | Chiusa `R16`; 9 unità residue, denominatore invariato; P-030 trovato e risolto | Pubblicato il manuale amministratore con collaudo end-to-end; i comandi sono verificati su `0.1.0-17`, i link sono sotto test e la UI può ora creare, ruotare e revocare il primo accesso API senza modifiche dirette allo storage |
| 2026-10-14 | v1, 25 unità | Chiusa `R15` e M4.6; 10 unità residue, denominatore invariato | Policy di deprecazione/major/migrazione/rollback pubblicata; drill read-only accetta l'additiva, rifiuta la breaking e preserva baseline e contratto byte-per-byte |
| 2026-10-14 | v1, 25 unità | Chiusa `R14`; 11 unità residue, denominatore invariato; P-029 risolto | HTTPS/CA, allowlist, spoofing, limiti e mTLS sono verificati su Caddy 2.6.2; configurazione live invariata ed esposizione Internet ancora vietata |
| 2026-10-14 | v1, 25 unità | Chiusa `R13`; 12 unità residue, denominatore invariato; P-028 assegnato a R23/R24 senza estendere lo scope | Rotazione e revoca negano vecchi token, download e job accodati; rate limit, audit, assenza segreti e cleanup sono verificati end-to-end |
| 2026-10-14 | v1, 25 unità | Chiusa `R12` e M4.4; 13 unità residue, denominatore invariato | Matrice R01–R12, runbook, installazione, laboratorio, handoff e limiti schema sono allineati; nessun TODO M4.4 resta implicito |
| 2026-10-14 | v1, 25 unità | Chiusa `R11`; 14 unità residue, denominatore invariato; P-026 risolto | Fault e rollback/restore reali sono seguiti dal candidate correttivo firmato: stato terminale, hash, writer, health e idempotenza sono verdi |
| 2026-10-14 | v1, 25 unità | Registrato P-026 dentro R11; denominatore invariato | Rollback e restore reali sono riusciti, ma il classificatore terminale deve riconoscere l'intent già archiviato prima di chiudere il gate |
| 2026-10-14 | v1, 25 unità | Registrato P-025 dentro R11; denominatore invariato | Il primo upgrade 14→15 è sano ma terminale; il drill viene ripetuto su 15→16 senza alterare ricevute né usare intent manuali |
| 2026-10-14 | v1, 25 unità | Chiusa `R10`; 15 unità residue, denominatore invariato; registrato P-024 risolto | Due snapshot dpkg reali provano pending/awaited, retry e rifiuto della closure estranea; il primo falso negativo era il solo dimensionamento dell'overlay |
| 2026-10-14 | v1, 25 unità | Chiusa `R09`; 16 unità residue, denominatore invariato | Il package immutabile `0.1.0-14` prova handoff lock e storico terminale; tre fault dpkg definiscono gli stati reali, cleanup e retry sono verdi senza `--force-*` reale |
| 2026-10-14 | v1, 25 unità | Registrati P-022 in R11 e P-023 risolto in R09; denominatore invariato | Gli intent terminali richiedono separazione dall'area attiva; dpkg non ha esposto candidate `half-installed` nelle finestre reali provate |
| 2026-10-13 | v1, 25 unità | Registrato P-021 dentro R09; 17 unità residue, denominatore invariato | Il recovery reale ha trovato che lo storico terminale dei rollback non era riconosciuto dal finalizer; la correzione è parte del gate R09 esistente |
| 2026-10-13 | v1, 25 unità | Registrato P-020 dentro R09; 17 unità residue, denominatore invariato | Il gate R09 ha trovato un bug reale nell'handoff lock; la remediation appartiene ai criteri di chiusura già pianificati |
| 2026-10-13 | v1, 25 unità | Registrato P-019 come rischio accettato; 17 unità residue, denominatore invariato | Il maintainer ha deciso di riutilizzare le chiavi esistenti e di non ripetere la cerimonia offline |
| 2026-10-13 | v1, 25 unità | Registrato lifecycle keyring APT in P-018/R24; 17 unità residue, denominatore invariato | Il rinnovo del trust è parte necessaria della repository APT finale già pianificata, non una nuova feature |
| 2026-10-13 | v1, 25 unità | Aggiunto export APT GitHub Pages; 17 unità residue, denominatore invariato | È un affinamento della repository APT di prova già inclusa in R24; chiave e pubblicazione stabile restano P-017/R24–R25 |
| 2026-10-13 | v1, 25 unità | Chiusa `R08`; 17 unità residue, denominatore invariato | Rifiuti pre-arming, cancellazione, crash del claim e no-unpack reale verdi |
| 2026-10-13 | v1, 25 unità | Chiusa `R07`; 18 unità residue, denominatore invariato | Upgrade firmato `0.1.0-12 → 0.1.0-13`, ricevute, health, hash e cleanup verdi; P-016 risolto |
| 2026-10-13 | v1, 25 unità | Chiusa `R06`; 19 unità residue, denominatore invariato | Trust release/upgrade separato, firme reali, rifiuti e due backup offline verificati |
| 2026-10-12 | v1, 25 unità | Chiusa `R05`; 20 unità residue, denominatore invariato | Candidate `0.1.0-13` verificato dal commit pulito, arco esatto con `0.1.0-12` e P-003 risolto |
| 2026-10-12 | v1, 25 unità | Chiusa `R04`; 21 unità residue, denominatore invariato | Drill reale stale/failure/recovery, Unix/HTTPS, journald e cleanup interamente verde |
| 2026-10-12 | v1, 25 unità | Chiusa `R03`; 22 unità residue, denominatore invariato | Baseline Debian `0.1.0-12` integra, health/hash/rete verificati e rollback fail-closed provati |
| 2026-10-12 | v1, 25 unità | Chiusa `R02`; 23 unità residue, denominatore invariato | Lineage univoca e bundle predecessor `0.1.0-10` verificato dal commit pulito `6dab5a8` |
| 2026-10-09 | v1, 25 unità | Creata baseline `R01`–`R25`; stime precedenti ritirate | Rendere avanzamento, dipendenze, blocchi e criteri di chiusura misurabili e impedire crescita implicita dello scope |
