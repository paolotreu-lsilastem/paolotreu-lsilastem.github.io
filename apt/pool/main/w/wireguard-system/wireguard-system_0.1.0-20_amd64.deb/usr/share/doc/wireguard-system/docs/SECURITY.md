# Modello di sicurezza

## Premessa

La “sicurezza assoluta” non è garantibile. Il progetto mira a riduzione del rischio,
least privilege, difesa in profondità, fail-closed, aggiornamenti e verifiche ripetibili.
Una release production dovrebbe ricevere code review indipendente, test di penetrazione
e threat-model review. Per la v1 il maintainer ha approvato il waiver R19 per mancanza di
risorse e urgenza di consegna: questi controlli esterni non sono stati eseguiti, P-005 è
un rischio residuo alto accettato e la release deve restare dichiarata non auditata.

## Asset e minacce principali

Asset: private key, password hash, sessioni, credenziali API, configurazioni, mapping
tenant, capacità di eseguire operazioni privilegiate e audit. Avversari: anonimo remoto,
utente o client API autenticato che tenta escalation/cross-tenant, processo web
compromesso, operatore locale, client VPN compromesso.

Controlli richiesti:

- autenticazione con Argon2id, risposta generica e hash dummy anti-enumerazione,
  MFA/WebAuthn pianificata, rate limiting file-backed e session rotation;
- autorizzazione object-level centralizzata, negative tests cross-tenant per ogni use case;
- CSRF, CSP rigorosa con script e stili statici same-origin, escaping template, HSTS al
  proxy e header sicuri;
- validazione semantica di IP/porte/ID, UUID non predicibili e path mai controllati
  dall'utente;
- helper root minimale con protocollo allowlisted e socket autorizzato; niente shell;
- firewall nftables deny-by-default: solo forwarding intra-rete sulla stessa interfaccia,
  nessun forwarding WAN/inter-network;
- configurazioni e backup cifrati quando contengono private key; le private key client
  restano cifrate at-rest per consentire download successivi autorizzati; redazione di
  errori/log;
- dipendenze bloccate e scansioni supply-chain; build/rilasci riproducibili e firmati;
- audit append-only con hash chain/HMAC conservato fuori dal data tree, rotazione
  giornaliera, retention operativa di 30 giorni ed eliminazione definitiva al compimento
  di 3 mesi;
- backup cifrato, restore drill e procedura di rotazione/revoca.

La sessione browser firmata contiene ID e revisione canonica dell'utente. Ogni richiesta
ricarica il documento e cancella il cookie se account, tipo o revisione non coincidono;
un cambio password, una disabilitazione o una modifica amministrativa revocano quindi le
sessioni precedenti. Cookie legacy privi di revisione falliscono chiusi.

Il gate Python M4.4 descritto in `SUPPLY_CHAIN.md` scansiona tutte e sole le dipendenze
hashate di `requirements-prod.lock`, senza risoluzione ambientale, advisory ignorati o
correzioni automatiche. Report e SBOM devono coprire ogni entry; un finding o un output
incompleto blocca il rilascio. Il gate non sostituisce ancora firma, provenienza del `.deb`
e scansione dei pacchetti host.

Il bundle di provenienza rifiuta source tree sporchi, origin con credenziali, versioni
divergenti, link di input e audit non puliti. La Statement in-toto/SLSA collega gli
artefatti tramite SHA-256 e l'inventario elenca semanticamente il payload `.deb` senza
estrarlo. Finché non viene racchiusa in un envelope firmato, questa coerenza non prova
l'identità del produttore e non autorizza la pubblicazione del candidate.

Il trust APT client è separato dall'applicazione nel package
`wireguard-system-archive-keyring`. Sorgente pubblico e fingerprint ammessi sono
versionati; il builder rifiuta mismatch e la provenienza include entrambi i package nello
stesso bundle firmato. Il primo bootstrap richiede comunque la verifica del fingerprint
su un canale indipendente. Rinnovo e rotazione devono usare una finestra con vecchia e
nuova chiave sovrapposte; R24 ha verificato la sequenza isolata A→A+B→B e nessuna chiave
privata APT entra nel repository o negli artefatti client.

Endpoint pubblico, ultimo handshake e pattern temporali sono metadati sensibili. Sono
visibili soltanto ai ruoli già autorizzati sulla rete, non appaiono nei log applicativi e
seguono la retention minima necessaria alla presenza corrente. Le dashboard non espongono
chiavi pubbliche complete e non distinguono errori interni dettagliati a utenti non
autorizzati.

L'audit non accetta payload richiesta, username, password, chiavi o motivazioni testuali
libere. Registra UUID, scope, azione, esito, nomi dei campi cambiati e codici errore
stabili. I login falliti usano attore di sistema e UUID nullo, evitando di rivelare o
confermare l'esistenza dell'account. Ogni append verifica prima l'intera catena della
giornata e fallisce in chiusura se i due stream divergono. La chiave HMAC può essere
fornita separatamente; in assenza viene derivata dal secret applicativo con separazione di
dominio e resta comunque esterna allo storage.
Le operazioni critiche multi-file registrano prima l'intento e poi l'esito, permettendo di
individuare un crash nella finestra in cui non è possibile avere atomicità distribuita.

I probe host eseguono soltanto argv assoluti e allowlistati, senza shell, con timeout e
limite di output. Il dump WireGuard contiene chiavi private anche se destinato a script:
il parser le valida ma non le conserva, non le include nelle eccezioni e non le espone
nel JSON. Le chiavi pubbliche peer complete restano solo nello snapshot in memoria per la
correlazione; l'output serializzato contiene il fingerprint SHA-256 completo, mentre
eventuali viste utente possono abbreviarlo.

Le chiavi private WireGuard sono generate con entropia del sistema, clampate per X25519 e
persistite soltanto in envelope AES-256-GCM. La AAD include versione envelope, tipo e UUID
di risorsa, tenant e rete, quindi copiare un ciphertext in un altro scope fallisce
l'autenticazione. Il keyring master è esterno al data tree, `0600`, non-symlink e
obbligatorio in produzione. Download e rotazione client richiedono nuova verifica della
password, autorizzazione object-level e stato non revocato/archiviato. Errori di password,
scope o cifratura non rivelano dettagli al chiamante, ma restano distinti nell'audit.

Il compiler non interpreta template né include campi testuali liberi. Renderizza soltanto
direttive note dopo validazione semantica e base64 canonica, verifica che ogni private key
corrisponda alla public key persistita e ordina stabilmente i peer. Sul server include solo
client `active` con host route `/32`; sul client vieta implicitamente default route
compilando esclusivamente il CIDR gestito. Non emette `PostUp`, `PostDown`, `DNS`,
`SaveConfig` o altre direttive capaci di mutare l'host fuori dal protocollo privilegiato.

Il socket privilegiato non si affida ai soli permessi filesystem: il client rifiuta path
symlink/non-socket, socket world-writable o non appartenenti a root e verifica l'UID del
server con `SO_PEERCRED`; il helper verifica allo stesso modo l'UID del control plane prima
di leggere la richiesta. Il protocollo ammette un solo frame ASCII, JSON senza chiavi
duplicate, schema top-level chiuso, UUID canonico e limiti distinti per richiesta/risposta.
Il protocollo non permette mai al processo web di fornire shell, argv, unità systemd o
path. Le unità applicano socket activation, `NoNewPrivileges`, filesystem protetto,
device chiusi e capability bounding ristretto.

M2.5 ammette envelope tipizzati per `network.apply` e `network.stop`, ma resta fail-closed
senza un mutation handler esplicito. Gli envelope legano UUID tenant/rete, nome interfaccia
canonico, configurazione ASCII limitata e relativo SHA-256; non accettano path o argv. Un
registry root-owned `0600`, in directory systemd `0700` esterna al data tree della UI,
registra solo interfacce applicate con successo e relativi digest. Ownership, permessi,
symlink, collisioni e corruzione causano il rifiuto dell'operazione. Configurazioni e chiavi
private non vengono conservate nel registry.

Il registry v2 persiste soltanto l'identità minima dell'isolamento verificato: modalità
VRF, route table, CIDR e IP hub. La migrazione v1 assegna `null`, mai una capacità presunta;
route table duplicate, cambio d'identità e versioni sconosciute falliscono in chiusura.
Un aggiornamento privo di piano non può cancellare un'identità VRF già attestata.

L'executor M2.5 non usa `wg-quick`: esegue soltanto argv fissi di `ip` e `wg` senza shell.
Il processo root ripete la validazione della grammatica server e ammette unicamente CIDR
RFC1918, porta dedicata, chiavi canoniche e peer host-route nella stessa rete; direttive
extra, hook e default route sono impossibili. La configurazione filtrata raggiunge
`setconf`/`syncconf` via stdin e non viene salvata su disco. Snapshot ottenuti da
`wg showconf` e dal kernel vivono solo in memoria per la durata del rollback. Gli endpoint
peer appresi dinamicamente vengono esclusi dallo snapshot perché non fanno parte del
desired state; ogni altra direttiva inattesa resta rifiutata. Un lock root-only serializza
kernel e registry; collisioni non gestite e drift falliscono in chiusura.

Il worker non considera il job una capability: prima di ogni effetto ricarica l'utente e
gli oggetti canonici, ricostruisce il principal e ripete RBAC sul tenant e sulla rete.
Desired state e lifecycle sono rivalidati al consumo. Per start/sync la chiave server viene
decifrata soltanto in memoria e passata al compiler; stop non la apre. Risposte helper
malformate o codici non allowlistati diventano errori generici. Nei job e nell'audit
restano soltanto riepiloghi predefiniti e codici stabili, mai configurazioni, chiavi o
testi restituiti dal confine privilegiato.

I job automatici di reconcile usano un attore di sistema riservato, non impersonano
l'ultimo operatore e sono accettati esclusivamente per `network.reconcile`. Passano dallo
stesso compiler e helper dei job utente e non possono fornire configurazioni arbitrarie.
Un lock globale serializza recovery, worker one-shot e reconciler: senza il lock il
recovery potrebbe dichiarare interrotto un job ancora attivo. La ricostruzione di
un'interfaccia scomparsa è consentita solo quando tenant, rete e nome interfaccia
corrispondono al registry root-owned; una collisione non gestita resta fail-closed.

Il reconciler periodico non interpreta un probe fallito o incompleto come assenza delle
interfacce: richiede esplicitamente `wireguard.runtime=ok` e una struttura valida, altrimenti
non accoda mutazioni e applica backoff. Il confronto ignora endpoint e contatori dinamici,
ma include indirizzo/prefisso, porta, fwmark, fingerprint SHA-256 completi, host route e
keepalive. Il servizio systemd non possiede capability e raggiunge root soltanto tramite
il socket Unix autenticato.

## API pubblica

L'API amplia la superficie remota e richiede controlli specifici contro furto e replay
dei bearer token, brute force, enumerazione, broken object-level authorization/IDOR, mass
assignment, esaurimento risorse, amplificazione dei job e perdita di segreti. L'adattatore
API non accede mai direttamente a repository, coda, helper o host: risolve il principal e
chiama esclusivamente il service layer autorizzato.

La baseline approvata in `docs/USER_DECISIONS.md` e ADR 0016 richiede:

- identità macchina separate dagli account browser; segreto casuale mostrato una volta,
  conservazione del solo hash, scadenza obbligatoria, rotazione e revoca immediata;
- assegnazioni RBAC esplicite e controllo object-level sullo scope canonico di ogni
  risorsa, con risposta non enumerabile per oggetti fuori scope;
- rivalidazione di credenziale, identità e assegnazioni quando il worker consuma un job,
  perché un job non è una capability durevole;
- schemi JSON chiusi, limiti di body e collezioni, allowlist dei campi modificabili e
  rifiuto di proprietà inattese per prevenire mass assignment;
- rate limit per credenziale e IP, quote di job per identità/scope e backpressure;
- `Idempotency-Key` persistente per retry delle mutazioni ed `ETag`/`If-Match` per evitare
  aggiornamenti persi o replay con precondizioni obsolete;
- segreti mai in query string, request ID propagato senza dati sensibili, errori redatti,
  payload esclusi da log e audit, e `Cache-Control: no-store` per risposte riservate;
- CORS disabilitato per default, HTTPS obbligatorio tramite Caddy, accesso iniziale
  ristretto alle reti amministrative configurabili e mTLS opzionale.

L'accesso alle configurazioni client deve usare un permesso distinto e non abilita mai
chiavi server o export massivi. La cancellazione fisica remota è esclusa dalla baseline
approvata. Il modello di credenziali prevede scadenza massima di 90 giorni. L'esposizione
Internet resta vietata: threat review, drill di revoca R13 e drill Caddy R14 sono
completati, ma il penetration test indipendente resta un gate obbligatorio.

### Threat model API v1

Il flusso attraversa quattro confini: client remoto → Caddy, Caddy → adattatore Flask,
adattatore → service layer/repository e worker → helper privilegiato. Solo Caddy termina
TLS e costruisce gli header forwarded; l'adattatore autentica e autorizza ogni richiesta;
il service layer ricarica oggetti canonici; il worker rivalida l'identità prima degli
effetti. Né il bearer token né un job ID trasferiscono autorità al helper.

| Minaccia | Controllo obbligatorio | Verifica prevista | Rischio residuo |
|---|---|---|---|
| Furto o replay bearer | Token ad alta entropia, hash at-rest, scadenza ≤90 giorni, rotazione/revoca, TLS, `no-store` | Token scaduto/ruotato/revocato e drill compromissione | Malware sul client può usare il token fino alla revoca |
| Enumerazione credenziali | Identificatore e secret verificati con risposta e timing uniformi, rate limit token+IP | Token assente, malformato e ignoto indistinguibili | Analisi statistica distribuita da mitigare al proxy |
| BOLA/IDOR cross-tenant | Lookup canonico e RBAC object-level; fuori scope uguale a inesistente | Matrice per ruolo, oggetti condivisi e UUID di altri tenant | Errore futuro nel service layer, coperto da test per use case |
| Confused deputy asincrono | Job non è capability; credenziale, assegnazioni e desired state ricaricati dal worker | Revoca/declassamento tra enqueue e consume | Breve coda operativa, senza effetto se rivalidazione fallisce |
| Mass assignment | Request e patch schema chiusi, allowlist campi, nessuna deserializzazione storage | Proprietà extra, campi read-only e fuzzing | Divergenza contratto/codice, coperta da conformance test |
| Retry/replay mutazioni | Idempotency UUID legata a identità, route e digest payload; ETag forte | Stesso/diverso payload, concorrenza e retention | Crescita dello store, limitata da quota e cleanup |
| Cursor tampering/scope leak | Cursore opaco cifrato e autenticato, legato a identità, filtri, ordinamento e versione | Modifica, scadenza e riuso cross-scope | Invalidazione dopo grandi migrazioni, restituita come errore |
| Esaurimento risorse | Body massimo a Caddy e Flask, rate limit token+IP, quote job e backpressure | Oversize, burst, coda piena e processi concorrenti | DoS distribuito richiede anche limiti host/upstream |
| Esfiltrazione segreti | Proiezioni separate dallo storage, download dedicato, permesso fresco, audit e `no-store` | Assenza in response/error/log/audit/cache | Endpoint client autorizzato espone intenzionalmente quel secret |
| Spoof proxy o downgrade | Gunicorn su socket Unix, Caddy sovrascrive forwarded header, HTTPS/HSTS, allowlist rete | E2E Caddy, accesso diretto negato e header ostili | Compromissione Caddy equivale al confine TLS compromesso |
| Drift del contratto | OpenAPI versionata, copia packaged byte-identica, inventario route, conformance JSON Schema e baseline v1 | CI su ogni modifica con compatibility check automatico | Semantica non esprimibile interamente in JSON Schema |
| XSS/UI spoofing | Autoescape Jinja, nessun HTML utente, script vietati da CSP, CSS same-origin, frame negati e navigazione derivata server-side | Test header, template semantici e assenza script | Un futuro componente dinamico richiederà revisione CSP dedicata |

I cursori non contengono JSON decodificabile o scope in chiaro: M3.3 serializza posizione,
versione, scadenza e digest dello scope, poi usa AES-256-GCM con nonce casuale e chiave
derivata per il solo contesto cursor. La decodifica verifica scadenza, identità,
collezione e filtri; qualunque mismatch restituisce `INVALID_CURSOR`. Lo store
idempotency M3.4 conserva identità, operazione, digest canonico SHA-256, ID risorsa
preallocato e soltanto risposte 2xx redatte; non conserva bearer token né payload
richiesta. I record sono serializzati per identità/chiave, il riuso incompatibile è un
conflitto e una risposta con campi sensibili non può passare a `completed`. I completati
scadono dopo 24 ore; pending mai rimossi automaticamente, quota per identità e riserva
minima disco limitano crescita e failure durante il commit della risposta.
Le risposte create/rotate dei service account separano il body pubblico one-time dal body
redatto persistibile. Un replay completato o il recovery di un effetto già committato
restituisce `CREDENTIAL_RECOVERY_REQUIRED`; il server non cifra né deriva il token per
riprodurlo. Un marker UUID interno e non esposto, aggiornato nello stesso CAS della
credenziale attiva, distingue l'esatto recovery da una nuova richiesta con ETag obsoleto.

M3.2 implementa token opachi con 256 bit casuali e prefisso/versione espliciti. Il record
credenziale contiene soltanto hash Argon2id, scadenza e identità proprietaria; il record
identità indica la sola credenziale attiva. L'autenticazione richiede insieme hash valido,
scadenza futura, identità attiva e corrispondenza del puntatore. La rotazione pubblica il
nuovo token solo dopo il CAS e il vecchio token perde autorità nello stesso cambio; la
revoca azzera il puntatore. Percorsi falliti, malformati, scaduti, revocati o corrotti
producono lo stesso errore e gli UUID ignoti verificano un hash dummy. Il throttling
persistente avviene prima della verifica, per IP e coppia credenziale+IP.

Il primo sottogate M3.3 espone esclusivamente letture con proiezioni allowlistate. Le
query rifiutano proprietà sconosciute e duplicati; i dettagli fuori scope e gli UUID
inesistenti condividono la stessa risposta 404 e le negazioni autenticate producono audit
redatto. Password hash, chiavi WireGuard, envelope cifrati, hash token, attori e payload
job non attraversano l'adattatore. Lo stato runtime resta `unknown` fino al sottogate
telemetrico, evitando di trasformare un probe assente o ambiguo in uno stato attendibile.

La telemetria M3.3 autorizza l'oggetto canonico prima di inviare il probe al helper. I peer
sono correlati ai soli client attivi mediante SHA-256 della chiave pubblica in memoria;
fingerprint, chiavi e nome interfaccia non compaiono nella risposta o nella cache. La
risposta è attendibile soltanto se capability, registry root-owned, isolamento, interfaccia,
porta, indirizzo e insieme completo dei peer coincidono con lo stato canonico. Un singolo
mismatch rende l'intero snapshot `unknown` e lascia intatta la cache, impedendo risultati
parziali o falsi `offline`. La cache presence è derivata, schema-chiusa e atomicamente
scritta sotto `runtime/presence`; corruzione o identity mismatch sono fail-closed.

Le mutazioni utenti M3.4 serializzano unicità globale dello username e verifica
dell'ultimo superadmin. La password iniziale viene hashata Argon2id e non entra nella
risposta idempotente. Per account multi-tenant, un admin può cambiare soltanto
assegnazioni nel proprio scope preservando quelle esterne; stato globale, superadmin e
side effect cross-tenant falliscono come risorsa non visibile.

La UI utenti M3.9 ricostruisce le assegnazioni esclusivamente da checkbox i cui UUID
appartengono alle proiezioni scoped dei read service; UUID forgiati, chiavi duplicate e
campi inattesi sono rifiutati. Gli scope esterni sono preservati dalla copia autorizzata
del server e non da valori client. Password iniziali errate non vengono reinserite
nell’HTML. La modifica del proprio account è nascosta e negata dalla UI; la policy RBAC
nega inoltre ogni modifica delle proprie assegnazioni anche attraverso altri adattatori.

La preview rete M3.10 è read-only: non genera coppie WireGuard, non cifra materiale e non
scrive documenti. Esegue però autorizzazione object-level, normalizzazione endpoint,
risoluzione IPv4, allocazione porta e controllo overlap con gli stessi metodi della
create. Non costituisce una prenotazione: il salvataggio rivalida tutto sotto il lock di
mutazione, chiude eventuali race e solo allora genera la chiave privata in memoria.

L’update HTML rete M3.10 deriva i campi accettati dal ruolo: un manager non può nemmeno
inviare lifecycle o conferma archive, e payload forgiati falliscono prima del service.
CIDR e hub non attraversano il form di modifica. La revisione previene lost update;
il service rifiuta endpoint, porta e lifecycle se la rete è running, mentre archive
richiede sia autorità admin sia conferma esplicita nel form.

Le pagine client M3.11 usano esclusivamente le proiezioni allowlistate di
`ApiReadService`: HTML e context non ricevono `public_key`, `private_key_envelope` o
materiale decifrato. Create genera le chiavi solo nel service dopo autorizzazione e
allocazione IP sotto lock; retry con UUID stabile non duplica identità o reservation.
Update accetta soltanto nome e descrizione, quindi non può alterare IP, chiavi, stato o
reservation neppure tramite campi form forgiati.

Le azioni lifecycle HTML hanno route e conferme dedicate, form chiusi, CSRF, revisione e
mutation UUID. La disponibilità mostrata dal template non è un controllo di sicurezza:
il service rivalida permesso object-level e transizione. I job live creati dalla UI
salvano `actor_user_id`, mai una credenziale fittizia; il worker ricarica l’utente e
rivalida stato, ruolo e scope prima dell’effetto host. Lista e dettaglio job usano
proiezioni allowlistate, non mostrano attore o payload e rendono job mancanti e fuori
scope indistinguibili tramite `404` auditato.

Il download HTML della configurazione non riusa l’endpoint bearer. Dopo il controllo
object-level della pagina, il service ricarica dal repository l’utente della sessione,
richiede `must_change_password=false`, rivalida `client.download_config` sullo scope e
verifica la password corrente sul nuovo snapshot. La verifica è rate-limited; form e
query sono chiusi e protetti da CSRF. Sono ammessi solo client `pending`, `active` o
`disabled` in tenant e rete attivi. Chiave e profilo vengono decifrati/compilati in
memoria e restituiti con `Cache-Control: no-store`, `Pragma: no-cache`, `Expires: 0` e
senza ETag; audit registra soltanto identità, scope, esito e codice redatto.

Il monitor job M3.12 espone un endpoint JSON di sola lettura con la stessa sessione e lo
stesso controllo object-level della pagina. La proiezione contiene soltanto ID, stato,
percentuale, timestamp, terminalità e codice errore redatto; non include attore, payload,
risultati interni o messaggio persistito. Le indicazioni operative sono selezionate da una
tabella server-side chiusa. Il poller usa credenziali same-origin, `no-store`, backoff e
pausa a pagina nascosta; 404/403 o sessione scaduta interrompono il ciclo.

Lo snapshot HTML M3.13 usa una route session-based distinta dall’API bearer. La rete è
autorizzata prima del probe e oggetti mancanti o fuori scope producono lo stesso `404`
auditato. La risposta include soltanto nome e stato amministrativo client, IP VPN,
endpoint osservato, timestamp, presenza e contatori; chiavi, fingerprint, envelope e
dettagli helper sono esclusi. Il browser osserva una sola rete per volta, usa una sola
richiesta in volo e non converte errori o dati incompleti in `offline`.

Lo snapshot aggregato risolve e autorizza ogni ID di rete prima della singola chiamata
helper. Il probe contiene necessariamente lo stato host complessivo, ma la risposta
proietta soltanto reti comprese negli scope dell’utente. Parsing globale non affidabile
rende tutte le reti `unknown`; drift, peer incoerenti o cache non valida di una singola
rete degradano soltanto quella rete. `running` e `stopped` non sono inferiti dal desired
state: vengono dichiarati solo quando runtime e assenza attesa risultano verificati.

L’unico JavaScript è un file statico packaged. CSP `script-src 'self'` consente tale asset
ma continua a negare inline script, eval e origini esterne. Nessun dato server diventa
codice: URL e stato sono attributi HTML escaped, gli aggiornamenti usano `textContent` e
classi scelte da allowlist. La protezione doppio submit è difesa UX aggiuntiva; UUID
idempotenti, revisioni e lock server-side restano il confine di correttezza.

Le mutazioni rete M3.4 non accettano chiavi, envelope o nomi interfaccia dal chiamante.
Create è disponibile soltanto con master key caricata, genera la coppia in memoria e
cifra la privata prima della scrittura atomica. Allocazione porte e verifica collisioni
usano endpoint normalizzati e risoluzione IPv4 fail-closed. I campi che cambierebbero la
configurazione runtime sono rifiutati finché la rete non è `stopped`, così il reconciler
non trasforma un PATCH CRUD in un apply implicito. L'overlap cross-tenant resta inerte
finché worker/helper non riconfermano la capability VRF al momento dello start.

Le mutazioni client M3.4 non accettano chiavi dal chiamante: create genera la coppia in
memoria, cifra la privata con AAD client/tenant/rete e restituisce soltanto una fingerprint.
Allocazione manuale e automatica considerano tutte le reservation non rilasciate. Il
lifecycle è esposto tramite azioni chiuse; activate e ogni rimozione di un peer active
richiedono rete stopped, evitando apply impliciti del reconciler. Revoca e archiviazione
non rilasciano l'IP; `release-ip` richiede uno di questi stati ed è auditata separatamente.

Le azioni rete API M3.5 non invocano mai il helper dal processo HTTP. Desired state e job
sono coordinati sotto il lock del worker con marker di recovery; ETag e idempotency
impediscono lost update e doppio enqueue. Il job lega service account e credenziale
autenticata, senza conservarne il token. Il worker ricarica entrambi e verifica puntatore
alla credenziale attiva, scadenza, stato account, RBAC e stato tenant/rete immediatamente
prima dell'effetto host. Una rotazione o revoca dopo il `202` annulla quindi l'autorità
del job invece di congelarla al momento della richiesta.

Le azioni client live seguono lo stesso confine. Quando activate o una transizione da
`active` cambia l'insieme dei peer di una rete running, il service layer salva client e
marker sotto il lock globale e accoda `network.sync`; il processo HTTP non contatta il
helper. Il marker consente di recuperare il crash prima dell'enqueue senza accettare un
ETag obsoleto estraneo. Il job non contiene chiavi o configurazioni e conserva gli ID
della credenziale da rivalidare. Transizioni fra stati non attivi e rilascio IP non
richiedono convergenza host e non ampliano l'autorità del chiamante.

La coda M3.5 applica backpressure sui job `queued` e `running` con limiti globale,
identità, tenant e rete. Un lock dedicato rende atomici conteggio e creazione anche tra
processi; replay dello stesso job è verificato prima del conteggio. Le azioni live fanno
il preflight sotto il lock worker prima di modificare documenti canonici, quindi un
`429 QUEUE_CAPACITY_EXCEEDED` non lascia desired state o client alterati. Il reconciler
interno non usa quota identità ma resta vincolato da globale/tenant/rete, impedendo che
diventi un bypass. Limiti invalidi bloccano l'avvio invece di disabilitare la protezione.

Il download API M3.6 non eredita implicitamente l'autorità del ruolo: richiede
`client.config:read` anche a un superadmin e una credenziale la cui durata totale non
superi 24 ore. Account e credenziale esatta vengono ricaricati sotto il lock condiviso
con rotate/revoke, insieme ad assegnazioni e permessi. Solo dopo questa autorizzazione
fresca vengono letti rete/tenant attivi e decifrata la chiave client. Il profilo rimane in
memoria e la risposta vieta cache e validatori; audit registra solo identità, scope ed
esito. Chiavi, profilo, envelope ed errori crittografici non entrano in audit o Problem
Details. Il solo endpoint individuale impedisce export massivi e non carica mai la chiave
privata server.

## Bootstrap admin/admin

È accettato solo per aderire al requisito iniziale. L'account ha
`must_change_password=true`; finché non cambia password, può accedere unicamente da
loopback e solo alla pagina di cambio password. In produzione il bootstrap dovrebbe
accettare una password da stdin o generarla casualmente. La UI non può essere esposta
prima del cambio.

Il controllo loopback usa l'indirizzo forwarded soltanto se il peer immediato è locale o
se è stata abilitata esplicitamente la modalità proxy Unix. In produzione Caddy raggiunge
Gunicorn sul socket `0660`, sovrascrive gli header forwarded e il servizio imposta
`WG_PORTAL_TRUST_UNIX_PROXY=true`; senza opt-in, un peer privo di indirizzo resta
`unknown`. Gunicorn non deve essere pubblicamente raggiungibile. Login, logout e cambio
password usano CSRF; logout è esclusivamente POST.

## Autorizzazione object-level

Ogni service deve passare alla policy l'azione e gli UUID di tenant e rete ricavati
dall'oggetto canonico, mai fidarsi del solo scope indicato dal client. Le operazioni su
una rete o un client richiedono sempre entrambi gli scope; gli identificatori mancanti
sono negati. Un manager opera soltanto sulla rete assegnata, mentre un admin opera nei
tenant per cui possiede un'assegnazione esplicita. Cancellazione fisica, export audit e
gestione lifecycle dei tenant rimangono superadmin-only.

Un admin può vedere un utente condiviso quando almeno un'assegnazione ricade nel proprio
tenant. Può modificare solo le assegnazioni comprese nei tenant amministrati e deve
preservare integralmente quelle esterne. La modifica di campi account globali, inclusa la
disabilitazione, è consentita soltanto se amministra tutti i tenant dell'utente. Assegnare
o amministrare un superadmin è sempre riservato a un superadmin. Prima di disabilitare,
declassare o eliminare un superadmin va verificato che ne rimanga almeno uno attivo.

## Network isolation acceptance test

La baseline M2.6 assegna una VRF per rete e genera nomi VRF, route table e tabelle
nftables soltanto da valori canonici validati. Le chain per rete intercettano traffico
input/forward sul master VRF e uscita sulla slave WireGuard; l'output locale viene
controllato su entrambi i passaggi osservati. Non sostituiscono la policy firewall
generale dell'host, ma ogni pacchetto VPN fuori dal CIDR o diretto a LAN, WAN o un'altra
rete viene scartato. L'uso di VRF evita di concedere `CAP_SYS_ADMIN` al helper.
Le verifiche leggono `ip -json -details` e `nft --json`: campi inattesi, master/tabella
discordanti, regole aggiunte/rimosse o forwarding diverso da `1` causano errore. Dei dati
nft vengono esclusi dal confronto solo metadati di versione e handle runtime.

L'interfaccia WireGuard non viene portata `UP` prima che VRF e firewall siano applicati.
Il registry viene aggiornato solo dopo verifica completa. Ogni failure point della
creazione attiva una compensazione verso assenza; sostituzioni e stop ripristinano lo
snapshot precedente quando la scrittura finale del registry fallisce. Collisioni di
VRF/tabella nft non riconducibili alla rete gestita causano rifiuto senza cancellazione.

Il reconciler non deduce l'isolamento dalla sola presenza dell'interfaccia WireGuard:
richiede un'attestazione fresca del helper basata sul registry root-owned e sulla verifica
semantica VRF/nftables. Stati mancanti, legacy o discordanti causano reconcile; payload
duplicati o malformati bloccano il ciclo. Il probe espone soltanto UUID, nome interfaccia,
CIDR, IP hub, route table e stato sintetico, mai configurazioni o chiavi.

L'overlap cross-tenant non dipende da un booleano fornito dalla UI: la validazione accetta
solo la capability versionata `per-network-vrf-v1` del helper. Helper legacy o deployment
parziali non la pubblicano e vengono rifiutati anche dal reconciler. I test di regressione
devono continuare a provare sia raggiungibilità intra-rete sia irraggiungibilità reciproca
tra reti con CIDR identico.

Per due reti A/B: A1 raggiunge A2 via hub; A1 non raggiunge B1, LAN host o Internet via
hub; B replica lo stesso comportamento. Peer disabilitato/revocato perde accesso senza
riavvio degli altri peer. L'acceptance M2.6 sul target Debian ha verificato questi casi
con namespace Linux, inclusi client ostili con route LAN/WAN via VPN e revoca mediante
`wg syncconf` senza variazione dell'ifindex. Senza VRF verificata l'overlap resta rifiutato.

## Stato dei controlli compensativi pre-v1

R20 e R21 hanno rieseguito separatamente i test avversariali sui confini web/API e sui
confini privilegiati/operativi. R21 ha verificato helper, WireGuard/VRF/nftables, storage,
backup/restore, upgrade, package e supply chain con 463 test verdi e una scansione
aggiornata pulita delle 24 dipendenze production hash-locked. Le evidenze sono in
`docs/SECURITY_REMEDIATION_R21_2026-10-15.md` e `docs/evidence/r21/`.

Questi controlli riducono il rischio ma non equivalgono a un audit indipendente. La v1
deve continuare a dichiararsi non auditata; P-005 e P-019 restano rischi alti accettati e
P-018 è chiuso dal package keyring e dal drill di rotazione R24. La pubblicazione nel
canale APT stabile resta subordinata all'acceptance e al GO R25.

La regressione R22 ha inoltre verificato che il delta applicativo dal freeze R18 riguarda
soltanto il binding sessione/revisione utente: helper, engine, storage, recovery,
packaging, tool di release e lock dipendenze non sono cambiati. Gli smoke read-only sul
laboratorio confermano identità del peer helper, capability, hardening systemd, permessi,
health e assenza di risorse gestite residue. Il registro canonico dei limiti accettati e
dei blocker è `docs/RESIDUAL_RISK_REGISTER_R22_2026-10-15.md`.

## Segnalazioni

Non aprire issue pubbliche con dettagli di vulnerabilità o segreti. Prima della release
va aggiunto `SECURITY.md` con il canale privato reale del maintainer e una policy di
supporto versioni.
