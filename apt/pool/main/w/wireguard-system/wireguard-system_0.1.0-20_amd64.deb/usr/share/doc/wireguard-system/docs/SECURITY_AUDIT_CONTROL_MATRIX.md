# Matrice controlli ed evidenze R18

Questa matrice è un indice per l’audit, non un’autocertificazione. “Evidenza” indica una
prova già presente nel repository; “verifica indipendente” descrive ciò che un futuro
audit dovrà confermare. R19 è stato chiuso con waiver, senza audit esterno; R23 ha
allineato la matrice al delta R20–R22 senza trasformare i controlli interni in una
certificazione.

| ID | Controllo e implementazione | Test/evidenza esistente | Verifica indipendente richiesta |
|---|---|---|---|
| AUTH-01 | Password Argon2id, hash dummy, rate limit IP+utente, bootstrap loopback e cambio obbligatorio in `security/authentication.py`, `web/auth.py` | `test_authentication.py`, `test_web_auth.py`, manuali R16/R17 | Enumerazione/timing qualitativo, brute force distribuito, bootstrap remoto e password policy |
| SESS-01 | Sessione vincolata a user ID e revisione canonica, cookie sicuro in produzione, invalidazione su modifica utente, rotazione al login/cambio, CSRF su POST | `test_web_auth.py`, `test_ui.py`, ADR 0100 e remediation R20 | Fixation, logout, revoca utente durante sessione, cookie/header browser e CSRF cross-origin |
| RBAC-01 | `PolicyEngine` deny-by-default e lookup object-level; 404 non enumerabile | `test_rbac.py`, test `*_ui.py`, `test_api_v1.py` | Matrice superadmin/admin multi-tenant/manager e UUID estranei per ogni use case |
| USER-01 | Preserva scope non amministrabili, vieta self-edit/ultimo superadmin e hash password iniziale | `test_user_ui.py`, `test_api_mutation.py`, `test_api_v1.py` | Escalation tramite account condiviso, race sull’ultimo superadmin, mass assignment |
| UI-01 | Autoescape, CSP, frame/object negati, asset same-origin, form chiusi e messaggi redatti | `test_ui.py`, `test_network_ui.py`, `test_client_ui.py`, `docs/UI.md` | XSS persistente/riflesso, clickjacking, duplicate fields, Unicode/HTML ostile |
| API-01 | Bearer machine identity separata, token 256 bit hashato, scadenza/rotazione/revoca | `test_service_accounts.py`, `test_api_v1.py`, drill R13 | Token assente/ignoto/scaduto/ruotato/revocato, timing e persistenza secret |
| API-02 | JSON/query chiusi, limite body, proiezioni allowlistate e Problem Details redatto | `test_api_v1.py`, `test_openapi_contract.py`, drill R14 | Mass assignment, oversize Caddy/Flask, CORS, error disclosure e contract drift |
| API-03 | Idempotency persistente, ETag/If-Match e cursori AEAD scoped | `test_api_mutation.py`, `test_api_v1.py`, `test_api_read.py` | Replay payload diverso, race, cursor tamper/cross-scope/scaduto e quota storage |
| JOB-01 | Quote globali/per identity/scope, stato revisionato e backpressure | `test_jobs.py`, `test_network_actions.py`, `test_client_actions.py` | Saturazione concorrente, retry, collisione job ID e corretto `Retry-After` |
| JOB-02 | Worker ricarica identità/risorse/RBAC e non tratta job come capability | `test_network_worker.py`, drill R13 | Revoca/declassamento/sospensione fra enqueue e consume; nessuna chiamata helper |
| REC-01 | Reconciler system actor ristretto, probe completo, backoff e lock condiviso | `test_network_worker.py`, `test_telemetry.py`, `test_health.py` | Probe parziale/malformato, drift, concorrenza recovery/worker e storm di job |
| HELP-01 | Socket root con mode/owner e `SO_PEERCRED` bilaterale; frame/protocollo chiusi | `test_helper_protocol.py`, unità systemd | Peer UID errato, symlink/socket world-writable, frame oversize/duplicati e timeout |
| CMD-01 | Helper usa solo `/usr/bin/ip`, `/usr/bin/wg`, `/usr/sbin/nft`, argv fissi e niente shell | `test_isolated_executor.py`, `test_isolation_host.py`, `test_engine_probe.py` | Revisione di ogni subprocess/stdin, injection, path/argv controllabili e output segreto |
| ISO-01 | VRF per rete, nft deny-by-default e capability `per-network-vrf-v1` | `test_engine_isolation.py`, `test_isolation_host.py`, `docs/ISOLATION_ACCEPTANCE.md` | Test reale intra-rete, WAN/LAN, CIDR sovrapposti, drift e collisioni |
| ISO-02 | Mutazione compensata, registry root-owned e verifica identità prima del cleanup | `test_isolated_executor.py`, `test_privileged_registry.py` | Fault in ogni fase, rollback incompleto, registry swap/corruzione e risorsa estranea |
| KEY-01 | X25519 + AES-256-GCM, AAD scoped, keyring esterno `0600`, rewrap | `test_keys.py`, `test_key_access.py`, `test_key_rewrap.py` | Nonce/entropia, ciphertext swap, symlink/hardlink, rotazione e memoria/process exposure |
| CFG-01 | Compiler allowlist, chiave pubblica verificata, peer `/32`, niente hook/default route | `test_engine_compiler.py`, `test_client_configuration.py` | Direttive in campi liberi, key mismatch, client revocati e AllowedIPs impropri |
| STORE-01 | JSON schema chiusi, lock, atomic replace/fsync, revisioni e indice derivato | `test_storage.py`, `test_repository.py`, `test_schemas.py` | TOCTOU, link, mode/owner, disco pieno, crash, schema futuro e indice corrotto |
| AUD-01 | JSONL append-only con HMAC chain, intent/esito, rotazione/retention/export | `test_audit.py`, `docs/OPERATIONS.md`, drill incidenti | Delete/reorder/tamper, split stream, rollover, retention e assenza dati sensibili |
| BAK-01 | Bundle dati/segreti separati cifrati `age`, manifest e verify/preflight | `test_backup.py`, `test_restore.py`, `test_recovery.py`, drill DR | Swap/traversal/link, identity errata, bundle incompleto, staging e cleanup secret |
| UPG-01 | Authorization SSHSIG distinta, target binding, recovery set, writer freeze e rete ferma | `test_upgrade_preflight.py`, drill R07–R11 | Replay/scadenza, key/namespace errati, dpkg fault windows, rollback/restore e retry |
| PKG-01 | systemd sandbox, web Unix socket, private Python payload e ABI 3.11 delimitata | `test_systemd_units.py`, `test_debian_packaging.py`, ADR 0098 | `systemd-analyze security`, install/remove, import ABI, permessi e servizi non-root |
| PROXY-01 | Caddy TLS/HSTS, allowlist, forwarded header sovrascritti, body 1MB e mTLS opzionale | `test_caddy_config.py`, drill R14 | Origine ammessa/negata, header ostili, accesso diretto, TLS e request smuggling |
| SUP-01 | Lock hashati, audit/SBOM, inventario `.deb`, provenienza e tree pulito | `test_security_artifacts.py`, `test_release_provenance.py`, `docs/SUPPLY_CHAIN.md` | Rigenerazione su target, advisory correnti, materiali/byproduct e builder compromise |
| SIG-01 | SSHSIG release e upgrade separati per chiave/principal/namespace/revocation | `test_release_signing.py`, cerimonia R06 e R07 | Firma errata/cross-policy/revocata, custody P-019 e verifica offline indipendente |
| APT-01 | `reprepro`, OpenPGP fingerprint, export Pages manifestato, package keyring aggiornabile separato e verifica byte dei package | `test_apt_repository_deployment.py`, `test_apt_keyring_package.py`, ADR 0101 e `docs/APT_REPOSITORY_DEPLOYMENT.md` | Firma/indice/pool, retry interrotto, overwrite e rotazione sovrapposta reale R24; P-018 resta aperto fino a quel drill |
| OBS-01 | Request ID, log strutturato redatto, liveness/readiness e dashboard fail-closed | `test_observability.py`, `test_health.py`, `test_dashboard.py` | Secret/log injection, error path pre-hook, helper down e telemetria ambigua |
| REL-01 | Revision 18 riservata, nessun artefatto prematuro e package audit deterministico | `test_audit_package.py`, ADR 0098, verbale R18 | Ricalcolo manifest/archive, corrispondenza commit e assenza file privati/build 18 |

## Criterio di copertura

Un test automatico verde dimostra una regressione nota, non l’assenza di altri percorsi.
I risultati R20–R23 sono controlli compensativi interni; un controllo sarà verificato
indipendentemente soltanto quando un revisore esterno registrerà metodo ed esito sul
commit effettivamente rilasciato. Ogni finding deve riferire uno o più ID; un’area non
rappresentabile riceve un nuovo ID nel report senza modificare retroattivamente le
evidenze storiche.
