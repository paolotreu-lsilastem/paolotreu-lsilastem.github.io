# Freeze sorgente e pacchetto audit R18 — 2026-10-15

## Esito

R18 è chiusa sul target immutabile:

```text
d09bce0741b6d458385d7e84dde5767642620f04
```

Il target è un candidate per audit, non una release approvata. La revisione Debian
`0.1.0-18` è riservata, dichiara come unico predecessore `0.1.0-17`, ma non è stata
costruita, firmata o pubblicata. Questo verbale è intenzionalmente successivo al target:
lo identifica senza creare un riferimento circolare nel sorgente auditato.

## Artefatto consegnabile

| Campo | Valore |
|---|---|
| Archivio | `wireguard-system-audit-d09bce0741b6.tar.gz` |
| SHA-256 archivio | `790c762f5b4d7980f123a2902778dcd89475fe7dac63591d2c8a312e22afdfe2` |
| Dimensione | 826.980 byte |
| SHA-256 manifest sorgente | `f33e38e2839391cde207daa56b92da14644a715baffb2a384897ecee9c6be53b` |
| File versionati | 393 |
| ADR | 98 |
| Package riservato | `wireguard-system 0.1.0-18`, `built=false` |

L'archivio esterno contiene `AUDIT-INVENTORY.json`, `README.txt`,
`SOURCE-MANIFEST.sha256` e l'archivio Git del target. Due generazioni in directory
distinte hanno prodotto lo stesso SHA-256 e `cmp` byte-per-byte è riuscito. Il checksum
esterno e tutti i 393 record del manifest sono stati verificati dopo una nuova estrazione.
L'output locale ha mode `0600`; gli artefatti restano ignorati da Git.

Il generatore rifiuta worktree sporchi, commit diverso da `HEAD`, path non canonici,
documenti obbligatori mancanti, marker di chiavi private all'inizio di riga e artefatti
tracciati della revisione riservata. P-033 documenta il primo target preliminare rifiutato
dal controllo stesso; P-034 documenta il successivo conteggio route obsoleto. Solo il
commit e l'hash riportati sopra sono consegnabili per R19.

## Gate automatici

Sul commit target:

- Ruff: verde;
- Mypy: verde su 75 file sorgente/tool;
- contratto OpenAPI packaged: byte-identico e valido;
- drill compatibilità: modifica additiva accettata, rimozione operazione rifiutata;
- Pytest: 1.056 test superati, uno saltato perché l'integrazione `reprepro` reale è
  opt-in; copertura complessiva 84%;
- enumerazione Flask: 64 regole totali, 63 applicative oltre `static`, 80 combinazioni
  metodo-route applicative; il revisore deve acquisire l'elenco, non fidarsi dei conteggi;
- audit dipendenze del 2026-10-15: pulito su tutti i 24 requirement hashati con
  `pip-audit 2.10.1`.

Artefatti supply-chain rigenerati:

| Evidenza | SHA-256 |
|---|---|
| `python-audit.json` | `82a195448eb5d207856233111106256d337d8882f9b3dafe94a759ea8ae5bde1` |
| `python-sbom.cdx.json` | `883207f46fbf062db349d6d81b51a8d59e8ba5d0bf561ecf2e09000e44719031` |
| `manifest.json` | `c5a1808ffb519c28949507ca0384f6baa664e625d77b896f8f838694cd9d21b4` |

La scansione advisory è temporale e deve essere rigenerata dal revisore. Il test APT
saltato non sostituisce i drill reali già acquisiti e non autorizza il canale stabile.

## Review interna

La review ha coperto dossier, threat model, superficie privilegiata, crypto, storage,
UI/API, isolamento, recovery/upgrade, packaging e supply chain tramite la
[matrice dei controlli](SECURITY_AUDIT_CONTROL_MATRIX.md). Le ricerche sul target non
hanno trovato `shell=True`, `os.system`, `eval`, `exec`, `pickle`, `yaml.load`, debug
Flask forzato, TODO/FIXME nei percorsi eseguibili o nomi di file privati tracciati.

Sono presenti 79 riferimenti a primitive `subprocess` in codice e tool: il dato definisce
una superficie di review, non una certificazione. CMD-01 richiede al revisore di seguire
ogni executable, argv, stdin, timeout e ramo errore. La review interna ha inoltre chiuso:

- P-028, delimitando il futuro package a Python `>=3.11, <<3.12`;
- P-032, allineando la descrizione CSP alla policy same-origin reale;
- P-033, correggendo il falso positivo dello scanner segreti;
- P-034, sostituendo il conteggio route manuale con l'enumerazione runtime.

## Limiti e handoff R19

Restano esplicitamente aperti P-005 (audit indipendente), P-007 (nessuna sicurezza
assoluta), P-018 (keyring APT aggiornabile prima del canale stabile) e P-019 (custodia
SSHSIG non più esclusivamente air-gapped, rischio accettato dal maintainer).

Il revisore riceve archivio, checksum e il [dossier autonomo](SECURITY_AUDIT_PACKAGE.md),
parte dalla [matrice](SECURITY_AUDIT_CONTROL_MATRIX.md) e restituisce un report datato
con commit, scope, metodo, ambiente, finding, severità, prove e remediation. R20/R21 sono
riserva per le remediation; nessun finding `critical` o `high` può essere ignorato o
riclassificato unilateralmente dal maintainer.
