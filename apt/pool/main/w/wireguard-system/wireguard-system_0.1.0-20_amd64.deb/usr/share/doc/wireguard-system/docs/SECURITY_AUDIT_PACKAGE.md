# Dossier per l’audit di sicurezza indipendente

Questo documento è il punto di ingresso autonomo per il revisore R19. Definisce oggetto,
confini, inventario, prove disponibili, limiti e formato dell’esito. Non presuppone un
briefing orale. Il target esatto è dichiarato in `AUDIT-INVENTORY.json` nel pacchetto
generato da `scripts/prepare-audit-package.py`; la chiusura R18 ne registra commit e
SHA-256 senza attribuire al target lo stato di release.

## Identità e stato del target

- progetto: WireGuard System, AGPL-3.0-or-later;
- piattaforma v1: Debian 12 Bookworm `amd64`, Python di sistema 3.11;
- storage applicativo: soli file JSON/JSONL atomici, nessun database SQL;
- package riservato: `wireguard-system 0.1.0-18`, non costruito né pubblicato in R18;
- upgrade dichiarato dal futuro package: esclusivamente `0.1.0-17 → 0.1.0-18`;
- maturità: candidate per audit, non approvato per produzione;
- gate ancora obbligatori: audit R19, remediation R20–R21, regressione R22, chiusura
  documentale R23, build/firma offline R24 e acceptance R25.

La revisione 18 è una prenotazione. Il pacchetto di audit contiene sorgente e trust
pubblico, non `.deb`, chiavi private, recovery identity, configurazioni live o dati del
laboratorio. P-030 e P-031 sono presenti nel sorgente auditato ma non nel package testing
storico `0.1.0-17`.

## Obiettivi dell’audit

Il revisore deve stabilire se un attore remoto, un utente autenticato, un service account,
un client VPN o un processo web compromesso può:

1. superare autenticazione, scope RBAC o isolamento tenant/rete;
2. ottenere password, bearer token, chiavi WireGuard, master key o backup in chiaro;
3. trasformare input UI/API/storage in comando, path o configurazione root arbitrari;
4. aggirare revisione, idempotenza, quote o rivalidazione dei job asincroni;
5. uscire dalla VPN a stella, raggiungere WAN/LAN o attraversare una rete di altro tenant;
6. corrompere file, audit, restore o upgrade ottenendo uno stato dichiarato sano;
7. sostituire package, provenienza, trust release/upgrade o repository APT;
8. ricavare dati sensibili da errori, log, cache, dashboard o differenze di risposta.

Il lavoro deve comprendere review statica e test dinamici in un laboratorio sacrificabile.
Non è accettabile usare dati o reti di produzione. Finding, severità e prove restano del
revisore: il maintainer non deve reinterpretare un finding per abbassarne la priorità.

## Modello di minaccia autoritativo

Il modello principale è [SECURITY.md](SECURITY.md), inclusa la tabella API v1. Le
decisioni normative sono in [USER_DECISIONS.md](USER_DECISIONS.md); architettura e flussi
sono in [ARCHITECTURE.md](ARCHITECTURE.md) e [DATA_MODEL.md](DATA_MODEL.md). I 98 ADR in
`docs/decisions/` spiegano le scelte e non prevalgono sui documenti correnti quando
descrivono uno stato storico.

Asset ad alta sensibilità:

- chiavi private client/server, master keyring e recovery identity;
- password hash, session cookie e bearer token API;
- mapping tenant/rete/client, endpoint osservati e timestamp handshake;
- audit HMAC e catene JSONL;
- socket helper, registry root-owned e capacità `CAP_NET_ADMIN`;
- chiavi SSHSIG release/upgrade e chiave OpenPGP APT;
- authorization monouso, backup cifrati e ricevute di upgrade/restore.

Avversari nel perimetro: anonimo intranet, utente legittimo ostile, service account
compromesso, client WireGuard compromesso, processo Flask/worker compromesso, operatore
locale non root e maintainer/build host compromesso. Root già compromesso, firmware,
kernel malevolo, hypervisor e disponibilità fisica sono fuori dal controllo applicativo,
ma vanno indicati come assunzioni, non come proprietà garantite.

## Architettura e confini di fiducia

```text
Browser/API client
        │ HTTPS + allowlist/mTLS opzionale
        ▼
      Caddy ── Unix socket ──► Gunicorn/Flask (wg-portal, senza capability)
                                  │
                JSON/JSONL ◄──────┼──────► worker/reconciler (wg-portal)
                                  │ protocollo JSON v1 + SO_PEERCRED
                                  ▼
                         helper socket root, una richiesta
                                  │ argv fissi / stdin validato
                                  ▼
                         ip + wg + nft + kernel Linux
```

Confini separati aggiuntivi:

- data tree `/var/lib/wg-portal` e keyring/configurazione sotto `/etc/wg-portal`;
- registry privilegiato `/var/lib/wg-portal-helper/registry.json`;
- backup `age` separati per dati e segreti;
- build workstation, postazione offline SSHSIG e repository APT firmato;
- request di upgrade firmata dall’operatore, distinta dalla firma release.

Il browser non comunica con il helper. L’adattatore API/UI non invoca endpoint HTTP
interni: costruisce un principal e usa il service layer. Un job non è una capability; il
worker ricarica identità e oggetti e ripete l’autorizzazione prima dell’effetto.

## Inventario del codice da revisionare

`AUDIT-INVENTORY.json` elenca ogni path versionato, categorie, ADR e hash del manifest.
La review non deve limitarsi ai file elencati qui; questi sono gli entry point prioritari.

| Area | Entry point principali | Domande minime |
|---|---|---|
| App factory/config | `src/wg_portal/__init__.py`, `config.py`, `health.py` | Avvio fail-closed, segreti obbligatori, debug assente, readiness attendibile |
| Autenticazione/RBAC | `security/authentication.py`, `security/api_tokens.py`, `security/rbac.py`, `web/auth.py` | Enumerazione, brute force, session fixation, self-escalation, scope compositi |
| UI/API | `web/*.py`, `services/api_*.py`, `openapi*.py` | CSRF, XSS, IDOR/BOLA, mass assignment, cache, errori, contratto reale |
| Storage/audit | `storage.py`, `repository.py`, `audit.py`, `migrations.py` | Symlink/hardlink, TOCTOU, lock, atomicità, rollback, catena e retention |
| Chiavi/config | `security/keys.py`, `services/key_*.py`, `engine/compiler.py` | Entropia, AAD, nonce, key substitution, download e redazione |
| Job | `services/jobs.py`, `network_actions.py`, `client_actions.py`, `network_worker.py`, `reconciler.py` | Replay, race, revoca dopo enqueue, quote, stato parziale |
| Helper | `helper.py`, `engine/helper_protocol.py`, `isolated_executor.py` | Peer credential, parser, framing, timeout, rollback, output/secret leakage |
| Host/isolamento | `engine/mutations.py`, `isolation*.py`, `probe.py`, `registry.py` | argv/stdin, collisioni, drift, VRF/nftables, forwarding, cleanup |
| Recovery/upgrade | `backup.py`, `restore.py`, `recovery.py`, `scripts/upgrade-preflight.py`, maintainer script Debian | Path traversal, bundle swap, journal, writer freeze, dpkg fault windows |
| Supply chain | `requirements*.lock`, `scripts/security-artifacts.py`, `release-*.py`, `deploy-apt-package.py` | Lock/hash, SBOM, provenance, firme, trust separation, publication race |
| Deployment | `packaging/systemd/`, `packaging/caddy/`, `packaging/debian/` | Privilegi, socket, sandbox, header proxy, ABI, install/upgrade/remove |

Il revisore deve enumerare a runtime tutte le route Flask dichiarate nel target e
includere nell'evidenza il relativo elenco, oltre a tutti gli schemi JSON packaged. Le
route effettive vanno confrontate con OpenAPI, RBAC e test negativi; un conteggio manuale
non costituisce copertura e non viene usato come contratto.

## Superficie privilegiata

Il solo processo applicativo root è l’istanza socket-activated
`wg-portal-helper@.service`. Ha `CAP_NET_ADMIN`, `NoNewPrivileges=yes`, filesystem
protetto, device chiusi, runtime massimo 30 secondi e accetta soltanto il peer Unix
`wg-portal` verificato anche con `SO_PEERCRED`. Il socket è `0660 root:wg-portal`.

Il helper può eseguire soltanto:

- `/usr/bin/ip` per link, indirizzi, VRF e verifiche netlink;
- `/usr/bin/wg` per `setconf`, `syncconf`, show e snapshot controllati;
- `/usr/sbin/nft` con policy generata e passata su stdin.

Non sono ammessi shell, argv forniti dal chiamante, path di configurazione, unità systemd
o hook WireGuard. La configurazione privata passa in memoria/stdin e non viene scritta dal
helper. Il revisore deve verificare ogni costruzione argv, grammatica stdin, rollback e
ramo errore, incluso `ROLLBACK_FAILED`.

Web, worker e reconciler girano come `wg-portal` senza capability. I maintainer script di
installazione, restore e upgrade sono invece eseguiti da root e fanno parte della
superficie privilegiata anche se non sono raggiungibili dalla UI.

## Crittografia e gestione dei segreti

- password e token API: Argon2id; token opachi da 256 bit, durata massima 90 giorni;
- private key WireGuard: X25519, envelope AES-256-GCM con nonce casuale e AAD scoped;
- cursori API: AES-256-GCM con chiave separata per dominio;
- audit: catena HMAC; chiave separata o derivata con domain separation;
- backup: `age` X25519, bundle dati e segreti separati;
- release e authorization upgrade: SSHSIG Ed25519 con principal/namespace distinti;
- repository APT: OpenPGP e `Signed-By` dedicato.

Le primitive non provano da sole una custodia sicura. Verificare permessi, symlink,
hardlink, lifecycle, rotazione, backup, cancellazioni temporanee, error path e process
memory. Il rischio P-019 registra che copie delle chiavi SSHSIG sono state portate sul PC
di sviluppo per scelta esplicita del maintainer: non descrivere più la custodia come
esclusivamente air-gapped.

## Storage, audit e privacy

I documenti canonici usano schema chiuso, UUID, revisione e scrittura atomica sotto lock.
Gli indici e la presence cache sono derivati e ricostruibili. Le chiavi master e la
configurazione ambiente sono esterne al data tree. Il revisore deve tentare almeno:

- file symlink/hardlink, directory sostituita, mode/owner errati e path traversal;
- JSON duplicato, schema futuro, indice corrotto, lock contention e disco pieno;
- lost update, retry concorrente, crash fra intent/esito e recovery successivo;
- modifica/rimozione/riordino dell’audit attivo o archiviato;
- endpoint/handshake/chiavi/token/password in log, errori, audit, HTML, cache o backup
  sbagliato.

La retention audit operativa è 30 giorni, con rotazione giornaliera, compressione/export
nativo e cancellazione definitiva a tre mesi. La cache presence è telemetria derivata;
`online dal` è una stima, non una sessione attestata.

## API, UI e proxy

Il contratto normativo è `docs/openapi/v1.yaml`; la copia packaged deve essere
byte-identica e compatibile con la baseline v1. L’API usa bearer token distinti dagli
account browser, permessi espliciti, schemi chiusi, idempotency key, ETag/If-Match, cursor
scoped, rate limit e quote job. Il download della configurazione richiede permesso
dedicato e nuova validazione dell’identità.

La UI usa session cookie, CSRF su ogni POST, autoescape, CSP same-origin e pagine errore
redatte. Caddy termina TLS, sovrascrive gli header forwarded, impone body `1MB` e
allowlist intranet; mTLS è opzionale. L’esposizione diretta a Internet non è supportata.

Testare almeno login/token inesistente, timing qualitativo, CSRF, session fixation,
clickjacking, XSS persistente/riflesso, header host/forwarded, request smuggling al confine
Caddy/Gunicorn, body oversize, CORS, IDOR per ogni ruolo, account multi-tenant, revoca fra
enqueue/consume, replay idempotente e response cache.

## Isolamento WireGuard

Ogni rete usa interfaccia WireGuard, VRF dedicata e policy nftables deny-by-default. Sono
ammessi input/output dell’hub e forwarding fra peer sulla stessa interfaccia; WAN, LAN e
inter-rete sono negati. I client ricevono esclusivamente il CIDR VPN come `AllowedIPs`,
mai una default route. CIDR uguali fra tenant sono ammessi solo con capability
`per-network-vrf-v1` completamente verificata.

Il revisore deve validare sul kernel Debian 12: traffico client↔client, isolamento tra due
tenant con CIDR sovrapposto, tentativi WAN/LAN, collisione interfaccia/VRF/table, drift
manuale, stop e cleanup. Un mock non sostituisce questa parte.

## Build, update e trust

`requirements-prod.lock` e `requirements-release.lock` sono hash-lock. La pipeline
costruisce wheel e `.deb`, audit/SBOM, inventario e provenienza da worktree pulito. La
provenienza locale è coerente ma non rivendica un livello SLSA e non autentica il builder
finché il bundle non è firmato offline.

Release e upgrade authorization usano chiavi/principal/namespace distinti. L’upgrade
richiede package e rollback attestati, recovery set cifrato verificato, target binding,
writer freeze, reti ferme, spazio e ricevute monouso. Il verifier offline deve essere
provato anche su postazione senza rete.

P-018 resta blocker del canale stabile: la keyring APT client non è ancora distribuita da
un package aggiornabile. R23/R24 devono implementare e far revisionare il delta, poi
provare rinnovo e rotazione sovrapposta prima della scadenza 2028-10-12. La repository
`bookworm-testing` non è il canale stabile.

## Matrice controlli ed evidenze

La [matrice R18](SECURITY_AUDIT_CONTROL_MATRIX.md) lega ogni controllo a implementazione,
test ed evidenze reali. La colonna “verifica indipendente” è lavoro richiesto, non una
certificazione già ottenuta. Evidenze storiche dimostrano il comportamento dei commit
indicati nei relativi verbali; non trasferiscono automaticamente il risultato al target
R18.

Evidenze prioritarie:

- `docs/ACCEPTANCE_TEST.md` e `docs/ISOLATION_ACCEPTANCE.md`;
- `docs/DISASTER_RECOVERY_DRILL.md` e `docs/INCIDENT_DRILL.md`;
- `docs/M4_4_CLOSURE.md` e drill R07–R11;
- `docs/API_CREDENTIAL_COMPROMISE_DRILL.md`;
- `docs/CADDY_EXPOSURE_DRILL_R14_2026-10-14.md`;
- manuali e verifiche R16–R17;
- `docs/RELEASE_SIGNING_CEREMONY_2026-10-13.md`.

## Riproduzione

Su una macchina di review senza segreti:

1. verificare lo SHA-256 esterno del pacchetto;
2. estrarre il pacchetto e poi l’archivio sorgente;
3. dalla radice sorgente eseguire
   `sha256sum --check ../SOURCE-MANIFEST.sha256`;
4. confrontare commit, versione, predecessore, conteggi e manifest con
   `AUDIT-INVENTORY.json`;
5. creare il virtualenv con `scripts/bootstrap.sh` ed eseguire `scripts/check.sh`;
6. rigenerare audit dipendenze/SBOM secondo [SUPPLY_CHAIN.md](SUPPLY_CHAIN.md);
7. eseguire test dinamici privilegiati soltanto su Debian 12 isolato seguendo
   [LOCAL_TEST_ENVIRONMENT.md](LOCAL_TEST_ENVIRONMENT.md).

La scansione advisory richiede dati correnti e può quindi produrre un risultato diverso
da quello R18. Ogni finding nuovo blocca la release; non è ammessa una allowlist implicita.

## Limiti e blocker dichiarati

- P-005: audit indipendente non ancora eseguito;
- P-007: nessuna garanzia di “sicurezza assoluta” è possibile;
- P-018: lifecycle aggiornabile della keyring APT ancora aperto;
- P-019: custodia SSHSIG non più esclusivamente offline, rischio accettato dal maintainer;
- nessuna MFA/WebAuthn nella v1;
- niente IPv6, alta disponibilità, container o esposizione Internet;
- schema dati 1: il drill prova migrazione no-op, non compatibilità cross-schema futura;
- supporto solo Debian 12 Bookworm `amd64`; il metadata del futuro package limita Python
  a `>=3.11, <<3.12`;
- builder self-hosted, nessuna attestazione indipendente SLSA;
- availability e compromissione root/kernel/hypervisor non sono risolte dall’applicazione.

## Consegna del report

Il report R19 deve riportare: revisore e indipendenza, data, commit completo, ambiente,
scope incluso/escluso, strumenti e metodo, test eseguiti, limiti, finding con ID e prova,
severità, impatto, riproduzione e remediation consigliata. Usare almeno `critical`,
`high`, `medium`, `low`, `informational`; motivare la classificazione.

R20/R21 non possono chiudere un `critical` o `high` senza correzione verificata oppure
rifiuto esplicito del rischio al gate finale. R22 riesegue regressione e pubblica rischi
residui; R23 richiede al revisore la review del delta prima di fissare il commit approvato.
