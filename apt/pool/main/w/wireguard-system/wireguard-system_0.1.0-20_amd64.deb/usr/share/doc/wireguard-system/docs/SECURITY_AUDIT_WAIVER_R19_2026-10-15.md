# Waiver audit indipendente R19 — 2026-10-15

## Esito corretto

R19 è chiuso per decisione esplicita del maintainer, **senza audit indipendente**. Non
esiste un report esterno, non sono stati assegnati finding da un revisore e il bundle R18
non è stato certificato. La motivazione dichiarata è l'indisponibilità di risorse insieme
a una scadenza di consegna ravvicinata.

La decisione canonica è registrata in [USER_DECISIONS.md](USER_DECISIONS.md) e motivata
nell'[ADR 0099](decisions/0099-v1-independent-audit-waiver.md). Il target e il bundle
preparati restano identificati nel
[verbale R18](SECURITY_AUDIT_FREEZE_R18_2026-10-15.md), senza modificarne retroattivamente
lo stato.

## Rischio accettato

P-005 passa da blocco esterno a rischio residuo alto accettato per la v1. La review
interna, i test automatici e i drill privilegiati possono non individuare vulnerabilità
nelle seguenti aree:

- autenticazione, sessioni, RBAC e IDOR cross-tenant;
- parser, socket e comandi del helper root;
- isolamento WireGuard/VRF/nftables;
- storage file-backed, chiavi, backup e restore;
- upgrade, maintainer script, package e supply chain;
- confine Caddy/Gunicorn e comportamento dinamico UI/API.

Non è quindi consentito dichiarare la v1 auditata, certificata o immune da vulnerabilità.

## Controlli compensativi obbligatori

R20 e R21 restano unità reali, non vengono saltate. In assenza di finding esterni devono
rieseguire e documentare test avversariali interni per tutte le aree elencate nella
[matrice R18](SECURITY_AUDIT_CONTROL_MATRIX.md), includendo almeno casi negativi,
concorrenza, corruzione, revoca dopo enqueue, fault/rollback e confini privilegiati.

R22 deve pubblicare il registro dei rischi residui e confermare che nessun problema
critico/alto **interno noto** sia aperto. R23 deve riportare la deroga nei documenti
utente e release; R25 deve includerla esplicitamente nel verbale `GO/NO-GO`.

## Attività futura

L'audit indipendente resta il primo debito di assurance post-v1 quando saranno disponibili
risorse. Dovrà esaminare il commit realmente rilasciato, ricevere il dossier e produrre un
report autonomo. Un audit futuro non modifica retroattivamente lo stato della v1 iniziale.
