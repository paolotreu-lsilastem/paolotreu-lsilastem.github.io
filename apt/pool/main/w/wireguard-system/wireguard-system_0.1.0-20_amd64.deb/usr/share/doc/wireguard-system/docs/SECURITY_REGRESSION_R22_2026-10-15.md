# Verbale R22 — regressione e smoke privilegiati

Data: 2026-10-15

Baseline sorgente iniziale: `70ee821` (`Close R21 privileged security review`)

Target laboratorio: `root@vrt-debian1.lsinet.it`, Debian 12, package `0.1.0-17`

Esito: **chiuso; nessun finding interno critico/alto non accettato aperto**

## Confine della verifica

R22 è una regressione interna post-waiver, non un audit indipendente. Il confronto tra il
freeze R18 `d09bce0741b6d458385d7e84dde5767642620f04` e la baseline R22 mostra un solo
file applicativo modificato: `src/wg_portal/web/auth.py`, per il binding della sessione
alla revisione utente di P-035. Helper, engine WireGuard/isolamento, storage, backup,
recovery, restore, packaging, script di release e lock dipendenze sono invariati.

Ne consegue che R20 non ha ampliato operazioni privilegiate, argv, capability, formati
persistiti o superficie di rete. R21 e R22, fino al presente verbale, aggiungono soltanto
documentazione, evidenze e test.

## Inventario e smoke Debian

L'inventario iniziale e gli smoke successivi sono stati esclusivamente read-only:

- `wireguard-system 0.1.0-17` installato, `dpkg --audit` e `dpkg -V` puliti;
- systemd `running`; web/socket, helper socket, reconciler, health timer e Caddy attivi;
- `doctor`, catena audit su due giornate, reconciler health, `/healthz` e `/readyz` verdi;
- recovery `no_pending_transaction`, senza authorization, claim o next action;
- helper probe come `wg-portal` verde con capability `per-network-vrf-v1`;
- probe helper come root e `nobody` entrambi negati con exit `1`;
- `systemd-analyze verify` pulito; helper root limitato a `CAP_NET_ADMIN`, web e
  reconciler senza capability, `NoNewPrivileges=yes` e `ProtectSystem=strict`;
- data tree `0700 wg-portal:wg-portal`, registry directory `0700 root:root`, registry
  `0600 root:root`, environment `0640 root:wg-portal`, keyring `0600 wg-portal:wg-portal`,
  socket helper `0660 root:wg-portal` e socket web `0660 wg-portal:caddy`;
- registry vuoto con SHA-256
  `571bb8f03c7fffff060975bf63455c80bb54d47e7c30dfc30b7ab5f1ebdd7d72`;
- nessun link WireGuard, VRF o tabella nftables `wgp_`; IPv4 forwarding `0`.

P-036, P-037 e P-038 registrano tre falsi negativi dell'harness: quoting di
`dpkg-query`, frontend errato per recovery status e interrogazione del nome template
systemd. Tutti si sono fermati senza mutazioni e i retry corretti sono verdi.

## Regressione locale

Il gate conclusivo ha superato Ruff, Mypy, controllo e drill di compatibilità OpenAPI,
con **1.074 test passati**, un solo test APT reale opt-in saltato e copertura complessiva
84%. L'integrazione APT resta assegnata a R24/R25, dove sono disponibili repository, GPG
e candidate finale.

## Esito

Non risultano finding interni critici o alti non accettati aperti. I rischi accettati e i
limiti non vengono riclassificati come risolti: sono elencati nel registro R22. Il package
testing `0.1.0-17` non contiene il delta R16–R22 e non è autorizzato per produzione. R23
deve allineare tutta la documentazione sul commit final-candidate prima della build.
