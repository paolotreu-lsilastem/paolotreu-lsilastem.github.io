# Remediation e gate avversariale R20 — 2026-10-15

## Scope

R20 applica i controlli compensativi successivi al waiver R19 alle aree autenticazione,
sessioni, RBAC/IDOR, utenti, UI, API, job asincroni e segreti. È una review interna e non
sostituisce l'audit indipendente mancante registrato in P-005.

Controlli R18 riesaminati: `AUTH-01`, `SESS-01`, `RBAC-01`, `USER-01`, `UI-01`,
`API-01`, `API-02`, `API-03`, `JOB-01`, `JOB-02`, `KEY-01` e `CFG-01`.

## Finding interno

La review ha rilevato P-035, severità alta: i cookie browser non erano vincolati alla
revisione dell'utente e una seconda sessione poteva restare valida dopo un cambio
password fino alla scadenza configurata.

La correzione salva `user_id` e `user_revision` nel cookie firmato, ricarica il documento
canonico a ogni richiesta e cancella fail-closed sessioni legacy, manomesse o stale.
Cambio password, disabilitazione o modifica amministrativa invalidano quindi i cookie
precedenti. ADR 0100 registra il trade-off e i test coprono due browser concorrenti,
revisione assente, stringa, booleano, zero, futura e sessione aggiornata valida.

## Gate eseguito

Il 2026-10-15 è stato eseguito:

```text
.venv/bin/pytest -q \
  tests/test_authentication.py tests/test_web_auth.py tests/test_rbac.py \
  tests/test_user_ui.py tests/test_ui.py tests/test_api_v1.py \
  tests/test_api_read.py tests/test_api_mutation.py \
  tests/test_service_accounts.py tests/test_service_account_ui.py \
  tests/test_jobs.py tests/test_network_worker.py tests/test_keys.py \
  tests/test_key_access.py tests/test_key_rewrap.py \
  tests/test_client_configuration.py
```

Esito: **257 test superati**.

| Area | Casi avversariali rieseguiti | Esito |
|---|---|---|
| Autenticazione/sessioni | enumerazione, CSRF, bootstrap remoto, rate limit, fixation/rotazione, revisione stale | Verde; P-035 risolto |
| RBAC/utenti | matrici dei tre ruoli, multi-tenant, self-edit, ultimo superadmin, scope estraneo | Verde |
| UI | XSS per costruzione, CSP, errori redatti, query/form chiusi, IDOR non enumerabile | Verde |
| API | token ignoto/scaduto/ruotato/revocato, cursori tamper/scoped, JSON/query chiusi, ETag | Verde |
| Idempotenza/job | replay diverso, quota, pending, revoca fra enqueue/consume, backpressure | Verde |
| Segreti | hash-only, token one-time, AEAD tamper/AAD/nonce, keyring link/mode, download scoped | Verde |

Il quality gate completo successivo è verde: Ruff, Mypy e contratto OpenAPI superati;
1.068 test passati, una sola integrazione APT reale opt-in saltata e copertura totale 84%.

## Esito e limiti

Non restano finding interni critici o alti noti nel perimetro R20. Questo significa
soltanto che le regressioni e i percorsi esaminati sono verdi; timing quantitativo,
browser automation ostile, fuzzing esteso e creatività di un revisore indipendente non
sono sostituiti. P-005 resta accettato, non risolto. Helper root, rete/isolamento,
storage/recovery, package e supply chain passano al gate separato R21.
