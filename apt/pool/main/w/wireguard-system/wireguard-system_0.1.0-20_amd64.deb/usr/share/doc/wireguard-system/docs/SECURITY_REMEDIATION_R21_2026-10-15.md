# Verbale R21 — secondo controllo compensativo interno

Data: 2026-10-15

Baseline applicativa verificata: `31042f4` (`Close R20 adversarial remediation gate`)

Ambiente: WSL Debian 12, Python 3.11, systemd 252

Esito: **chiuso; nessun finding interno critico o alto noto nello scope R21**

## Limite di assurance

Questo verbale documenta una review interna assistita e non sostituisce l'audit
indipendente rinviato in R19. Non autorizza a descrivere il prodotto come auditato,
certificato o sicuro in modo assoluto. P-005 e P-019 restano rischi alti accettati; P-018
resta release blocker per il canale APT stabile.

## Scope e metodo

La review ha coperto:

- autenticazione bilaterale UID e protocollo JSON chiuso del helper root;
- grammatica WireGuard, argv assoluti, assenza di shell e limiti di input/output;
- transazioni e rollback di WireGuard, VRF e nftables, incluso drift fail-closed;
- path confinement, lock, scritture atomiche, permessi e gestione dei symlink nello
  storage JSON e nel registry privilegiato;
- cifratura streaming, inventario, estrazione confinata, journal e rollback di
  backup/restore;
- guard di upgrade, stato dpkg, packaging Debian, provenance, firma e repository APT;
- lock hashati, audit vulnerabilità e SBOM delle dipendenze production.

Sono stati cercati esplicitamente shell interpolation, eseguibili o argv controllabili,
path traversal, leaf/intermediate symlink, estrazione archivio non confinata, file mode
eccessivi, output illimitato, parsing ambiguo, commit parziali e rollback incompleti.

## Evidenze automatiche

La suite mirata ha superato **463 test**. L'unico skip è
`test_real_apt_repository_update_from_export`, integrazione reale opt-in che richiede
`WG_PORTAL_RUN_APT_INTEGRATION=1`, `reprepro` e GPG; resta assegnata a R24/R25. Le aree
incluse sono helper protocol, executor isolato, isolation probe, compiler/probe,
network worker, storage/repository, backup/recovery/restore, upgrade, packaging,
provenance, firma, repository APT e audit package.

Il quality gate conclusivo ha inoltre superato Ruff, Mypy e i controlli OpenAPI, con
**1.071 test passati**, lo stesso singolo skip APT opt-in e copertura complessiva 84%.

La scansione aggiornata eseguita con `pip-audit 2.10.1` ha verificato tutte le **24
dipendenze** di `requirements-prod.lock` e ha rilevato **0 vulnerabilità note**. Il lock
ha SHA-256 `83a7c1fed4cfedf6ae14d21ce98395676cb59673a2966a8edb66f7461a98a28f`.
Le evidenze versionate sono:

- `docs/evidence/r21/manifest.json`;
- `docs/evidence/r21/python-audit.json`;
- `docs/evidence/r21/python-sbom.cdx.json`.

`systemd-analyze security --offline=yes` su systemd 252 ha classificato tutte le unità
come `OK`: helper `4.5`, web `3.9`, reconciler `3.8`, health `3.8`. I punteggi sono una
misura euristica di hardening, non attestazioni di assenza di vulnerabilità. Il helper
resta intenzionalmente root con il solo `CAP_NET_ADMIN`; web e reconciler restano utenti
non privilegiati e senza capability.

## Esito della review

Non sono emersi finding critici o alti che richiedano remediation in R21. I controlli
esistenti hanno fallito chiuso nei casi ostili già codificati e non sono state ampliate
capability, operazioni helper, formati persistiti o superfici di rete.

R21 è quindi chiuso. R22 deve eseguire la regressione completa post-review e gli smoke
privilegiati interessati, poi pubblicare il registro conclusivo dei rischi residui. Il
candidate `0.1.0-18` resta non costruito e non firmato fino ai gate successivi.
