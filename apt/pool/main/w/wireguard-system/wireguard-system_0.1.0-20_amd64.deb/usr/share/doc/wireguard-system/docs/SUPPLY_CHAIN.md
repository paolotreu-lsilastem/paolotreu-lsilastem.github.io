# Supply chain e artefatti di sicurezza

Questo documento definisce i gate M4.4 per dipendenze Python, toolchain di build e
provenienza del pacchetto Debian. Non sostituisce la firma del rilascio, la scansione dei
pacchetti di sistema o la verifica del percorso di upgrade, che restano task distinti.

## Fonte e perimetro

`requirements-prod.lock` è la fonte normativa delle dipendenze Python runtime. Ogni entry
deve avere versione esatta e almeno un hash SHA-256; il builder Debian e lo scanner
rifiutano forme più deboli. La scansione non usa l'ambiente installato come inventario e
non risolve nuovamente le dipendenze: `--disable-pip` fa sì che report e SBOM coprano
esattamente tutte le entry del lock.

`requirements-release.in` elenca con versione esatta i soli strumenti di release diretti;
`requirements-release.lock` ne fissa anche tutte le dipendenze transitive e gli hash. I
pin `setuptools` e `wheel` devono coincidere con `[build-system].requires`; `build`, `pip`
e `pip-audit` devono coincidere con le versioni osservate durante la generazione. Il lock
si rigenera intenzionalmente, mai a mano, con configurazione pip locale disabilitata:

```bash
PIP_CONFIG_FILE=/dev/null PIP_INDEX_URL=https://pypi.org/simple \
PIP_TOOLS_CACHE_DIR=/tmp/wg-portal-release-lock-cache \
  .venv/bin/pip-compile --generate-hashes --allow-unsafe --strip-extras \
  --output-file requirements-release.lock requirements-release.in
```

Questo gate copre le librerie Python, non:

- il codice first-party `wireguard-system`;
- i pacchetti Debian come WireGuard, Caddy, systemd, nftables e `age`;
- kernel e firmware dell'host;
- provenienza e firma del file `.deb`.

Questi elementi devono essere associati al candidate nel successivo blocco M4.4 prima di
definire completo il materiale di rilascio.

## Esecuzione

Preparare il virtualenv e lanciare dalla radice del checkout:

```bash
./scripts/bootstrap.sh
.venv/bin/python scripts/security-artifacts.py
```

Lo scanner usa `pip-audit` in modalità `--strict --require-hashes --disable-pip`; non usa
`--fix` e non possiede una allowlist di advisory ignorate. Il database advisory richiede
accesso di rete durante il gate di release. L'assenza dello scanner, un output incompleto,
un lock ambiguo o l'indisponibilità del servizio sono errori chiusi, non un risultato
pulito.

Gli exit code sono:

- `0`: scansione completa senza vulnerabilità note;
- `1`: scansione completa con vulnerabilità note; gli artefatti vengono conservati;
- `2`: errore di input, tool o formato; gli artefatti precedenti non vengono sostituiti.

## Output

La directory privata `dist/security/` contiene:

| File | Contenuto |
|---|---|
| `python-audit.json` | dipendenze e advisory nel formato JSON nativo di `pip-audit` |
| `python-sbom.cdx.json` | SBOM CycloneDX JSON delle dipendenze Python |
| `manifest.json` | timestamp UTC, versione tool, hash del lock, conteggio e SHA-256 degli output |

Directory e file sono rispettivamente `0700` e `0600`. `dist/` non è versionata: il
materiale va rigenerato dal commit candidato e, nel blocco di signing, collegato in modo
autenticato al pacchetto e al sorgente. Il manifest registra l'istante perché i database
advisory evolvono; un risultato storico non dimostra che il candidate sia ancora pulito.

Il generatore verifica che il numero di dipendenze nel report e dei componenti nello SBOM
coincida esattamente con quello delle entry del lock. Verifica inoltre il formato
CycloneDX prima di pubblicare. Gli hash del manifest si possono ricontrollare con:

```bash
sha256sum dist/security/python-audit.json dist/security/python-sbom.cdx.json
```

I valori devono coincidere con `artifacts` in `manifest.json`.

## Failure policy e remediation

Un exit code diverso da zero blocca il rilascio. Non cancellare una vulnerabilità dal
report, non aggiungere `--ignore-vuln` e non modificare soltanto l'SBOM. Per correggere:

1. confermare package, versione e advisory nel report;
2. aggiornare intenzionalmente i vincoli e rigenerare tutto `requirements-prod.lock`;
3. revisionare il diff di versioni e hash;
4. eseguire `./scripts/check.sh` e nuovamente lo scanner;
5. costruire un nuovo candidate soltanto dopo un risultato `clean`.

Se una remediation immediata non è possibile, il candidate rimane non rilasciabile. Una
futura procedura di eccezione richiederà decisione esplicita, scadenza, compensazioni e
tracciamento; non è implicita in questo gate.

## Pipeline del candidate

Il comando normativo unico parte soltanto da un worktree Git pulito:

```bash
./scripts/build-release-candidate.sh
```

L'orchestratore richiede inoltre che il tag annotato indicato da
`packaging/debian/release-freeze-tag` punti esattamente a `HEAD`. Rifiuta package o
bundle di destinazione preesistenti, esegue l'intero
quality gate, crea un virtualenv effimero privato con `/usr/bin/python3`, ignora la
configurazione pip dell'operatore e installa da PyPI soltanto wheel ammesse dal lock con
`--require-hashes --only-binary=:all:`. Esegue poi, nello stesso ambiente, audit/SBOM,
build Debian senza isolamento dinamico, generazione e verifica offline della provenienza.
Ogni errore interrompe la sequenza e nessun candidate parziale viene dichiarato riuscito.

Il generatore rifiuta file simbolici, repository sporchi, package/versione divergenti,
tool non corrispondenti al lock, audit non pulito, hash incoerenti, origin Git locali o
contenenti credenziali e bundle già esistenti. Crea atomicamente
`dist/releases/<versione>/` con:

- il `.deb` applicativo byte-identico;
- il package `wireguard-system-archive-keyring` byte-identico, quando fornito dalla
  pipeline finale;
- un archivio sorgente `.tar.gz` prodotto da `git archive` sul commit attestato;
- i lock Python runtime e release usati dal package e dalla toolchain;
- report, SBOM e manifest del gate dipendenze;
- `debian-package-inventory.json`, con control `Depends` e inventario ordinato di path,
  tipi, mode, dimensioni, link e SHA-256 dei file nel payload;
- `provenance.intoto.json`, una Statement `_type=https://in-toto.io/Statement/v1` con
  `predicateType=https://slsa.dev/provenance/v1`.

Il verificatore ricalcola tutti gli hash locali, valida statement, fonte Git, build type,
builder, materiali, byproduct, inventario e stato `clean`. Non usa rete e non estrae il
package sul filesystem.

La Statement è intenzionalmente **non firmata**. Il comando `verify` dimostra coerenza e
integrità interna dei file presenti, non autenticità né identità del produttore. Non
pubblicare o fidarsi del bundle finché il task di signing non lo racchiude in un envelope
firmato e non ne documenta la verifica.

## Build type v1

Il TypeURI `BUILD_TYPE` punta a questa sezione. Il build type locale v1 ha come parametri
esterni repository HTTPS canonico, commit Git completo, versione package e architettura.
`sourceDateEpoch` deriva dal timestamp del commit ed è l'unico parametro interno.

I materiali risolti sono:

- commit Git con digest `gitCommit`;
- `requirements-prod.lock` copiato nel bundle e legato con SHA-256;
- `requirements-release.lock` copiato nel bundle e legato con SHA-256;
- backend Python dichiarati in `[build-system]`, obbligatoriamente `==` e rappresentati
  come package URL PyPI.

I prodotti sono il `.deb` applicativo, l'eventuale `.deb` keyring e l'archivio sorgente.
Inventario Debian applicativo, audit, SBOM e relativo manifest sono byproduct. Il comando
normativo è `scripts/build-release-candidate.sh`;
`packaging/debian/build-package.sh` rimane un componente interno e costruisce la wheel con
`--no-isolation`, quindi non può scaricare backend non registrati durante quel passaggio.

L'`umask 077` protegge i file temporanei del builder ma non deve propagarsi nel package:
tutte le directory del payload devono avere mode `0755` e tutti i file regolari sotto
`usr/lib/wireguard-system/site-packages` mode `0644`. La generazione della provenienza
rifiuta mode diversi; la verifica ricalcola inoltre l'inventario direttamente dal `.deb`
e lo confronta integralmente con `debian-package-inventory.json`. ADR 0091 registra il
contratto introdotto dopo il rifiuto di `0.1.0-11`.

## Local builder v1

Il `BUILDER_ID` punta a questa sezione e identifica un build manuale sulla workstation del
maintainer. Registra versioni esatte dei pacchetti Debian `coreutils`, `dpkg`, `git` e
`python3`, oltre ai frontend Python `build` e `pip`. Non registra hostname, username,
directory locali o variabili d'ambiente.

Questo builder non è isolato, non possiede un control plane indipendente e non rivendica
alcun livello SLSA. L'accuratezza resta quella di un'attestazione self-hosted prodotta dal
medesimo account che esegue il build. Tool e backend Python sono installati da un lock
hashato in un ambiente effimero, ma sistema operativo, `/usr/bin/python3`, rete e account
restano quelli della workstation. Ogni nuovo candidate deve essere rigenerato dal proprio
commit pulito prima del gate di firma.

## Evidenza storica candidate `0.1.0-9`

Il 2026-10-08 la pipeline normativa è stata completata sul commit Git
`10272fa6134df40c0794faafe433d6c3c56bef91`. Ha eseguito 812 test, auditato 24
dipendenze senza finding, costruito il package `amd64` e verificato il bundle offline.
Package e Statement hanno rispettivamente SHA-256:

```text
98f49a3d0ea69d29863a958c51b5754337b58bdeeaf1eca9516e3422e1f1654b  wireguard-system_0.1.0-9_amd64.deb
ca1c9141c21002ad988a62af6d92e7c7ac63b9b817724cab85418f051ba6ee81  provenance.intoto.json
```

L'evidenza completa e i limiti del collaudo sono conservati in
`docs/RELEASE_CANDIDATE_0.1.0-9.md`. Il risultato non sostituisce firma o riproduzione
indipendente del build e il candidate non è pubblicabile: quel commit precede il recovery
completo degli ADR 0066–0088. La revisione `0.1.0-10` assegna un'identità nuova al codice
corrente e dispone di un proprio bundle verificato, documentato nella sezione seguente.

## Evidenza fail-closed candidate `0.1.0-10`

Il 2026-10-12 la pipeline normativa è stata completata sul commit
`6dab5a8b02d57908caee8a0a5ca578332454041b`: 1.003 test superati, audit pulito di 24
dipendenze, SBOM di 24 componenti, package `amd64` e bundle offline verificato. Il package
dichiara `X-WireGuard-System-Upgrade-From: none` e non supporta upgrade in ingresso.
Package e Statement hanno rispettivamente SHA-256:

```text
76296a306e88dd7f6808feec28c6fc6c72e3878fc1203f7ac9ecc6213a8ac652  wireguard-system_0.1.0-10_amd64.deb
87483271eaa65e0aee19e6084c462b104ee28de13d35f63875f224189fe241eb  provenance.intoto.json
```

Hash completi, inventario e limiti sono in
`docs/RELEASE_CANDIDATE_0.1.0-10.md`. Il bundle è non firmato e non pubblicabile. R03 ha
poi dimostrato che non può essere usato dopo remove senza purge: il `preinst` nega
`install OLD NEW` prima dell'unpack. La prima correzione ha usato la nuova revisione
`0.1.0-11` senza modificare questi artefatti.

## Evidenza fail-closed candidate `0.1.0-11`

Il candidate costruito dal commit `1d3f3fa0abe351e652dfa67f9dfb9f9bf0c913d2` ha
superato 1.004 test, audit di 24 dipendenze, generazione e verifica del bundle. Sul
laboratorio ha accettato correttamente la forma dpkg `install OLD NEW`, ma il `postinst`
ha fallito chiuso: l'`umask 077` della pipeline aveva reso parte delle directory Python
non attraversabili dall'utente `wg-portal`. Il rollback ha ripristinato package, servizi,
dati e rete senza variazioni inattese.

Package e Statement hanno rispettivamente SHA-256:

```text
95a0fc3ac91c9b7ff54b70ef5005dbdeea74d0f0f20b6cca64f31c8061b9d5f8  wireguard-system_0.1.0-11_amd64.deb
363af5981d3b94938c606d07e49b40c9c4d81d5ea3d0c5d819e136090415d1e6  provenance.intoto.json
```

Hash completi e limiti sono in `docs/RELEASE_CANDIDATE_0.1.0-11.md`. Il bundle è
immutabile, non firmabile e non pubblicabile; la correzione è riservata alla revisione
`0.1.0-12`.

## Evidenza candidate corretto `0.1.0-12`

Il 2026-10-12 la pipeline normativa è stata completata sul commit
`f290ad9092ac05e06a17c3eb9ec9eb243d10c866`: 1.005 test superati, audit pulito di 24
dipendenze, SBOM di 24 componenti, inventario di 1.240 entry e bundle verificato. Nessuna
directory del payload o file regolare Python viola il contratto ADR 0091. Package e
Statement hanno rispettivamente SHA-256:

```text
4b993ef06306a037fef9786dff5ecc1ecbabb76a1bdad354ccae8238b7f60269  wireguard-system_0.1.0-12_amd64.deb
339eb59f07de2da1587f5f657fa6fb1d169a7e972c89e9ed42b200dd0609b4e0  provenance.intoto.json
```

Hash completi e limiti sono in `docs/RELEASE_CANDIDATE_0.1.0-12.md`. Il bundle è
immutabile e ha superato l'installazione controllata R03 sul laboratorio con hash, health
e rete verificati. Non è firmato né pubblicabile; firma e candidate consecutivo restano
gate separati nel momento storico descritto da questa evidenza.

## Evidenza candidate consecutivo `0.1.0-13`

Il 2026-10-12 la pipeline normativa è stata completata sul commit
`a7e3bacea1f3a2507d2cc20142ccf81876adac68`: 1.006 test superati, audit pulito di 24
dipendenze, SBOM di 24 componenti, inventario di 1.241 entry e bundle verificato. Il
package dichiara esclusivamente `0.1.0-12` come predecessor. Package e Statement hanno
rispettivamente SHA-256:

```text
96e4714546b682230274ceff85297c6041d9b6a2f40d166e17945aa6f7a2e3e6  wireguard-system_0.1.0-13_amd64.deb
c9b27229ba6575df58f9a832622dfc377c916888892d5002a0d950f323652168  provenance.intoto.json
```

Hash completi e limiti sono in `docs/RELEASE_CANDIDATE_0.1.0-13.md`. Al termine di R05 il
bundle era non firmato e non installato; il verbale R06 successivo aggiunge autenticità
senza dichiarare ancora supportato l'arco.

## Evidenza candidate correttivo `0.1.0-17`

Il 2026-10-14 la pipeline normativa è stata completata sul commit
`06a3b37c59706e9a8484cc15104c38d9b321e896`: 1.028 test superati, audit pulito di 24
dipendenze, SBOM di 24 componenti, inventario di 1.254 entry e bundle verificato. Il
package dichiara esclusivamente `0.1.0-15` come predecessor. Package e Statement hanno
rispettivamente SHA-256:

```text
2ecfbd13ac6eeba46ba984ad21a01b175701f9c47e99987cb57a9ee81fe8a4c4  wireguard-system_0.1.0-17_amd64.deb
2c9a72a0a4fd23260aa22d25dbd78f3be56dfe6b1bf199c9f646b756ab21ef1c  provenance.intoto.json
```

Hash completi e limiti sono in `docs/RELEASE_CANDIDATE_0.1.0-17.md`. La firma SSHSIG ha
SHA-256 `e404430408b883860254959cefbbdffee53e4997919c02870a6b5a59ec74cfa9`.
L'upgrade reale da `0.1.0-15` ha verificato la correzione P-026, health e idempotenza e
ha chiuso R11; il candidate resta non pubblicabile fino ai gate successivi.

## Evidenza candidate rollback `0.1.0-16`

Il 2026-10-14 la pipeline normativa è stata completata sul commit
`3d0da508e5c9b384288552a4547efeb48b1d7b16`: 1.028 test superati, audit pulito di 24
dipendenze, SBOM di 24 componenti, inventario di 1.252 entry e bundle verificato. Il
package dichiara esclusivamente `0.1.0-15` come predecessor. Package e Statement hanno
rispettivamente SHA-256:

```text
1fd6a0eca62afb997312638117726dc5f37efc4544af4af61cd91f93ce2c71d1  wireguard-system_0.1.0-16_amd64.deb
c041406e4a5e5789b53b26776b6fa1ef15bf230780dba170ae26fdeebb5e2a3b  provenance.intoto.json
```

Hash completi e limiti sono in `docs/RELEASE_CANDIDATE_0.1.0-16.md`. Il bundle è stato
firmato e ha completato rollback e restore reali, ma è rifiutato: il controllo terminale
ha esposto P-026 nel classificatore recovery. La revisione corretta deve essere costruita
e collaudata prima della chiusura R11.

## Evidenza candidate recovery `0.1.0-15`

Il 2026-10-14 la pipeline normativa è stata completata sul commit
`0b06c4e1d9255bfb85fe864254fc6520bde22f55`: 1.028 test superati, audit pulito di 24
dipendenze, SBOM di 24 componenti, inventario di 1.251 entry e bundle verificato. Il
package dichiara esclusivamente `0.1.0-14` come predecessor. Package e Statement hanno
rispettivamente SHA-256:

```text
10f3c78215cfb4c143b75e80839b2730c1e3138da3fcdfc6e3a68f981546a7d0  wireguard-system_0.1.0-15_amd64.deb
25596651eb94c07b46691dbafce44964ebf74b4cda3cb43350f9c5a0de4f466a  provenance.intoto.json
```

Hash completi e limiti sono in `docs/RELEASE_CANDIDATE_0.1.0-15.md`. Il bundle è stato
firmato e installato nel laboratorio; l'upgrade sano fino alla receipt terminale non
sostituiva il rollback attestato poi completato in R11 sull'arco successivo.

## Cerimonia offline R06

Il 2026-10-13 la root of trust Ed25519 release è stata generata offline e separata dalla
chiave operativa upgrade. Fingerprint, policy e revoche pubbliche sono versionati sotto
`release/`; due backup protetti da passphrase furono verificati e fisicamente separati.
Le copie successive sulla workstation costituiscono il rischio accettato P-019, quindi
la custodia corrente non è descritta come esclusivamente air-gapped. I manifest tecnici
fino a `0.1.0-17` richiesti dai drill sono firmati con SSHSIG.

Il verifier reale ha accettato entrambi i bundle e rifiutato namespace errato, chiave
revocata e package alterato. Hash e limiti sono in
`docs/RELEASE_SIGNING_CEREMONY_2026-10-13.md`. R07 ha poi provato authorization breve,
host-bound e monouso e installazione reale; il verbale è in
`docs/UPGRADE_DRILL_R07_2026-10-13.md`. R08 ha poi collaudato rifiuti, cancellazione e
crash del marker monouso, documentati in
`docs/UPGRADE_FAILURE_DRILL_R08_2026-10-13.md`. Recovery e rollback R09–R11 sono stati
poi completati; nessun bundle è ancora approvato per produzione.

## Preparazione alla firma

Al termine dei gate l'orchestratore invoca `scripts/release-signing.py prepare`. Il
comando verifica nuovamente la provenienza e crea, senza sovrascritture, un `SHA256SUMS`
ASCII ordinato che descrive l'insieme esatto dei file del bundle. Manifest e bundle
completo devono essere trasferiti alla postazione offline; firmare il solo manifest senza
prima ricontrollare localmente tutti i file renderebbe la cerimonia priva di valore.

La firma usa OpenSSH SSHSIG Ed25519 con namespace e identità
`release@wireguard-system`. La verifica richiede `allowed_signers`, lista delle chiavi
revocate e firma detached, quindi ricalcola checksum e provenienza. Il formato, i comandi
offline e la policy operativa sono normativi in `docs/RELEASE_SIGNING.md`. La procedura
resta normativa per i candidate futuri. Per la coppia corrente il gate manuale è chiuso
dal verbale R06; firme e manifest tracciati sono sotto `release/`.

## Pubblicazione APT

`scripts/deploy-apt-package.py` è il solo percorso documentato per inserire il `.deb` del
bundle in una root APT locale. Prima della mutazione riesegue il verifier SSHSIG; delega
pool, database, indice e firma OpenPGP a `reprepro`, quindi verifica con una keyring
pubblica dedicata il fingerprint `InRelease` e la catena di hash fino ai bytes pubblicati.
Questo aggiunge un confine di autenticità per APT ma non completa la cerimonia SSHSIG né
il provisioning della chiave privata dell'archivio. ADR 0065 e
`docs/APT_REPOSITORY_DEPLOYMENT.md` definiscono contratto e recovery. L'export opzionale
GitHub Pages è una proiezione verificata e manifestata dei soli alberi pubblici; ADR 0092
vieta di usare la cartella web come root interna `reprepro`.
