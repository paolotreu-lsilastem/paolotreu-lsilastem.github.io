# Convenzioni della UI gestionale

## Obiettivo e confine

La UI Flask è un adattatore HTML dello stesso service layer usato dall'API. Rendere una
voce invisibile o mostrare uno scope non costituisce autorizzazione: ogni GET e mutazione
gestionale deve costruire il principal corrente e applicare `PolicyEngine` nel backend.
Non leggere o scrivere direttamente file JSON da una view.

M3.8 fornisce la shell e i componenti di base; i CRUD vengono aggiunti dalle milestone
successive. JavaScript, framework CSS, font remoti e CDN non sono ammessi nella baseline.

## Template e componenti

- Tutte le pagine ereditano da `templates/base.html` e definiscono almeno `title` e
  `content`; deve esistere un solo `h1` e un solo landmark `main` per risposta.
- La shell contiene skip link, header, navigazione principale, scope autorizzati, messaggi
  flash e logout POST protetto da CSRF. Non duplicare questi elementi nei child template.
- Usare le classi esistenti in `static/portal.css`: `page-heading`, `panel`, `card-grid`,
  `feature-card`, `form-stack`, `field`, `button`, `badge`, `alert` e relativi modifier.
  Nuovi token colore vanno definiti in `:root`, verificati anche in dark mode e testati.
- Ogni campo visibile richiede `id` unico e `label for`; hint ed errori di campo usano
  `aria-describedby`. Non usare placeholder come unica etichetta. Le azioni distruttive
  future devono avere testo esplicito e conferma server-side.
- Messaggi di errore usano `role=alert`; conferme non urgenti usano `role=status`. Non
  includere eccezioni, path, hostname, payload o segreti nelle pagine d'errore.

## Navigazione scoped

`web/ui.py` genera una proiezione deterministica dalle assegnazioni dell'utente:

- superadmin: tenant, utenti, reti, client, operazioni e accessi API;
- admin: utenti, reti, client e operazioni nei tenant assegnati;
- manager: reti, client e operazioni nelle reti assegnate.

La voce superadmin **Accessi API** punta alle viste create/list/detail/rotate/revoke delle
identità macchina. La creazione UI emette deliberatamente una sola identità globale di
bootstrap: il token viene mostrato nella sola risposta POST con `no-store`, non entra in
flash/sessione e non è recuperabile. Va usato per creare identità API scoped e poi
revocato. Rotate usa la revisione osservata e invalida subito il token precedente; utenti
non superadmin ricevono lo stesso `404` non enumerabile degli oggetti invisibili.

I nomi degli scope vengono risolti dal repository soltanto per presentazione. Documento
mancante, corrotto o non canonico produce `Ambito non disponibile`, senza eccezioni o
dettagli storage. Aggiungere una voce richiede sia la regola di visibilità UI sia test
RBAC della route reale; non passare documenti canonici completi ai template.

## Sicurezza browser

La CSP usa `default-src 'none'` e consente CSS, immagini e il solo JavaScript packaged
same-origin; frame/object/base sono negati e i form sono same-origin. `unsafe-inline`,
`unsafe-eval`, script inline, handler HTML, CDN e asset remoti restano vietati. Il piccolo
asset progressivo è registrato da ADR 0041; autoescape Jinja non va disabilitato.

Le sessioni conservano soltanto l'ID utente. Ogni richiesta ricarica il documento attivo,
genera `X-Request-ID` e applica `no-store`. CSRF protegge ogni POST HTML. API e UI non
condividono form o token: le route `/api/v1` restano bearer e CSRF-exempt.

## Errori e test obbligatori

Gli errori UI 400/403/404/405/413/500/503 usano `error.html`; gli equivalenti sotto `/api/`
restano `application/problem+json`. Gli errori applicativi attesi devono essere convertiti
in messaggi azionabili e redatti dalla view specifica, con audit quando rilevante.

Le route tenant sono `/tenants`, `/tenants/new`, `/tenants/{id}` e
`/tenants/{id}/edit`. Usano Post/Redirect/Get; il form create conserva un UUID generato
dal server così un retry identico converge sulla stessa risorsa, mentre update invia la
revisione canonica e tratta un conflitto come errore `409` senza sovrascrivere. Query e
campi form sono allowlistati, inclusi duplicati. Replicare questo pattern nei CRUD
successivi senza chiamare gli endpoint HTTP API dall’interno dell’applicazione.

Le route utenti sono `/users`, `/users/new`, `/users/{id}` e `/users/{id}/edit`.
Il form assegna ruoli mediante controlli server-rendered: un superadmin vede tutti gli
scope, mentre un admin vede solo i tenant amministrati e le relative reti. In modifica,
le assegnazioni esterne vengono preservate dal server e non sono affidate a hidden field
manipolabili. Un account condiviso può cambiare stato solo se tutti i suoi scope sono
amministrabili dall’attore; nessun utente può modificare il proprio account dalla UI.
La password iniziale compare solo come input `password` vuoto, non viene riproposta dopo
errori e non entra mai in response, flash o audit.

Le route rete del primo sottogate M3.10 sono `/networks`, `/networks/new` e
`/networks/{id}`. Il form create offre due submit espliciti: anteprima e creazione. La
preview chiama lo stesso service e gli stessi validator della mutazione, calcola CIDR,
capacità client, endpoint, porta e interfaccia senza generare chiavi o scrivere file. La
creazione ripete sempre risoluzione DNS e controlli sotto lock: l’anteprima informa
l’utente ma non è una prenotazione. Manager può consultare solo le reti assegnate; la
creazione resta riservata a superadmin e admin del tenant attivo.

`/networks/{id}/edit` espone solo i campi modificabili nella v1. CIDR e hub sono
read-only; nome e descrizione possono cambiare anche durante l’esecuzione, mentre
endpoint, modalità/porta e lifecycle richiedono `desired_state=stopped`. Manager può
modificare i campi ordinari della rete assegnata ma non inviare `lifecycle_status`;
admin e superadmin possono archiviare solo selezionando `archived` e una checkbox di
conferma distinta. Update trasporta la revisione e restituisce `409` senza overwrite in
caso di concorrenza.

R17 aggiunge `/networks/{id}/actions/{start|stop|sync|reconcile}` come workflow UI
revisionato. Il dettaglio espone soltanto le azioni compatibili con stato e ruolo; ogni
GET presenta descrizione e conferma esplicita, mentre il POST usa CSRF, mutation UUID,
optimistic concurrency e quote della coda. Un successo reindirizza sempre a
`/jobs/{id}?monitor=1`; backpressure restituisce `429` con `Retry-After`, conflitto o
revisione obsoleta `409` e una risorsa fuori scope `404` non enumerabile. Le azioni UI
usano l’identità utente, non simulano credential ID delle API.

Il primo sottogate M3.11 usa `/clients` come selettore delle reti visibili e
`/networks/{id}/clients` come inventario scoped. Create conserva un UUID server-side e
accetta assegnazione IP automatica oppure un IPv4 manuale; il client nasce `pending` e
l’indirizzo rimane immutabile nel form update. Dettaglio e liste ricevono soltanto la
proiezione redatta con fingerprint SHA-256, mai chiave pubblica completa, privata o
envelope. `/clients/{id}/edit` modifica solo nome e descrizione con revisione; è sicuro
anche su rete running perché non cambia la configurazione WireGuard.

Il secondo sottogate M3.11 espone il lifecycle come route d’azione separate, mai come
campi CRUD. Dettaglio mostra soltanto le transizioni valide per stato e ruolo; ciascuna
ha pagina di conferma, revisione e mutation UUID stabile. Sulle reti running una modifica
dei peer reindirizza al job `network.sync`; `/jobs` e `/jobs/{id}` sono filtrati da RBAC e
mostrano stato, percentuale ed eventuale codice errore redatto. Il pulsante “Aggiorna
stato” esegue per ora un refresh completo; polling e dialogo non bloccante arrivano in
M3.12.

Il terzo sottogate chiude M3.11 con `/clients/{id}/configuration`. Il link appare soltanto
per client e scope scaricabili; GET mostra un form di riautenticazione e POST accetta solo
CSRF e password corrente. Un successo avvia il download dell’attachment senza inserire il
profilo nell’HTML. Password errata produce un messaggio generico, i tentativi sono
limitati e password/configurazione non vengono riproposte. Revoked, archived, tenant o
rete inattivi e risorse fuori scope non espongono il download.

M3.12 rende live la pagina job senza rimuovere il fallback server-rendered. Il redirect
da un’azione asincrona aggiunge `monitor=1` e apre un dialogo; il client interroga soltanto
`/jobs/{id}/status`, aggiorna testo tramite `textContent`, sospende il polling quando la
pagina è nascosta, applica backoff limitato e termina su successo o errore. Messaggi
azionabili derivano da una allowlist server-side di codici, mai dal testo interno del job.
Ogni form POST ha inoltre un guard client-side: il primo submit resta intatto, inclusi
nome e valore del pulsante, mentre invii successivi sono ignorati fino alla navigazione.

Il primo sottogate M3.13 sostituisce il placeholder `/` con un inventario scoped di
tenant, reti e client. L’utente sceglie una rete visibile; il rendering iniziale e
`/dashboard/networks/{id}/snapshot` usano lo stesso `DashboardService`, che compone
metadati allowlistati e `TelemetryService` dopo il controllo object-level. Il browser
aggiorna soltanto la rete selezionata, così ogni ciclo produce al massimo un probe
privilegiato. Il polling usa credenziali same-origin, `no-store`, una sola richiesta in
volo, pausa quando la pagina è nascosta e backoff fino a 60 secondi. I nodi vengono
ricostruiti con `textContent`; endpoint e timestamp non entrano in HTML eseguibile.
Client non attivi sono mostrati come `inactive` e non vengono interpretati come peer
WireGuard. `online`, ultimo handshake e “online dal” restano esplicitamente stime.

Il sottogate conclusivo M3.13 usa `/dashboard/snapshot?network_id={id}` per aggiornare
nello stesso ciclo conteggi globali scoped, stato effettivo e presenza aggregata di ogni
rete visibile e dettaglio della rete selezionata. Il backend esegue un solo probe host,
poi valuta ciascuna rete in modo indipendente: una rete incoerente diventa `unknown`
senza oscurare quelle verificate. I valori `running` e `stopped` vengono mostrati solo
dopo la verifica congiunta di registry, VRF, interfaccia, peer e assenza attesa. Test HTML
per manager, admin e superadmin verificano selector etichettato, landmark, ID univoci,
scope e assenza di segreti.

Ogni nuova pagina deve aggiungere test per:

- route anonima e autenticata, CSRF, ruolo consentito e negato, IDOR cross-tenant;
- struttura semantica, label, focus/navigazione da tastiera e messaggi assistivi;
- assenza di segreti e dettagli interni in HTML, header e audit;
- layout senza dipendenze esterne e rispetto CSP;
- contrasto di nuovi token e `prefers-reduced-motion` per qualunque animazione.
