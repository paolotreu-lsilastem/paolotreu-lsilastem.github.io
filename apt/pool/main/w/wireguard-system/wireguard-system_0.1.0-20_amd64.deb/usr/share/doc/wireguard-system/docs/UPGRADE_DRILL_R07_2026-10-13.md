# Drill upgrade R07 — 2026-10-13

## Esito

`R07` è **superata**. Il laboratorio Debian 12 è stato aggiornato realmente da
`wireguard-system 0.1.0-12` a `0.1.0-13` usando bundle release firmati, recovery set
verificato offline e autorizzazione SSHSIG monouso legata a host e artefatti. Dpkg,
servizi, health, audit, HTTPS, hash persistenti e cleanup sono verdi.

Questo happy path non rende ancora l'arco supportato in produzione: i failure point,
recovery e rollback attestato restano `R08`–`R11`.

## Identità degli artefatti

| Elemento | Valore |
|---|---|
| Candidate | `0.1.0-13`, SHA-256 `96e4714546b682230274ceff85297c6041d9b6a2f40d166e17945aa6f7a2e3e6` |
| Rollback | `0.1.0-12`, SHA-256 `4b993ef06306a037fef9786dff5ecc1ecbabb76a1bdad354ccae8238b7f60269` |
| Recovery set | `1a54bde7-749e-48f9-9159-c21da49dd861` |
| Bundle data | `966c7bf11f84870f526949a94819f5f3dacbe0ca071d11769ae3f6246fbf7bd4` |
| Bundle secrets | `7cf697653250e9941e12e4b228f2d629f5f68a633cb8ac7540c8a6f5e5788fed` |
| Authorization JSON | `f0ee25f62c3f108452eab41bd55e565f7464c1b29075c2214279637adea06486` |
| Firma authorization | `f2e05f6a4382baba8f0e97593abf0b9621238a82833a116059af0159ab7d67c2` |

La request canonica v2 era valida dalle `10:15:27Z` alle `14:15:27Z`, dichiarava
schema dati 1, arco esatto, architettura `amd64`, digest del target contestualizzato e i
digest sopra. La firma usa principal `upgrade-operator@wireguard-system`, namespace
`upgrade@wireguard-system` e chiave con fingerprint
`SHA256:eK6dmIh0lnDw0YV22nDFDW3Rki82G6TvzPx7Kkpv1dc`.

## Verifica air-gapped

L'input offline da 12.523.520 byte aveva SHA-256
`e1dde8bb80db7ce42eed5d074b93e368aaefb2ed0f6bb0d42c15f7b852b9a3e2`.
Il manifest interno ha verificato tutti i bundle, ciphertext, trust e request. Entrambi i
manifest release sono stati ricalcolati e le firme SSHSIG sono risultate valide con il
fingerprint release R06.

`backup-verify` ha autenticato 4 file data e 2 file secrets; `restore-preflight` ha
confermato lo stesso UUID e che nessun dato live è cambiato. La postazione Kali aveva
Python 3.13, incompatibile con l'estensione `rpds` CPython 3.11 del package: il primo
tentativo è fallito prima di leggere i bundle. Non è stata firmata alcuna request finché
un runtime Python 3.11.2 separato, hash
`508343cc0dde709e91972800d59fd469bcade9b35a766fdb50a2bfe2d0fa0a21`, non ha eseguito
con successo entrambi i controlli. Il preflight non privilegiato ha usato un mount
namespace effimero per rappresentare `/var/lib`; nessun `sudo` era disponibile e nessun
path host è stato modificato. La roadmap registra il caso come `P-016` risolto.

Il builder ripetibile `scripts/build-offline-verifier-runtime.sh` conserva interpreter e
stdlib 3.11 in un archivio deterministico, elimina package Python di sistema estranei,
aggiunge manifest interno e rifiuta overwrite. Runtime e package restano artefatti
distinti: l'operatore deve verificare entrambi gli hash.

## Esecuzione sul target

La baseline immediata mostrava dpkg integro, `systemd=running`, registry v2 vuoto,
nessuna rete o job e 2.431.451.136 byte liberi. Preflight artefatto e verifica firmata
read-only sono riusciti prima dell'arming. Il guard ha quindi fermato esattamente web
socket/service, reconciler, health timer e helper socket; Caddy è rimasto fuori dal set.

Il `preinst` ha consumato il marker prima dell'unpack. Dpkg ha configurato `0.1.0-13` con
exit 0 e `postinst` ha finalizzato alle `10:53:16Z`, riavviando le cinque unità registrate.
La directory transazionale conserva, tutti root-only `0600`:

- authorization verificata da 991 byte;
- receipt `consumed` da 546 byte;
- receipt `finalized` da 412 byte;
- lock stabile vuoto.

Il nome delle tre ricevute usa il digest authorization `f0ee25f6…486`;
`armed.json` è assente e impedisce un secondo consumo accidentale.

## Controlli post-upgrade

- `dpkg-query` restituisce `0.1.0-13`; `dpkg --audit` e `dpkg -V` non producono output;
- `systemd-analyze verify` è pulito, systemd è `running` e le cinque unità ripristinate
  più Caddy sono attive;
- `doctor`, `audit-verify`, `reconciler-health` e helper probe sono verdi;
- readiness Unix e HTTPS Caddy rispondono `200`, con HSTS e header difensivi;
- environment, keyring, audit, meta, utente, registry e Caddyfile hanno SHA-256 identici
  alla fotografia pre-upgrade;
- registry e job sono vuoti, non esistono interfacce WireGuard/VRF o tabelle nftables
  gestite e `ip_forward` resta `0`;
- restano 2.431.393.792 byte liberi.

Il journal del progetto contiene soltanto stop e avvio ordinati. Il journal globale
mostrava retry estranei di `ollama.service` verso un eseguibile mancante; non hanno creato
unità fallite né cambiato `systemd=running` e non sono stati modificati perché fuori
scope.

## Custodia e passo successivo

Bundle, recovery set cifrato, request e ricevute restano nella directory root-only
`/root/wg-r07-20261013T101500Z` e nello state dir transazionale per i drill `R08`–`R11`.
Identity `age` e chiave privata upgrade non sono mai entrate nel target, repository o
log. `R08` deve ora esercitare rifiuti e crash prima/durante il consumo senza riutilizzare
questa authorization già consumata.

Stato successivo: R08 ha completato tali prove senza alterare le ricevute R07; vedere
`docs/UPGRADE_FAILURE_DRILL_R08_2026-10-13.md`. Il paragrafo precedente conserva il
passo successivo dichiarato al momento della chiusura R07.
