# Drill failure upgrade R08 — 2026-10-13

## Esito

`R08` è **superata**. I rifiuti prima dell'arming e i crash sui due lati del claim
monouso convergono negli stati previsti senza unpack non autorizzato, perdita delle
ricevute o writer lasciati ambigui. Il laboratorio resta su `wireguard-system 0.1.0-13`
installato e sano; recovery e rollback post-unpack restano `R09`–`R11`.

R08 non ha riutilizzato l'autorizzazione R07 per una nuova installazione e non ha
richiesto la chiave privata offline. La request firmata già consumata è stata usata solo
come input autenticato di verifiche negative read-only.

## Matrice dei casi

| Confine | Prova | Esito osservato |
|---|---|---|
| Firma | SSHSIG R07 deliberatamente troncata sul target | exit 2, errore pubblico redatto, nessun marker |
| Artefatto/hash | package candidate/rollback scambiati rispetto alla request | exit 2 prima dell'arming |
| Host e stato | target-id differente nei test; request R07 contro package già `0.1.0-13` sul target | rifiuto, nessun replay e `armed.json` assente |
| Tempo e revoca | clock oltre scadenza, lifetime fuori policy e chiave revocata | rifiuto deterministico |
| Operatività | writer o rete attivi, job/restore pendenti, reconciler non sano e spazio insufficiente | rifiuto prima di fermare o scrivere stato |
| Annullamento | marker non consumato, retry dopo resume fallito e claim parziale | tombstone monouso, ripristino del solo set originario, retry idempotente |
| Crash dopo claim | hard-link `consumed` durevole, unlink non eseguito | stesso inode con due link, classificabile `hardlink_incomplete` |
| Crash dopo unlink | marker rimosso, fsync finale interrotto | singola receipt `consumed`; retry del consumo negato |
| Unpack non autorizzato | `dpkg -i` dello stesso candidate senza intent/marker | `preinst` exit 1 prima dell'unpack; package e dati invariati |

I casi crittografici e operativi usano i test di `test_upgrade_preflight.py`; i confini
del consumo usano il `preinst` renderizzato da `packaging/debian/preinst.py.in`. I due
nuovi fault test in `test_upgrade_preinst.py` iniettano l'interruzione nei punti non
ottenibili in modo affidabile inviando un segnale a un processo reale.

## Identità del codice esercitato

Il `preinst` estratto dal `.deb` R07 e quello ancora registrato da dpkg hanno entrambi
SHA-256:

```text
c9166873f389c8ebc282e9c244dd4d11ed26ff3013f98cd4e0c02b47692e18c6
```

Lo stesso digest è prodotto dal template corrente renderizzato con versione
`0.1.0-13`, predecessor `0.1.0-12`, architettura `amd64` e schema 1. Questo collega i
fault test alla routine realmente installata, senza sostituire maintainer script o
directory dpkg sul server.

## Rifiuti live sul laboratorio

Alle `12:16Z` il target riportava `install ok installed 0.1.0-13 amd64`, systemd
`running`, zero unità fallite e nessun `armed.json`. Firma malformata, artefatto errato
e tentativo di armare nuovamente la request R07 sono terminati tutti con exit 2. La CLI
ha esposto soltanto `Upgrade artifact preflight failed`, senza path o dettagli sensibili.

Il successivo `dpkg -i wireguard-system_0.1.0-13_amd64.deb`, privo di un intent di
reinstallazione attestato, è terminato con exit 1 e
`WireGuard System upgrade authorization failed`. Il rifiuto è avvenuto nel `preinst`
prima dell'unpack. Dpkg ha richiamato il normale hook idempotente `abort-upgrade`, che ha
ricontrollato environment, keyring e bootstrap esistenti senza modificarne i contenuti.

Dopo il rifiuto:

- `dpkg-query` restituisce ancora `install ok installed 0.1.0-13 amd64`;
- `dpkg --audit` e `dpkg -V wireguard-system` non producono output;
- web socket/service, reconciler, health timer, helper socket e Caddy sono attivi;
- `meta.json`, utente, keyring, registry, environment e Caddyfile conservano gli hash
  R07;
- lock, authorization verificata e receipt `consumed`/`finalized` R07 conservano
  dimensione e SHA-256; `armed.json` è assente.

## Stato finale

Doctor, audit chain, reconciler health, helper probe, `/healthz` e `/readyz` Unix sono
verdi. HTTPS risponde 200 su loopback autorizzato verificando esplicitamente la CA
interna Caddy; una workstation fuori allowlist riceve 403, come previsto. Registry v2 è
vuoto, non esistono link WireGuard/VRF, tabelle nftables gestite o porte nel range
`51820–51999/UDP`, `ip_forward` resta 0 e sono disponibili 2.427.551.744 byte.

La directory root-only `/root/wg-r08-20261013T122000Z` contiene soltanto la firma
deliberatamente malformata usata dal caso negativo: 321 byte, mode `0600`, SHA-256
`5ff65fd20e4521c760fafc504c8992e58631168bf9f31d0b48f4651117fbb230`.
Nessuna chiave privata, identity `age` o plaintext recovery è stata creata o trasferita.

## Passo successivo

R09 deve creare in modo controllato gli stati dpkg `unpacked`, `half-configured` e
candidate incompleto, quindi provarne repair, retry, lock e ripresa esatta dei writer.
Non cancellare o modificare le ricevute R07 e non usare `dpkg --force-*`.
