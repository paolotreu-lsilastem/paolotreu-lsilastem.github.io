# Drill R09 — recovery di configurazione e installazione interrotta

Data esecuzione: 2026-10-14  
Target: Debian 12, `root@vrt-debian1.lsinet.it`  
Arco: `wireguard-system 0.1.0-13` → `0.1.0-14`  
Esito R09: conclusa; P-020 e P-021 risolti, P-022 assegnato a R11

## Artefatti verificati

Il candidate immutabile deriva dal commit `d0a7d6d` e usa esclusivamente
`0.1.0-13` come predecessor. Prima dei fault sono stati verificati:

- package `wireguard-system_0.1.0-14_amd64.deb`:
  `0ad1e8b6fa869f4741d4c91a442c3656247d38721f83510829e0ebdf04139087`;
- `SHA256SUMS`:
  `ee19d78b491a9f3961c957fa0a53286abc1509587e5a000a27283e1c6ae5c1d8`;
- firma release:
  `1ef3cb0449ca8e61b04b0f4af7f912f2424f9354d717cf21dbb2cd755beeb8bb`;
- fingerprint release:
  `SHA256:6KitBJHvrhPyWHGfu8Np+6l4nETVr5RD95lYSapb4rg`;
- executor preflight nel package:
  `77904ec9d022dc0a67d09a79d61c0d76d5bdb505f5c28f6358c04757c5282c9f`;
- finalizer nel package:
  `f4418a9027afd71ddff8f07d9257f6a2f24df5b85d2bbc820e90f3cb4e2f53f5`.

Il manifest, la firma SSHSIG e tutti i file elencati dal bundle hanno superato il verifier
completo sul target. Le tre autorizzazioni operative avevano digest `037df279…4e1`,
`d5d84378…167` e `51e180bb…988`; firme e policy upgrade sono state verificate con il
fingerprint distinto `SHA256:eK6dmIh0lnDw0YV22nDFDW3Rki82G6TvzPx7Kkpv1dc`.

## Configuration repair e handoff dei lock

Con la prima autorizzazione, il `postrm` del predecessor è stato fatto fallire solo per
l'azione `upgrade`. Il fallback al `postrm` del nuovo package è riuscito e dpkg ha lasciato
`0.1.0-14` in stato `unpacked`; recovery status ha restituito
`candidate_configuration_incomplete` e `repair_candidate_configuration`.

Prima del repair è stato mascherato soltanto `wg-portal-helper.socket`. L'executor
immutabile `0.1.0-14` ha ceduto correttamente `lock-frontend`, backend dpkg e lock
transazionale al figlio `dpkg --configure`: il figlio ha raggiunto il `postinst` e il
finalizer, che ha fallito chiuso sul socket intenzionalmente indisponibile. Il risultato
era `0.1.0-14 half-configured`, writer ancora fermi e la stessa classificazione di
recovery. Questo prova su dpkg reale la correzione P-020: non si è riprodotto il deadlock
del parent `0.1.0-13`.

Il finalizer ha inoltre attraversato senza falsa ambiguità i rollback terminali già
presenti e ha raggiunto il fault systemd deliberato. La sequenza immutabile prova quindi
anche P-021 e ADR 0094; una receipt storica corrotta o concorrente resta coperta dai test
fail-closed.

## Installazione interrotta: semantica reale di dpkg

Sono state provate tre finestre distinte:

1. fallimento del vecchio `postrm` e del nuovo `postrm` su `daemon-reload`;
2. `SIGKILL` al primo evento status-fd `half-installed`, prima del `preinst`;
3. `SIGKILL` immediatamente dopo il passaggio atomico `armed` → `consumed`.

Nel primo e nel terzo caso dpkg ha riportato il predecessor
`0.1.0-13 half-installed`; nel secondo ha conservato `0.1.0-13 unpacked` e il guard non
consumato. In nessuna finestra reale è esistito uno stato osservabile
`0.1.0-14 half-installed`: dopo l'estrazione completa dpkg passa invece a
`0.1.0-14 unpacked`, già coperto dal configuration repair.

Per questo il ramo difensivo `--reinstall-candidate` resta testato a livello di contratto,
intent, lock e retry, ma R09 non dichiara una sua attivazione live artificiale. P-023
registra la correzione del modello di test. Le interruzioni reali del candidate sono state
recuperate reinstallando il predecessor attestato e verificando il retry idempotente.

## Problema P-022 trovato durante il cleanup

Il `preinst` del predecessor richiede che `rollback-intent/` contenga globalmente una
sola entry. La directory conservava correttamente intent di rollback precedenti, tutti
associati a receipt terminali `predecessor-resumed`; l'intent corrente diventava quindi
falsamente ambiguo. Lo stesso rischio strutturale esiste per la directory degli intent di
reinstallazione candidate.

Per non cancellare o riscrivere l'audit trail, il solo laboratorio ha usato una bind view
root-only contenente l'intent corrente mentre dpkg eseguiva il `preinst` immutabile
`0.1.0-13`. Questo workaround non è una procedura supportata e non entra in `UPGRADE.md`.
P-022 resta release blocker di R11; ADR 0095 prescrive la separazione fra intent attivo e
storico terminale validato.

Gli intent sono stati creati dall'executor `0.1.0-14` con un runner dpkg deliberatamente
fermato prima dell'esecuzione. Il log mostra l'argv teorico `--force-downgrade`, ma tutti i
processi dpkg reali del drill hanno ricevuto soltanto `--unpack` oppure `--install`.
Nessun processo dpkg reale ha eseguito opzioni `--force-*`.

## Stato finale

Alle `13:11Z` il server riportava:

- `ii install ok installed 0.1.0-13 amd64`, `dpkg --audit` e `dpkg -V` vuoti;
- recovery status `no_pending_transaction` e retry rollback
  `No pending predecessor rollback remains`;
- web socket/service, reconciler, health timer, helper socket e Caddy attivi; unità
  transiente health inattiva a riposo e zero unità fallite;
- `doctor`, audit chain, reconciler health, helper probe, `/healthz` e `/readyz` Unix
  verdi;
- registry e stato WireGuard vuoti, nessuna VRF, nessuna porta UDP 51820–51999 e
  `net.ipv4.ip_forward=0`;
- 2.323.251.200 byte liberi sul filesystem root;
- tutte le authorization, consumed, intent e receipt conservate root-only `0600`.

Le evidenze grezze root-only sono sotto
`/root/wg-r09-20261013T140000Z/evidence`. Nessuna chiave privata o identity `age` è stata
copiata sul target.

## Chiusura e seguito

R09 soddisfa il gate sugli stati realmente prodotti da dpkg: `unpacked`,
`half-configured`, interruzione prima/dopo il consumo, handoff lock, classificazione,
writer quiescenti, ricevute e retry. P-020 e P-021 sono chiusi sul package immutabile.
R10 deve ora provare i due stati trigger; R11 deve risolvere P-022 prima di considerare
supportato il rollback con storico multiplo.
