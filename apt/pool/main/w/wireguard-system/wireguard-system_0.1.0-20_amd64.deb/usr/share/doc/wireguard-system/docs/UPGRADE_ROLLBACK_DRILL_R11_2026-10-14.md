# Drill R11 — rollback attestato, restore e stato terminale

Data: 2026-10-14  
Target: `root@vrt-debian1.lsinet.it`, Debian 12 amd64  
Esito R11: conclusa; P-022, P-025 e P-026 risolti

## Risultato

R11 ha provato su dpkg reale l'intero percorso attestato senza modificare manualmente
marker, intent o receipt. Il candidate firmato `0.1.0-16` è stato fermato
deliberatamente in `half-configured`; l'executor ha reinstallato il predecessor pinned
`0.1.0-15`, ripristinato il recovery set autorizzato e riattivato esclusivamente i cinque
writer originari. Il cleanup ha poi esposto P-026 nel classificatore terminale. Il
candidate correttivo firmato `0.1.0-17` ha verificato la correzione sullo stesso storico
reale ed è rimasto installato e sano.

L'arco mantiene `data_schema_version=1`: dimostra preservazione dei dati e migrazione no-op,
non una migrazione cross-schema.

## Artefatti e firme

Il package rollback aveva SHA-256
`1fd6a0eca62afb997312638117726dc5f37efc4544af4af61cd91f93ce2c71d1`;
la firma SSHSIG di `SHA256SUMS` aveva SHA-256
`f1887f6f351b41b396c52e79cd8e650c3e226e8b54c5de9a5bd32fe677773a68`.

Il package correttivo aveva SHA-256
`2ecfbd13ac6eeba46ba984ad21a01b175701f9c47e99987cb57a9ee81fe8a4c4`;
la firma SSHSIG di `SHA256SUMS` aveva SHA-256
`e404430408b883860254959cefbbdffee53e4997919c02870a6b5a59ec74cfa9`.
Entrambe le firme sono state accettate con namespace `release@wireguard-system` e
fingerprint release
`SHA256:6KitBJHvrhPyWHGfu8Np+6l4nETVr5RD95lYSapb4rg`, sia prima del trasferimento sia sul
target. I manifest interni e gli artefatti elencati sono stati ricalcolati sul server.

## Fault, rollback e restore `0.1.0-15 → 0.1.0-16`

Il recovery set di baseline era
`9c7f296f-2d7a-4269-878c-03984fc90d20`:

| Oggetto | SHA-256 |
|---|---|
| bundle dati | `3653d1a4e108dd8fbc8aa66201dcccf88fc6a9f17f25916d5656337880f11e50` |
| bundle segreti | `0f6c04a5672b525c7ea7d2eb4366692bdf9385244f10bc480c03dd48abbe94b1` |
| authorization | `40dd4cc283241084d36e83115811f38747519b5726a4867d4d8aa4c0605ddc81` |
| firma authorization | `688f9214f2218b820ddfd6a18750b7f433097a1cf7f8c8bc155a8fd1f6c803a2` |

`backup-verify` e `restore-preflight` erano verdi prima dell'arming. Dopo il consumo
dell'authorization è stato mascherato soltanto `wg-portal-helper.socket`. `dpkg` ha
completato unpack e setup fino al fault atteso di finalizzazione, è uscito con codice 1
e ha lasciato `wireguard-system 0.1.0-16 half-configured`. Non è stata creata una receipt
`finalized`.

`--rollback-with-restore` ha quindi:

1. verificato nuovamente package predecessor e recovery set pinned;
2. reinstallato `0.1.0-15` tramite il solo percorso autorizzato;
3. ripristinato quattro file dati e due file segreti;
4. pubblicato `rollback-restored` e `predecessor-resumed` con mode `0600`;
5. ripreso socket web, servizio web, socket helper, reconciler e timer health;
6. rimosso la mask e l'identità temporanea.

Nel punto di controllo successivo `dpkg-query` riportava `install ok installed 0.1.0-15`:
il candidate `0.1.0-16` era assente e il predecessor era sano. Solo dopo questa verifica
è iniziato l'upgrade correttivo separato a `0.1.0-17`.

I quattro intent legacy sono stati spostati nello storico senza cambiare byte:

| Digest authorization | SHA-256 intent |
|---|---|
| `037df2791964add05287b6670325fca5208d57d3e5c5b58e350d441b7e2e04e1` | `7f896031537be5c4777504c26926d374ff2134c1b7e6539b5b91e2c93e3ff177` |
| `51e180bb5996df478be086216c89381389ce73729858fcd3d0b8ac212ea57988` | `7e9d5adc4a3537ba42b553612e8e48d70ed8aea53a302ef41e73d624a8140c2e` |
| `7b805d40ee20f7831c9a943b8bb4dea8636018764d970250236e212588609869` | `e527787c33310c27adde39a45f9523e876a2dc86eabdd9afa289827350b83dde` |
| `d5d84378eb036452844c4d9d16a50d53c3cb6f524e50e16b4147a6603efc9167` | `3eb128807d9b182d281fbba917b7b5da08f6ac301949ec548b0feb4786f01381` |

Anche l'intent corrente `40dd4cc2...` è stato archiviato con SHA-256
`85f999742789e00f763a864fbcc65da9b84acc779009297bbebee6bbf9a4190f`.
La directory attiva era assente. Questo chiude P-022 e il fault controllato chiude P-025.

## P-026 e candidate correttivo

Subito dopo il rollback sano, `recovery-status` ha rifiutato il layout con
`upgrade recovery state is ambiguous`: le receipt di restore venivano collegate soltanto
all'intent attivo, benché `predecessor-resumed` l'avesse già archiviato. Il timer health
ha riportato failure per lo stesso motivo. Non sono stati rimossi o riscritti record per
aggirare il controllo.

ADR 0096 e il commit `06a3b37c59706e9a8484cc15104c38d9b321e896` correggono il
classificatore: l'intent dello stesso digest può essere letto dallo storico solo dopo la
validazione completa del suo terminale. Il candidate `0.1.0-17` ha superato 1.028 test,
audit, SBOM, build, inventario e provenance prima della firma.

Per l'upgrade correttivo è stato creato un nuovo recovery set
`05ad4af3-58d5-4b2d-af4a-387809f1caf6`:

| Oggetto | SHA-256 |
|---|---|
| bundle dati | `f99871663cc1201780c9a8e4c9d2dd0d149492751bebe852be03bc475ebae5b6` |
| bundle segreti | `30c89e034965ec3b5daa9cee40f486560ca4413738ebceb6bb703494a550a393` |
| authorization | `d9901c51e4ed8234fc5d0db90374029f750fbd1a31ed39974b4204a7d49a691c` |
| firma authorization | `a230661fff596adda1eb352c5aafa8ea7c74a1e8a6cdc699b1135cc1c0b8f84a` |

L'upgrade `0.1.0-15 → 0.1.0-17` è uscito con codice 0 e ha creato la receipt
`finalized`. Il classificatore restituisce ora `no_pending_transaction`; la directory
attiva non esiste e i cinque intent storici conservano gli hash precedenti.

## Integrità e stato operativo finale

Il confronto tra manifest del secondo recovery set e stato autorevole live ha prodotto
gli stessi SHA-256 per tutti i sei file dati e i due segreti:

| File logico | SHA-256 |
|---|---|
| audit integrity 2026-10-08 | `479e6fc76ff3aee3828a856c1b68674aa3399d6d205490620f8dee7edfe4c8a6` |
| audit JSONL 2026-10-08 | `3d657807b98ff196ad783818cb95f10ec5b39ad6417e40780e277997d257ad57` |
| audit integrity 2026-10-14 | `ff640c3a6caa9c65bbf415003905aa85031f579130d6c26b9d643a55d3a93852` |
| audit JSONL 2026-10-14 | `8ddbcb518c5d65dd4aaf121794700cc0622362f29eb99697eaba859aafd4ab28` |
| `meta.json` | `dbda9cb641289b06b0c8fb57d6f25a04e21d426feefd336469eabc0a3c535b7c` |
| utente | `99d95297173fb0e917b59a9a6eec4183e85b9220ab75a7e14f48f4c3fcf406a5` |
| environment | `7e91416a0f7f5171eb3ebbb0d26d9c2302dde9980d59098ebb25831870a98d24` |
| keyring | `c353dea8681d864e57d04d1433fb0c02377fa0686f9e88812f743d1207d00bb6` |

I file dati e keyring mantengono mode `0600`; l'environment mantiene `0640` e ownership
`root:wg-portal`. `dpkg --audit`, `dpkg -V wireguard-system`,
`systemd-analyze verify` e `systemctl --failed` sono vuoti/verdi. `doctor`, verifica
audit, health reconciler e probe helper sono verdi con il `PATH` operativo esplicito.
Il primo `doctor` eseguito con ambiente completamente vuoto non trovava `nft`; è il noto
errore di harness P-014, non un difetto del package.

Caddy è attivo. `/healthz` e `/readyz` rispondono HTTP/2 200 via HTTPS; readiness riporta
`OK` per storage, recovery, keyring, helper e reconciler. La risposta contiene HSTS
`max-age=31536000`, mentre HTTP effettua redirect 308 a HTTPS. Non risultano interfacce
WireGuard/VRF né listener UDP gestiti; `net.ipv4.ip_forward=0`.

Il timer `wg-portal-reconciler-health.timer` ha eseguito più cicli automatici dopo
l'installazione; l'ultimo controllo osservato alle 19:08:38 CEST aveva `Result=success`,
`ExecMainStatus=0`. Tutti e cinque i writer sono `active`.

## Idempotenza e cleanup

Un secondo `--rollback-with-restore` sugli artefatti conclusi ha restituito:

```text
No pending rollback restore remains
```

Per questo controllo è stato usato come parametro obbligatorio un file vuoto `0600`
effimero: il percorso no-op fissa gli inode ma ritorna prima di invocare il decryptor. Il
file è stato eliminato automaticamente. Nessuna identità recovery, mask systemd o
directory intent attiva resta sul server; package, hash storici, receipt e writer sono
rimasti invariati.

Log e artefatti di laboratorio sono conservati root-only sotto
`/root/wg-r11-20261014T153500Z`. Nessuna chiave privata è stata inserita nel repository.

## Limiti

`0.1.0-17` è un candidate tecnico di laboratorio, non una release production. Il build è
self-hosted e il gate v1 richiede ancora consolidamento R12, sicurezza operativa API,
manuali, audit indipendente, remediation, candidate finale e acceptance R25. Il rischio
di custodia delle chiavi già accettato in P-019 resta invariato.
