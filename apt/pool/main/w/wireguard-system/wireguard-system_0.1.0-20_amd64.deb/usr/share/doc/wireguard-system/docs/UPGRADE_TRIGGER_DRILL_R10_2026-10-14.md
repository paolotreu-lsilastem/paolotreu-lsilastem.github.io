# Drill R10 — recovery dei trigger dpkg

Data esecuzione: 2026-10-14

Target: Debian 12, `root@vrt-debian1.lsinet.it`

Baseline reale: `wireguard-system 0.1.0-13`

Esito R10: conclusa; `triggers-pending`, `triggers-awaited`, retry e closure esatta verdi

## Confine del laboratorio

Il package di produzione non dichiara trigger dpkg e non può quindi produrre naturalmente
gli stati richiesti dal gate. Il drill ha usato due snapshot indipendenti della baseline
reale, creati con mount namespace privato e overlay effimero. Dentro ciascuno snapshot è
stato installato un derivato **solo di laboratorio** di `0.1.0-14`:

- il payload applicativo estratto, inclusi contenuti, mode, owner e link, coincide con il
  package release R09;
- il control archive aggiunge soltanto le dichiarazioni trigger necessarie e un guard
  runtime che rinvia il finalizer fino al fault point controllato;
- lo SHA-256 del derivato è
  `7cd1a76bbb2043898f6a857fbedc25c5f72fef0c9e663d605a0c760d40a07c3a`;
- il derivato non è un artefatto release, non è firmato come release e non deve essere
  pubblicato né installato fuori dal laboratorio R10.

Due package consumer minimali e confinati hanno materializzato il grafo:

- `wg-r10-trigger-consumer 1.0.0`, SHA-256
  `cbc0474bc7a8ddbe6fc675efd415951c269405a33a49e3a5ccb3cd504c6b3b34`;
- `wg-r10-unrelated-consumer 1.0.0`, SHA-256
  `2bdbefd3cbcb47486b0aabd35566e1556c1d9b8eb5d63f555c5ce7264eddb523`.

Un sostituto di `systemctl` esisteva soltanto nell'overlay e teneva lo stato dei cinque
writer in `/run`. Nessun mount, package, unità o file di stato del test è sopravvissuto
alla chiusura del namespace.

## Autorizzazioni

Le due richieste sono state firmate con namespace `upgrade@wireguard-system`, principal
`upgrade-operator@wireguard-system` e fingerprint
`SHA256:eK6dmIh0lnDw0YV22nDFDW3Rki82G6TvzPx7Kkpv1dc`. Firma e policy sono state verificate sia
in WSL sia sul target prima dell'esecuzione.

| Scenario | SHA-256 request | SHA-256 firma |
|---|---|---|
| `triggers-pending` | `5e6cccc2871cdd64a119976f08c3db0e74f79f55dcf63d53ad7d89a8fddd3436` | `345eedb6d0c0c356ea2a5b9c3e85576e276859cb87fa51b4c1be8390e25fef4c` |
| `triggers-awaited` | `b83024b93ede46bd5c9d060f89fcda6116f1b249ae9b3c5e9c031fcddeee8fbd` | `36fc3a5986408a55fdae7086e8b843c35a5af737b38ba96f89d30b8ce8d2d68d` |

Il guard monouso è stato consumato e finalizzato nello snapshot corrispondente. La
distruzione intenzionale degli snapshot elimina anche quelle receipt: le request non
devono essere riutilizzate come autorizzazioni operative. Questo non riduce la garanzia
del guard su un root persistente; un clone deliberato ripristina per definizione anche lo
stato precedente al consumo.

## Scenario `triggers-pending`

Dopo unpack e configure con elaborazione trigger rinviata, dpkg riportava:

```text
it  triggers-pending 0.1.0-14 amd64 awaited= pending= wg-r10-candidate
```

`--recovery-status` ha classificato lo stato come
`candidate_trigger_processing_incomplete` con azione
`repair_candidate_triggers`. Il primo repair ha elaborato il trigger ma ha incontrato il
fault deliberato sulla prima ripresa dei writer ed è uscito con codice 2. Lo stato è
diventato `candidate_triggers_processed_resume_pending`, il relativo intent era presente,
la receipt finalizzata assente e tutti i writer erano ancora fermi.

Il retry della stessa operazione ha ripreso esattamente i writer originari, scritto la
receipt e riportato dpkg a `installed`; un ulteriore retry ha risposto
`No pending candidate trigger repair remains`. `dpkg --audit`, `dpkg -V` e recovery
status erano puliti. Intent e receipt root-only risultavano `0600`.

## Scenario `triggers-awaited` e package estraneo

Il candidate attendeva il consumer previsto, mentre entrambi i consumer avevano trigger
pendenti. È stato quindi aggiunto un trigger separato al package estraneo. Dpkg mostrava
simultaneamente:

```text
it  triggers-pending 1.0.0 all awaited= pending= wg-r10-dependency
it  triggers-pending 1.0.0 all awaited= pending= wg-r10-unrelated
iW  triggers-awaited 0.1.0-14 amd64 awaited= wg-r10-trigger-consumer pending=
```

La classificazione era `candidate_external_trigger_awaited`. Il primo
`--repair-candidate-awaited-triggers` ha rifiutato l'operazione con codice 2
(`unrelated_repair_exit=2`) prima di creare l'intent perché la closure globale includeva
il package estraneo. Dopo aver elaborato esplicitamente soltanto il trigger estraneo, il
retry ha chiuso il grafo candidate/consumer previsto, verificato l'effetto del consumer,
ripreso i writer e finalizzato. Il retry successivo è stato un no-op; dpkg, verifica
package e recovery status erano puliti.

## P-024 e dimensionamento dell'overlay

Il primo avvio dello scenario pending si è fermato nel preflight prima dell'arming. Il
tmpfs da 1.536 MiB non poteva soddisfare sul filesystem unico la somma dei gate: 512 MiB
di headroom root, quattro volte il candidate e 1 GiB di headroom dati. La firma e gli
artefatti risultavano validi e nessuna request era stata consumata. L'overlay è stato
portato a 3.072 MiB, con circa 14 GiB di RAM disponibile, e i due run successivi sono
terminati verdi. P-024 registra il falso negativo come problema dell'harness risolto, non
come difetto del prodotto.

## Evidenze e stato finale dell'host

I log grezzi sono root-owned in `/root/wg-r10/evidence`:

- `pending.log`, SHA-256
  `105d43026d0bf8445725b1164ea8d387cca1d8b7c8ef3bdb29d1ac34a839f6ff`;
- `awaited.log`, SHA-256
  `17d5c42f6ab9f9fce95a963a5f0d65f701fb4041e205d4dcc243923e22aeca68`.

Alle `14:10Z`, dopo la distruzione di entrambi gli snapshot, l'host reale riportava:

- `wireguard-system 0.1.0-13`, `dpkg --audit` e `dpkg -V` vuoti;
- recovery status `no_pending_transaction`;
- helper socket, web socket/service, reconciler e health timer tutti `active`;
- modulo overlay scaricato e nessun mount overlay residuo.

R10 dimostra pertanto classificazione, closure fail-closed, intent, receipt, ripresa
esatta e idempotenza su dpkg reale senza alterare la baseline. Il prossimo gate è R11:
correggere P-022 e provare rollback attestato con restore.
