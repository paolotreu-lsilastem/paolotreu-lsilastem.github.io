# ADR 0001 — Contratti persistenti v1

Data: 2026-09-23  
Stato: accettata

## Contesto

Il repository file-based necessita contratti stabili prima dei CRUD. Stato desiderato,
stato runtime e segreti hanno lifecycle e requisiti di sicurezza differenti; mescolarli
renderebbe ambigui recovery e riconciliazione dopo un crash.

## Decisione

- Ogni documento canonico usa JSON Schema Draft 2020-12, `schema_version = 1`, UUID,
  revisione e timestamp, salvo gli eventi audit append-only che hanno un solo timestamp e
  non vengono aggiornati.
- Il documento rete conserva `lifecycle_status` e `desired_state`; stati effettivi come
  `starting`, `running`, `stopping` ed `error` appartengono esclusivamente allo snapshot
  runtime ricostruibile.
- I ruoli utente sono unioni discriminate: superadmin globale, admin con tenant e manager
  con tenant e rete. Combinazioni incomplete o con scope extra sono invalide.
- Le chiavi private server e client sono rappresentate da un envelope AES-256-GCM v1 con
  `key_id`, nonce casuale da 96 bit e ciphertext autenticato. La master key resta esterna
  al data tree. M2.2 dovrà usare come AAD almeno versione schema, tipo risorsa, UUID
  tenant, UUID rete e UUID proprietario per impedire lo spostamento di ciphertext tra
  record.
- Il keepalive client è fissato a 25 secondi nel contratto v1. Cambiarlo richiederà un
  nuovo schema o una migrazione esplicita.

## Conseguenze

I repository M1.2 possono rifiutare documenti sconosciuti prima della scrittura. Le
invarianti relazionali e semantiche — unicità, appartenenza IP alla subnet, RFC1918,
overlap e transizioni di stato — restano responsabilità di M1.2/M1.3 perché JSON Schema
valida un documento isolato. Introdurre o cambiare campi persistenti richiede una nuova
versione, fixture della versione precedente e migrazione avanti.

