# ADR 0002 — Concorrenza repository, indici e migrazioni

Data: 2026-09-23  
Stato: accettata

## Contesto

Più worker Flask o processi operativi possono modificare gli stessi file. Il filesystem
non offre transazioni multi-documento e un indice derivato può diventare obsoleto durante
una mutazione o un crash.

## Decisione

- Ogni documento usa optimistic concurrency sul campo `revision`. Una patch acquisisce
  il lock del file, confronta la revisione attesa, incrementa esattamente di uno e usa
  scrittura temporanea, `fsync` e rename atomico.
- Identità, versione, data di creazione e scope tenant/rete sono immutabili nel repository.
  I documenti nuovi partono obbligatoriamente da revisione 1.
- I path canonici derivano soltanto da tipo e UUID canonicali. Durante get/list il
  contenuto deve ricostruire lo stesso path; discrepanze fanno fallire l'operazione.
- L'indice in `runtime/indexes/documents-v1.json` è una cache ricostruibile tramite scan
  e non viene mai usato come fonte di autorizzazione o verità canonica.
- Le migrazioni sono forward-only, lavorano su una copia, avanzano una versione alla
  volta, non cambiano l'ID e validano il risultato contro lo schema target. Non esistendo
  formati precedenti alla v1, il registry parte senza trasformazioni registrate.

## Conseguenze

Un client che salva una revisione obsoleta riceve un conflitto e deve ricaricare. Le
operazioni su più documenti saranno orchestrate da job idempotenti, non simulate come
transazioni. Una futura migrazione su disco dovrà fermare le mutazioni, creare un backup
coerente, applicare il registry e ricostruire l'indice.

