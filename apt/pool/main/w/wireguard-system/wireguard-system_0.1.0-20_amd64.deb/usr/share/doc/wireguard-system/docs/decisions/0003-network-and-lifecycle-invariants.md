# ADR 0003 — Invarianti di rete e lifecycle

Data: 2026-09-23  
Stato: accettata

## Contesto

JSON Schema valida forma e tipi di un singolo documento, ma non può garantire appartenenza
di un IP, assenza di overlap, unicità tra file o transizioni lifecycle consentite. Queste
regole devono restare indipendenti da Flask e dal filesystem per essere testabili e
riusabili dai servizi.

## Decisione

- Il dominio accetta soltanto reti canoniche interamente contenute in RFC1918, da `/16` a
  `/30`, con hub utilizzabile e diverso da network/broadcast.
- L'overlap nello stesso tenant è sempre vietato. Tra tenant è fail-closed salvo callback
  che certifichi isolamento L3 reale. Nome interfaccia è unico globalmente.
- Le porte sono allocate in modo deterministico dal basso nel range `51820–51999`; la
  scelta manuale usa lo stesso validatore. Endpoint normalizzati uguali non possono
  condividere porta. M2 deve ripetere il controllo sugli IP effettivamente risolti prima
  dell'applicazione, perché alias DNS differenti possono convergere sullo stesso IP.
- L'IP client viene allocato dal primo host disponibile oppure richiesto manualmente.
  Hub, network, broadcast e IP riservati sono esclusi.
- Un client revocato o archiviato conserva l'IP finché `address_reservation` non passa a
  `released` mediante un'azione esplicita e auditata. Un client operativo non può avere
  indirizzo rilasciato; le chiavi pubbliche non vengono mai riutilizzate.
- Le transizioni sono macchine a stati esplicite e idempotenti. La revoca client è
  irreversibile; l'archiviazione client è terminale. Tenant e rete possono essere
  ripristinati dall'archivio, ma una rete archiviata deve essere stopped.

Il campo `address_reservation` completa lo schema client v1 prima che esista un writer o
un documento client prodotto dall'applicazione; non esiste quindi un formato client v1
precedente da migrare. Da questo punto ogni variazione incompatibile richiederà una nuova
versione e la relativa migrazione.

## Conseguenze

I servizi M1.4+ devono validare schema, dominio e conflitti prima della patch repository.
Il rilascio di un IP è un use case distinto, non un effetto implicito di revoca o archivio.
Gli errori dominio hanno codici stabili e campo opzionale, così la UI può mostrarli senza
esporre eccezioni interne.
