# ADR 0004 — Sicurezza di autenticazione e sessione

Data: 2026-09-23  
Stato: accettata

> Emendamento R20: la frase storica “contenente solo UUID utente” è sostituita, per il
> runtime corrente, dal binding a UUID e revisione canonica definito in ADR 0100. Il
> resto della decisione rimane valido.

## Contesto

Il portale deve autenticare utenti file-backed senza database o servizi esterni e deve
rendere utilizzabile, ma strettamente confinato, il bootstrap `admin/admin` richiesto.
Più worker devono condividere la protezione brute-force.

## Decisione

- Password verificate e generate con Argon2id. Errori di utente inesistente, password
  errata e account disabilitato sono indistinguibili; per utenti assenti viene verificato
  un hash dummy per ridurre differenze temporali.
- Password nuove da 14 a 1024 caratteri, diverse dalla precedente e senza username. Non
  vengono imposte regole di composizione che favoriscono pattern prevedibili.
- Sessione Flask firmata, contenente solo UUID utente, cookie Secure in produzione,
  HttpOnly, SameSite Strict e durata predefinita 30 minuti. Login e cambio password
  cancellano la sessione precedente prima di crearne una nuova.
- Tutte le mutazioni web, incluso logout, richiedono CSRF con la stessa scadenza della
  sessione. Login è protetto da CSRF per impedire login CSRF.
- Il rate limit persistente usa bucket con nome SHA-256: 5 tentativi per IP+username e
  25 per IP in 15 minuti. Lo stato sopravvive ai worker e non salva username/IP nel nome
  del file.
- `admin/admin` può creare una sessione soltanto se l'IP client effettivo è loopback e
  accede unicamente a cambio password/logout. `X-Forwarded-For` viene considerato solo
  quando il peer immediato è loopback; connessioni remote dirette non possono falsificarlo.

## Conseguenze

Caddy deve essere l'unico processo capace di raggiungere Gunicorn in produzione e deve
riscrivere, non concatenare da input non fidato, gli header forwarded. L'application
server non va esposto su una socket TCP pubblica. Gli eventi login/cambio/logout saranno
inseriti nell'audit append-only in M1.6; fino ad allora non dichiarare M1 production-ready.
MFA/WebAuthn resta un hardening successivo alla v1.

