# ADR 0005 — Autorizzazione object-level centralizzata

Data: 2026-09-23  
Stato: accettata

## Contesto

Gli utenti possono avere più assegnazioni, anche in tenant differenti. Un controllo
basato soltanto sul ruolo o sul tenant presente nella URL permetterebbe IDOR, escalation
orizzontali o modifiche con effetti involontari su tenant non amministrati.

## Decisione

- Una policy centrale deny-by-default riceve principal, azione e scope canonici. Le
  operazioni su oggetti rete/client richiedono `tenant_id` e `network_id` espliciti.
- Il superadmin attivo può operare globalmente. L'admin è confinato all'unione dei tenant
  assegnati; il manager alla coppia tenant/rete assegnata.
- Cancellazioni fisiche, gestione lifecycle dei tenant ed export audit sono
  superadmin-only. Il manager non archivia reti e non gestisce utenti.
- Un admin vede un utente condiviso se esiste almeno un tenant in comune, ma modifica
  soltanto assegnazioni nei tenant amministrati e preserva quelle esterne.
- Poiché username, stato e password hanno effetto globale, un admin li modifica soltanto
  se amministra tutti i tenant assegnati all'utente. I superadmin restano fuori dal suo
  controllo.
- Qualunque modifica a un superadmin deve lasciare almeno un superadmin attivo.

## Conseguenze

I service applicativi devono caricare prima gli oggetti canonici dal repository e passare
alla policy gli scope ricavati da essi, non quelli dichiarati dal browser. Le query di
lista devono filtrare per scope e ogni singolo risultato va comunque autorizzato. Le
negazioni mostrate all'utente restano generiche; il `reason_code` interno è destinato
all'audit della milestone M1.6. Ogni nuovo use case deve aggiungere la propria azione e
almeno un test negativo cross-tenant.
