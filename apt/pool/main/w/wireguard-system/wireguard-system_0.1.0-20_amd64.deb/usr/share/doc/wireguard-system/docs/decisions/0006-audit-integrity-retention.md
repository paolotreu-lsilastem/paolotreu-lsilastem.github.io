# ADR 0006 — Integrità, retention ed export dell'audit

Data: 2026-09-23  
Stato: accettata

## Contesto

Gli eventi devono restare file JSON portabili, rilevare manomissioni e rispettare la
policy già approvata: rotazione giornaliera, 30 giorni operativi, eliminazione definitiva
al compimento di tre mesi ed export nativo compresso. Il contratto evento v1 è già
pubblicato e non include campi di integrità.

## Decisione

- Gli eventi restano righe JSONL conformi allo schema v1. Un secondo stream append-only
  conserva per ogni evento ID, SHA-256, HMAC precedente e HMAC corrente.
- L'HMAC copre data, HMAC precedente e serializzazione canonica dell'evento. La chiave è
  esterna al data tree; può essere distinta o derivata con separazione di dominio dal
  secret applicativo.
- Ogni append verifica prima la giornata completa sotto lock. Uno strappo tra evento e
  integrità viene rilevato e richiede recovery esplicito, senza riparazione automatica.
- Dopo 30 giorni i due stream sono compressi separatamente con gzip. Un manifest registra
  conteggio, HMAC finale e checksum. Al compimento di tre mesi calendario i file vengono
  verificati e poi eliminati.
- L'export `tar.gz` acquisisce i lock delle giornate, verifica le catene e include i file
  nativi, le catene e gli eventuali manifest. Non sovrascrive file esistenti.
- L'API di scrittura accetta soltanto metadati strutturati, nomi dei campi cambiati e
  codici errore; non espone un parametro per payload o testo diagnostico libero.
- Le mutazioni critiche su file distinti scrivono prima un evento `*_requested` e poi
  l'esito. In caso di crash non possono garantire una transazione distribuita, ma lasciano
  almeno una traccia verificabile dell'intento da riconciliare.

## Conseguenze

La catena rileva manomissioni ma non può impedire a chi possiede anche la chiave HMAC di
riscrivere la storia: chiave e data tree devono avere controlli operativi distinti. La
rotazione della chiave richiederà in futuro un keyring con ID e una cerimonia documentata;
fino ad allora la chiave usata da archivi ancora in retention deve restare disponibile.
Gli export copiati fuori dal data tree devono essere eliminati dall'operatore secondo la
stessa retention. I service futuri devono registrare esito e campi cambiati per ogni
mutazione o negazione autorizzativa.
