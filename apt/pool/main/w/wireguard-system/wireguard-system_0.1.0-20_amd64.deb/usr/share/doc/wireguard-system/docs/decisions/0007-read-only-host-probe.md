# ADR 0007 — Probe host e parsing WireGuard read-only

Data: 2026-09-24  
Stato: accettata

## Contesto

Il control plane deve conoscere prerequisiti e stato effettivo senza girare come root,
eseguire shell o confondere un errore di lettura con una VPN offline. Il formato `dump`
di `wg` è stabile e destinato agli script, ma include anche chiavi private e preshared.
Alias DNS differenti possono inoltre convergere sullo stesso endpoint e porta.

## Decisione

- Il runner accetta esclusivamente un argv con eseguibile assoluto, usa `shell=False`,
  ambiente minimale, timeout di 5 secondi e massimo 4 MiB per stdout/stderr.
- Il probe usa `wg show interfaces`, valida i nomi e interroga separatamente
  `wg show <interfaccia> dump`. Legge inoltre sysfs/procfs, `systemctl is-system-running`,
  `ip -json link show type wireguard` e `nft --json list ruleset`.
- Il parser valida conteggio e tipo dei campi, chiavi, endpoint, CIDR, timestamp e
  contatori. Scarta chiavi private, preshared e chiave pubblica dell'interfaccia. Conserva
  la chiave pubblica peer solo nel DTO in memoria; la serializzazione usa un fingerprint.
- Handshake `0`, endpoint `(none)`, fwmark `off` e keepalive `off` diventano valori nulli
  o zero espliciti. Endpoint osservati IPv6 sono accettati come trasporto runtime, senza
  estendere il supporto a subnet VPN IPv6 nella v1.
- Tutti i record A di ogni endpoint configurato vengono risolti prima dell'applicazione.
  Se due reti con la stessa porta condividono almeno un IPv4, l'operazione è negata. Un
  errore DNS è fail-closed e la risoluzione viene ripetuta prima di ogni apply.

## Conseguenze

Il processo web non ottiene privilegi aggiuntivi: quando nftables o WireGuard non sono
leggibili il risultato è `unavailable`. M2.4 potrà esporre gli stessi dati tramite un
helper ristretto. Il dump completo esiste brevemente nella memoria del processo figlio e
del parser, ma non viene persistito né inserito in output o errori. Un fallimento del
probe deve produrre presenza `unknown`, mai `offline`.

Riferimenti normativi: `wg(8)` e il sorgente upstream `wireguard-tools/src/show.c` per il
formato dump; documentazione kernel `networking/ip-sysctl.html` per `ip_forward`; API
userspace WireGuard per endpoint, handshake e contatori.
