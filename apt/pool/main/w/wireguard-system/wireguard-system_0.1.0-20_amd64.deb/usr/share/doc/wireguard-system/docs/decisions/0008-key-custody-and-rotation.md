# ADR 0008 — Custodia e rotazione delle chiavi WireGuard

Data: 2026-09-24  
Stato: accettata

## Contesto

Il prodotto deve consentire download successivi delle configurazioni client senza
salvare chiavi private in chiaro. Lo storage applicativo resta copiabile e file-based,
ma un furto del solo data tree non deve essere sufficiente a recuperare le chiavi.

## Decisione

- Le coppie WireGuard sono generate localmente con entropia del sistema e primitive
  X25519 della libreria crittografica; le chiavi private non sono mai scritte in chiaro.
- Ogni private key è cifrata con AES-256-GCM, nonce casuale da 96 bit e AAD canonica che
  lega versione, tipo risorsa, UUID risorsa, tenant e rete.
- La master key risiede in un keyring JSON esterno al data tree, file regolare non-symlink
  con permessi massimi `0600`. In produzione il percorso è obbligatorio.
- La rotazione aggiunge una nuova chiave attiva e conserva le precedenti come `retired`.
  Un comando idempotente ricifra ogni envelope con optimistic concurrency e audit di
  intent/esito; nessuna chiave ritirata viene eliminata automaticamente.
- Accesso e rotazione client richiedono RBAC object-level, password corrente, lifecycle
  consentito e audit redatto. Il chiamante riceve un errore generico anche se fallisce
  l'autenticazione crittografica.

## Conseguenze

Data tree e keyring devono avere backup e controllo accessi separati. Perdere il keyring
rende irrecuperabili le configurazioni; comprometterlo insieme al data tree espone le
chiavi, quindi restano necessari hardening host e rotazione. Il rewrap cambia revisioni e
ciphertext ma non la coppia WireGuard. La rotazione di una coppia client è persistita in
M2.2 e diventa effettiva sul kernel soltanto con l'apply/reconcile previsto in M2.5.
