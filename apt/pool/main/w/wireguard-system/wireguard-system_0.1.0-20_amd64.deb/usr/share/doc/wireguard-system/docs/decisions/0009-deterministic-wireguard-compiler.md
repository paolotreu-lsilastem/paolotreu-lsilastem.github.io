# ADR 0009 — Compiler WireGuard deterministico

Data: 2026-09-24  
Stato: accettata

## Contesto

Lo stato JSON deve produrre configurazioni server e client ripetibili, prive di direttive
iniettate da campi utente e coerenti con la topologia hub-and-spoke senza traffico Internet.
Il futuro reconciler deve poter confrontare byte identici a parità di input.

## Decisione

- Il compiler è puro, non accede a file o host e produce formato `wg-quick` con LF,
  separazione canonica dei blocchi e newline finale.
- L'interfaccia server usa indirizzo hub con prefisso della rete. Include soltanto client
  `active`, ordinati per IP numerico e UUID, con `AllowedIPs = <IP>/32`.
- L'interfaccia client usa il proprio indirizzo `/32`; il peer server contiene endpoint,
  CIDR completo della sola VPN e `PersistentKeepalive = 25`. Non esistono default route.
- La chiave privata viene passata come 32 byte già decifrati, ricodificata canonicamente e
  verificata contro la public key persistita prima di generare output.
- Nomi, descrizioni e altri campi liberi non vengono inclusi. Il compiler non emette DNS,
  MTU, hook, firewall inline o `SaveConfig`; queste policy non devono essere sovrascritte
  o trasformate in comandi dal file WireGuard.

## Conseguenze

Configurazioni uguali producono byte uguali e possono essere protette da hash nei job e
nei rollback futuri. Il server non accetta traffico attribuito a subnet intere da un peer,
mentre il client raggiunge tutti i peer della propria VPN passando dall'hub. L'applicazione
live, i permessi dei file temporanei, il firewall e il rollback restano compiti M2.4–M2.5.
