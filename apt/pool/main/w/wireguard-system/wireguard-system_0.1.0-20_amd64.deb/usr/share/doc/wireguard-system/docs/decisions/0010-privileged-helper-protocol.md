# ADR 0010 — Helper privilegiato e protocollo locale ristretto

Data: 2026-09-25  
Stato: accettata

## Contesto

Flask non deve girare come root, ma probe e future mutazioni WireGuard richiedono accesso
host. I permessi di un socket da soli non proteggono da sostituzione del peer, membri di
gruppo inattesi, parsing ambiguo o ampliamento accidentale dell'interfaccia privilegiata.

## Decisione

- systemd crea un socket Unix root:`wg-portal` `0660` e avvia un processo helper root per
  connessione, con timeout, capability bounding e filesystem/device hardening.
- Il client valida tipo, proprietario e permessi del socket e richiede UID peer 0 tramite
  `SO_PEERCRED`; il helper accetta soltanto l'UID risolto dall'utente `wg-portal`.
- Ogni connessione contiene un solo frame JSON ASCII newline-delimited. Richieste oltre
  64 KiB e risposte oltre 16 MiB sono negate; versioni, UUID, campi e parametri sono chiusi,
  le chiavi duplicate e i valori JSON non finiti sono rifiutati.
- La prima allowlist contiene soltanto `probe` con parametri vuoti. Eccezioni interne sono
  convertite in codici stabili senza testo sensibile; request e response ID devono coincidere.
- Il protocollo non accetta shell, argv, path, interfacce o unità arbitrarie. Le operazioni
  mutanti saranno aggiunte singolarmente in M2.5 con validazione e test negativi dedicati.

## Conseguenze

Il web compromesso può richiedere soltanto telemetria già prevista e non ottiene una
primitive generica root. L'attivazione per connessione riduce stato e durata del processo,
ma ogni chiamata ha costo di startup e richiede systemd: è coerente con il target Debian
scelto. WSL resta ambiente di sviluppo non privilegiato; socket e unità richiedono smoke
test sul target Debian reale prima della release.
