# ADR 0011 — Job persistenti e idempotenti per operazioni live

Data: 2026-09-25  
Stato: accettata

## Contesto

Start, stop, sync e reconcile attraversano file JSON, helper privilegiato e kernel senza
una transazione distribuita. Retry HTTP, doppio submit, crash del worker e più processi
non devono duplicare un'operazione o nasconderne un esito incerto.

## Decisione

- L'UUID della richiesta diventa anche UUID del job e chiave di idempotenza. Un retry è
  valido soltanto se operazione, attore, risorsa, tenant e rete coincidono esattamente.
- I job sono documenti JSON revisionati; ogni transizione usa compare-and-swap e segue
  `queued -> running -> succeeded|failed`. Il progresso è monotono e inferiore a 100
  finché il job non riesce.
- Enqueue e transizioni registrano intent prima della write ed esito dopo. Audit conserva
  codici stabili e campi cambiati, non il messaggio pubblico del job o output dei comandi.
- Un job `running` trovato al recovery viene marcato `failed/WORKER_INTERRUPTED` da attore
  di sistema. Non è dichiarato riuscito per inferenza; un reconciler separato ripristinerà
  desired e actual state.
- Autorizzazione e scope sono verificati prima della creazione. I job queued non concedono
  privilegi: worker e helper rivalideranno documenti canonici e protocollo.

## Conseguenze

La UI potrà fare polling di uno stato durevole e ritentare in sicurezza con lo stesso ID.
Un intent senza esito o un job interrotto resta evidenza esplicita. Non essendoci ancora
un worker, questo ADR completa soltanto il primo incremento M2.5; mutazioni, rollback e
reconcile richiedono registry e protocollo helper tipizzato.
