# ADR 0012 — Registry root-owned e envelope delle mutazioni

Data: 2026-09-25  
Stato: accettata

## Contesto

Il worker applicativo deve poter chiedere apply e stop senza trasformare il socket root in
un'interfaccia generica. Lo storage applicativo è scrivibile dal processo web e quindi non
può attestare quali interfacce siano state effettivamente create dal helper. Inoltre retry,
collisioni di nomi e sostituzione dei file non devono permettere di prendere controllo di
un'interfaccia estranea.

## Decisione

- Il helper mantiene `/var/lib/wg-portal-helper/registry.json`, creato da systemd tramite
  `StateDirectory` root-only `0700`; file e lock sono privati e le scritture sono atomiche.
- Il registry contiene soltanto identità canoniche, interfaccia, stato, digest della
  configurazione, ultimo request ID e timestamp. Non contiene configurazioni o chiavi.
- Ogni lettura fallisce se proprietario, permessi, symlink, dimensione o struttura non
  sono sicuri. Network UUID e nome interfaccia hanno associazione stabile e univoca.
- Il protocollo v1 aggiunge soltanto `network.apply` e `network.stop`. Non accetta path,
  argv, unità systemd o opzioni libere. Apply trasporta una configurazione ASCII limitata
  e il suo SHA-256; il helper rifiuta digest non corrispondenti e forme non canoniche.
- Finché l'executor M2.5 con validazione semantica, snapshot e rollback non è collegato,
  entrambe le mutazioni rispondono `MUTATION_HANDLER_UNAVAILABLE` e non cambiano l'host.
  Il registry viene aggiornato soltanto dopo una futura applicazione riuscita.

## Conseguenze

Un processo web compromesso non può dichiarare affidabile il proprio stato né scegliere
un file host. Il contenuto della configurazione attraversa il socket locale perché include
la chiave necessaria a WireGuard, ma non viene persistito nel registry. Il prossimo
incremento deve analizzarlo nuovamente nel confine root, scrivere uno staging file privato,
eseguire argv fissi e aggiornare il registry solo dopo verifica dell'actual state.
