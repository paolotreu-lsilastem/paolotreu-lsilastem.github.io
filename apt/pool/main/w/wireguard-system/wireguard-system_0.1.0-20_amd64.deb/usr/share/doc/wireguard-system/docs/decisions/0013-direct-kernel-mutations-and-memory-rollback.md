# ADR 0013 — Mutazioni kernel dirette e rollback in memoria

Data: 2026-09-26  
Stato: accettata

## Contesto

Apply, sync e stop richiedono privilegi root, ma `wg-quick` interpreta file e supporta
hook non necessari al prodotto. Conservare una configurazione attiva per il rollback
replicherebbe inoltre la chiave privata server in chiaro su disco, in contrasto con la
custodia cifrata del control plane.

## Decisione

- Il helper usa esclusivamente argv fissi di `/usr/bin/ip` e `/usr/bin/wg`, senza shell:
  `ip link/address`, `wg setconf`, `wg syncconf` e `wg showconf`.
- Una seconda validazione nel processo root accetta soltanto la grammatica emessa dal
  compiler: IPv4 RFC1918 `/16`–`/30`, porta `51820`–`51999`, chiavi canoniche e peer `/32`
  univoci nella subnet. Hook, default route e direttive extra sono rifiutati.
- La configurazione WireGuard filtrata passa a `wg` tramite stdin. Non viene creato alcun
  file di configurazione server in chiaro.
- Prima di sync o stop, actual state e indirizzo vengono acquisiti dal kernel e mantenuti
  soltanto in memoria. Un errore ripristina lo snapshot; un rollback non riuscito produce
  `ROLLBACK_FAILED` e richiede reconcile.
- Un lock root-only serializza l'intera sequenza host/registry. Interfacce esistenti ma non
  registrate, registry senza interfaccia e cambi di indirizzo live falliscono in chiusura.
  Un cambio indirizzo richiederà stop/start esplicito nel worker.

## Conseguenze

La superficie privilegiata non dipende da parser o hook di `wg-quick` e non aggiunge copie
persistenti della chiave. Resta una finestra inevitabile tra kernel e registry in caso di
kill o crash del processo: il job interrotto e il futuro reconciler devono segnalarla e
non dedurre il successo. Le operazioni sono serializzate sull'host, scelta conservativa
adeguata al control plane iniziale.
