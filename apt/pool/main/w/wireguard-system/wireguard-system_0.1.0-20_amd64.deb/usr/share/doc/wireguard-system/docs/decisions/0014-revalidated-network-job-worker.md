# ADR 0014 — Worker di rete con rivalidazione al consumo

Data: 2026-09-26  
Stato: accettata

## Contesto

Tra enqueue ed esecuzione possono cambiare ruolo dell'utente, lifecycle, desired state,
client, chiavi e documenti. Un job autorizzato quando creato non può quindi diventare una
capability durevole. Il worker deve anche evitare che errori crittografici o risposte del
helper espongano segreti nei documenti job e nell'audit.

## Decisione

- Il worker rivendica il job con transizione CAS `queued -> running`; processi concorrenti
  non eseguono due volte lo stesso documento.
- Al consumo ricarica utente, rete e client dai path canonici, ricostruisce il principal e
  ripete la policy object-level. Utenti disabilitati o scope rimossi causano un fallimento.
- Desired state e lifecycle determinano l'azione: stop non apre chiavi; start/sync e
  reconcile-running decifrano la sola chiave server in memoria e compilano nuovamente la
  configurazione dai client correnti.
- L'UUID del job è anche request ID del helper. Risultato e forma della risposta vengono
  verificati prima del successo; codici helper conosciuti restano azionabili, gli altri
  diventano `HELPER_OPERATION_FAILED`. Testi e payload del helper non sono persistiti.
- `wg-portal worker-once` elabora al massimo il job queued più vecchio e restituisce un
  exit code non zero se il job termina failed. Un futuro servizio systemd potrà invocarlo
  ripetutamente senza incorporare un worker nel processo web.

## Conseguenze

Revocare un ruolo prima dell'esecuzione revoca anche il job. La configurazione applicata
riflette lo stato canonico al consumo, non uno snapshot potenzialmente obsoleto accodato
dalla UI. Il worker attuale è sincrono e processa un job per invocazione; polling continuo,
backoff e reconcile periodico restano nel prossimo incremento.
