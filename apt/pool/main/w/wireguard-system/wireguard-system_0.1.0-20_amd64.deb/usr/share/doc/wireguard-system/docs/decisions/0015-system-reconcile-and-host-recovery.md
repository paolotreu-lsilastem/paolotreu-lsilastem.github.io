# ADR 0015 — Reconcile di sistema e recovery dello stato host

Data: 2026-09-27  
Stato: accettata

## Contesto

Un job avviato da un utente rivalida correttamente quel ruolo al consumo, ma la
convergenza dopo crash o riavvio host non può dipendere dalla permanenza dei privilegi
dell'ultimo operatore. Inoltre il registry root-owned può indicare una rete attiva mentre
l'interfaccia kernel è scomparsa: il helper rifiutava questo stato invece di ripararlo.

## Decisione

- L'identificatore UUID nullo è riservato nei job v1 all'attore interno di sistema. Può
  essere creato soltanto dal metodo dedicato e può eseguire esclusivamente
  `network.reconcile`; ogni altra operazione con tale attore fallisce in chiusura.
- `reconcile-once` recupera i job interrotti, crea o riusa un job persistente di sistema
  per ogni rete canonica e lo esegue attraverso lo stesso worker, compiler, custodia
  chiavi e helper delle richieste utente. Intento, transizioni ed esito restano auditati.
- Un lock file-backed globale rende mutuamente esclusivi `worker-once` e
  `reconcile-once`, evitando che il recovery marchi come interrotto un job ancora in
  esecuzione in un altro processo.
- Se registry e identità coincidono ma l'interfaccia non esiste, `network.apply` la
  ricrea dalla configurazione corrente e la verifica prima di aggiornare il registry;
  `network.stop` elimina invece il record stale. Collisioni non gestite e mismatch di
  identità restano rifiutati.

## Conseguenze

La convergenza one-shot è ripetibile, redatta e non attribuisce azioni automatiche a un
utente umano. Il comando verifica tutte le reti, quindi non è ancora il loop periodico
ottimizzato: polling, backoff, pianificazione basata sul drift e test E2E hub/client
rimangono il prossimo incremento M2.5.
