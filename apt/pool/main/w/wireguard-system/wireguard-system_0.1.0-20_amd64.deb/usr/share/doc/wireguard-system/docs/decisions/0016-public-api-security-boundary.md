# ADR 0016 — Confine di sicurezza dell'API pubblica v1

Data: 2026-09-27  
Stato: accettata

## Contesto

L'automazione remota richiede credenziali revocabili e scope indipendenti dalle sessioni
browser. Download di configurazioni client, raggiungibilità di rete e cancellazioni
fisiche aumentano però l'impatto di una credenziale compromessa e devono avere confini
espliciti prima di definire il contratto OpenAPI.

## Decisione

- La v1 usa service account file-backed con assegnazioni RBAC esplicite. I bearer token
  sono casuali, mostrati una sola volta e persistiti solo come identificatore pubblico e
  hash del secret. Scadono entro 90 giorni e supportano rotazione e revoca auditata; il
  contratto non impedisce una futura integrazione OAuth 2.1/OIDC.
- Il download completo di una configurazione client richiede il permesso separato
  `client.config:read`, negato per default, e una credenziale a vita breve. Ogni risposta
  è auditata e `no-store`; chiavi private server ed export massivi non sono esposti.
- `/api/v1` condivide l'endpoint HTTPS Caddy della UI ma inizialmente accetta richieste
  soltanto da reti amministrative configurabili. mTLS è opzionale per integrazioni ad alto
  privilegio. L'accesso Internet richiede penetration test e drill di revoca superati.
- La v1 non offre cancellazioni fisiche. Lifecycle, disabilitazione, revoca e archiviazione
  restano automatizzabili; le eliminazioni rare rimangono superadmin-only via UI/CLI con
  precondizioni e backup.

## Conseguenze

Prima dei CRUD API vanno definiti schema dei service account/token, hashing, retention,
rate limit e contratto OpenAPI. Caddy deve applicare la policy di rete senza fidarsi di
header del chiamante. Le future estensioni OAuth/OIDC, Internet-facing o distruttive
richiederanno una nuova decisione e una revisione del threat model.
