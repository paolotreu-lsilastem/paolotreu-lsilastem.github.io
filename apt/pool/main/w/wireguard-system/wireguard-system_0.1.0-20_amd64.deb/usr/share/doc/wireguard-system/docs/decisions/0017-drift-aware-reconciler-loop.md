# ADR 0017 — Reconciler periodico basato sul drift

Data: 2026-10-02  
Stato: accettata

## Contesto

Il reconcile one-shot applicava tutte le reti a ogni invocazione. Un servizio periodico
non può generare job e operazioni privilegiate quando desired e actual state coincidono;
deve inoltre distinguere un'interfaccia realmente assente da un probe incompleto.

## Decisione

- Il reconciler acquisisce il lock globale, recupera eventuali job interrotti e richiede
  al helper un probe autenticato. Se `wireguard.runtime` non è `ok` o il payload è
  malformato, non assume che le interfacce siano assenti e non crea job.
- Per ogni rete confronta presenza, indirizzo hub/prefisso, porta, fwmark e insieme dei
  peer attivi. I peer sono correlati con fingerprint SHA-256 completi, host route `/32` e
  keepalive server osservato; endpoint e traffico dinamici non partecipano al drift.
- Soltanto le reti divergenti ricevono un job persistente `network.reconcile`. Job queued
  già presenti vengono riusati e il worker/helper conservano validazione, audit e rollback.
- Il loop parte immediatamente, usa l'intervallo configurato dopo un ciclo sano e un
  backoff esponenziale limitato dopo probe, job o contesa falliti. SIGTERM/SIGINT
  interrompono l'attesa. L'unità systemd gira come `wg-portal`, senza capability, e parla
  al processo root soltanto tramite il socket helper.
- Se il registry contiene il digest atteso ma la configurazione kernel è stata alterata,
  il helper risincronizza WireGuard. Un indirizzo alterato fuori banda richiede
  ricostruzione dell'interfaccia con snapshot e rollback in memoria.

## Conseguenze

Lo stato convergente non produce crescita continua dei job. Un probe non affidabile
provoca backoff e stato di errore, non mutazioni. L'incremento completa servizio e drift
della M2.5; il test E2E hub/client resta un gate separato prima di chiuderla.
