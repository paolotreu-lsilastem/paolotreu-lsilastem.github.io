# ADR 0018 — Isolamento L3 tramite VRF per rete

Data: 2026-10-03  
Stato: accettata

## Contesto

La v1 consente CIDR sovrapposti tra tenant soltanto con isolamento L3 reale. Ogni VPN
deve inoltrare traffico tra i propri peer attraverso l'hub, senza offrire transito verso
LAN, Internet o altre reti gestite. Il helper privilegiato possiede oggi soltanto
`CAP_NET_ADMIN`; creare namespace dinamici con `ip netns` richiederebbe anche
`CAP_SYS_ADMIN`, capability molto più ampia.

## Decisione

- Ogni rete attiva viene associata a una VRF Linux distinta e a una tabella di routing
  riservata nell'intervallo `10000`–`59999`. L'allocazione parte da un hash versionato
  dell'UUID rete, risolve collisioni con probing deterministico e verrà persistita nel
  registry root-owned.
- Nome VRF (`wgv<TABELLA>`) e tabella nftables (`wgp_<TABELLA>`) sono derivati soltanto
  dall'ID numerico validato; nessun nome, comando o frammento nft arriva dall'utente.
- Ogni rete ha una tabella nftables `inet` indipendente. Le chain base mantengono
  `policy accept` per non assumere il controllo del firewall host, ma intercettano la
  propria interfaccia WireGuard: consentono input solo verso l'IP hub, output solo
  dall'IP hub e forwarding soltanto VPN→stessa VPN con sorgente/destinazione nel CIDR.
  Tutti gli altri pacchetti che entrano o escono da quell'interfaccia vengono scartati.
- Il forwarding IPv4 dell'host è prerequisito esplicito e verificato. L'abilitazione sarà
  installata come configurazione operativa dichiarativa; l'isolamento non dipende da una
  policy firewall globale preesistente.
- Apply, verifica, drift repair, stop e rollback tratteranno WireGuard, VRF, route e
  tabella nftables come un'unica risorsa. Stato parziale, collisioni o componenti non
  verificabili causano errore fail-closed.
- L'overlap nello stesso tenant resta sempre vietato. Quello cross-tenant verrà accettato
  dal service layer soltanto quando il percorso VRF è disponibile e verificato.

## Conseguenze

Le reti sovrapposte ottengono tabelle di routing distinte senza ampliare il helper con
`CAP_SYS_ADMIN`. Il firewall per interfaccia impedisce transito accidentale verso host,
WAN o un'altra VRF anche se il forwarding globale è attivo. VRF e nftables non proteggono
da root compromesso, che è già fuori dal confine di sicurezza del prodotto; proteggono
invece da configurazioni client ostili, errori operativi e collisioni tra tenant.

Il registry privilegiato v2 implementa la persistenza dell'identità VRF e migra v1 in
modo atomico, lasciando intenzionalmente `isolation: null` sulle entry legacy. L'executor
collega ora WireGuard, VRF e nftables in una transazione compensata; il probe privilegiato
ne attesta lo stato al reconciler, che tratta entry mancanti, residue, legacy o in drift
come non convergenti. Il test minimo per abilitare l'overlap richiede due reti con CIDR
identici, isolamento negativo e cleanup dopo errore.

Il contratto è ora identificato dalla capability `per-network-vrf-v1`, emessa soltanto
dal helper che usa executor e probe isolati. Il dominio la richiede per accettare overlap
cross-tenant e il reconciler la rivalida a ogni ciclo. L'acceptance reale conclusiva ha
verificato due client nella stessa rete, due tenant con CIDR identico, blocco verso
LAN/Internet e revoca live senza interrompere gli altri peer. Ha inoltre fissato nel
contratto la semantica Linux osservata: nei hook input/forward l'ingresso da una slave
VRF è identificato dal master VRF, mentre l'uscita forward è la slave WireGuard. Tutte le
risorse temporanee sono state rimosse e il forwarding host ripristinato.
