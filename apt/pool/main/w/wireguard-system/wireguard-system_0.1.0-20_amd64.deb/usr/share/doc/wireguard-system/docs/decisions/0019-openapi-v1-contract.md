# ADR 0019 — Contratto HTTP pubblico API v1

Data: 2026-10-05  
Stato: accettata

## Contesto

L'API remota amplia il confine di fiducia e deve restare un adattatore del service layer,
non una serializzazione dei documenti storage. Prima di implementare token o route occorre
fissare versioning, proiezioni pubbliche, concorrenza, retry, paginazione ed errori in una
forma controllabile automaticamente. Le decisioni di prodotto e sicurezza sottostanti
sono già state confermate in `USER_DECISIONS.md` e ADR 0016.

## Decisione

- Il contratto normativo è OpenAPI 3.1.0 in `docs/openapi/v1.json`; il formato JSON evita
  una dipendenza YAML nel bootstrap minimo. Tutti i path appartengono a `/api/v1` e usano
  bearer token opachi dietro HTTPS Caddy.
- Le response sono proiezioni esplicite con schemi chiusi. Hash password/token, envelope
  cifrati, chiavi private server, path e dettagli helper non appartengono al modello API.
- Le collezioni hanno ordine deterministico definito dall'implementazione, `limit` default
  50 e massimo 200, più cursore opaco autenticato di massimo 512 caratteri. Un cursore non
  valido fallisce, non viene interpretato come offset né come nuovo scope.
- Gli errori usano `application/problem+json` con campi chiusi `type`, `status`, `code`,
  `title`, `request_id` ed eventuali errori campo redatti. Oggetti fuori scope e inesistenti
  condividono `404`; dettagli interni non attraversano il confine.
- Ogni POST mutante richiede `Idempotency-Key` UUID. PATCH e azioni che dipendono dalla
  revisione richiedono un ETag forte `"rev-N"` tramite `If-Match`; assenza produce `428`,
  revisione obsoleta `412`, riuso incompatibile della chiave `409`.
- Le operazioni host restituiscono `202`, un corpo `JobAccepted` e `Location` del job. Non
  esistono `DELETE` fisici: sospensione, revoca e archivio sono transizioni esplicite.
- Download client, telemetria e risposte che mostrano una credenziale una sola volta usano
  `Cache-Control: no-store`. La configurazione client resta `text/plain`; nessun endpoint
  offre chiavi server o export massivi.
- M3.1 controlla struttura, riferimenti e invarianti. Conformance test contro Flask e
  compatibility test tra release diventano obbligatori in M3.7.

## Conseguenze

Gli endpoint possono essere implementati in incrementi senza inventare convenzioni locali.
La separazione tra storage e proiezioni pubbliche riduce il rischio di esposizione per
serializzazione accidentale. Idempotenza e cursori richiederanno stato file-backed
autenticato e cleanup esplicito; ETag richiederà mapping univoco alla revisione repository.
Una modifica incompatibile non può essere introdotta silenziosamente nella v1 e richiede
una nuova major o una fase di deprecazione documentata.
