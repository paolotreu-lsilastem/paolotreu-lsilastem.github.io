# ADR 0020 — Credenziali API file-backed a puntatore attivo

Data: 2026-10-05  
Stato: accettata

## Contesto

I service account richiedono token revocabili e ruotabili senza salvare il secret e senza
una transazione SQL. Aggiornare separatamente vecchia e nuova credenziale produrrebbe una
finestra di crash con due token attivi oppure nessun token valido.

## Decisione

- Identità e credenziale sono documenti distinti. `service_account` conserva nome, stato,
  assegnazioni RBAC, permessi e `active_credential_id`; `api_credential` conserva UUID
  pubblico, UUID identità, hash Argon2id e scadenza.
- Il token one-time ha formato `wgp_v1.<credential-uuid>.<secret-base64url>`. Il secret è
  generato da 32 byte casuali e non viene scritto in file, audit, indice, log o eccezioni.
- È valida soltanto la credenziale indicata dal puntatore dell'identità attiva. La
  rotazione crea prima un record non ancora autorevole e cambia poi il puntatore con CAS;
  il vecchio token diventa invalido in una singola scrittura atomica. Un errore elimina il
  nuovo record orfano. La revoca imposta stato `revoked` e puntatore nullo nello stesso CAS.
- Le credenziali normali scadono entro 90 giorni. Il permesso sensibile
  `client.config:read` limita la credenziale a 24 ore. Record storici non puntati non sono
  autenticabili anche se il loro hash resta disponibile per audit/diagnosi.
- Parsing, hash errato, credenziale ignota, scadenza, revoca e corruzione restituiscono lo
  stesso errore. Un hash dummy bilancia il percorso degli identificatori ignoti.
- Il rate limit persistente usa finestre configurabili per coppia credenziale+IP e per IP;
  nomi file derivati da SHA-256 non espongono identificatore o indirizzo. I default sono
  120 richieste per credenziale+IP e 600 per IP ogni 60 secondi.
- La gestione delle identità è inizialmente superadmin-only. Le identità autenticate
  riusano le assegnazioni RBAC, ma i futuri job dovranno adottare un attore discriminato
  prima di accettare mutazioni asincrone da service account.

## Conseguenze

Rotazione e revoca sono fail-closed senza lock multi-file e senza conservare plaintext.
Una credenziale creata ma non puntata è inerte; il servizio tenta comunque il cleanup.
Backup del data tree contengono hash costosi ma non token riutilizzabili in chiaro e vanno
comunque protetti. M3.3 potrà autenticare letture API tramite il servizio registrato
nell'app factory; M3.5 dovrà versionare l'attore job prima delle azioni live remote.
