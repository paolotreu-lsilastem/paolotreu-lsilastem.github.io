# ADR 0021 — API read-only scoped e cursori cifrati

Data: 2026-10-05  
Stato: accettata

## Contesto

Il primo adattatore HTTP pubblico deve esporre documenti file-backed senza trasformare
gli schemi storage in un contratto remoto, senza permettere enumerazione cross-tenant e
senza rendere i cursori una fonte di metadati o una capability riutilizzabile.

## Decisione

- Il blueprint `/api/v1` autentica ogni richiesta tramite service account e costruisce un
  `Principal`; non usa cookie o login utente. Rate limit per credenziale+IP e IP precede
  la verifica del token.
- Un service read-only applica RBAC sull'oggetto canonico e restituisce proiezioni
  allowlistate separate dagli schemi storage. Chiavi, envelope, password hash, hash token,
  attori e payload job non sono campi della proiezione.
- Risorse inesistenti e risorse fuori scope restituiscono lo stesso Problem Details 404.
  Le negazioni autenticate sono auditate con attore, tipo/UUID allowlistati e request ID,
  senza motivazione RBAC o dati richiesta.
- Le liste sono ordinate per `(created_at, id)`, con limite predefinito 50 e massimo 200.
  Il cursore include posizione, versione, scadenza e digest di identità/risorsa/filtri;
  l'intero payload è protetto con AES-256-GCM e nonce casuale. La chiave è derivata dal
  secret applicativo per il solo contesto `api-cursor/v1` e il cursore scade dopo 15
  minuti.
- Parametri query sconosciuti o duplicati sono rifiutati. Request ID client validi sono
  propagati, gli altri sostituiti. Dettagli revisionati espongono ETag forte e tutte le
  risposte API usano `Cache-Control: no-store`.
- Finché il sottogate telemetrico non correla in modo affidabile peer runtime e client
  canonici, la proiezione rete dichiara `actual_state=unknown` e non inferisce presenza.

## Conseguenze

Il contratto remoto resta stabile anche se evolvono i documenti persistiti. Un cursore
non rivela scope e non può attraversare identità, collezioni o filtri, ma viene invalidato
alla scadenza o quando cambia la chiave applicativa. Le liste sono snapshot deboli: una
scrittura concorrente può cambiare le pagine successive, comportamento accettato per la
v1 read-only. M3.3 resta aperta fino allo snapshot telemetrico scoped; M3.7 aggiungerà la
conformance automatica completa tra risposte runtime e OpenAPI.
