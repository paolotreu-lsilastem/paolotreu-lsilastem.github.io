# ADR 0022 — Presenza client fail-closed e cache ricostruibile

Data: 2026-10-05  
Stato: accettata

## Contesto

WireGuard espone handshake, endpoint e contatori ma non una sessione “connessa”. La
telemetria remota deve associare questi dati ai client del tenant senza esporre chiavi,
senza scambiare drift per disconnessione e mantenendo una stima prudente di “online dal”
attraverso i riavvii.

## Decisione

- L'accesso alla rete viene autorizzato prima di chiamare il helper privilegiato. Lo
  snapshot è accettato soltanto se ha meno di 60 secondi e dichiara runtime WireGuard sano
  e capability `per-network-vrf-v1`.
- Registry root-owned, rete, interfaccia, VRF, CIDR, hub, porta e indirizzo devono
  coincidere. L'insieme dei peer deve corrispondere esattamente ai client attivi, incluse
  route `/32` e keepalive server; duplicati, peer mancanti o estranei invalidano l'intero
  snapshot.
- La correlazione usa il fingerprint SHA-256 della chiave pubblica solo in memoria. API e
  cache non contengono chiave, fingerprint o nome dell'interfaccia.
- Con soglia globale `T`, un handshake è `online` fino a `T`, `stale` fra `T` e `2T` e
  `offline` oltre `2T`; senza handshake è `never_seen`. Il default approvato di `T` è 180
  secondi e l'intervallo configurabile è 30–86400 secondi.
- Un errore, campione vecchio o mismatch produce `unknown` per tutti i client attivi e non
  aggiorna la cache. Una rete desired-stopped è `offline` soltanto quando probe sano
  conferma assenza sia dell'interfaccia sia del record privilegiato.
- `runtime/presence/<client-uuid>.json` conserva l'ultimo campione con schema v1 e update
  atomico. La stima `online_since_estimated` continua dopo un riavvio solo se due campioni
  online distano al massimo `T`; altrimenti riparte dal nuovo campione. La cache è derivata
  e non influenza autorizzazione, desired state o reconcile.

## Conseguenze

La dashboard distingue esplicitamente evidenza recente, degrado temporale, assenza
verificata e impossibilità di osservare. Un peer realmente online può apparire `unknown`
durante drift o guasto del probe, scelta intenzionale per evitare falsi dati operativi.
La cache può essere cancellata a servizio fermo e ricostruita; la stima “online dal” si
azzera, mentre configurazioni e chiavi restano inalterate.
