# ADR 0023 — Mutazioni API tenant idempotenti e revisionate

Data: 2026-10-05  
Stato: accettata

## Contesto

Le mutazioni remote devono tollerare timeout e crash senza creare due risorse, impedire
aggiornamenti persi e non introdurre payload o segreti in un nuovo archivio persistente.
Più processi Flask possono inoltre tentare contemporaneamente di creare lo stesso slug
tenant, vincolo che attraversa documenti distinti.

## Decisione

- Ogni POST mutante richiede un UUID canonico `Idempotency-Key`. Il record è collocato
  sotto identità macchina e chiave, protetto da lock, e lega `principal_id`, operazione e
  SHA-256 del JSON canonico. Lo stesso UUID in identità diverse forma namespace distinti.
- Prima dell'use case viene persistito un record `pending` con ID risorsa preallocato. Un
  retry dopo crash esegue nuovamente l'operazione con lo stesso ID; l'use case riconosce
  l'eventuale risorsa già creata soltanto se tutti i campi iniziali coincidono.
- Solo risposte 2xx con body oggetto redatto e header `ETag`/`Location` possono diventare
  `completed`. Payload richiesta, token, password, secret, configurazioni ed envelope di
  chiavi non vengono conservati; una risposta che li contiene fallisce in chiusura.
- PATCH usa un ETag forte `"rev-N"`. Header assente produce 428, formato errato 400 e
  revisione non corrente 412; il repository mantiene il compare-and-swap effettivo.
- Il parser accetta soltanto JSON UTF-8 oggetto e rifiuta chiavi duplicate, costanti non
  finite e campi non allowlistati. Il blueprint bearer API è escluso dal CSRF basato su
  cookie; autenticazione e rate limit continuano ad applicarsi prima delle route.
- Create e update tenant sono superadmin-only. Un lock globale breve racchiude scansione
  e creazione per garantire unicità dello slug fra file e processi. Lifecycle, fallimenti,
  intenti ed esiti sono auditati senza valori ricevuti.

## Conseguenze

Un timeout può essere ritentato in sicurezza e una chiave riusata con altro payload o
operazione restituisce conflitto. I record `pending` non possono essere eliminati alla
cieca perché conservano l'identità necessaria alla riconciliazione post-crash. Durata dei
record completati, gestione dei pending e quota, aperte al momento di questa decisione,
sono state successivamente approvate e implementate dall'ADR 0025.
