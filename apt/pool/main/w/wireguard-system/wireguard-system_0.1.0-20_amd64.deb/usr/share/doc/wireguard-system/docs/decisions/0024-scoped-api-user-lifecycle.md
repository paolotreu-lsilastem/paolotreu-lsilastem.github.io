# ADR 0024 — Lifecycle utenti API scoped e fail-closed

Data: 2026-10-05  
Stato: accettata

## Contesto

Un utente può avere assegnazioni in più tenant. Un admin che controlla soltanto uno di
essi deve poter gestire la propria parte senza modificare stato globale o assegnazioni
esterne. Creazione idempotente e recovery post-crash devono inoltre evitare di conservare
la password iniziale in chiaro.

## Decisione

- Create usa l'ID preallocato dallo store idempotency. La password iniziale rispetta la
  policy comune di almeno 14 caratteri, non contiene lo username, viene hashata Argon2id
  prima della persistenza e imposta `must_change_password=true`.
- Un recovery riconosce l'utente preesistente soltanto con revisione iniziale, identità,
  assegnazioni e password verificata contro l'hash. Password, hash e payload non entrano
  in risposta o record idempotency.
- Lo username è globalmente univoco senza distinzione tra maiuscole/minuscole. Un lock
  file globale serializza scansione, create e modifiche che devono proteggere l'ultimo
  superadmin attivo.
- Il superadmin può gestire ogni assegnazione. Un admin può cambiare soltanto assegnazioni
  nei propri tenant e deve preservare quelle esterne; può cambiare lo stato globale solo
  se controlla tutti i tenant dell'account. Manager, target superadmin e side effect
  cross-tenant sono indistinguibili da una risorsa inesistente.
- Tenant e reti referenziati dalle assegnazioni vengono risolti dai documenti canonici.
  PATCH è chiusa a `status` e `assignments`, usa `If-Match` e non consente password o
  username amministrativi.

## Conseguenze

La gestione delegata resta utile per account multi-tenant senza trasformare un admin
parziale in amministratore globale. Il cambio password rimane nel flusso autenticato
dedicato. Le operazioni sono file-backed e sincrone; non toccano WireGuard né il helper.
