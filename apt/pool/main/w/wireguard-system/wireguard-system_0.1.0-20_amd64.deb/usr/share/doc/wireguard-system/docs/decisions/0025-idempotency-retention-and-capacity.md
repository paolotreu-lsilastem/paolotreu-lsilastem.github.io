# ADR 0025 — Retention e capacità dello store idempotency

Data: 2026-10-05  
Stato: accettata

## Contesto

I risultati idempotenti contengono metadati e copie redatte delle risposte. Conservarli
senza limite aumenta esposizione e consumo disco; cancellare un record `pending` dopo un
crash può invece rendere possibile duplicare una mutazione non ancora riconciliata.

## Decisione

- Un record `completed` viene eliminato quando `updated_at` ha almeno 24 ore. Il cleanup
  avviene sotto lock globale sia tramite `wg-portal idempotency-maintain` sia prima della
  creazione di una nuova chiave.
- Un record `pending` non viene mai eliminato automaticamente, a prescindere dall'età.
  La manutenzione ne restituisce identità e chiave affinché l'operatore possa
  riconciliare la risorsa preallocata.
- Ogni service account può conservare per default al massimo 1000 record non scaduti.
  Il limite è configurabile, viene verificato dopo il cleanup e prima di scrivere il
  nuovo pending.
- Prima del pending e del completamento viene preservata una riserva filesystem
  predefinita di 256 MiB, anch'essa configurabile. Superare quota o riserva restituisce
  `429 RATE_LIMITED`; un use case non viene invocato se manca capacità per il pending.
- Record corrotti, timestamp non validi o lock conteso bloccano manutenzione e nuova
  allocazione senza cancellazioni implicite.

## Conseguenze

I retry automatici hanno una finestra garantita di 24 ore, mentre i crash ambigui
richiedono intervento esplicito. Il limite per identità contiene l'abuso di una singola
integrazione e la riserva disco protegge lo storage condiviso. Il packaging dovrà
pianificare il comando di manutenzione e monitorare i pending segnalati.
