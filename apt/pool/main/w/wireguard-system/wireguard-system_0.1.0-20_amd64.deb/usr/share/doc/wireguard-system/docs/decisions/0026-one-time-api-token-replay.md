# ADR 0026 — Replay delle risposte con token API one-time

Data: 2026-10-05  
Stato: accettata

## Contesto

Create e rotate dei service account restituiscono un bearer token casuale che il server
conserva soltanto come hash Argon2id. Il contratto generale di idempotenza riproduce una
risposta completata, ma applicarlo al token richiederebbe conservarne una copia
reversibile o derivarlo deterministicamente. Entrambe le opzioni ridurrebbero la
separazione delle chiavi e contraddirebbero la custodia hash-only già approvata.

## Decisione

- La prima risposta riuscita di create/rotate contiene il token e usa `no-store`.
- Lo store idempotency salva soltanto la proiezione redatta del service account; token,
  secret e payload originale non vengono persistiti.
- Un replay completato con la stessa `Idempotency-Key` restituisce
  `409 CREDENTIAL_RECOVERY_REQUIRED` e non crea una seconda credenziale.
- Il recupero richiede una rotazione esplicita con una nuova chiave idempotente.
- La revoca, che non restituisce segreti, conserva il normale replay della risposta.
- Un marker opaco dell'ultima mutazione API viene persistito nel documento interno del
  service account e omesso da ogni proiezione. Sotto lock per risorsa consente di
  distinguere il recovery post-crash da una nuova richiesta con `If-Match` obsoleto.
- Gli ID delle credenziali API sono deterministici rispetto alla singola mutazione: ciò
  permette di eliminare in sicurezza un eventuale hash orfano dopo un crash antecedente
  al commit dell'account, senza rendere deterministico il secret casuale.

## Conseguenze

La perdita della prima risposta comporta una rotazione aggiuntiva, ma una copia del data
tree non consente di ricostruire token attivi. Create, rotate e revoke restano serializzati,
revisionati e recuperabili senza duplicare risorse; un client deve gestire esplicitamente
il nuovo problem code invece di aspettarsi il replay del plaintext.
