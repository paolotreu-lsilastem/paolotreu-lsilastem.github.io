# ADR 0027 — Mutazioni API delle reti senza effetti host impliciti

Data: 2026-10-06  
Stato: accettata

## Contesto

La creazione e modifica di una rete deve produrre documenti completi, inclusa l'identità
WireGuard cifrata, senza accettare chiavi o nomi interfaccia dal chiamante. Una modifica
alla configurazione canonica di una rete `running` potrebbe inoltre essere rilevata dal
reconciler e trasformarsi in un effetto host, contraddicendo il confine del CRUD M3.4.

## Decisione

- Create richiede un tenant attivo e autorizzato, genera una coppia WireGuard casuale,
  cifra la privata con AAD tenant/rete e persiste la rete in stato `active/stopped`.
- Il nome interfaccia è derivato internamente come prefisso `wgp` più 48 bit di SHA-256
  dell'UUID rete; collisioni vengono comunque verificate globalmente e negate.
- La porta automatica sceglie il primo valore libero nel range `51820–51999` considerando
  sia hostname normalizzati sia gli insiemi IPv4 risolti. La porta manuale è obbligatoria
  soltanto in modalità manuale e subisce gli stessi controlli.
- CIDR sovrapposti nello stesso tenant sono vietati. Tra tenant sono accettati nel modello
  desiderato perché l'engine implementa isolamento VRF per rete; worker e reconciler
  rivalidano la capability privilegiata prima di qualunque start/apply.
- Nome e descrizione possono cambiare senza fermare la rete. Endpoint, modalità/porta e
  lifecycle possono cambiare soltanto quando `desired_state=stopped`, evitando effetti
  live indiretti. CIDR e hub non sono modificabili nella v1.
- L'archiviazione è una transizione revisionata e admin/superadmin-only; non elimina file,
  chiavi o reservation. Manager può aggiornare soltanto reti esplicitamente assegnate.
- Tutte le mutazioni sono serializzate sotto lock globale, validate contro lo snapshot
  canonico, protette da ETag e auditate. Create usa l'ID preallocato idempotente per il
  recovery post-crash e non restituisce chiavi o envelope.

## Conseguenze

Un'installazione senza master key rifiuta create con `503` prima di allocare un record
idempotente o generare chiavi. Un endpoint DNS non risolvibile è rifiutato fail-closed.
Le modifiche runtime richiedono prima un'azione stop esplicita, che verrà esposta nel
sottogate asincrono M3.5.
