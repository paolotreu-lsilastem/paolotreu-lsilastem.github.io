# ADR 0028 — Lifecycle API dei client senza apply implicito

Data: 2026-10-06  
Stato: accettata

## Contesto

Il CRUD M3.4 deve creare identità WireGuard, assegnare indirizzi permanenti e gestire
transizioni client senza anticipare la coda live di M3.5. Il reconciler considera i
client `active` parte della configurazione desiderata di una rete running: una modifica
diretta di tale insieme potrebbe quindi diventare un effetto host implicito.

## Decisione

- Create è scoped alla rete, richiede tenant e rete attivi, genera internamente la coppia
  WireGuard, cifra la privata con AAD client/tenant/rete e crea il client `pending` con
  reservation `reserved` e keepalive 25 secondi.
- L'IP può essere richiesto esplicitamente o scelto come primo host disponibile. Hub,
  network, broadcast e reservation non rilasciate restano indisponibili anche quando il
  client è revocato o archiviato.
- PATCH modifica soltanto nome e descrizione. Indirizzo, scope, chiavi, reservation e
  lifecycle non sono campi scrivibili direttamente.
- Le azioni revisionate sono `activate`, `disable`, `revoke`, `archive` e `release-ip`.
  Activate e ogni transizione che rimuove un client `active` richiedono
  `desired_state=stopped`; così il reconciler non può applicare indirettamente la
  mutazione. Le transizioni fra stati non attivi restano puramente file-backed.
- Revoca e archiviazione non rilasciano l'indirizzo. `release-ip` è un'azione distinta,
  idempotente e auditata, ammessa soltanto per client `revoked` o `archived`.
- Revoca e archiviazione sono irreversibili secondo la state machine v1. Il materiale
  cifrato può restare nel record per integrità storica, ma non è più scaricabile né
  accettato nella configurazione server dopo l'apply successivo.
- Create e azioni POST usano idempotenza persistente; PATCH e azioni usano ETag. Tutte
  le risposte sono proiezioni allowlistate con sola fingerprint della chiave pubblica.

## Conseguenze

M3.4 non crea job e non contatta helper o host. Per cambiare un client attivo occorre
prima fermare esplicitamente la rete; M3.5 sostituirà questo confine operativo con job
asincroni `202 Accepted` che rivalidano identità e stato al consumo. La rotazione chiave
e il download della configurazione restano separati dal lifecycle e saranno completati
nel gate dedicato ai segreti client.
