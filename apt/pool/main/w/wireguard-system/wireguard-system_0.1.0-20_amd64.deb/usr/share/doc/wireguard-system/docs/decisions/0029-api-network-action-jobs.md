# ADR 0029 — Azioni rete API e identità macchina nei job

Data: 2026-10-07  
Stato: accettata

## Contesto

Le azioni API `start`, `stop`, `sync` e `reconcile` devono modificare lo stato desiderato
e accodare lavoro privilegiato senza eseguire WireGuard nel processo HTTP. Il contratto
job originario identificava soltanto utenti UI tramite `actor_user_id`; riutilizzarlo per
un service account avrebbe creato ambiguità fra namespace e impedito di verificare la
credenziale esatta dopo rotazione o revoca. Va inoltre recuperato il crash fra commit
dello stato desiderato e creazione del job.

## Decisione

- L'adattatore HTTP richiede body `{}`, `If-Match` e `Idempotency-Key`, quindi delega a
  `NetworkActionService`. Una richiesta accettata restituisce `202`, job ID e `Location`;
  non esegue inline il worker e non contatta il helper.
- Lo store idempotency prealloca un UUID distinto usato come job ID. Sotto il lock globale
  condiviso con worker e reconciler, start/stop aggiornano `desired_state` e il marker
  interno `last_api_mutation_id`, quindi accodano il job. Un retry dopo crash riconosce il
  marker; un job già creato viene validato e riutilizzato.
- Start richiede rete e tenant attivi; sync richiede inoltre stato desiderato running.
  Stop resta consentito per convergere verso uno stato sicuro. Reconcile segue lo stato
  desiderato canonico.
- I nuovi job API persistono `actor_service_account_id` e `actor_credential_id`, mai il
  token. Il worker ricarica account e credenziale e richiede account attivo, puntatore
  alla stessa credenziale, scadenza futura e RBAC ancora valido prima di compilare o
  invocare il helper. Rivalida anche lo stato del tenant per operazioni running.
- I job legacy con il solo `actor_user_id` restano validi. Il sentinel UUID nullo rimane
  riservato al reconcile di sistema. Lo schema v1 viene esteso in modo additivo con un
  vincolo one-of fra attore utente e coppia service-account/credenziale; non serve una
  riscrittura dei file esistenti.

## Conseguenze

Rotazione, revoca o scadenza della credenziale dopo l'enqueue impediscono l'esecuzione
del job, anche se il service account esiste ancora. La risposta 202 rappresenta soltanto
l'accettazione persistente: l'esito si legge da `/api/v1/jobs/{id}`. Quote e backpressure
della coda e le mutazioni client live restano nei sottogate successivi di M3.5.
