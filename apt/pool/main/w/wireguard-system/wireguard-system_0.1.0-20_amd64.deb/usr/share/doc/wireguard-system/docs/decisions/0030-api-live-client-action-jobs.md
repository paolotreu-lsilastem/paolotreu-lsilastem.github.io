# ADR 0030 — Lifecycle client live e job di sincronizzazione

Data: 2026-10-07  
Stato: accettata

## Contesto

Le azioni client modificano il documento canonico, ma l'aggiunta o rimozione di un peer
attivo su una rete `running` richiede anche convergenza host. Limitare tali transizioni a
reti ferme impediva finestre incoerenti ma non soddisfaceva il requisito di modifiche
live. Documento client e job sono file distinti, quindi va recuperato anche il crash fra
la patch del client e l'enqueue.

## Decisione

- L'adattatore richiede body `{}`, `If-Match` e `Idempotency-Key`. Una transizione che
  aggiunge o rimuove un peer attivo su rete `running` aggiorna prima il client e accoda
  `network.sync`, restituendo `202`, job ID e `Location`. Se non serve convergenza host,
  restituisce il client aggiornato con `200` ed ETag.
- `ClientActionService` condivide il lock globale di worker e reconciler. La patch client
  salva `last_api_mutation_id`; un retry con la stessa mutazione completa l'enqueue dopo
  un crash e un job già presente viene soltanto validato e riutilizzato.
- Una transizione fra stati entrambi non attivi e `release-ip` non cambiano i peer e non
  accodano job. Revoca e archiviazione continuano a conservare l'indirizzo; il rilascio
  resta esplicito e ammesso solo dopo revoke/archive.
- Il job sincronizza l'intera rete dallo stato canonico, senza incorporare configurazioni
  o segreti. Mantiene l'identità service account/credenziale della richiesta, che il
  worker rivalida immediatamente prima dell'effetto host come stabilito da ADR 0029.
- Il processo HTTP non esegue il worker e non contatta il helper. Il `202` attesta solo
  persistenza della richiesta; il risultato operativo è quello del job.

## Conseguenze

Activate, disable, revoke e archive possono operare su reti attive senza apply implicito
nel processo web. Durante l'intervallo fra patch ed esecuzione del job lo stato canonico è
già quello nuovo, mentre il job rende esplicita la convergenza ancora pendente. Quote e
backpressure della coda restano l'ultimo sottogate di M3.5.
