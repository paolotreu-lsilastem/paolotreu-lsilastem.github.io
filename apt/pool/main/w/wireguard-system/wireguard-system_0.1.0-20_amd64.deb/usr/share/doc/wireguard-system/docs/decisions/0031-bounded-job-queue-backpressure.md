# ADR 0031 — Quote e backpressure della coda job

Data: 2026-10-07  
Stato: accettata

## Contesto

Una coda persistente senza limiti permetterebbe a una singola identità o rete di occupare
disco e ritardare indefinitamente la convergenza degli altri tenant. Il worker serializza
già gli effetti host, ma il rate limit HTTP non limita il numero di job durevoli creati da
richieste distribuite nel tempo.

## Decisione

- La capacità considera tutti i job non terminali, cioè `queued` e `running`. I limiti
  predefiniti sono 1000 globali, 25 per identità, 100 per tenant e 10 per rete; sono
  configurabili soltanto entro bound espliciti e devono rispettare la gerarchia
  rete ≤ tenant ≤ globale e identità ≤ globale.
- Controllo e creazione sono serializzati da un lock multiprocesso dedicato. Il retry
  idempotente di un job già esistente viene validato e restituito prima del controllo,
  quindi non consuma capacità aggiuntiva. Un job terminale libera quota immediatamente.
- Le azioni rete/client verificano capacità sotto il lock globale prima di modificare lo
  stato canonico. A coda piena rispondono `429 QUEUE_CAPACITY_EXCEEDED` con
  `Retry-After`, predefinito a 30 secondi, e lasciano il record idempotency `pending` per
  un retry sicuro con la stessa chiave.
- Il reconciler di sistema è esente dalla sola quota identità, perché non è controllabile
  da un chiamante remoto; continua a rispettare limiti globale, tenant e rete. Capacità
  esaurita è trattata come contesa e attiva il backoff del loop.
- Non esiste bypass per ruoli elevati o operazioni stop: l'operatore attende il consumo
  della coda o interviene sulla causa. Worker e reconciler mantengono un solo effetto host
  concorrente mediante il lock globale già esistente.

## Conseguenze

Il numero di operazioni privilegiate pendenti è limitato in modo deterministico anche con
molte credenziali o tenant. `Retry-After` è un minimo suggerito, non garantisce capacità
al tentativo successivo; i client devono usare backoff con jitter e conservare la stessa
chiave idempotente. I file job terminali richiederanno una policy di retention operativa
separata, ma non occupano capacità della coda.
