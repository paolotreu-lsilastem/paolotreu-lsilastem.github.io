# ADR 0032 — Download API sensibile della configurazione client

Data: 2026-10-07  
Stato: accettata

## Contesto

Il provisioning remoto necessita del profilo WireGuard completo, inclusa la chiave
privata client. Applicare soltanto il ruolo RBAC renderebbe ogni token amministrativo un
lettore di segreti; fidarsi del principal costruito all'inizio della richiesta lascerebbe
inoltre una finestra durante rotazione o revoca della credenziale.

## Decisione

- `GET /api/v1/clients/{id}/configuration` è disponibile esclusivamente a service
  account con permesso additivo `client.config:read`, negato per default, e scope RBAC
  sul client. Superadmin senza il permesso non costituisce un bypass.
- La credenziale deve avere durata totale non superiore a 24 ore ed essere ancora attiva.
  Sotto lo stesso lock usato da rotate/revoke, il servizio ricarica account, puntatore
  alla credenziale esatta, permessi e assegnazioni prima di decifrare; non si affida allo
  snapshot del principal creato dal middleware.
- Sono scaricabili solo client `pending`, `active` o `disabled` appartenenti a tenant e
  rete attivi. Fuori scope, permesso assente, credenziale sostituita, stato vietato e
  risorsa inesistente producono lo stesso `404` e audit dedicato.
- La chiave privata client viene decifrata e compilata soltanto in memoria. La risposta è
  un singolo file `text/plain` in attachment con `Cache-Control: no-store`, `Pragma:
  no-cache` ed `Expires: 0`; non usa ETag e non entra nello store idempotency.
- Non sono esposti chiave privata server, download multipli o export massivi. Errori di
  envelope, dominio o compilazione restituiscono `503` redatto e non includono profilo,
  chiavi o dettagli crittografici in audit/log.

## Conseguenze

Il bearer sensibile resta utilizzabile per automazione ma ha blast radius temporale e di
scope ridotto. Una rotazione completata prima del lock invalida il download; se il
download ha già il lock, termina prima della rotazione secondo un ordine seriale
definito. La UI con sessione continua a usare la riautenticazione tramite password e non
condivide questo endpoint bearer.
