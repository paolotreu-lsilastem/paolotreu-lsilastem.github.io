# ADR 0033 — Pubblicazione OpenAPI e baseline di compatibilità v1

Data: 2026-10-07  
Stato: accettata

## Contesto

Gli integratori devono poter scoprire il contratto senza accesso al repository, mentre
il deploy da wheel non può dipendere dalla presenza della cartella `docs`. Pubblicare una
console interattiva allargherebbe inutilmente la superficie. Il solo schema corrente non
impedisce inoltre che una modifica futura rimuova silenziosamente operazioni o renda più
restrittivi gli input della v1.

## Decisione

- `GET /api/v1/openapi.json` è la sola route API anonima. Serve OpenAPI come risorsa
  statica packaged con cache pubblica breve e request ID; non esegue use case, non espone
  hostname reali, segreti o riferimenti host e non abilita Swagger UI/ReDoc.
- `docs/openapi/v1.json` resta la fonte normativa. Una copia nel pacchetto è generata
  esplicitamente e il quality gate ne richiede l'identità byte-per-byte.
- `docs/openapi/v1.compatibility.json` congela la superficie strutturale iniziale della
  major v1. Il confronto automatico consente nuove operazioni additive, ma rifiuta
  rimozioni, cambio degli operation ID o della sicurezza, perdita di response/header,
  nuovi parametri/input obbligatori e modifiche incompatibili degli schemi.
- L'inventario delle route Flask deve coincidere con paths e metodi OpenAPI. Risposte
  seeded ed esempi pubblicati sono validati con JSON Schema Draft 2020-12 e format
  checker. Questi controlli entrano in `scripts/check.sh`.
- La baseline non viene aggiornata per aggirare un errore. Una rottura deliberata richiede
  nuova major, ADR, migrazione documentata e nuova baseline prima della pubblicazione.

## Conseguenze

Il contratto è disponibile anche da installazioni pacchettizzate e può alimentare client
codegen senza token. Il repository conserva un artefatto generato aggiuntivo e ogni
modifica OpenAPI compatibile richiede la sincronizzazione esplicita della copia packaged.
Il confronto strutturale non può provare tutta la semantica del servizio: test RBAC,
idempotenza, concorrenza ed E2E restano obbligatori.
