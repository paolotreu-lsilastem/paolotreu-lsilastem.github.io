# ADR 0034 — Fondamenta UI accessibili e server-rendered

Data: 2026-10-07  
Stato: accettata

## Contesto

I CRUD HTML successivi necessitano di una shell coerente prima di moltiplicare template e
pattern. Una SPA o asset remoti aumenterebbero dipendenze, CSP e superficie supply-chain;
nascondere voci in base al ruolo senza ribadire il confine backend potrebbe invece creare
una falsa impressione di autorizzazione.

## Decisione

- La baseline è Jinja server-rendered, responsive e priva di JavaScript. Un solo CSS
  packaged usa token locali, dark mode, focus visibile e `prefers-reduced-motion`; font e
  CDN esterni sono vietati.
- Ogni pagina eredita dalla shell comune con skip link, landmark, messaggi assistivi,
  account e logout CSRF. Campi e controlli devono avere nomi accessibili espliciti.
- La navigazione viene proiettata server-side dalle assegnazioni; nomi tenant/rete vengono
  risolti soltanto per presentazione e falliscono redatti. Questa proiezione non sostituisce
  mai RBAC object-level nelle view e nei service.
- Errori UI comuni sono HTML redatto con request ID; errori di routing API sono Problem
  Details. CSP mantiene `script-src 'none'` e consente soltanto stile/immagini same-origin.
- Test automatici verificano semantica HTML di base, label, scope per ruolo, formati errore,
  CSP, token colore WCAG AA e supporto reduced-motion.

## Conseguenze

Le milestone CRUD possono riusare pattern accessibili senza introdurre subito una toolchain
frontend. Interazioni complesse richiederanno round-trip server finché un caso concreto non
giustificherà JavaScript; tale introduzione richiederà una decisione e una revisione CSP.
