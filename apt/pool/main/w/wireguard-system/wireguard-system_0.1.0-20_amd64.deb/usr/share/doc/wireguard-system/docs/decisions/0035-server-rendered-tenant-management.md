# ADR 0035 — Gestione tenant server-rendered con retry e revisione

Data: 2026-10-07  
Stato: accettata

## Contesto

La UI tenant deve riusare autorizzazione, validazione e audit già applicati dall’API senza
effettuare richieste HTTP verso sé stessa o duplicare accessi repository. Un timeout dopo
la creazione può indurre un nuovo submit, mentre due sessioni possono modificare lo stesso
tenant concorrendo.

## Decisione

- Le view chiamano `ApiReadService` e `TenantMutationService` con un `Principal` ricavato
  dal documento utente ricaricato a ogni richiesta; nessuna view accede ai file canonici.
- Il form create riceve un UUID generato server-side e lo conserva sugli errori. Retry con
  stesso UUID e payload è idempotente nel service; slug duplicati restano conflitti.
- Il form update trasporta la revisione corrente e usa optimistic concurrency. Una
  revisione obsoleta restituisce pagina `409` redatta e non applica modifiche.
- Tutti i POST sono CSRF-protected e seguono Post/Redirect/Get dopo successo. Query,
  campi e cardinalità sono chiusi; messaggi non riportano eccezioni o dettagli storage.
- Scope negato e risorsa inesistente sono entrambi `404`. Le negazioni intercettate
  dall’adattatore HTML generano `ui.authorization`; i service auditano le mutazioni.

## Conseguenze

API e UI condividono use case e invarianti senza accoppiamento HTTP. L’UUID nel form non
è una capability e può essere modificato da un superadmin già autorizzato, ma deve restare
canonico. Il pattern viene riutilizzato nei successivi CRUD HTML.
