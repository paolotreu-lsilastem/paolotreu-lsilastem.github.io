# ADR 0036 — Gestione utenti multi-tenant senza autorità delegata al form

Data: 2026-10-07  
Stato: accettata

## Contesto

Un utente può avere assegnazioni in tenant amministrati da persone diverse. Il form HTML
di un admin deve consentire la modifica locale senza esporre un modo per eliminare ruoli
esterni, cambiare campi globali di un account condiviso o forgiare UUID non presentati.
La password iniziale è un segreto e non può essere riflessa dopo una validazione fallita.

## Decisione

- Le view usano soltanto `ApiReadService` e `UserMutationService`; tenant e reti
  selezionabili provengono da proiezioni autorizzate paginate, mai da accessi repository.
- Il browser invia solo le selezioni modificabili. Il server ricostruisce le assegnazioni
  e preserva quelle fuori scope lette dal modello autorizzato; hidden field non
  trasportano autorità o assegnazioni esterne.
- Checkbox ripetibili hanno allowlist e cardinalità esplicite. Ogni UUID deve appartenere
  alle opzioni offerte; campi inattesi, valori duplicati e UUID forgiati restituiscono
  `400` prima della mutazione.
- Lo stato è modificabile da un admin solo quando ogni assegnazione ricade nei tenant che
  amministra. Superadmin può assegnare il ruolo globale; admin e manager non possono.
- Nessun utente può modificare il proprio account dalla UI. La policy centrale rifiuta
  anche una modifica delle proprie assegnazioni richiesta attraverso un altro adattatore.
- Create conserva un UUID server-side per retry idempotenti. Update usa la revisione
  canonica. La password iniziale usa `autocomplete=new-password`, resta vuota dopo ogni
  errore e non compare in risposta, flash, audit o storage in chiaro.

## Conseguenze

La modifica parziale di account condivisi non dipende dalla correttezza del client ed è
fail-closed contro IDOR e mass assignment. L’assenza di JavaScript mantiene la CSP
`script-src 'none'`; il costo è una matrice server-rendered potenzialmente ampia, limitata
e paginata durante la costruzione delle opzioni.
