# ADR 0037 — Anteprima rete read-only e rivalidazione al salvataggio

Data: 2026-10-07  
Stato: accettata

## Contesto

La creazione di una rete deve rendere comprensibili indirizzamento, capacità e conflitti
prima di generare chiavi o modificare lo storage. Porte disponibili e indirizzi IPv4
risolti da un hostname possono però cambiare tra anteprima e conferma; trattare il
risultato come prenotazione produrrebbe una garanzia falsa o richiederebbe stato temporaneo.

## Decisione

- `NetworkMutationService.preview_create` applica lo stesso payload chiuso, RBAC,
  normalizzazione endpoint, resolver, allocatore porte e validator conflitti della
  create, sotto il medesimo lock di mutazione.
- La preview restituisce soltanto dati derivati e non sensibili: CIDR, hub, capacità
  client, endpoint, porta, modalità e nome interfaccia. Non genera una coppia WireGuard,
  non crea envelope, non persiste documenti e non riserva porte o indirizzi.
- Create ripete integralmente i controlli sotto lock e può quindi rifiutare una conferma
  se lo stato canonico o DNS è cambiato. La UI dichiara esplicitamente questo confine.
- Un UUID server-side rimane stabile tra preview, errori e conferma. Un retry identico
  dopo il commit riconosce la risorsa esistente senza generare una seconda rete.

## Conseguenze

Non viene introdotto storage effimero né cleanup di prenotazioni abbandonate. La preview
è fedele al momento in cui viene calcolata, mentre la mutazione resta autoritativa e
fail-closed. Il doppio calcolo al salvataggio è intenzionale e limita le race senza
promettere stabilità del DNS.
