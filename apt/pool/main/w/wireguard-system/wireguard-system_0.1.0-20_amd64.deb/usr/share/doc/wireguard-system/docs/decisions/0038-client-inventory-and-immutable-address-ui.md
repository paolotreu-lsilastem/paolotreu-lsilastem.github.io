# ADR 0038 — Inventario client redatto e indirizzo immutabile nella UI

Data: 2026-10-07  
Stato: accettata

## Contesto

La UI deve creare client con indirizzi stabili e mostrarne lo stato senza trasferire al
presentation layer documenti canonici contenenti chiavi. Consentire la modifica diretta
dell’IP dopo la creazione romperebbe reservation, configurazioni distribuite e
riconciliazione; nome e descrizione sono invece metadati sicuri anche su rete running.

## Decisione

- `/clients` seleziona una rete visibile; inventario e create sono nested sotto la rete,
  mentre dettaglio e update risolvono il client con autorizzazione object-level.
- Create conserva un UUID server-side e accetta modalità IP automatica o manuale. Solo
  `ClientMutationService` alloca/valida l’indirizzo e genera/cifra la coppia WireGuard
  sotto lock; il client nasce sempre `pending`.
- L’update HTML accetta esclusivamente nome, descrizione e revisione. IP, reservation,
  stato, fingerprint e chiavi non sono campi form e un tentativo di mass assignment
  restituisce `400`.
- I template ricevono la proiezione del read service: fingerprint SHA-256 sì, chiave
  pubblica completa, envelope e chiave privata mai. Lifecycle e download restano route
  dedicate con requisiti più forti nei sottogate successivi.

## Conseguenze

La stabilità dell’indirizzo non dipende dal browser e la modifica metadati non richiede
stop/sync. Cambiare IP richiede il lifecycle esplicito previsto dal dominio, incluso il
rilascio della reservation; non viene introdotta una scorciatoia CRUD distruttiva.
