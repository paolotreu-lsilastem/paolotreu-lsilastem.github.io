# ADR 0039 — Azioni client interattive e identità dei job

Data: 2026-10-07  
Stato: accettata

## Contesto

Le azioni lifecycle possono cambiare i peer di una rete running e quindi devono usare la
coda già adottata dall’API. Un utente web autenticato non possiede però una credenziale
API: inventarne una impedirebbe una corretta revoca dell’autorità e confonderebbe audit e
quote. Inoltre retry del browser e doppio submit non devono duplicare mutazioni o job.

## Decisione

- Ogni azione ha una route GET/POST dedicata, una conferma esplicita, la revisione del
  client e un mutation UUID generato nel form. Stato e reservation non sono campi CRUD.
- `ClientActionService` accetta `credential_id=None` esclusivamente per principal utente.
  `JobService` persiste allora `actor_user_id`; per principal macchina la credenziale
  resta obbligatoria e viene salvata insieme al service account.
- Il mutation UUID identifica sia la mutazione recuperabile sia l’eventuale
  `network.sync`. Un replay valido converge sullo stesso job; una collisione con attore,
  operazione o scope diverso fallisce.
- Il processo HTTP non esegue il worker. Lista e dettaglio job usano `ApiReadService`,
  scope object-level e proiezioni prive di attore, payload, chiavi o dettagli interni.
- Lo stato è già consultabile con refresh manuale; dialogo, polling e prevenzione client
  del doppio submit rimangono nel gate M3.12.

## Conseguenze

Revocare o ridurre i ruoli di un utente dopo l’enqueue impedisce al worker di applicare
il job, esattamente come la revoca della credenziale API. Le azioni su rete ferma o senza
variazione dei peer restano immediate; quelle live hanno un esito persistente e
ispezionabile senza ampliare l’autorità dell’utente.
