# ADR 0040 — Download interattivo della configurazione client

Data: 2026-10-07  
Stato: accettata

## Contesto

La configurazione completa contiene la chiave privata del client. Il ruolo della sessione
non basta come prova recente dell’identità e l’endpoint API usa intenzionalmente un
meccanismo diverso, basato su service account e credenziale breve. Il browser non deve
ricevere il segreto in una pagina intermedia né lasciarlo in cache.

## Decisione

- La UI usa una route GET/POST individuale e richiede la password corrente per ogni
  download. POST accetta soltanto CSRF e password, mai identificatori o campi profilo.
- Il service ricarica l’utente dal repository, verifica corrispondenza con sessione,
  account attivo, cambio password completato, RBAC corrente e lifecycle del client prima
  di decifrare. Non si affida al solo principal costruito a inizio richiesta.
- La stessa policy anti brute-force del login limita i tentativi per IP e identità
  sensibile; errori password e autorizzazione hanno messaggio generico e audit redatto.
- Il profilo è compilato soltanto in memoria e restituito direttamente come attachment
  `text/plain` con `no-store`, `no-cache`, scadenza immediata e nessun ETag. Non viene
  inserito in template, flash, idempotency store o file temporanei.
- Sono scaricabili soltanto client `pending`, `active` o `disabled` in tenant e rete
  attivi. Revoked, archived e oggetti fuori scope non presentano un link utilizzabile.

## Conseguenze

Una sessione sottratta da sola non consente di esportare chiavi. La password transita nel
solo body POST protetto da TLS/CSRF e non viene riproposta dopo errore. Il download API
resta separato e continua a richiedere `client.config:read` e credenziale breve, evitando
di confondere identità umane e automazioni.
