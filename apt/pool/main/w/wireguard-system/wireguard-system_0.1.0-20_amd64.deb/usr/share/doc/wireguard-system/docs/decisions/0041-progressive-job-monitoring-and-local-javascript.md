# ADR 0041 — Monitoraggio progressivo dei job e JavaScript locale

Data: 2026-10-07  
Stato: accettata; sostituisce il vincolo `script-src 'none'` di ADR 0034

## Contesto

Il requisito di mostrare una finestra di attesa fino all’esito di un’operazione live non
può essere soddisfatto bene con soli refresh manuali. Una SPA o dipendenze CDN sarebbero
sproporzionate e allargherebbero supply chain e CSP. Il controllo client-side non deve
inoltre diventare il confine contro retry o doppi submit.

## Decisione

- La UI resta server-rendered e pienamente utilizzabile senza JavaScript. Un unico asset
  packaged, `portal.js`, aggiunge dialogo/polling dei job e guard dei form POST.
- CSP passa da `script-src 'none'` a `script-src 'self'`; inline script, handler HTML,
  `unsafe-inline`, `unsafe-eval`, CDN e origini esterne restano vietati.
- `/jobs/{id}/status` usa sessione, RBAC object-level e proiezione allowlistata. Non
  restituisce il messaggio persistito del worker: un mapping server-side converte codici
  noti in istruzioni operative redatte e usa un fallback generico per codici ignoti.
- Il poller usa fetch same-origin senza cache, pausa a pagina nascosta, backoff limitato,
  una sola richiesta in volo e arresto allo stato terminale o alla perdita di autorità.
  Tutti gli aggiornamenti DOM usano `textContent` e classi di stato allowlistate.
- Il primo submit POST marca il form e blocca i successivi senza disabilitare il pulsante
  originale, preservandone `name/value`. Idempotenza, CAS e lock server-side restano
  obbligatori e rendono innocui retry che bypassino JavaScript.

## Conseguenze

Le operazioni live hanno feedback immediato e accessibile senza introdurre una toolchain
frontend. La superficie script cresce in modo circoscritto e verificabile; una futura
estensione deve restare nello stesso asset o motivare separatamente nuove dipendenze e
origini CSP.
