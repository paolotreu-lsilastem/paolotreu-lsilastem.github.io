# ADR 0042 — Dashboard scoped sulla rete selezionata

## Stato

Accettata — 2026-10-07.

## Contesto

Una dashboard che interroga tutte le reti a ogni refresh moltiplica le chiamate al helper
privilegiato per il numero di reti visibili. Endpoint, handshake e pattern temporali sono
inoltre metadati sensibili e devono seguire lo stesso confine object-level della rete.
La pagina deve restare utile senza JavaScript e non può interpretare l’assenza di un
campione affidabile come disconnessione.

## Decisione

`DashboardService` produce due proiezioni redatte: un inventario di tutti gli scope
visibili, ricavato senza probe, e uno snapshot live di una singola rete selezionata.
Lo snapshot autorizza la rete tramite `TelemetryService` prima di interrogare il helper,
poi unisce ai peer soltanto nome, stato e IP del client. I client non attivi sono
`inactive`; errori e incoerenze del runtime restano `unknown`.

La route HTML esegue un campionamento iniziale per il fallback progressivo. Il browser
interroga un endpoint session-based same-origin ogni cinque secondi, mantiene una sola
richiesta in volo, sospende il polling quando la pagina non è visibile e applica backoff
fino a 60 secondi. Gli aggiornamenti usano esclusivamente API DOM sicure e valori di
classe allowlistati.

## Conseguenze

- Ogni ciclo produce al massimo un probe privilegiato, indipendentemente dal numero di
  tenant o reti visibili.
- La selezione rende esplicito l’ambito dei metadati runtime e semplifica il controllo
  IDOR e la redazione.
- Inventario e ultimo snapshot restano visibili senza JavaScript; l’auto-refresh è un
  miglioramento progressivo.
- Lo stato runtime aggregato delle reti e i conteggi aggiornati senza reload rimangono un
  sottogate separato di M3.13.
