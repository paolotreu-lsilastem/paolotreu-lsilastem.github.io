# ADR 0043 — Stato dashboard aggregato con un solo probe

## Stato

Accettata — 2026-10-08.

## Contesto

Il probe privilegiato restituisce già uno snapshot atomico dell’intero host. Eseguirne
uno per ciascuna rete visibile moltiplicherebbe costo e contesa e produrrebbe timestamp
non confrontabili. La dashboard deve tuttavia mostrare lo stato effettivo di tutte le
reti senza rivelare metadati cross-tenant e senza lasciare che il drift di una rete
nasconda lo stato delle altre.

## Decisione

`TelemetryService.networks_snapshot` riceve l’elenco delle reti visibili, risolve ogni
documento e applica `dashboard.view` a tutti gli ID prima di chiamare il helper. Se anche
un ID è mancante o fuori scope, la richiesta termina con `404` senza probe. Limiti globali
vincolano numero di reti e client.

Un’unica risposta helper viene validata globalmente. Registry, isolamento, interfaccia e
peer vengono poi correlati separatamente per rete. Una rete desiderata running diventa
`actual_state=running` soltanto dopo la verifica completa; una rete desiderata stopped
diventa `stopped` soltanto quando interfaccia e registry risultano assenti. Qualunque
incoerenza locale produce `unknown` per la sola rete interessata. Un probe globalmente
non affidabile produce `unknown` per tutte le reti.

`DashboardService.live_snapshot` espone conteggi e riepiloghi di presenza per tutte le
reti autorizzate e include i dettagli client soltanto per la rete selezionata. Il browser
aggiorna la vista tramite un unico endpoint session-based e una sola richiesta in volo.

## Conseguenze

- Tutte le reti dello stesso ciclo condividono lo stesso timestamp osservato.
- Il numero di chiamate privilegiate è costante rispetto ai tenant e alle reti visibili.
- Un superadmin riceve più riepiloghi ma non più dettagli peer di quelli necessari alla
  selezione corrente; admin e manager restano confinati dalle stesse policy object-level.
- Lo stato effettivo è fail-closed e distinto dal desired state.
