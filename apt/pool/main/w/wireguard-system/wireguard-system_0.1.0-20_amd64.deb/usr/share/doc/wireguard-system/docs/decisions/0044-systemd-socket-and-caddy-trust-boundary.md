# ADR 0044 — Socket systemd e confine di fiducia Caddy

## Stato

Accettata — 2026-10-08.

## Contesto

Il processo web deve conoscere l’IP reale per bootstrap, rate limit e audit, senza
accettare header scelti da un client. Un bind TCP applicativo allargherebbe la superficie
e renderebbe ambigua l’identità del proxy. Caddy deve inoltre restare separato dal gruppo
`wg-portal`, perché quel gruppo può raggiungere il helper privilegiato.

## Decisione

systemd crea `/run/wg-portal/web.sock` come `wg-portal:caddy` con modo `0660` e lo passa a
Gunicorn tramite `fd://3`. Gunicorn gira come `wg-portal`, senza capability e senza access
log HTTP; Caddy è l’unico membro esterno autorizzato dal socket e non viene aggiunto al
gruppo applicativo. Il servizio usa l’app factory `wg_portal:create_app()` e rifiuta
mapping permissivi di header non standard.

Caddy termina HTTPS, applica un’allowlist CIDR all’intero origin e sovrascrive gli header
`X-Forwarded-*`. L’applicazione mantiene `WG_PORTAL_TRUST_UNIX_PROXY=false` come default.
Quando l’unità production imposta `true`, un peer WSGI senza indirizzo può usare il primo
`X-Forwarded-For` validato; peer TCP non loopback non diventano fidati. Header assente o
invalido produce un’identità fail-closed.

## Conseguenze

- Caddy non acquisisce accesso al socket helper root-owned.
- Nessuna porta Gunicorn è raggiungibile dalla rete o dal loopback host.
- La modalità di sviluppo conserva il proxy loopback, ma non abilita implicitamente il
  caso Unix.
- Cambiare reverse proxy, ownership o trasporto richiede una nuova analisi del confine e
  test di bootstrap, rate limit e audit.
- Il pacchetto Debian e il collaudo Caddy reale restano necessari prima della produzione.
