# ADR 0045 — Payload Python privato e hash-locked nel pacchetto Debian

## Stato

Accettata — 2026-10-08.

## Contesto

Debian 12 offre Python 3.11, ma le versioni native di Flask e Gunicorn sono precedenti
alla baseline applicativa e di sicurezza. Scaricare pacchetti Python nel `postinst`
renderebbe l’installazione dipendente dalla rete e non riproducibile; un virtualenv creato
in una directory temporanea introdurrebbe inoltre shebang non rilocabili.

## Decisione

Il builder risolve le dipendenze da `requirements-prod.lock`, che contiene versioni e
hash, accetta esclusivamente wheel binarie e installa applicazione e runtime sotto
`/usr/lib/wireguard-system/site-packages`. Il `.deb` non contiene `pip` né gli entrypoint generati
dalle wheel. Un launcher Python condiviso dai due comandi applicativi carica unicamente il payload privato,
rimuove `PYTHONHOME`, sovrascrive `PYTHONPATH` e usa `python3 -P`; il file ambiente
viene interpretato come dati `NAME=value`, mai da una shell.

Il `postinst` crea identità e directory, genera una sola volta segreti distinti e keyring,
inizializza i documenti come `wg-portal` e abilita le unità. Un ambiente esistente non
viene riscritto, ma owner e mode vengono ricondotti alla baseline. Remove e purge non
cancellano automaticamente stato o segreti.

## Conseguenze

- L’installazione del `.deb` non contatta PyPI e usa lo stesso runtime testato dal build.
- Ogni aggiornamento delle dipendenze produce un diff esplicito del lockfile.
- Il pacchetto è specifico per architettura quando include wheel native.
- Vulnerability scanning e aggiornamento periodico del lockfile restano obbligatori in M4.4.
- La riproducibilità richiede lo stesso sorgente, lockfile, architettura e
  `SOURCE_DATE_EPOCH`; due build candidate amd64 sono risultate byte-identiche.
