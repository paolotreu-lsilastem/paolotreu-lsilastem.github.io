# ADR 0046 — Autorilevamento socket e CSRF HTTPS same-origin

## Stato

Accettata — 2026-10-08.

## Contesto

Il collaudo Debian 12 ha mostrato che Gunicorn 23 rileva automaticamente i descrittori
`LISTEN_FDS` di systemd. Dichiarare anche `--bind fd://3` registrava due volte lo stesso
socket e falliva dopo la chiusura del primo duplicato. Il collaudo HTTPS ha inoltre
evidenziato che Flask-WTF richiede un `Referer` same-origin sui POST sicuri, incompatibile
con l’header applicativo `Referrer-Policy: no-referrer`.

## Decisione

Il servizio avvia Gunicorn direttamente con Python safe-path e lascia che rilevi il
socket systemd senza opzione `--bind`. Il browser riceve `Referrer-Policy: same-origin`:
il referrer resta disponibile per il controllo CSRF strict soltanto nello stesso origin
e non viene inviato verso origini differenti. L’allowlist Caddy include i loopback
espliciti per consentire il bootstrap esclusivamente attraverso un tunnel SSH locale.

## Conseguenze

- Gunicorn non apre listener propri e Caddy rimane l’unico ingresso di rete.
- I form production conservano token CSRF e verifica HTTPS dell’origine.
- Il bootstrap `admin/admin` resta negato dalla rete anche falsificando gli header proxy;
  via tunnel loopback conduce obbligatoriamente al cambio password.
- Cambi a worker server, reverse proxy o referrer policy richiedono nuovamente test reali
  di socket activation, form HTTPS e identità client.
