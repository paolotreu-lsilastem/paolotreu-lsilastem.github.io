# ADR 0047 — Recovery set offline separato e manifestato

## Stato

Accettata — 2026-10-08. La cifratura esterna è definita dall'ADR 0048.

## Contesto

Il data tree contiene envelope di chiavi, hash di credenziali, scope tenant e audit; il
keyring e i segreti applicativi vivono invece sotto `/etc`. Una copia live può combinare
revisioni diverse, mentre un archivio unico annullerebbe la separazione tra ciphertext e
materiale capace di decifrarlo. Cache e registry host non sono fonti di verità portabili.

## Decisione

La v1 usa un recovery set composto da bundle `data` e `secrets` separati, legati dallo
stesso UUID. Entrambi contengono un manifest v1 con inventario, mode, dimensioni e hash.
La consistenza supportata inizialmente è soltanto offline; file non classificati, link,
permessi estesi o mutazioni durante la lettura fanno fallire l’operazione. Idempotenza e
audit sono stato di recovery; cache, lock, output generati e registry helper sono esclusi.

## Conseguenze

- Un restore richiede entrambi i bundle dello stesso set e non riconcilia automaticamente
  reti sull’host.
- Il backup non può essere scritto dentro il data tree e non crea tar plaintext durevoli.
- Nuovi formati persistenti devono aggiornare esplicitamente inventario, manifest, test e
  procedura di migrazione.
- Snapshot online, cifratore e retention generale richiedono decisioni o ADR successivi.
