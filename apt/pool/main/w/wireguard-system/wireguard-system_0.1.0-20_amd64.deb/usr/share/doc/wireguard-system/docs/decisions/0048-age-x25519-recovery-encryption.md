# ADR 0048 — Cifratura recovery con age e recipient X25519

## Stato

Accettata — 2026-10-08.

## Contesto

I bundle di recovery contengono credenziali, chiavi applicative e chiavi private
WireGuard racchiuse in envelope. Una password simmetrica richiederebbe distribuzione e
rotazione affidabili; usare il keyring applicativo come chiave di backup eliminerebbe la
separazione necessaria per recuperare un host compromesso. Il server deve poter creare
backup senza possedere materiale capace di decifrarli.

## Decisione

La versione 1 usa `age` con un recipient X25519 nativo. Sul server è configurato solo il
recipient pubblico; la relativa identity privata non viene installata e ne esistono
almeno due copie offline sotto controllo separato. I bundle `data` e `secrets` sono
compressi e cifrati come stream distinti `.tar.gz.age`, senza tar plaintext persistente e
senza fallback a passphrase. Il binario production è `/usr/bin/age`, invocato con argv
fisso, ambiente minimo e senza shell.

## Conseguenze

- Il pacchetto Debian dipende da `age >= 1.1` e `doctor` ne verifica la presenza.
- La perdita di tutte le identity offline rende deliberatamente irrecuperabili i backup;
  non esiste una backdoor applicativa.
- Rotazione del recipient e custodia delle identity sono cerimonie operative da provare
  nel disaster-recovery drill.
- Create e verify devono validare il recipient e pubblicare soltanto ciphertext completo
  con mode `0600`, senza sovrascrivere artefatti esistenti.
