# ADR 0049 — Promozione atomica del data tree con `renameat2`

## Stato

Accettata — 2026-10-08.

## Contesto

Il restore deve sostituire un intero data tree file-backed senza mostrare ai processi una
combinazione parziale di stato vecchio e nuovo. La sequenza portabile
`live -> rollback`, `staging -> live` lascia invece una finestra in cui il path live non
esiste e un crash può interrompere la transazione a metà. Copiare file singolarmente non
è accettabile perché perde atomicità, revisioni e coerenza fra documenti.

## Decisione

Su Linux la sostituzione di un data dir esistente usa `renameat2` con
`RENAME_EXCHANGE`: live e staging, già sibling sullo stesso filesystem, vengono scambiati
con una sola operazione atomica. Il vecchio tree viene quindi rinominato in un sibling
privato con prefisso riservato e trattenuto fino al completamento delle verifiche
post-promozione. Qualsiasi eccezione esegue lo scambio inverso; il commit elimina il
rollback con controlli stretti su path, tipo e permessi.

Un target inesistente viene pubblicato con un singolo `rename`. Un target non vuoto non è
mai sostituito senza consenso `replace` esplicito. Se kernel o filesystem non supportano
lo scambio atomico, l’operazione fallisce chiusa: non esiste fallback alla sequenza a due
rename.

## Conseguenze

- Il restore applicativo è Linux-only, coerentemente con WireGuard, systemd e il target
  Debian del progetto.
- Il data tree live è sempre interamente vecchio oppure interamente nuovo; le directory
  vengono sincronizzate dopo rename e rimozioni.
- Errori Python sono rollbackati automaticamente. Il recovery di un arresto del processo
  tra exchange e consolidamento del rollback richiede il journal durevole previsto dal
  successivo sottoblocco di orchestrazione.
- Environment e master keyring esterni non partecipano a questo singolo exchange e
  richiedono una pubblicazione coordinata separata prima di esporre un comando restore.
