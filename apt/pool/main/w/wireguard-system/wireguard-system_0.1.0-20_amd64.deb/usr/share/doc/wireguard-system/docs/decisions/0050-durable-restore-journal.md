# ADR 0050 — Journal durevole per il restore del data tree

## Stato

Accettata — 2026-10-08.

## Contesto

`renameat2(RENAME_EXCHANGE)` rende atomica la visibilità del singolo data tree, ma il
processo può terminare tra exchange, consolidamento della directory di rollback, controlli
post-promozione e cleanup. Il solo nome dei path non basta a distinguere con certezza il
tree vecchio da quello nuovo dopo un arresto.

## Decisione

Prima del primo rename viene pubblicato nel parent del data dir un journal JSON `0600`,
creato senza overwrite e sincronizzato. Il journal registra UUID della transazione, fase,
path confinati, presenza del target precedente e coppie device/inode dei tree vecchio e
nuovo. Gli aggiornamenti di fase usano file temporaneo, `os.replace` e fsync.

Le fasi sono monotone: `prepared`, `promoted`, quindi una decisione durevole
`commit_pending` oppure `rollback_pending`. Il recupero confronta le identità registrate
con live, staging e rollback:

- prima di `commit_pending`, un arresto implica sempre rollback;
- dopo `commit_pending`, il recupero completa commit e cleanup senza tornare allo stato
  precedente;
- combinazioni mancanti, duplicate o con inode inattesi falliscono chiuse e preservano il
  journal per intervento manuale.

Una nuova operazione di staging è rifiutata finché il journal non viene recuperato.

## Conseguenze

- Arresti in ogni finestra fra exchange, rename e rimozione sono distinguibili senza
  interpretare il contenuto dei documenti.
- Journal e path temporanei sono confinati allo stesso parent privato; symlink, mode
  estesi, hard link e nomi non riservati sono rifiutati.
- Il protocollo corrente copre il solo data tree. La transazione coordinata di environment
  e keyring estenderà il journal prima dell’esposizione di `restore-apply`.
