# ADR 0051 — Staging restore inerte prima della promozione

## Stato

Accettata — 2026-10-08.

## Contesto

Un recovery set può contenere reti con stato desiderato `running` e job `queued` o
`running` catturati prima del quiesce. Promuoverli invariati permetterebbe al reconciler o
al worker di applicare attività obsolete subito dopo il riavvio. Indici e lock runtime non
appartengono inoltre al bundle e devono avere uno stato coerente prima della promozione.

## Decisione

Dopo il preflight semantico e prima della transazione live, una fase dedicata modifica
soltanto il data tree staged:

- ogni job `queued` o `running` diventa `failed` con codice stabile
  `RESTORE_INTERRUPTED` e timestamp di conclusione;
- ogni rete viene forzata a `desired_state=stopped`;
- ogni documento mutato incrementa la propria revisione e genera un evento audit HMAC;
- `meta.json` e l’indice documentale ricostruibile ricevono lo stesso timestamp UTC;
- dopo la verifica finale dell’audit vengono eliminati e sincronizzati tutti i file lock
  ricostruibili creati durante staging e validazione.

La fase è idempotente rispetto ai documenti canonici: job già terminali e reti già ferme
non cambiano revisione. Non esegue comandi host, non avvia reti e non modifica il live data
tree.

## Conseguenze

- Il primo avvio dopo restore non eredita intenzioni operative o lavori incompleti dal
  momento del backup; la riattivazione delle reti richiede un’azione successiva esplicita.
- Audit e revisioni rendono osservabile ogni normalizzazione effettuata sul recovery set.
- L’indice promosso corrisponde ai documenti preparati, mentre lock non portabili non
  attraversano il confine di promozione.
- La pubblicazione coordinata di data tree, environment e keyring, il quiesce host e i
  controlli finali restano responsabilità del futuro orchestratore `restore-apply`.
