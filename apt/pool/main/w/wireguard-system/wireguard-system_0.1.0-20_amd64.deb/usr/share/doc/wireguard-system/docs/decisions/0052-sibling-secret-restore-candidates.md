# ADR 0052 — Candidati sibling per i secrets di restore

## Stato

Accettata — 2026-10-08.

## Contesto

Il data tree, l’environment applicativo e il master keyring possono risiedere su filesystem
diversi. Un rename dal workspace del data tree verso `/etc` può quindi fallire con
`EXDEV`; copiare direttamente sopra un file live introdurrebbe invece contenuti parziali e
nessun rollback. Il bundle normalizza volutamente ownership, mentre l’host di destinazione
deve conservare i propri UID/GID e permessi operativi.

## Decisione

Prima di qualsiasi promozione, environment e keyring staged vengono copiati in due file
candidati creati con `O_EXCL|O_NOFOLLOW` nello stesso parent dei rispettivi target live.
Ogni target deve già esistere: un’installazione pulita del pacchetto prepara quindi account,
directory e file host prima del restore.

Il target deve avere path assoluto canonico, essere un file regolare con un solo link e
risiedere fuori dal data tree e dal workspace; il parent non può essere symlink né
scrivibile da gruppo/altri. Il candidato riceve UID, GID e mode del target live, non quelli
normalizzati nell’archivio, e file e parent vengono sincronizzati. Environment ammette
`0600` o `0640`, il keyring soltanto `0600`.

Il workspace mantiene ownership dei candidati: errori e uscita dal contesto li eliminano,
mentre detach e promozione del solo data tree sono vietati. Nessun candidato viene ancora
scambiato con il live finché il journal non ne registra path e identità.

## Conseguenze

- Ogni candidato è sullo stesso filesystem del proprio target e potrà essere scambiato
  atomicamente senza dipendere dalla posizione del data tree.
- Restore su host nuovo richiede prima l’installazione/bootstrap del pacchetto, così utenti,
  gruppi, parent e file placeholder abbiano metadata affidabili.
- Un’interruzione in questa fase lascia al massimo file candidati non pubblicati; il live
  resta invariato e il cleanup ordinario li rimuove.
- Il prossimo incremento deve estendere journal e recovery prima di abilitare gli exchange
  e l’orchestratore `restore-apply`.
