# ADR 0053 — Journal coordinato per data tree e secrets

## Stato

Accettata — 2026-10-08.

## Contesto

Environment, master keyring e data tree costituiscono un unico stato applicativo, ma
possono vivere su filesystem differenti. Ogni singolo exchange è atomico, mentre una
sequenza di tre exchange non lo è rispetto a un arresto del processo o dell’host. Il
recovery deve quindi distinguere senza euristiche quali inode sono pubblicati e applicare
una sola decisione globale.

## Decisione

Il journal passa alla versione 2 e aggiunge due entry secrets. Ogni entry contiene tipo,
path assoluto del target e del candidato sibling, più identità device/inode del file vecchio
e nuovo. Path e parent sono validati fail-closed: devono essere canonici, sullo stesso
filesystem, non riservati, esterni a data/workspace e non scrivibili da gruppo/altri.

Dopo la pubblicazione sincronizzata del journal, la promozione scambia nell’ordine master
keyring, environment e data tree. La fase `promoted` viene resa durevole soltanto dopo tutti
gli exchange. La regola di recovery resta unica:

- in `prepared`, `promoted` o `rollback_pending`, riportare ogni target al vecchio inode e
  rimuovere i candidati nuovi;
- in `commit_pending`, richiedere ogni nuovo inode sul relativo target e rimuovere soltanto
  rollback e candidati vecchi;
- per inode mancanti, duplicati o inattesi, non scegliere uno stato: conservare il journal
  e richiedere intervento.

Il loader continua ad accettare journal v1, interpretandoli come transazioni senza secrets,
così un upgrade non rende irrecuperabile un restore del solo data tree già pendente.

## Conseguenze

- Un arresto fra due exchange non può produrre una configurazione mista dopo recovery.
- La decisione `commit_pending` è il solo punto oltre il quale non si torna allo stato
  precedente; cleanup parziali sono ripetibili.
- I secrets live non vengono dedotti dal contenuto: path e inode sono fissati prima della
  prima mutazione.
- La primitiva resta interna. Esposizione live richiede ancora quiesce root-only, controlli
  post-promozione e comando `restore-apply` esplicitamente confermato.
