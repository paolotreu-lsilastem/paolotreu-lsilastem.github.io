# ADR 0054 — Orchestrazione restore root-only e servizi fermi in errore

## Stato

Accettata — 2026-10-08.

## Contesto

Le primitive di staging, preparazione e promozione sono sicure singolarmente, ma l’ordine
operativo determina se writer applicativi o risorse WireGuard possono osservare uno stato
intermedio. Inoltre il socket helper viene fermato durante il quiesce e non può essere usato
per rimuovere le reti host prima della promozione.

## Decisione

Un orchestratore root-only richiede conferma dell’UUID del recovery set e consenso
esplicito alla sostituzione. Decifratura e preflight avvengono in staging prima del fermo
servizi. La preparazione rende reti e job inerti. Dentro il quiesce vengono poi eseguiti,
nell’ordine:

1. copia dei candidati environment/keyring sui filesystem target;
2. stop di ogni rete presente nel registry privilegiato usando direttamente lo stesso
   executor isolato del helper;
3. promozione journaled di keyring, environment e data tree;
4. verifica live di environment, keyring, envelope, documenti, audit, indice, reti ferme e
   prerequisiti host;
5. audit `restore.apply` e decisione durevole di commit.

Un journal lasciato da un arresto viene recuperato prima di creare un nuovo workspace, ma
soltanto dopo quiesce e stop delle reti registrate. Se qualsiasi operazione eseguita con i
servizi fermi fallisce, le unità non vengono riavviate automaticamente, anche quando il
rollback dei file riesce. L’operatore deve ispezionare e riavviare esplicitamente; su
successo vengono ripristinate soltanto le unità originariamente attive.

## Conseguenze

- Nessun writer applicativo opera durante cattura degli inode live, exchange o verifica
  post-promozione.
- Il registry escluso dal backup viene svuotato insieme alle risorse WireGuard e potrà
  essere ricostruito solo da azioni future esplicite; le reti restaurate restano ferme.
- Errori di restore possono causare downtime intenzionale, preferito al riavvio automatico
  su uno stato non verificato.
- L’orchestratore resta interno finché parser CLI, output redatto e drill Debian reale non
  superano il gate successivo.
