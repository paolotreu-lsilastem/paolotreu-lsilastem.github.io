# ADR 0055 — CLI restore esplicita e output redatto

## Stato

Accettata — 2026-10-08.

## Contesto

L'orchestratore di restore può sostituire stato applicativo e secrets, fermare servizi e
rimuovere reti WireGuard dall'host. Una CLI ambigua o troppo verbosa potrebbe applicare il
set sbagliato, consentire una sostituzione involontaria oppure esporre path della identity
e dettagli di errori contenenti informazioni sensibili.

## Decisione

`wg-portal restore-apply` richiede sempre bundle data/secrets, identity, data dir target e
UUID atteso del recovery set. La sostituzione di un target non vuoto richiede inoltre il
flag separato `--replace`. Il comando è gestito prima del caricamento dell'environment
applicativo corrente e l'orchestratore resta root-only.

In successo vengono mostrati soltanto UUID confermato, conteggi operativi e la conferma
che tutte le reti recuperate restano ferme. In errore la CLI non stampa eccezioni o path:
restituisce codice non zero e avvisa che i servizi possono essere rimasti intenzionalmente
fermi. Il runbook impone verifica e preflight preliminari, finestra isolata e copia
temporanea `0600` della identity.

## Conseguenze

- Nome dei file e semplice presenza dei bundle non costituiscono consenso al restore.
- Gli errori CLI sono meno diagnostici per scelta; l'analisi usa journal e controlli
  read-only sull'host, senza riversare secrets nel terminale o nei log di automazione.
- Le reti non vengono riavviate implicitamente dopo il successo.
- Il comando resta candidate finché un disaster-recovery drill reale su Debian non chiude
  il gate operativo M4.2.
