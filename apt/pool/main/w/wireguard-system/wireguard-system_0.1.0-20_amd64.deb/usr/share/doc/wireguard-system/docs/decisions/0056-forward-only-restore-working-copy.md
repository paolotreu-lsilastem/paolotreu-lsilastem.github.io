# ADR 0056 — Migrazioni restore su copia di lavoro forward-only

## Stato

Accettata — 2026-10-08.

## Contesto

Un recovery set autenticato può appartenere a una versione dati precedente. Modificarne
direttamente l'estrazione cancellerebbe il riferimento esatto al contenuto verificato;
accettare salti o catene parziali renderebbe inoltre ambiguo quale schema validare e
promuovere.

## Decisione

Il verifier controlla prima che esista ogni passaggio `N → N+1` fino alla versione dati
corrente. Se serve migrare, copia l'albero estratto in un sibling privato sullo stesso
filesystem e applica gli step soltanto lì. Ogni step deve incrementare `schema_version`
di uno; link, hard link, file speciali, permessi estesi e versioni future falliscono
chiusi. File e directory vengono sincronizzati prima dell'attivazione della copia.

Manifest e ciphertext sorgente restano immutati. Un nuovo manifest in memoria inventaria
la copia migrata e guida la validazione semantica; l'albero estratto originale resta nel
workspace fino a cleanup o promozione. Il restore registra `restore.migrate` nell'audit e
la CLI indica la versione sorgente senza mostrare path.

## Conseguenze

- Una release che incrementa lo schema dati deve includere lo step dalla versione
  immediatamente precedente e fixture di recovery delle versioni ancora supportate.
- Una catena incompleta viene rifiutata anche da `backup-verify`, prima della promozione.
- Lo schema corrente è v1 e non ha predecessori rilasciati, quindi oggi la registry
  packaged non contiene step; il meccanismo è esercitato con una catena v1→v2 iniettata
  nei test.
- La migrazione richiede spazio temporaneo per albero estratto originale e copia di lavoro.
