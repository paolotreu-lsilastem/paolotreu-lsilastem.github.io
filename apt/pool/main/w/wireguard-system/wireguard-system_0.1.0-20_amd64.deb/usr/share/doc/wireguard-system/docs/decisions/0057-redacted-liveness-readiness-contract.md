# ADR 0057 — Contratto separato di liveness e readiness redatta

## Stato

Accettata — 2026-10-08.

## Contesto

La route storica `/healthz` provava soltanto che Flask rispondesse. Usarla anche per
verificare storage, keyring e helper avrebbe trasformato ogni controllo di liveness in
una sequenza di I/O e comandi privilegiati, favorendo restart inutili durante guasti
recuperabili. Una readiness troppo dettagliata esporrebbe invece informazioni host e
path sensibili a un endpoint anonimo.

## Decisione

`/healthz` resta una liveness costante e senza dipendenze. `/readyz` verifica separatamente
data tree/schema, journal restore, keyring e probe helper con capability attesa. Restituisce
`503` se un controllo fallisce, ma pubblica soltanto nomi e codici stabili redatti.

Il probe helper è read-only e il risultato, positivo o negativo, viene mantenuto in cache
per worker per un intervallo breve configurabile. Warning host e drift di singole reti non
rendono indisponibile l'intero control plane; errori host, helper non autenticato, versione
incompatibile o recovery pendente sì. Entrambe le route restano dietro socket Unix e
allowlist Caddy e non richiedono autenticazione applicativa.

## Conseguenze

- Monitor e orchestratori devono usare `/healthz` per la sola vitalità e `/readyz` per
  decidere se inviare traffico operativo.
- Un processo vivo può essere correttamente non ready senza essere riavviato in loop.
- Due worker Gunicorn hanno cache indipendenti e possono effettuare al massimo un probe
  helper ciascuno per finestra; non esiste stato condiviso aggiuntivo.
- I dettagli diagnostici restano nel journal operativo e nei comandi locali, che verranno
  formalizzati nei successivi task M4.3.
