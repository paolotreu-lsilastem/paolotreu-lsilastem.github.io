# ADR 0058 — Logging operativo JSON con schema allowlistato

## Stato

Accettata — 2026-10-08.

## Contesto

Un logger tradizionale accetta messaggi e dizionari arbitrari. Nel portale questi valori
potrebbero includere accidentalmente token, cookie, body, query, chiavi, path o output di
comandi. Affidarsi soltanto alla disciplina del chiamante non è sufficiente per il confine
di sicurezza richiesto; registrare traceback applicativi renderebbe inoltre imprevedibile
il contenuto inviato a journald.

## Decisione

Il logging operativo usa `JsonLineLogger`, che produce una sola JSON line ASCII su stderr
e accetta esclusivamente componenti, eventi, campi e tipi registrati nel codice. Non esiste
un campo messaggio libero. Un evento o campo sconosciuto, un UUID non canonico, un path al
posto dell'endpoint simbolico o un codice non conforme viene rifiutato prima della scrittura.

Il web registra endpoint Flask simbolico, metodo normalizzato, stato, durata e request ID;
un errore inatteso è convertito in risposta redatta e codice `UNHANDLED_EXCEPTION`, senza
testo né traceback. Il reconciler registra soltanto conteggi e stato del ciclo. Il helper
registra soltanto codici stabili dei fallimenti di processo. Audit firmato e log operativo
restano flussi distinti.

## Conseguenze

- Aggiungere un nuovo campo richiede modifica esplicita dello schema e test anti-leak.
- Query string, route concrete, indirizzi client, header, payload e identità applicative
  non sono disponibili nei log operativi; la diagnosi usa request ID e audit autorizzato.
- `WG_PORTAL_LOG_LEVEL` può filtrare per priorità, ma la validazione avviene anche sugli
  eventi soppressi così configurazioni errate non restano nascoste.
- Messaggi Gunicorn/systemd non prodotti dall'applicazione non adottano automaticamente
  questo schema; identificazione, rate limit e retention sono il prossimo task M4.3.
