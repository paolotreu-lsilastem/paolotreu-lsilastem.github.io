# ADR 0059 — Namespace journald dedicato e retention limitata

## Stato

Accettata — 2026-10-08.

## Contesto

Applicare quota e retention al journal globale modificherebbe il comportamento di servizi
fuori dal perimetro del portale. Scrivere file di log applicativi reintrodurrebbe invece
rotazione, permessi e parsing custom, oltre a duplicare la persistenza già fornita da
systemd. Audit HMAC e log operativo hanno inoltre finalità e retention differenti.

## Decisione

Le tre unità applicative usano `LogNamespace=wg-portal`, supportato dalla baseline
systemd 252 di Debian 12. Il pacchetto installa un drop-in vendor per il solo namespace:
storage persistente compresso, massimo 256 MiB, fallback runtime 64 MiB, file ruotati al
massimo giornalmente e retention massima 30 giorni. Forward verso syslog, console, wall,
kernel e audit sono disabilitati per evitare duplicazioni e confusione con altri flussi.

Web, reconciler e helper hanno `SyslogIdentifier`, campo indicizzato
`WG_PORTAL_COMPONENT`, finestra di rate limit di 30 secondi e burst rispettivamente 1000,
120 e 20. Il namespace applica anche un tetto di 2000 messaggi per servizio nella stessa
finestra. Gli override amministrativi vanno in
`/etc/systemd/journald@wg-portal.conf.d/`, senza modificare i file vendor.

## Conseguenze

- La consultazione deve specificare `journalctl --namespace=wg-portal`; il journal di
  default non contiene gli eventi applicativi del portale.
- Il rate limit può scartare log operativi durante una tempesta, generando il riepilogo
  journald previsto; l'audit firmato non attraversa questo canale e non viene scartato.
- La retention è un massimo, non una garanzia: quota, spazio libero o corruzione possono
  eliminare prima i file archiviati. Gli eventi richiesti per compliance restano audit.
- Remove e purge non cancellano retroattivamente i journal persistenti; l'eventuale
  eliminazione è un'azione amministrativa esplicita successiva a backup e policy locale.
