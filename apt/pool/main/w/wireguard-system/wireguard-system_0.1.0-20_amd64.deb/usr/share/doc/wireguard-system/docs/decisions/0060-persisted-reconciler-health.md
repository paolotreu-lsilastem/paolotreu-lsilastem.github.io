# ADR 0060 — Health persistente e read-only del reconciler

## Stato

Accettata — 2026-10-08.

## Contesto

La sola presenza del processo reconciler non dimostra che continui a eseguire cicli, né
che la coda venga smaltita. Interrogare il helper o tentare una riparazione da un health
check renderebbe però il monitoraggio privilegiato e mutante. Anche riavviare il servizio
su un singolo ciclo fallito può amplificare un guasto temporaneo e nascondere la causa.

## Decisione

Dopo ogni ciclo il reconciler scrive atomicamente
`runtime/reconciler-health.json`: versione, timestamp UTC, esito, numero di fallimenti
consecutivi e soli contatori redatti del report. Il file è stato derivato e non entra nei
backup. Un lettore separato apre senza seguire link e non crea lock né scrive file; valida
forma, permessi e timestamp, poi verifica:

- ultimo ciclo entro 600 secondi;
- meno di 3 cicli falliti consecutivi;
- nessun job `queued` o `running` invariato da oltre 300 secondi.

Le soglie sono configurabili entro limiti chiusi. `/readyz` include il risultato quando il
reconciler è configurato. `wg-portal reconciler-health` espone lo stesso controllo con
exit code, mentre un timer systemd lo esegue ogni minuto senza permessi di scrittura e
senza autoriparare o riavviare servizi.

## Conseguenze

- Subito dopo una prima installazione o un reboot la readiness può restare negativa fino
  al primo ciclo; uno stato precedente troppo vecchio non viene scambiato per salute.
- Tre fallimenti consecutivi rendono il control plane non ready, ma il backoff continua e
  un ciclo riuscito azzera il contatore senza interventi manuali.
- Il timer segnala il guasto come unità oneshot fallita; non entra in un restart loop e
  non modifica reti, job o stato canonico.
- Corruzione, link, permessi troppo larghi o timestamp futuri producono solo codici stabili
  redatti. Diagnosi e riparazione restano azioni esplicite da runbook.
