# ADR 0061 — SBOM e audit Python derivati dal lock

## Stato

Accettata — 2026-10-08.

## Contesto

Il pacchetto Debian incorpora wheel Python private e non usa PyPI durante l'installazione.
Una scansione del solo virtualenv di sviluppo può però includere tool non distribuiti,
omettere una dipendenza già soddisfatta o risolvere versioni diverse dal candidate. Un
semplice SBOM senza prova della fonte non permette inoltre di collegare l'inventario al
lock revisionato.

## Decisione

Il primo gate M4.4 usa `pip-audit` 2.x sul solo `requirements-prod.lock`, che deve essere
completamente pinned e hashato. Le opzioni `--strict --require-hashes --disable-pip`
impediscono fallback silenziosi e risoluzione dall'ambiente. Due output vengono generati
dalla stessa fonte: report advisory JSON e SBOM CycloneDX JSON.

Un wrapper stdlib verifica lock, documenti JSON, formato CycloneDX e corrispondenza esatta
del conteggio delle dipendenze. Solo dopo questi controlli sostituisce gli artefatti
precedenti e scrive un manifest con versione tool e SHA-256. I risultati vivono sotto
`dist/`, non nel repository. Nessun advisory è ignorato e la correzione automatica è
vietata: un finding conserva le evidenze ma restituisce fallimento.

## Conseguenze

- Il release gate inventaria esattamente le dipendenze Python installate dal lock, senza
  eseguire package o confondere dipendenze di sviluppo.
- La ricerca advisory richiede rete ed è sensibile all'istante; timestamp e versione tool
  rendono il risultato interpretabile, non immutabile.
- Il formato CycloneDX è interoperabile, mentre il JSON nativo conserva il dettaglio
  necessario alla remediation.
- Questo incremento non attesta codice first-party, pacchetti Debian o file `.deb` e non
  firma gli output. Provenienza completa, firma e upgrade path restano nei task successivi
  di M4.4.
