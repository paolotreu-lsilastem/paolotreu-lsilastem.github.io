# ADR 0062 — Provenienza release SLSA non firmata e fail-closed

## Stato

Accettata — 2026-10-08.

## Contesto

Report advisory, SBOM e package Debian separati non dimostrano di provenire dallo stesso
commit o lock. Un manifest proprietario sarebbe semplice, ma imporrebbe formato e logica
di verifica specifici del progetto. Firmare subito metadati incompleti renderebbe invece
autentica un'affermazione insufficiente.

## Decisione

Il candidate usa una Statement in-toto v1 con predicate SLSA Provenance v1. I subject
sono package Debian e archivio sorgente del commit pulito. Materiali e byproduct collegano
commit, lock Python, backend dichiarati, audit, SBOM, manifest e inventario completo del
payload Debian tramite SHA-256. Il builder registra gli strumenti Debian e Python senza
hostname, utente o path locali.

Generazione e verifica usano solo stdlib, `git`, `dpkg-deb` e `dpkg-query`. La generazione
fallisce prima di pubblicare se il repository è sporco, l'origin contiene credenziali,
versione/control/filename divergono, gli artefatti sono link, l'audit non è pulito o un
hash non coincide. Il bundle vive in una directory di versione nuova e viene rinominato
solo dopo verifica completa; una directory preesistente non viene sostituita.

La Statement resta JSON non firmato in questo incremento. CLI e documentazione dichiarano
esplicitamente che il controllo locale non autentica il produttore e non attribuiscono un
livello SLSA al builder workstation.

## Conseguenze

- Un revisore può ricostruire tutti i collegamenti del candidate senza accedere al server
  o estrarre file nel proprio filesystem.
- Il formato è interoperabile e predisposto per un futuro envelope firmato, senza
  inventare una grammatica di attestazione privata.
- Il worktree sporco non può produrre provenienza, quindi il collaudo reale del nuovo
  candidate avviene soltanto dopo il commit dello strumento.
- Il builder locale non è isolato e i backend Python pinned non hanno ancora un lock wheel
  separato con hash. Orchestrazione clean-tree, hardening dei build tool e firma restano
  gate espliciti di M4.4.
