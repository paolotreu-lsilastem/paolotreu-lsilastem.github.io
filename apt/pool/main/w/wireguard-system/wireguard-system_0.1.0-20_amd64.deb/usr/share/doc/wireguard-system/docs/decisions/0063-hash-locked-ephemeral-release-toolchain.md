# ADR 0063 — Toolchain di release effimera e hash-locked

## Stato

Accettata — 2026-10-08.

## Contesto

Il package runtime era già costruito da wheel hashate, ma `python -m build` poteva creare
un ambiente isolato risolvendo nuovamente i backend. Audit, build e provenienza erano
inoltre comandi separati eseguibili con versioni Python differenti. Pin nominali senza
hash e configurazioni pip locali non delimitano sufficientemente il materiale di build.

## Decisione

`requirements-release.in` contiene pin esatti per frontend, backend e scanner;
`requirements-release.lock` contiene l'intero grafo con SHA-256. L'orchestratore
`scripts/build-release-candidate.sh` richiede un tree pulito e destinazioni nuove, esegue
il quality gate, crea un virtualenv privato da `/usr/bin/python3` e vi installa soltanto
wheel verificate, usando esclusivamente l'indice pubblico dichiarato e ignorando config,
extra index, trusted host e user site dell'operatore.

Audit, package e provenienza usano lo stesso interprete effimero. La wheel first-party è
costruita con `--no-isolation`, perché `setuptools` e `wheel` sono già installati dal lock.
La provenienza incorpora entrambi i lock e rifiuta divergenze fra lock, build-system,
versioni effettive di `build`/`pip` e versione `pip-audit` del manifest.

## Conseguenze

- Nessun backend Python viene risolto implicitamente durante il build del candidate.
- Configurazioni pip private o locali non possono cambiare indice e materiale installato.
- L'intera sequenza è ripetibile da un solo comando e si interrompe al primo gate fallito.
- `requirements-release.lock` deve essere rigenerato e revisionato a ogni aggiornamento dei
  tool; pin e hash non si modificano manualmente.
- Host Debian, Python di sistema, rete e account non sono isolati: il builder locale non
  acquisisce per questo un livello SLSA e la Statement resta non autenticata fino alla firma.
