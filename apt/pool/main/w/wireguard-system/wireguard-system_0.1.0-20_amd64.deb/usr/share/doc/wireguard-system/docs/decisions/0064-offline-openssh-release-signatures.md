# ADR 0064 — Firma release SSHSIG con chiave Ed25519 offline

## Stato

Accettata — 2026-10-08.

## Contesto

La Statement non firmata collega già commit, package e materiali, ma chiunque possa
sostituire l'intero bundle può rigenerare hash coerenti. OpenPGP introduce un modello di
trust e una superficie operativa più ampi; un'identità keyless richiede servizi online e
trasparency log; una nuova dipendenza dedicata amplia il bootstrap del verificatore.
OpenSSH è già disponibile sulla piattaforma Debian supportata e implementa firme file con
namespace, signer allowlist e revoche.

## Decisione

Ogni bundle contiene un `SHA256SUMS` ASCII, ordinato per path, che copre esattamente tutti
i file tranne se stesso e `SHA256SUMS.sig`. La firma detached usa SSHSIG Ed25519,
namespace e principal fissi `release@wireguard-system`. Un `allowed_signers` pubblicato
lega principal, namespace e chiave; una lista pubblicata separatamente nega le chiavi
revocate.

La chiave privata viene generata con passphrase e conservata soltanto su una postazione
offline, con almeno due backup cifrati separati. Prima di firmare, l'operatore trasferisce
l'intero bundle e ricontrolla ogni digest offline. Sul sistema connesso torna soltanto la
firma. Il verifier nega link, file mancanti o extra, manifest non canonici, hash errati,
namespace/principal diversi, chiavi non autorizzate o revocate e provenienza non valida.

## Conseguenze

- La verifica usa `/usr/bin/ssh-keygen` e non dipende da Python crittografico o servizi
  remoti.
- Una vecchia release correttamente firmata resta crittograficamente valida: prevenzione
  del downgrade richiede anche una fonte di versione corrente autenticata.
- Revocare una chiave invalida intenzionalmente tutte le sue firme quando si usa la lista
  aggiornata; copie offline della policy possono conservare fiducia ormai superata.
- Il repository non contiene e gli script non generano chiavi private production. La
  milestone resta aperta fino alla cerimonia reale e alla verifica del candidate.
