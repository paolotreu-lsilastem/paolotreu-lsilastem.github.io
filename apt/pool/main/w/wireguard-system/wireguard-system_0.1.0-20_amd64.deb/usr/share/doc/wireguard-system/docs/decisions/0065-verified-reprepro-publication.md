# ADR 0065 — Pubblicazione APT verificata tramite reprepro

- Stato: accettata
- Data: 2026-10-08

## Contesto

Il package Debian verificato deve poter essere inserito, data la root locale, in una
repository APT senza reimplementare database, pool, indici e firma dell'archivio. La firma
SSHSIG del bundle autentica la release ma non produce i metadati OpenPGP attesi da APT.
Una semplice copia del `.deb` o una repository `trusted=yes` romperebbero il modello di
fiducia e non offrirebbero un aggiornamento gestibile degli indici.

## Decisione

Usare una repository esistente gestita da `reprepro`. Il wrapper di progetto riceve root,
codename, bundle, policy SSHSIG, keyring pubblica APT e fingerprint completo. Prima della
mutazione verifica il bundle firmato e la configurazione `SignWith`; dopo `includedeb`
verifica firma `InRelease`, hash dell'indice, record e bytes del package. Path, permessi,
identità e architettura sono validati fail-closed; i processi sono avviati con argv fisso
senza shell. Un package già presente e coerente rende il comando idempotente.

La chiave privata OpenPGP resta esterna al progetto e viene resa disponibile a `reprepro`
attraverso GnuPG/gpg-agent. Il wrapper non accetta segreti o passphrase. La distribuzione
ai client usa una keyring dedicata con `Signed-By`.

## Conseguenze

- Pool, database e indici restano responsabilità di un tool Debian maturo.
- La pubblicazione richiede sia una release SSHSIG valida sia una repository OpenPGP
  configurata; un ambiente non ancora provisionato fallisce chiuso.
- Il tool opera sulla root locale. Replica atomica verso mirror/CDN e lifecycle della
  chiave APT richiedono procedure infrastrutturali separate.
- Un errore post-mutazione non innesca rimozioni automatiche: l'operatore mette offline la
  pubblicazione e usa le primitive di recovery di `reprepro`.
