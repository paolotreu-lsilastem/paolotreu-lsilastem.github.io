# ADR 0066 — Archi di upgrade consecutivi espliciti

- Stato: accettata
- Data: 2026-10-08

## Contesto

Versioni Debian ordinabili e schema dati uguale non dimostrano che maintainer script,
unità, configurazione, dipendenze e formati runtime siano compatibili. Dichiarare un
intervallo minimo permetterebbe salti mai collaudati; consentire downgrade dopo una
migrazione forward-only potrebbe rendere il data tree illeggibile al vecchio binario.

## Decisione

Ogni candidate dichiara nel control un solo `X-WireGuard-System-Upgrade-From` e la propria
`X-WireGuard-System-Data-Schema`. Il preflight accetta uguaglianza esatta di versione,
architettura e schema live. La baseline corrente è `0.1.0-8` verso `0.1.0-9`, schema 1.
Installazione pulita segue un percorso separato; reinstall, salti e downgrade sono negati.

La sola verifica artefatto non abilita l'upgrade. Un gate successivo deve esigere recovery
set verificato offline mediante ricevuta firmata, stato host sano e quiesce; maintainer
script e drill Debian devono applicare la policy prima di chiudere M4.4.

## Conseguenze

- La matrice cresce per archi collaudati e non per assunzioni semver.
- Un host molto arretrato deve attraversare package intermedi firmati.
- Lo schema resta un controllo necessario ma non sufficiente.
- Rollback di codice è ammesso solo con schema invariato e procedura collaudata; dopo una
  migrazione forward-only serve il recovery set pre-upgrade con il package precedente.
