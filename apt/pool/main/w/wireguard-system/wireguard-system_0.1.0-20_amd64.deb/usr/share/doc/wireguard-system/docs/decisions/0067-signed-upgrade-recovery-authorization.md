# ADR 0067 — Ricevuta SSHSIG per autorizzare il recovery set di upgrade

- Stato: accettata
- Data: 2026-10-08

## Contesto

La presenza di due file cifrati sul server non dimostra che siano stati trasferiti,
decifrati e sottoposti a restore preflight offline. Portare l'identity privata `age` sul
server annullerebbe la separazione del recovery; riutilizzare la chiave release per
autorizzazioni operative mescolerebbe domini di fiducia con lifecycle e revoche diversi.

## Decisione

Il target prepara un documento JSON canonico, esclusivo e `0600` che lega candidate,
versione installata, architettura, schema dati, hash dei bundle `data`/`secrets`, UUID del
recovery set, hash contestualizzato del machine-id e finestra temporale massima di quattro
ore. Il default è due ore.

Dopo `backup-verify` e `restore-preflight` offline, un operatore firma esattamente quel
documento con SSHSIG Ed25519, principal `upgrade-operator@wireguard-system` e namespace
`upgrade@wireguard-system`. Chiave, `allowed_signers` e revocation list sono distinti
dalla firma release. Il target verifica firma, tempo e corrispondenza con bytes e stato
correnti; qualunque variazione fallisce chiusa.

## Conseguenze

- La identity `age` e la chiave SSH privata operativa non raggiungono il target.
- Una ricevuta copiata su un altro host, usata con altri bundle/candidate o scaduta è
  inutilizzabile.
- La firma attesta un controllo umano/offline: il runbook deve imporre i due comandi di
  verifica prima della firma e il confronto dell'UUID.
- Il protocollo è pronto, ma diventa enforcement soltanto quando il prossimo sottotask lo
  rende obbligatorio nel guard pre-unpack.
