# ADR 0068 — Guard pre-unpack root-only e monouso

- Stato: accettata
- Data: 2026-10-09

## Contesto

La verifica della ricevuta firmata era volontaria e separata da `dpkg`: un operatore
poteva verificare un recovery set e installare poi un altro candidate, oppure ignorare il
controllo. Il maintainer script deve fallire prima dell'unpack, quando il nuovo payload non
è ancora installato, senza richiedere chiavi private o fidarsi del data tree scrivibile dal
servizio.

## Decisione

La verifica esplicita `--arm-upgrade` crea un marker canonico `0600` in una directory
separata `root:root` `0700`. Il marker contiene digest della ricevuta, arco versione,
architettura, schema e scadenza; viene scritto soltanto dopo avere ricontrollato firma,
candidate, host, stato installato e recovery set.

Ogni candidate incorpora un `preinst` Python autonomo, renderizzato durante il build con
i metadati control. Per gli upgrade accetta solo il predecessor dichiarato, valida marker
e schema live e consuma il marker mediante hard link esclusivo seguito da unlink e fsync.
Il digest consumato resta come tombstone e non può essere riarmato. Installazioni pulite
non richiedono una ricevuta.

## Conseguenze

- Mancanza, expiry, replay, symlink, permessi errati e mismatch bloccano `dpkg` prima
  dell'estrazione; gli errori pubblici non espongono path.
- Un tentativo fallito dopo il consumo richiede una nuova ricevuta: è un costo operativo
  intenzionale per evitare autorizzazioni riutilizzabili.
- Il marker non replica l'hash del `.deb`: certifica che il verifier root ha controllato i
  bytes. Firma release/APT resta responsabile dell'autenticità del package e root rimane il
  confine di fiducia locale.
- Health, job/recovery, spazio, quiesce, riavvio e rollback rimangono gate separati da
  integrare prima di dichiarare supportato l'upgrade in produzione.
