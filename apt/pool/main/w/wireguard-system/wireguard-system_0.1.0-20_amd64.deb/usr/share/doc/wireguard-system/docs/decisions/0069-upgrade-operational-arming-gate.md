# ADR 0069 — Gate operativo read-only prima dell'arming

- Stato: accettata
- Data: 2026-10-09

## Contesto

Una ricevuta recovery valida non rende sicuro iniziare l'upgrade se il control plane è
degradato, esistono mutazioni pendenti, un restore è incompleto o manca spazio per
preservare lo stato. Fare affidamento soltanto su `/readyz` richiederebbe il servizio web
e una risposta cacheabile; importare l'applicazione nel verifier root caricherebbe inoltre
configurazione e segreti non necessari.

## Decisione

Il verifier esegue autonomamente un inventario standard-library, read-only e fail-closed
immediatamente prima di creare il marker. Richiede storage privato senza link, assenza del
restore journal, zero job `queued/running` e uno stato reconciler riuscito, senza failure o
probe error, vecchio al massimo dieci minuti.

Il budget disco richiede sul volume dati una copia della dimensione allocata corrente più
1 GiB e sul volume di `/usr` quattro volte la dimensione del candidate più 512 MiB. Quando
i volumi coincidono, i budget sono sommati. Le riserve sono costanti chiuse, non opzioni
CLI abbassabili dall'operatore.

## Conseguenze

- Corruzione, permessi rilassati, link, health mancante/stale, restore o job pendenti e
  spazio insufficiente negano l'arming con un errore pubblico redatto.
- Il controllo accetta correttamente `meta.json` posseduto dall'utente di servizio, ma ne
  esige modo privato, file regolare e singolo hard link.
- Il gate non scrive nel data tree e non chiama helper o servizi.
- Rimane una finestra TOCTOU fra inventario e `dpkg`: il prossimo incremento deve
  quiescere i writer, fermare le reti e ricontrollare prima dell'unpack.
