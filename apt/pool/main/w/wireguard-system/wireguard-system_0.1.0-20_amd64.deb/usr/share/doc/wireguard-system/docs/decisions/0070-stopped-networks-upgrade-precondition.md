# ADR 0070 — Reti realmente ferme come precondizione di upgrade

- Stato: accettata
- Data: 2026-10-09

## Contesto

Fermare soltanto web e reconciler lascerebbe attive le interfacce WireGuard, VRF e regole
nftables. D'altra parte, rimuoverle direttamente dal verifier duplicherebbe il motore
privilegiato e potrebbe divergere dal registry. Il solo `desired_state=stopped` non prova
che il job sia terminato o che il cleanup host sia riuscito.

## Decisione

Prima dell'arming l'operatore porta ogni rete a `stopped` tramite UI/API e attende la
convergenza ordinaria. Il gate legge tutti i documenti rete canonici e richiede
`desired_state=stopped`; separatamente valida ownership, modo, forma canonica e versione 2
di `/var/lib/wg-portal-helper/registry.json`, che deve avere la mappa `networks` vuota.

Il path del registry è fisso nella CLI di produzione e non può essere sostituito con un
argomento operatore. Le injection usate dai test non sono esposte dall'interfaccia.

## Conseguenze

- Desired state e stato privilegiato devono concordare: cleanup incompleto o registry
  mancante/corrotto bloccano l'upgrade.
- Il verifier resta read-only e non introduce una seconda implementazione di stop host.
- Tutte le VPN subiscono downtime intenzionale durante la finestra di manutenzione.
- Fino al quiesce dei writer permane una race dopo l'arming; preinst e rollback non sono
  ancora dichiarati pronti per produzione.
