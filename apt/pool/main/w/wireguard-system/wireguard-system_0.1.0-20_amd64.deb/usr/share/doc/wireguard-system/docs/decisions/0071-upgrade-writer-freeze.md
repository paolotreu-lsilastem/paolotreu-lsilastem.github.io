# ADR 0071 — Freeze dei writer fra arming e unpack

- Stato: accettata
- Data: 2026-10-09

## Contesto

I gate read-only lasciavano una race: web, reconciler o helper potevano creare un job o
riattivare una rete dopo il controllo ma prima di `dpkg`. Fermare i processi nel `preinst`
sarebbe troppo tardi per registrare in modo affidabile lo stato precedente e recuperare
un errore dell'arming.

## Decisione

`--arm-upgrade` inventaria le unità attive, ferma socket/servizi web, reconciler, health e
helper con argv `systemctl` fissi, verifica anche l'assenza delle istanze helper e ripete
l'intero gate operativo. Il marker registra soltanto i nomi appartenenti all'allowlist.
Qualsiasi errore durante lo stop o il ricontrollo riavvia le sole unità originariamente
attive; se anche il ripristino fallisce, l'errore distinto resta fail-closed.

Il `preinst` ricontrolla che tutte le unità e istanze siano ancora inattive prima di
consumare il marker, impedendo un unpack dopo riavvio accidentale dei writer.

## Conseguenze

- La finestra di mutazione applicativa fra gate e unpack è chiusa senza shell e senza
  accettare nomi unità dall'utente.
- Un arming riuscito lascia intenzionalmente il portale fermo in attesa di `dpkg`.
- Il normale `postinst` avvia ancora il set standard, non quello esatto registrato;
  crash, annullamento e failure post-unpack richiedono il prossimo protocollo di resume.
- Il percorso resta pre-release finché resume e rollback non sono idempotenti e collaudati.
