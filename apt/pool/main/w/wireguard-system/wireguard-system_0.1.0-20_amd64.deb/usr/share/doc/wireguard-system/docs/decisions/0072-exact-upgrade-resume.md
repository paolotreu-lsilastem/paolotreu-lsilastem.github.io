# ADR 0072 — Resume esatto dopo upgrade riuscito

- Stato: accettata
- Data: 2026-10-09

## Contesto

L'arming registra e ferma le unità writer attive, ma il `postinst` precedente avviava
sempre il set standard. Un upgrade poteva quindi attivare servizi che l'operatore aveva
lasciato intenzionalmente fermi. Inoltre mancava una prova persistente che il resume fosse
stato completato e verificato.

## Decisione

Il package incorpora un finalizer Python standalone, senza import dell'applicazione. Il
`postinst configure` di upgrade gli passa la versione precedente e il finalizer:

1. seleziona l'unico marker consumato, non ancora finalizzato, della coppia
   predecessor/candidate incorporata;
2. valida file, ownership, permessi e forma canonica del marker;
3. avvia esattamente le unità presenti in `active_units`, in un ordine fisso sicuro;
4. verifica che ciascuna unità persistente sia attiva e che la health oneshot completi lo
   start con successo;
5. crea in modo esclusivo e con `fsync` una ricevuta canonica `0600` sotto
   `finalized/<hash-ricevuta>.json`.

Se un avvio o la verifica falliscono, la ricevuta non viene scritta e il retry resta
possibile. Se la ricevuta esiste già, una nuova configurazione del package è un no-op.
L'installazione pulita continua ad abilitare e avviare il set standard.

## Conseguenze

- Lo stato intenzionalmente fermo viene preservato attraverso un upgrade riuscito.
- Il retry dopo un errore è idempotente e il completamento è attestato da un tombstone
  root-only.
- Restano da progettare il recupero esplicito dopo annullamento/crash prima del consumo e
  il rollback dei failure point successivi all'unpack.
