# ADR 0073 — Stato upgrade serializzato da un lock persistente

- Stato: accettata
- Data: 2026-10-09

## Contesto

Arming, `preinst` e finalizzazione leggono e mutano marker correlati. Senza mutua
esclusione, un comando operatore concorrente a `dpkg` potrebbe superare una validazione e
poi competere sul consumo del marker, producendo più hard link o decisioni basate su stato
ormai cambiato. Il recovery degli annullamenti aggiungerà un ulteriore writer.

## Decisione

Ogni fase mutante acquisisce un lock advisory esclusivo sul file persistente
`/var/lib/wireguard-system-upgrade/.transaction.lock`. Il file viene creato in modo
esclusivo `0600`, deve essere regolare, root-owned, con un solo link e permessi esatti;
`O_NOFOLLOW` nega i symlink. Il descriptor resta aperto per l'intera transazione e il
kernel rilascia il lock alla terminazione del processo.

Il lock non sostituisce hard link esclusivi, JSON canonico, `fsync` o validazioni dello
stato: li serializza e chiude la finestra fra controllo e mutazione per i writer che
aderiscono al protocollo.

## Conseguenze

- Arming, consumo e finalizzazione non possono modificare contemporaneamente lo stato.
- Un processo concorrente attende la fase già attiva e rivaluta poi lo stato protetto.
- Corruzione o metadati permissivi del lock bloccano l'upgrade senza tentare riparazioni.
- I futuri comandi di cancel/recovery devono acquisire lo stesso lock.
