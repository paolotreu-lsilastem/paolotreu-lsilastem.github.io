# ADR 0074 — Annullamento monouso di un upgrade armato

- Stato: accettata
- Data: 2026-10-09

## Contesto

L'arming ferma i writer prima che `dpkg` consumi il marker. Un operatore che annulla la
finestra o un crash in questo intervallo lascia quindi il portale fermo. Eliminare
`armed.json` e avviare servizi manualmente perderebbe sia il set esatto precedente sia la
prova che l'autorizzazione firmata non è più utilizzabile.

## Decisione

`upgrade-preflight --cancel-armed-upgrade` è l'unico percorso supportato prima del
consumo. Sotto il lock di ADR 0073:

1. valida marker canonico, ownership, permessi e stato dpkg/schema ancora uguale al
   predecessor registrato;
2. nega uno stato già rivendicato da `preinst` o writer attivi non presenti nel marker;
3. sposta durevolmente il claim sotto `cancelled/<digest>.json`, mantenendolo come
   tombstone che impedisce il re-arming;
4. avvia e verifica esattamente `active_units` in ordine fisso;
5. pubblica atomicamente una ricevuta canonica root-only sotto
   `cancel-resumed/<digest>.json`.

Una scadenza trascorsa non impedisce il recovery. Un errore dopo il claim lascia il
tombstone pendente: lo stesso comando riprende servizi già parzialmente avviati e completa
la ricevuta. Un claim hard-link interrotto viene riconosciuto e concluso; un hard link
verso `consumed` viene invece rifiutato.

## Conseguenze

- L'annullamento preserva esattamente lo stato dei writer e non riabilita reti, che erano
  già richieste `stopped` prima dell'arming.
- La stessa autorizzazione non può essere riutilizzata dopo l'annullamento.
- Il comando non tenta rollback dopo il consumo: quegli stati possono includere payload o
  schema nuovi e richiedono un protocollo distinto fail-closed.
