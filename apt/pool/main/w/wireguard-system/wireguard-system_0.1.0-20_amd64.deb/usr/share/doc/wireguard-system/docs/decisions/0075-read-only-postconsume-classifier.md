# ADR 0075 — Classificatore read-only del recovery post-consumo

- Stato: accettata
- Data: 2026-10-09

## Contesto

Dopo il claim `consumed`, un arresto può lasciare il predecessor ancora configurato, il
candidate soltanto unpacked, il candidate configurato ma non finalizzato oppure uno schema
dati già divergente. Una singola azione automatica sarebbe pericolosa: lo stesso comando
potrebbe avviare payload non configurato o tentare un downgrade incompatibile.

## Decisione

`upgrade-preflight --recovery-status` acquisisce il lock transazionale già esistente e
costruisce un report JSON canonico senza mutazioni. Valida tutti i marker pending e le
ricevute completate, riconosce un claim hard-link interrotto, legge stato/versione/
architettura da dpkg e confronta lo schema live con quello autorizzato.

Il report espone una classificazione chiusa e un'etichetta `next_action`. Quest'ultima è
solo un input normativo per executor futuri, non un comando né un'autorizzazione. Stato
ambiguo, più transazioni pending, receipt corrotta, lock mancante o metadati insicuri
producono un errore redatto.

## Conseguenze

- La diagnosi è ripetibile e non altera le evidenze necessarie al rollback.
- Resume del predecessor e retry della finalizzazione candidate potranno avere primitive
  diverse e precondizioni specifiche.
- Package incompleto, schema divergente e versione fuori arco restano bloccati fino a un
  executor di repair/rollback o al restore del recovery set verificato.
