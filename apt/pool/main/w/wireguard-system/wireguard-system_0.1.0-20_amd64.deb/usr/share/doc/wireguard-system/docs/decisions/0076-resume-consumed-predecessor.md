# ADR 0076 — Resume del predecessor intatto dopo il consumo

- Stato: accettata
- Data: 2026-10-09

## Contesto

Il `preinst` può consumare l'autorizzazione e poi interrompersi prima dell'unpack. In
questo caso il predecessor può essere ancora completamente configurato, ma i writer
restano congelati. Un riavvio manuale perderebbe la verifica atomica delle precondizioni e
non lascerebbe una prova persistente del recovery.

## Decisione

`upgrade-preflight --resume-consumed-predecessor` gestisce esclusivamente la
classificazione `predecessor_configured_after_consumption`. Acquisisce in ordine il lock
nativo dpkg e il lock transazionale, quindi:

1. valida marker, receipt storiche e assenza di transazioni concorrenti o ambigue;
2. richiede package `installed` con versione e architettura del predecessor registrato e
   schema live invariato;
3. nega writer estranei e normalizza un eventuale claim hard-link rimasto incompleto;
4. riavvia e verifica esattamente `active_units` nell'ordine stabilito;
5. pubblica atomicamente una receipt canonica root-only
   `predecessor-resumed/<digest>.json`.

Il comando è ritentabile dopo un errore di start e diventa un no-op dopo la receipt. Non
invoca dpkg, non configura package incompleti e non esegue downgrade o restore.

## Conseguenze

- Un failure prima dell'unpack ha ora un recovery supportato, verificato e idempotente.
- Una mutazione dpkg concorrente non può invalidare la decisione fra controllo e resume.
- Candidate configurato/incompleto, predecessor incompleto e schema divergente restano
  bloccati in attesa dei rispettivi executor o del recovery manuale.
