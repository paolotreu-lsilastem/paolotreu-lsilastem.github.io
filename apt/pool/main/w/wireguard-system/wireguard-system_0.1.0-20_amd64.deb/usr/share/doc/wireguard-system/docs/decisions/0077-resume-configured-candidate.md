# ADR 0077 — Finalizzazione esplicita del candidate configurato

- Stato: accettata
- Data: 2026-10-09

## Contesto

Il candidate può risultare completamente configurato in dpkg mentre il `postinst` non ha
ancora ripristinato tutti i writer o pubblicato la ricevuta finale. Ripetere ciecamente la
configurazione package oppure avviare manualmente i servizi renderebbe ambiguo il confine
tra package installato e control plane nuovamente operativo.

## Decisione

`upgrade-preflight --resume-configured-candidate` gestisce esclusivamente la
classificazione `candidate_configured_resume_pending`. Sotto lock dpkg e transazionale:

1. valida l'intera storia di marker e receipt e seleziona l'unica transazione consumata;
2. richiede package `installed` con versione e architettura candidate esatte e schema live
   coincidente;
3. nega writer estranei e completa un eventuale claim hard-link interrotto;
4. ripristina e verifica esattamente `active_units` nell'ordine stabilito;
5. pubblica atomicamente `finalized/<digest>.json` nello stesso formato del finalizer
   invocato dal `postinst`.

Il comando non invoca dpkg e non accetta stati package incompleti. Retry manuale e
`postinst` riconoscono la stessa receipt e diventano no-op dopo il successo.

## Conseguenze

- Un candidate già configurato può completare il recovery senza riconfigurazione package.
- La semantica di completamento resta unica e interoperabile con il package Debian.
- Repair di `unpacked`/`half-configured`, rollback e restore restano protocolli separati da
  progettare e collaudare.
