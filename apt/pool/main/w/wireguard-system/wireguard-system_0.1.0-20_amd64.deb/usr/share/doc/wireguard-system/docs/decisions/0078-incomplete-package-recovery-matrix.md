# ADR 0078 — Matrice di recovery degli stati package incompleti

- Stato: accettata
- Data: 2026-10-09

## Contesto

La classificazione iniziale raggruppava sotto un'unica azione candidate `unpacked`,
`half-configured`, `half-installed` e stati trigger. Dpkg assegna invece semantiche e
procedure di recupero diverse: configurare nuovamente un package non equivale a
reinstallarne i file o a processarne i trigger.

## Decisione

Il classificatore separa, sia per candidate sia per predecessor:

1. `unpacked` e `half-configured`: payload unpacked, eleggibile a un futuro executor di
   configurazione idempotente;
2. `half-installed`, `config-files` e stati residui: payload non attestabile come completo,
   quindi reinstallazione o rollback con artefatto verificato;
3. `triggers-awaited` e `triggers-pending`: elaborazione trigger distinta, senza fallback
   automatico a `--configure`.

Ogni classe riceve `classification` e `next_action` proprie. In questa fase le azioni
restano dichiarative: nessun comando dpkg viene eseguito dal classificatore.

## Conseguenze

- Il futuro repair di configurazione avrà un insieme chiuso di stati ammessi.
- Un payload `half-installed` non potrà eseguire maintainer script senza reinstallazione
  attestata.
- La gestione trigger richiederà analisi ed executor dedicati.

## Riferimenti

- Debian Policy Manual, sezioni 6.2, 6.6 e 6.7: idempotenza dei maintainer script,
  differenza fra unpack e configure e stato `Half-Configured` dopo errore.
- `dpkg(1)` Debian bookworm: definizioni degli stati package e comandi di configurazione e
  trigger.
