# ADR 0079 — Repair della configurazione candidate

- Stato: accettata
- Data: 2026-10-09

## Contesto

Dopo l'unpack, dpkg può lasciare il candidate in stato `unpacked` o `half-configured`.
Debian richiede maintainer script idempotenti e supporta la ripetizione della fase
configure, ma invocare dpkg senza legare l'azione alla transazione consumata perderebbe il
confine fail-closed del progetto. Trattenere il lock backend dpkg durante l'invocazione
causerebbe invece un deadlock col processo dpkg e col finalizer eseguito dal `postinst`;
rilasciare anche il lock frontend permetterebbe però a un processo APT concorrente di
mutare il package durante il handoff.

## Decisione

`upgrade-preflight --repair-candidate-configuration`:

1. accetta solo l'unico marker consumato il cui candidate esatto è `unpacked` o
   `half-configured`, con architettura e schema invariati;
2. valida l'intera storia delle receipt e il confine dei writer sotto lock dpkg e
   transazionale;
3. pubblica atomicamente un'intenzione root-only
   `candidate-repair/<digest>.json`, quindi completa un eventuale claim hard-link;
4. trattiene il lock frontend dpkg per l'intera operazione, rilascia temporaneamente il
   lock backend e quello transazionale e invoca soltanto `dpkg --configure
   wireguard-system` con ambiente fisso non interattivo;
5. riacquisisce i lock backend e transazionale, richiede il candidate `installed` e
   valida la receipt `finalized` prodotta dal `postinst` oppure completa direttamente il
   resume esatto.

L'intenzione resta dopo un errore e autorizza il retry, incluso il caso in cui dpkg abbia
raggiunto `installed` prima che il processo chiamante osservi il successo. Intent orfane,
corrotte o riferite a un'altra transazione sono negate.

## Conseguenze

- Configure interrotto è recuperabile e auditabile senza riutilizzare la firma iniziale.
- Il lock handoff è esplicito, APT resta escluso e ogni risultato viene ricontrollato
  prima del resume.
- `half-installed`, trigger, predecessor incompleto, reinstallazione e rollback restano
  fuori dall'executor e falliscono chiusi.
