# ADR 0080 — Package di rollback legato alla transazione

- Stato: accettata
- Data: 2026-10-09

## Contesto

Un predecessor `unpacked`, `half-configured` o `half-installed` dopo il consumo indica
che è già iniziato un percorso di rollback o reinstallazione. La firma v1 autorizzava il
candidate e i recovery bundle, ma non identificava i byte del package predecessor.
Invocare dpkg basandosi soltanto sulla versione registrata avrebbe quindi accettato un
artefatto scelto dopo la firma e violato il confine fail-closed.

## Decisione

La request di upgrade passa allo schema v2 e richiede il `.deb` predecessor esatto:

1. `--prepare-authorization` valida con `dpkg-deb` nome package, versione, architettura e
   schema contro lo stato installato, poi include il descrittore e lo SHA-256 sotto
   `rollback`;
2. `--verify-authorization` ricalcola l'intero descrittore e nega sostituzioni, mismatch o
   artefatti coincidenti;
3. l'arming propaga `rollback_package_sha256` nel marker root-only v2, preservandolo dopo
   il consumo senza dipendere dalla request esterna;
4. `preinst`, finalizer e strumenti di recovery accettano soltanto il marker v2.

Il package deve provenire da un bundle release verificato prima della firma operativa. La
firma della request lega l'artefatto alla specifica transazione, ma non sostituisce la
verifica della firma di release.

## Conseguenze

- Un futuro executor potrà reinstallare o completare il predecessor solo se il digest del
  `.deb` coincide con quello autorizzato prima dell'unpack.
- Request e marker v1 vengono negati: il percorso è ancora pre-release e non vengono
  migrate autorizzazioni già armate.
- Questo incremento non invoca dpkg e non rende ancora eseguibile il rollback; intenzione,
  handoff dei lock, comportamento dei maintainer script e ricevuta restano da progettare.
