# ADR 0081 — Handshake dei maintainer script per rollback

- Stato: accettata
- Data: 2026-10-09

## Contesto

Il digest del `.deb` predecessor è legato alla transazione, ma una reinstallazione o un
downgrade esegue i maintainer script contenuti proprio in quel package. Il suo `preinst`
normale autorizza soltanto l'arco forward di cui era candidate; il suo `postinst` normale
può inoltre finalizzare quell'arco o attivare il set standard di servizi. Bypassare gli
script, modificarli sotto `/var/lib/dpkg` o avviare dpkg manualmente eliminerebbe le
garanzie di provenienza e quiesce.

## Decisione

Ogni package dichiara `X-WireGuard-System-Recovery-Protocol: 1`, campo obbligatorio nel
preflight sia per candidate sia per predecessor di rollback. I maintainer script
implementano un handshake comune:

1. il futuro executor pubblica una sola intenzione canonica root-only sotto
   `rollback-intent/<authorization_sha256>.json`;
2. il `preinst` del predecessor accetta `upgrade` o `install` a tre argomenti soltanto se
   intenzione, marker consumato, versioni, architettura, schema e digest coincidono, non
   esistono ricevute terminali e tutti i writer sono ancora fermi;
3. l'expiry originale non viene riapplicata dopo il consumo: l'intenzione è legata a una
   transazione già autorizzata e ancora pendente;
4. durante `configure`, il finalizer del predecessor valida nuovamente marker e intenzione
   e ritorna senza avviare writer o creare la ricevuta candidate `finalized`;
5. solo l'executor esterno potrà verificare dpkg `installed`, ripristinare il set esatto e
   pubblicare `predecessor-resumed`.

L'intenzione ammette come stato iniziale soltanto gli stati dpkg già classificati per
recovery e non viene creata dai maintainer script.

## Conseguenze

- Il package predecessor deve essere stato costruito con recovery protocol v1; artefatti
  più vecchi sono negati prima dell'arming.
- Invocazioni dpkg manuali senza intenzione continuano a fallire chiuse.
- Il finalizer non può dichiarare riuscito un rollback: conserva il freeze finché
  l'executor non ricontrolla package, schema e confine dei writer.
- Questo incremento prepara l'handoff ma non invoca ancora dpkg.
