# ADR 0082 — Executor di rollback attestato del predecessor

- Stato: accettata
- Data: 2026-10-09

## Contesto

Il marker consumato lega già il `.deb` predecessor e i maintainer script implementano un
handshake recovery-aware, ma mancava l'unico processo autorizzato a creare l'intenzione,
coordinare dpkg e attestare il risultato. Un semplice `dpkg -i` non protegge da package
sostituito, package manager concorrenti, stato dpkg divergente o riavvio prematuro dei
writer.

## Decisione

`upgrade-preflight --rollback-predecessor --rollback-package <deb>` è l'unico ingresso
supportato. L'executor:

1. apre senza seguire symlink un file regolare non scrivibile da gruppo/altri, conserva il
   descriptor e usa `/proc/self/fd/<n>` per ispezione e installazione dello stesso inode;
2. richiede metadata recovery protocol v1 e SHA-256 uguali al marker consumato;
3. mantiene il lock frontend dpkg per l'intera operazione, verificando sotto lock backend
   e transazionale package, schema, storia delle receipt e confine dei writer;
4. crea una sola `rollback-intent` canonica `0600`, quindi rilascia backend e lock
   transazionale durante `dpkg --force-downgrade --install` con argv e ambiente fissi;
5. dopo dpkg riacquisisce i lock, ricalcola il digest dal descriptor, richiede il
   predecessor esatto in stato `installed`, ripristina le sole unità originarie e scrive
   `predecessor-resumed`.

Un predecessor già `installed` senza intenzione usa il comando di resume esistente e non
viene reinstallato. Se l'intenzione esiste, il comando può saltare dpkg già completato e
ritentare soltanto verifica e resume.

## Conseguenze

- Sostituzione del path dopo l'apertura, package diverso, schema avanzato, architettura o
  versione estranee all'arco e writer riattivati falliscono chiusi.
- Errori dpkg e crash lasciano una prova durevole e un retry deterministico; il successo
  è idempotente.
- Gli stati trigger sono ammessi al rollback completo, ma il loro repair forward rimane
  un executor separato ancora da implementare.
- Il percorso richiede Linux `/proc` e dovrà essere collaudato con due package reali su
  Debian 12 prima della chiusura della milestone release.
