# ADR 0083 — Repair confinato dei trigger candidate

- Stato: accettata
- Data: 2026-10-09

## Contesto

Dopo un upgrade interrotto dpkg può registrare il candidate come `triggers-pending` o
`triggers-awaited`. Il primo stato indica trigger che il package deve elaborare; il
secondo indica che attende il trigger di un altro package. La raccomandazione generale di
dpkg per stati trigger impropri è un'operazione `--pending`, che può configurare package
estranei e quindi viola il confine della transazione WireGuard System.

## Decisione

Automatizzare soltanto `triggers-pending` mediante
`upgrade-preflight --repair-candidate-triggers`:

1. sotto lock backend e transazionale valida candidate, architettura, schema, storia
   recovery e writer congelati;
2. crea una sola intenzione canonica root-only `candidate-trigger-repair`;
3. trattiene il lock frontend, ma cede backend e lock transazionale durante l'argv fisso
   `dpkg --triggers-only wireguard-system`;
4. riacquisisce i lock, richiede il candidate in stato `installed` e completa la normale
   receipt `finalized` con resume esatto;
5. conserva l'intenzione per retry e per distinguere trigger completati senza receipt.

`triggers-awaited` viene classificato separatamente e resta recovery manuale fail-closed.

## Conseguenze

- Il repair non processa intenzionalmente trigger o configurazioni di altri package.
- Errori dpkg, crash e resume falliti sono ritentabili senza riscrivere l'intenzione.
- Un ambiente con dipendenze trigger esterne incoerenti richiede diagnosi package-level e
  non viene “riparato” implicitamente dal portale.
- Il percorso dovrà essere incluso nei failure-point drill reali su Debian 12.
