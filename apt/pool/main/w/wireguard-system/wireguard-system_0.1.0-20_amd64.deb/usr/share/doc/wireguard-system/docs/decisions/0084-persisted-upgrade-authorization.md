# ADR 0084 — Persistenza dell'autorizzazione upgrade verificata

- Stato: accettata
- Data: 2026-10-09

## Contesto

La request SSHSIG v2 lega sia il `.deb` candidate sia il predecessor mediante SHA-256,
ma il marker monouso consumato dal `preinst` conserva direttamente soltanto il digest del
predecessor. Una reinstallazione candidate post-unpack deve poter ricostruire la stessa
provenienza senza fidarsi di un path o di input operatore mutabili.

Aggiungere ora campi o una nuova versione del marker romperebbe il confine di recovery:
in caso di rollback quel marker deve essere validato dai maintainer script del package
predecessor, che incorporano il recovery protocol v1 e lo schema marker v2.

## Decisione

Durante l'arming, sotto il lock transazionale, il sistema persiste l'esatto documento
canonico già verificato in:

`/var/lib/wireguard-system-upgrade/verified-authorization/<authorization_sha256>.json`

La directory è `root:root` `0700`; il file è regolare, single-link e `0600`. Nome,
contenuto canonico e SHA-256 devono coincidere con `authorization_sha256` del marker. Una
copia già presente è accettata solo se identica, rendendo sicuro il retry; una copia
corrotta o con metadati non conformi blocca l'arming prima del quiesce.

La copia viene mantenuta anche dopo un errore di arming e dopo la conclusione della
transazione come evidenza non segreta. Le transazioni legacy prive della copia continuano
a essere classificabili e recuperabili con gli executor già esistenti; la futura
reinstallazione candidate dovrà invece richiederla esplicitamente.

## Conseguenze

- Lo SHA-256 firmato del candidate resta recuperabile senza cambiare marker v2 o recovery
  protocol v1.
- Retry e crash prima della pubblicazione di `armed.json` non richiedono una nuova copia
  né introducono ambiguità.
- La directory può crescere con la storia degli upgrade e dovrà essere inclusa in una
  futura policy esplicita di retention, senza cancellazione automatica in questo gate.
- Questo ADR non autorizza ancora alcun comando dpkg di reinstallazione candidate; servono
  handshake dei maintainer script, intenzione durevole ed executor dedicato.
