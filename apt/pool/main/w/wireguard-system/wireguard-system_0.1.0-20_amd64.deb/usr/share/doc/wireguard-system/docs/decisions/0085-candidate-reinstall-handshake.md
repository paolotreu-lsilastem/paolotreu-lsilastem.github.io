# ADR 0085 — Handshake dei maintainer script per reinstallazione candidate

- Stato: accettata
- Data: 2026-10-09

## Contesto

Dopo il consumo del marker, un'interruzione durante l'unpack può lasciare il candidate in
stato `half-installed`. Ripetere liberamente `dpkg -i` non è accettabile: il path può
essere sostituito e il `preinst` non dispone più del marker armato originale. Inoltre una
reinstallazione della stessa versione può rappresentare sia il candidate danneggiato sia
il predecessor che l'executor di rollback sta reinstallando.

ADR 0084 rende disponibile la request verificata originale, il cui digest è già nel
marker consumato e che contiene lo SHA-256 esatto del candidate.

## Decisione

L'executor futuro dovrà creare, prima del handoff dpkg, una ricevuta canonica root-only:

`candidate-reinstall-intent/<authorization_sha256>.json`

Lo schema v1 contiene kind, digest autorizzazione, versioni candidate/predecessor, digest
del package candidate, stato iniziale e timestamp. L'unico stato iniziale ammesso in
questo gate è `half-installed`; configurazione e trigger hanno executor separati.

Il `preinst` del candidate valida intenzione, marker consumato, request persistita, digest
del package, identità dell'arco, architettura, schema live e writer quiescenti. Il
finalizer del `postinst` ripete la catena e non avvia unità né produce `finalized`: il
successo resta responsabilità dell'executor dopo il controllo dello stato dpkg.
Entrambi accettano come argomento di versione precedente il candidate oppure il
predecessor supportato, perché dpkg può riferire l'ultimo package configurato dopo un
unpack interrotto; è l'intenzione completa, non quel solo argomento, a decidere il ramo.

La presenza simultanea delle intenzioni candidate e rollback per lo stesso digest è
ambigua e viene negata. Il dispatch verso il percorso candidate avviene solo quando la
relativa directory esiste; in sua assenza resta invariato il percorso di reinstallazione
del predecessor già autorizzato da `rollback-intent`.

## Conseguenze

- Una reinstallazione manuale della stessa versione continua a fallire chiusa.
- Request scaduta dopo il consumo può essere usata per il recovery, ma contenuto e digest
  devono restare quelli verificati prima dell'upgrade.
- I writer rimangono congelati attraverso `preinst` e `postinst` fino alla verifica
  esplicita dell'executor.
- Questo ADR non crea l'intenzione e non invoca dpkg; artefatto pinned, lock handoff, retry
  e resume saranno implementati nel prossimo incremento.
