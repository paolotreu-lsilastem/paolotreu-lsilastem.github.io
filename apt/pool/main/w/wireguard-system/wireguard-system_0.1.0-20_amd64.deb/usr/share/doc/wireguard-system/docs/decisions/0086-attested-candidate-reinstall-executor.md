# ADR 0086 — Executor attestato per reinstallazione candidate

- Stato: accettata
- Data: 2026-10-09

## Contesto

ADR 0084 conserva la request firmata verificata e ADR 0085 rende i maintainer script
capaci di riconoscere un'intenzione di reinstallazione. Mancava l'unico componente
autorizzato a selezionare l'artefatto, creare l'intenzione, coordinare i lock e verificare
la postcondizione prima di riattivare i writer.

Un path validato e poi riaperto da dpkg sarebbe vulnerabile a sostituzione tra verifica e
uso. Trattenere contemporaneamente i lock backend dpkg o transazionale causerebbe invece
deadlock quando `preinst` e finalizer acquisiscono gli stessi lock.

## Decisione

Il comando root-only `--reinstall-candidate <deb>`:

1. apre l'artefatto regolare con `O_NOFOLLOW`, verifica inode, ownership e permessi e
   mantiene il descriptor aperto;
2. confronta control metadata e SHA-256 con candidate, marker consumato e request
   persistita indicizzata da `authorization_sha256`;
3. accetta come stato iniziale soltanto `half-installed`, verifica schema e writer, quindi
   crea o riusa l'intenzione canonica `candidate-reinstall-intent`;
4. trattiene il lock frontend dpkg per escludere APT, ma rilascia lock backend e
   transazionale durante `dpkg --install /proc/self/fd/<descriptor>`;
5. riacquisisce i lock, ricalcola il digest dal medesimo descriptor e richiede candidate
   `installed`, versione, architettura e schema esatti prima di creare `finalized` e
   ripristinare i writer.

Dopo la creazione dell'intenzione, retry da `half-installed`, `unpacked`,
`half-configured`, `triggers-pending` o `triggers-awaited` sono consentiti. Se dpkg ha già
raggiunto `installed`, il retry salta la reinstallazione e completa soltanto la verifica e
il resume. Un'intenzione rollback concorrente è sempre ambigua.

## Conseguenze

- Sostituire il path dopo l'apertura non cambia i byte letti o consegnati a dpkg.
- Un errore dpkg non ritira l'intenzione e non riattiva i writer; lo stesso comando è il
  percorso di recovery documentato.
- Le transazioni legacy senza request persistita non possono usare questo executor e
  restano fail-closed verso rollback o recovery manuale.
- `triggers-awaited` senza un'intenzione di reinstallazione resta un problema di dipendenza
  esterna separato; questo executor non esegue operazioni globali sui package.
