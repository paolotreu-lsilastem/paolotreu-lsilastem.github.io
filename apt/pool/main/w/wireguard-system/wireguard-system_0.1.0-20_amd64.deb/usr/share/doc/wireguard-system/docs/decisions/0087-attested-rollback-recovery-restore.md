# ADR 0087 — Restore attestato durante il rollback

- Stato: accettata
- Data: 2026-10-09

## Contesto

ADR 0082 consente di reinstallare il predecessor attestato, ma ripristina i writer sul
data tree corrente. La request firmata v2 lega già UUID e SHA-256 dei bundle data/secrets;
`restore-apply` sa validarli e promuoverli atomicamente, ma invocarlo separatamente fra
rollback e resume lascerebbe all'operatore un ordine non attestato e non crash-safe.

Il restore chiama a sua volta `age`: usare semplicemente `/proc/self/fd` nel processo
orchestratore non manterrebbe il descriptor visibile al nipote. Inoltre il processo di
restore non deve riavviare autonomamente servizi che l'upgrade aveva congelato.

## Decisione

Il comando root-only `--rollback-with-restore`:

1. apre data bundle, secrets bundle e identity `0600` con `O_NOFOLLOW`, li richiede
   distinti e sicuri e confronta UUID/digest dei bundle con la request verificata persistita;
2. usa l'executor ADR 0082 in modalità interna senza resume, lasciando il predecessor
   esatto `installed` e tutti i writer congelati;
3. crea un `rollback-restore-intent` canonico e invoca il comando fisso
   `/usr/bin/wg-portal restore-apply`, passando gli inode pinned tramite
   `/proc/<pid-orchestratore>/fd/<n>` affinché anche `age` apra gli stessi file;
4. non inoltra stdout/stderr del restore e non persiste path o contenuto della identity;
5. ricontrolla i digest, package, architettura e schema, poi pubblica
   `rollback-restored` prima di eseguire il resume esatto già definito da ADR 0076.

Intent e receipt sono root-only, canonici e indicizzati da `authorization_sha256`. Un
retry riusa l'intent; se la receipt di restore esiste, non ripete la promozione e completa
soltanto il resume. Recovery status valida anche record corrotti/orfani e propone
`retry_rollback_with_restore`.

## Conseguenze

- Nessun package o bundle diverso da quelli firmati può entrare nel percorso mutante.
- Errori dpkg/restore lasciano i writer congelati e un'azione di retry deterministica.
- Il resume generico rifiuta un restore iniziato ma privo della receipt di completamento.
- L'identity resta una responsabilità offline dell'operatore e non entra nello stato
  persistente dell'upgrade.
- Il protocollo v1 continua a richiedere schema candidate e predecessor uguale. Un futuro
  rollback fra schemi diversi richiederà una nuova autorizzazione/protocollo esplicito.
- `triggers-awaited` di dipendenze esterne resta un recovery separato e fail-closed.
