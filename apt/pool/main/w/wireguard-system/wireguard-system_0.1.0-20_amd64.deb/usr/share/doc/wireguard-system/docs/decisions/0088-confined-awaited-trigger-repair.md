# ADR 0088 — Repair confinato della chiusura trigger attesa

- Stato: accettata
- Data: 2026-10-09

## Contesto

Un candidate in `triggers-awaited` non ha necessariamente trigger propri da elaborare:
attende uno o più package interessati ai trigger che ha attivato. La specifica dpkg
sconsiglia `--triggers-only <singolo-package>` in questo stato, perché può eludere il
rilevamento dei cicli. `dpkg --configure --pending` sarebbe però troppo ampio: potrebbe
configurare package estranei già incompleti.

Serve usare il processing pending nativo di dpkg senza autorizzare implicitamente ogni
stato package presente sulla macchina.

## Decisione

Il comando root-only `--repair-candidate-awaited-triggers`:

1. acquisisce lock frontend, backend dpkg e transazionale e richiede candidate esatto,
   schema invariato e writer congelati;
2. legge in un'unica proiezione tutti i campi package, stato, versione, architettura,
   `Triggers-Awaited` e `Triggers-Pending`;
3. calcola ricorsivamente la chiusura dal candidate, ammettendo dipendenze soltanto in
   stato trigger processabile e rifiutando package trigger-active fuori dalla chiusura;
4. persiste un intent canonico `0600` con identità e stato iniziale di ogni package;
5. trattiene il lock frontend ma cede backend e lock transazionale durante l'unico argv
   fisso `dpkg --triggers-only --pending`;
6. riacquisisce i lock, nega package/versioni nuovi o trigger residui e finalizza soltanto
   con candidate `installed`, architettura e schema esatti.

Nei retry lo stato attivo può soltanto ridursi o avanzare entro i package registrati;
versioni, architetture e riferimenti a package esterni restano vietati. Il comando non usa
`--configure --pending` e non interpreta stdout/stderr di maintainer script.

## Conseguenze

- Il rilevamento cicli rimane responsabilità di dpkg, anziché essere ricostruito in modo
  incompleto dall'applicazione.
- Un package pending preesistente e non raggiungibile dal candidate impedisce la mutazione.
- Trigger generati durante maintainer script fidati vengono verificati a posteriori; se
  ampliano la chiusura oltre l'intent, il retry resta fail-closed e richiede analisi offline.
- APT è escluso dal lock frontend; l'operatore deve inoltre rispettare la finestra di
  manutenzione e non avviare direttamente altri processi dpkg concorrenti.
