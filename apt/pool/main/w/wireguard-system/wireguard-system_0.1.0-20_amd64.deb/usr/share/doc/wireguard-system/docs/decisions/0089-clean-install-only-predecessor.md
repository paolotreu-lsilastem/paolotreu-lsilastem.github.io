# ADR 0089 — Predecessor installabile soltanto da zero

- Stato: accettata
- Data: 2026-10-12

## Contesto

Il bundle storico `0.1.0-9` deriva dal commit `10272fa` e precede il protocollo di
recovery completato negli ADR 0066–0088. Riutilizzare la revisione `9` per il codice
corrente legherebbe sorgenti diverse alla stessa versione; dichiarare invece
`0.1.0-9 → 0.1.0-10` come arco supportato attribuirebbe al predecessor capacità che non
possiede.

Serve un package corrente installabile come baseline pulita dal quale costruire e
collaudare il primo upgrade reale consecutivo.

## Decisione

La revisione Debian `0.1.0-10` dichiara:

```text
X-WireGuard-System-Upgrade-From: none
```

`none` è un valore canonico riservato, non una versione Debian. Il builder accetta
esclusivamente una versione sintatticamente valida oppure questo valore. Il parser del
preflight lo riconosce, ma ogni tentativo di upgrade in ingresso viene rifiutato prima
del confronto di versione. Il `preinst` continua ad ammettere la sola invocazione di
installazione pulita; nessun marker può trasformare `none` in un predecessor reale.

Il package successivo `0.1.0-11` dichiarerà esclusivamente `0.1.0-10` e costituirà il
primo arco da collaudare con l'attuale recovery protocol.

## Conseguenze

- `0.1.0-9` resta evidenza storica non firmata e non pubblicabile.
- `0.1.0-10` può ricostruire una baseline di laboratorio senza fare affermazioni false
  sulla compatibilità con package precedenti.
- Non esiste un percorso di upgrade supportato verso `0.1.0-10`: occorre una
  installazione pulita conforme al piano di recupero.
- Il primo upgrade supportabile sarà `0.1.0-10 → 0.1.0-11`, dopo build, firma e drill
  reali di entrambi gli artefatti.
