# ADR 0090 — Installazione pulita dopo remove senza purge

- Stato: accettata
- Data: 2026-10-12

## Contesto

Il drill R03 ha dimostrato che, dopo `dpkg --remove`, il package resta nello stato
`config-files`. La successiva selezione di un package nuovo invoca `preinst install OLD
NEW` e `postinst configure OLD`, non le forme senza versione previste per un host mai
installato. `0.1.0-10` ha rifiutato correttamente l'operazione prima dell'unpack, ma non
può quindi essere usato nel percorso conservativo remove/reinstall richiesto dal
laboratorio.

## Decisione

Quando e solo quando `X-WireGuard-System-Upgrade-From` vale `none`:

- `preinst` ammette sia `install` sia `install OLD NEW`;
- `upgrade OLD NEW` resta sempre negato, quindi un package ancora installato non può
  eludere il preflight;
- `postinst configure OLD` segue il percorso fresh-install e abilita le unità standard,
  senza invocare il finalizer di upgrade.

La correzione riceve una nuova identità `0.1.0-11`; `0.1.0-10` non viene ricostruito. Il
primo arco consecutivo pianificato diventa `0.1.0-11 → 0.1.0-12`.

## Conseguenze

- Remove senza purge preserva dati e configurazione e può essere seguito da una nuova
  baseline clean-install-only.
- Un upgrade diretto da qualunque package installato continua a fallire prima
  dell'unpack.
- L'evidenza del rifiuto `0.1.0-10` resta utile e immutabile, ma non è un predecessor
  idoneo al laboratorio.
