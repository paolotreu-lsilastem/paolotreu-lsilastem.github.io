# ADR 0091 — Permessi deterministici del payload Debian

- Stato: accettata
- Data: 2026-10-12

## Contesto

La pipeline di release usa intenzionalmente `umask 077` per proteggere wheelhouse,
materiali e staging. `pip install --target` ha però ereditato quel valore nel candidate
`0.1.0-11`: `usr/`, `usr/lib/`, la directory site-packages e i moduli Python sono entrati
nel `.deb` con mode privati. Dpkg ha completato l'unpack, ma il `postinst` eseguito come
`wg-portal` non ha potuto importare l'applicazione.

Correggere soltanto la directory site-packages non basta: anche i suoi parent possono
essere non attraversabili. Affidarsi al test remoto del `postinst` rileverebbe inoltre il
problema troppo tardi, dopo l'unpack.

## Decisione

Prima di costruire il `.deb`:

- tutte le directory sotto la root del package vengono normalizzate a `0755`;
- tutti i file regolari sotto `usr/lib/wireguard-system/site-packages` vengono
  normalizzati a `0644`;
- helper e launcher eseguibili restano fuori da site-packages e ricevono esplicitamente
  `0755` durante l'installazione nel tree.

L'inventario di provenienza applica lo stesso contratto direttamente al tar payload. La
generazione fallisce su un mode non conforme o su site-packages assente. La verifica di
un bundle ricalcola l'intero inventario dal `.deb` attestato e richiede uguaglianza esatta
con `debian-package-inventory.json`.

La correzione usa la nuova identità `0.1.0-12`; `0.1.0-11` resta immutabile e rifiutato.

## Conseguenze

- Il service user può attraversare il payload e leggere moduli, metadati, template e
  librerie native senza concessioni di scrittura.
- L'`umask` privata del builder continua a proteggere lo staging, ma non influenza il
  risultato installabile.
- Un package con la stessa regressione viene rifiutato localmente prima della firma e del
  deploy.
- Il criterio di R03 è stato soddisfatto il 2026-10-12: `0.1.0-12` ha superato la
  pipeline normativa e l'installazione reale sul laboratorio.
