# ADR 0092 — Export APT statico separato per GitHub Pages

- Stato: accettata
- Data: 2026-10-13

## Contesto

Il maintainer ha collegato `publish/` alla cartella `apt/` del worktree GitHub Pages e
vuole distribuire il package con normali source APT. Usare quella cartella direttamente
come base `reprepro` renderebbe pubblici anche configurazione, database, lock e log
operativi. Una copia manuale renderebbe invece facile lasciare indici obsoleti o
pubblicare un package diverso da quello autenticato.

## Decisione

Mantenere una root `reprepro` privata, non versionata, e aggiungere al deploy verificato
un export opzionale dei soli alberi `dists/` e `pool/` più materiale pubblico client. Il
tool accetta un symlink leaf assoluto per la destinazione Pages, costruisce e verifica una
staging completa, quindi sincronizza soltanto file dichiarati in un manifest grow/rewrite
controllato. File non gestiti sono preservati; modifiche esterne a file gestiti bloccano
l'export.

La firma SSHSIG della release e la firma OpenPGP `InRelease` restano domini distinti. La
chiave privata APT è dedicata, protetta da passphrase e fornita a `reprepro` soltanto via
GnuPG/gpg-agent. Il tool esporta la keyring pubblica e un source deb822 con `Signed-By`,
ma non crea chiavi, non tratta passphrase e non invoca Git o GitHub.

## Conseguenze

- GitHub Pages non riceve `conf/`, `db/`, `logs/`, `lists/` o materiale privato.
- Il delta del sito è revisionabile e richiede commit/push espliciti nel relativo
  worktree.
- La prima pubblicazione richiede provisioning umano della chiave OpenPGP APT e verifica
  indipendente del fingerprint.
- Il supporto rientra nella pubblicazione APT già pianificata in R24 e non modifica il
  denominatore della roadmap.
