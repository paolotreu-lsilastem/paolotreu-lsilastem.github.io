# ADR 0093 — Handoff del lock frontend al processo dpkg

- Stato: accettata
- Data: 2026-10-13
- Sostituisce: le sole regole di trattenimento del lock frontend in ADR 0079, 0083,
  0086 e 0088

## Contesto

Il drill reale R09 ha mostrato che trattenere `/var/lib/dpkg/lock-frontend` nel processo
Python mentre viene avviato `/usr/bin/dpkg` non serializza il figlio: dpkg rileva tramite
`fcntl` che il lock appartiene a un PID diverso e termina prima di configurare il
candidate. I test precedenti simulavano il runner dpkg e verificavano erroneamente che il
lock frontend restasse occupato, quindi non riproducevano il comportamento nativo.

Il lock backend e quello transazionale devono comunque essere rilasciati durante dpkg,
perché i maintainer script e il finalizer devono poter avanzare la stessa transazione.

## Decisione

Ogni executor di configurazione, trigger, reinstallazione e rollback:

1. acquisisce e rilascia il lock frontend prima di scrivere l'intenzione, fallendo chiuso
   se un package manager è già attivo;
2. esegue decisione e scrittura dell'intenzione sotto lock backend e transazionale;
3. cede tutti i lock nativi dpkg prima dell'argv confinato, affinché il figlio dpkg ne sia
   il proprietario effettivo;
4. considera sicura la piccola corsa di handoff: se un altro package manager vince, dpkg
   fallisce e l'intenzione durevole rende il retry deterministico;
5. riacquisisce il backend e il lock transazionale, quindi valida identità, stato,
   inventario e receipt prima di riprendere i writer.

I test devono osservare entrambi i lock nativi liberi dentro il runner sostitutivo. Il
drill reale deve inoltre provare che dpkg non restituisca più l'errore “frontend lock was
locked by another process”.

## Conseguenze

- Dpkg può acquisire correttamente i propri lock e l'handoff non dipende da lock ereditati.
- Un package manager concorrente può vincere la finestra fra precheck e `exec`; l'operazione
  fallisce chiuso o viene respinta dalle verifiche post-dpkg, senza riprendere i writer.
- R09 resta aperta finché il codice corretto non è incluso in un package immutabile e i
  percorsi configuration/reinstall non sono ripetuti sul laboratorio.

