# ADR 0094 — Il finalizer valida lo storico terminale

- Stato: accettata
- Data: 2026-10-13
- Integra: ADR 0077, 0083, 0086 e 0088

## Contesto

I marker `consumed` sono un audit trail grow-only e non vengono eliminati quando una
transazione termina. Un upgrade concluso crea `finalized`; un ritorno attestato al
predecessor crea invece `predecessor-resumed`. Nel drill reale R09, dopo un rollback e un
nuovo arming, il finalizer del postinst `0.1.0-13` ha ignorato soltanto i marker con
`finalized`. Ha quindi contato il rollback già concluso come una seconda transazione
pendente, ha fallito per ambiguità e ha lasciato il package `half-configured`.

## Decisione

Prima di scegliere l'unico marker pendente, il finalizer:

1. associa a ogni `consumed` le eventuali receipt `finalized` e
   `predecessor-resumed` con lo stesso digest;
2. valida tipo, ownership, mode, link count, JSON canonico, identità della transazione,
   ordine esatto delle unità e timestamp canonico della receipt terminale;
3. ignora il marker soltanto se esiste una sola receipt terminale valida;
4. rifiuta receipt corrotte, symlink e la presenza simultanea dei due esiti terminali;
5. richiede ancora una sola transazione realmente pendente prima di riprendere i writer.

Lo storico non viene cancellato, rinominato o riscritto. Il comportamento deve essere
provato sia con test unitari sia con una sequenza Debian reale che includa un rollback
concluso seguito da un nuovo upgrade.

## Conseguenze

- Upgrade successivi non sono bloccati da rollback storici validamente conclusi.
- Una manomissione dello storico continua a fallire chiuso invece di essere ignorata.
- La correzione entra in `0.1.0-14`, che dichiara esclusivamente `0.1.0-13` come
  predecessor; P-021 resta aperto fino al retest immutabile R09.
