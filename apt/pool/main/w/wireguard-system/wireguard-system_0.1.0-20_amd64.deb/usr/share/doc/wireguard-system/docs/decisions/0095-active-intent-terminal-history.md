# ADR 0095 — Separare l'intent attivo dallo storico terminale

- Stato: accettata; implementata per `0.1.0-15`, verificata nel drill reale con `0.1.0-16`
- Data: 2026-10-14
- Integra: ADR 0077, 0085, 0086, 0087 e 0094

## Contesto

Intent e receipt sono un audit trail grow-only. Il recovery selector distingue già una
transazione pendente da una conclusa, ma i maintainer script immutabili richiedono che
l'intera directory `rollback-intent/` o `candidate-reinstall-intent/` contenga una sola
entry. R09 ha quindi trovato falsa ambiguità quando un nuovo rollback conviveva con intent
storici validamente conclusi da `predecessor-resumed`.

Il caso rollback deve inoltre restare compatibile con il `preinst` del predecessor già
pubblicato: quel codice non può essere corretto retroattivamente.

## Decisione

Le directory lette dai maintainer script rappresentano esclusivamente intent attivi. Un
executor futuro, prima di invocare dpkg:

1. valida ogni intent storico contro il relativo marker `consumed` e contro un solo esito
   terminale integro (`finalized` oppure `predecessor-resumed`);
2. sposta atomicamente gli intent terminali in una directory di storia root-only,
   mantenendo nome, bytes, ownership, mode e associazione per digest;
3. pubblica nella directory attiva soltanto l'intent della transazione corrente;
4. dopo il completamento e la receipt terminale archivia anche l'intent corrente;
5. tratta crash e retry come una migrazione idempotente e rifiuta intent orfani, receipt
   corrotte, esiti terminali doppi o più intent realmente attivi.

Recovery status e finalizer devono validare sia area attiva sia storia. Nessun intent o
marker viene cancellato, riscritto o ignorato senza validazione. La migrazione deve
avvenire prima del rollback reale R11 e avere fixture del layout precedente.

## Conseguenze

- Il predecessor immutabile continua a vedere la singola entry richiesta dal suo
  `preinst` senza bind mount o cancellazioni operative.
- Lo storico resta completo e verificabile, ma il formato persistito acquista una nuova
  directory e richiede test di crash in ogni rename.
- La bind view usata nel solo laboratorio R09 resta evidenza diagnostica e non diventa una
  procedura supportata.
- P-022 è stato chiuso dal drill reale; ADR 0096 corregge l'indipendente classificazione
  delle receipt restore dopo l'archiviazione terminale.
