# ADR 0096 — Le receipt di restore riconoscono l'intent rollback terminale

- Stato: accettata; implementata e verificata nel drill reale R11 con `0.1.0-17`
- Data: 2026-10-14
- Integra: ADR 0087, 0094 e 0095

## Contesto

Il drill reale `0.1.0-15 → 0.1.0-16` ha completato rollback con restore e pubblicato
correttamente `rollback-restore-intent`, `rollback-restored` e
`predecessor-resumed`. ADR 0095 richiede che, dopo l'esito terminale, l'intent corrente
sia spostato da `rollback-intent/` a `rollback-intent-history/` senza cambiarne i byte.

Il classificatore `recovery-status` validava però le due receipt di restore soltanto se lo
stesso digest era ancora presente nell'area attiva. Il layout terminale corretto veniva
quindi rifiutato come ambiguo e il health timer diventava rosso. La validazione dello
storico aveva già provato marker, intent e receipt terminale, ma tale risultato non era
usato per il legame aggiuntivo del restore.

## Decisione

Durante la classificazione read-only, una coppia restore può essere legata a:

1. un intent rollback attivo validato, mentre la transazione è ancora recuperabile; oppure
2. l'intent con lo stesso digest nell'area storica, validato dal reconciler dello storico
   contro marker `consumed` e receipt `predecessor-resumed`.

La presenza contemporanea nelle due aree resta ambigua e viene rifiutata dal controllo
comune. Un restore senza alcun intent, un intent storico non terminale, una receipt
corrotta o un digest discordante continuano a fallire chiuso. Receipt e intent non vengono
cancellati o riscritti.

## Conseguenze

- Il layout terminale prodotto dal rollback con restore torna a
  `no_pending_transaction` senza indebolire la validazione grow-only.
- Health e readiness non segnalano più un falso recovery pendente dopo un rollback sano.
- Una regressione automatica esercita il ciclo completo e invoca `recovery-status` dopo
  l'archiviazione dell'intent.
- P-026 è chiuso dal drill reale di `0.1.0-17`: stato terminale e timer health sono verdi
  e il retry di rollback con restore è un no-op verificato.
