# ADR 0097 — Major API parallele e baseline immutabili

- Stato: accettata; implementata nel gate R15
- Data: 2026-10-14
- Integra: ADR 0019 e ADR 0033

## Contesto

La v1 pubblica una copia OpenAPI inclusa nel package e la confronta con una superficie di
compatibilità congelata. Mancava una regola operativa completa per deprecazioni, rollout
client, nuova major e rollback. Sovrascrivere documento o baseline v1 renderebbe verde la
CI cancellando proprio il contratto che deve proteggere.

## Decisione

La v1 accetta soltanto modifiche additive. Una deprecazione è metadata e segnalazione
runtime: non cambia il comportamento e mantiene vecchia e nuova operazione per tutta la
release stabile successiva. La rimozione, il restringimento di input, il cambio di
sicurezza o la semantica incompatibile richiedono un prefisso, un documento, una copia
packaged e una baseline di nuova major.

Le major convivono durante la migrazione. Il rollout è server-first e i client conservano
un fallback verificato prima di adottare il nuovo percorso. Il rollback procede in ordine
inverso, client prima del server quando la capacità è già usata. Una baseline pubblicata
non viene riscritta; per una nuova major si crea una baseline distinta prima della prima
release.

Il quality gate esegue un drill in memoria: accetta un parametro opzionale, rifiuta la
rimozione di un'operazione e attesta che contratto e baseline su disco non cambino.

## Conseguenze

- Un breaking change non può essere mascherato come incremento minor o baseline refresh.
- La coesistenza costa route e test duplicati durante la migrazione, ma rende reversibile
  l'adozione dei client.
- I cambi semantici richiedono review anche quando OpenAPI non può esprimerli.
- La compatibilità HTTP non implica compatibilità dello storage: upgrade e restore
  continuano a usare il protocollo attestato separato.
- La procedura normativa è `docs/API_EVOLUTION.md`; R15 chiude M4.6 senza abilitare
  esposizione Internet.
