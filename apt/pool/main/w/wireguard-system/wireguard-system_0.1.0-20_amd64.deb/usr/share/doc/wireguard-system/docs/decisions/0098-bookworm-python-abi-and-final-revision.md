# ADR 0098 — ABI Python Bookworm e revisione finale riservata

## Stato

Accettata il 2026-10-15.

## Contesto

Il package Debian incorpora nel payload privato wheel native compilate per CPython 3.11.
La dipendenza storica `python3 (>= 3.11)` consente però a un sistema con Python 3.12 o
successivo di considerare soddisfatto il metadata, anche se le estensioni `cpython-311`
non sono importabili. La matrice v1 approvata comprende esclusivamente Debian 12
Bookworm `amd64`, il cui interprete di sistema è Python 3.11.

Il package tecnico corrente è `0.1.0-17`; le correzioni P-030 e P-031 non devono essere
ricostruite riutilizzando quella identità. Serve inoltre riservare prima dell’audit la
revisione che potrà diventare il candidate finale, senza produrre artefatti prematuri.

## Decisione

- Il package dichiara insieme `python3 (>= 3.11)` e `python3 (<< 3.12)`.
- La revisione Debian `18` identifica il prossimo candidate e viene riservata nel
  sorgente, ma R18 vieta di costruire o pubblicare `0.1.0-18`.
- Il predecessore dichiarato diventa `0.1.0-17`, così il successivo drill verifica
  esattamente l’upgrade dal candidate testing attualmente installabile.
- R24 può costruire la revisione 18 soltanto dal commit approvato dopo audit e
  remediation; la presenza preventiva di qualunque `.deb`, bundle o indice APT 18 è un
  errore di processo.

## Conseguenze

P-028 è risolto per il futuro package: sistemi con un ABI Python diverso falliscono in
fase di risoluzione dipendenze invece che all’avvio. Debian 11, Debian 13, architetture
diverse da `amd64` e distribuzioni derivate restano fuori supporto v1.

La riserva non costituisce un rilascio né prova che l’upgrade `17 → 18` sia valido. Build,
firma offline, keyring APT, upgrade e acceptance restano gate espliciti R24–R25. Se
l’audit richiede modifiche, la revisione resta 18 finché nessun artefatto è stato
costruito; dopo una build, ogni modifica obbliga invece a una nuova revisione.
