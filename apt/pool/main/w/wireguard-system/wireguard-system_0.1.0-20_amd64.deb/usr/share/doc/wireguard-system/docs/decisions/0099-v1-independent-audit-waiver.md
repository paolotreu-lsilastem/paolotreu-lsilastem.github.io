# ADR 0099 — Deroga esplicita all'audit indipendente della v1

- Stato: accettata come eccezione di release
- Data: 2026-10-15
- Decisione: maintainer

## Contesto

R18 ha congelato e impacchettato il commit `d09bce0741b6d458385d7e84dde5767642620f04`
per un audit di sicurezza indipendente. Il piano R19 richiedeva un report esterno prima
delle remediation e del candidate finale. Il maintainer dichiara di non disporre delle
risorse necessarie e di avere una scadenza di consegna incompatibile con tale incarico.

## Decisione

R19 viene chiuso amministrativamente tramite waiver, senza rappresentare l'audit come
eseguito o superato. La v1 può avanzare verso R20–R25 soltanto se:

- documentazione, release notes e acceptance dichiarano che manca un audit indipendente;
- P-005 resta un rischio residuo alto esplicitamente accettato dal maintainer;
- R20 e R21 eseguono comunque le verifiche avversariali interne previste;
- nessun finding critico/alto interno noto resta aperto;
- bundle, target e dossier R18 restano disponibili per un audit futuro.

L'audit indipendente rimane debito post-v1 prioritario e deve usare il target della
release effettivamente distribuita o un suo successore, non presumere che il vecchio
target R18 rappresenti modifiche successive.

## Conseguenze

La release non può essere descritta come “auditata”, “certificata” o dotata di sicurezza
assoluta. Test, review e drill interni riducono regressioni note ma condividono autori,
assunzioni e possibili punti ciechi. Integratori e operatori devono poter valutare questo
rischio prima del deployment.
