# ADR 0100 — Vincolo della sessione alla revisione utente

- Stato: accettata
- Data: 2026-10-15

## Contesto

Il cookie Flask firmato conteneva soltanto l'ID utente. Il loader rileggeva a ogni
richiesta stato e assegnazioni canoniche, ma un cambio password effettuato da un'altra
sessione non rendeva invalido il cookie precedente. Con la durata predefinita di 30
minuti, una sessione sottratta poteva quindi sopravvivere alla risposta dell'utente.

## Decisione

Ogni login e cambio password riuscito salva nel cookie sia `user_id` sia la revisione
intera corrente del documento utente. Prima di ogni route il server ricarica il documento
e accetta la sessione soltanto quando account attivo e revisione coincidono esattamente.
Revisione assente, booleana, non intera, futura o superata cancella l'intera sessione.

Qualunque mutazione canonica dell'utente invalida quindi tutti i cookie precedenti. È un
trade-off intenzionale: una modifica amministrativa può richiedere un nuovo login, ma
password, disabilitazione e scope non lasciano sessioni stale.

## Conseguenze

I cookie emessi da versioni precedenti vengono invalidati al primo accesso dopo
l'aggiornamento. Non serve migrare storage o schema utente; `revision` era già un campo
obbligatorio e monotono. API bearer e service account restano separati.
