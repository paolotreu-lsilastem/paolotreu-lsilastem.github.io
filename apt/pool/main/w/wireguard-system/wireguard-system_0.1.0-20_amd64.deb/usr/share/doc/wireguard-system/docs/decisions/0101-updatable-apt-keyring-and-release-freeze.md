# ADR 0101 — Keyring APT aggiornabile e freeze verificabile

Data: 2026-10-15  
Stato: accettata

## Contesto

I client del canale testing installano manualmente la chiave pubblica APT. La chiave
corrente scade il 12 ottobre 2028: senza un artefatto aggiornabile, un rinnovo o una
rotazione potrebbe non raggiungere i client prima che `apt update` smetta di funzionare.
R24 deve inoltre costruire il candidate finale senza modificare il commit approvato in
R23.

## Decisione

- Il trust client è distribuito nel package indipendente
  `wireguard-system-archive-keyring`, architettura `all`, senza maintainer script né
  dipendenze dall'applicazione.
- Sorgente OpenPGP, fingerprint ammessi e versione del package sono versionati sotto
  `packaging/apt-keyring/`. Il builder fallisce se il materiale non corrisponde alla
  policy, normalizza mode e timestamp e rifiuta output preesistenti.
- Il bundle release contiene sia il package applicativo sia quello keyring. La
  provenienza li lega allo stesso commit e `SHA256SUMS.sig` li autentica insieme.
- Il deploy accetta al massimo questi due nomi esatti e pubblica prima la keyring. Le
  release storiche con il solo package applicativo restano verificabili.
- Il bootstrap iniziale richiede ancora la verifica manuale del fingerprint. Dopo
  l'installazione del package keyring, rinnovi e rotazioni arrivano tramite APT. Una
  rotazione deve distribuire vecchia e nuova chiave in sovrapposizione prima di firmare
  esclusivamente con la nuova.
- `packaging/debian/release-freeze-tag` identifica un tag annotato. La pipeline rifiuta
  il build se il tag non esiste, non è annotato o non punta esattamente a `HEAD`.

## Conseguenze

La chiave privata APT resta fuori dal repository e dal package. R23 chiude
l'implementazione, ma P-018 resta aperto fino al drill reale di rinnovo/overlap R24. Il
tag di freeze è un riferimento Git esterno al contenuto del commit e risolve senza
auto-riferimenti l'identità immutabile del candidate.
