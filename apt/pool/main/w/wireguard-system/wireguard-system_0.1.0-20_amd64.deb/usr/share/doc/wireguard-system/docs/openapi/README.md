# Contratto API v1 ed esempi

`v1.json` è la fonte normativa OpenAPI 3.1 dell'API pubblica. Il formato JSON consente
la validazione nel bootstrap minimo senza aggiungere un parser YAML. L'applicazione ne
serve una copia byte-identica e inclusa nel pacchetto da `GET /api/v1/openapi.json`.
Questa è la sola operazione API anonima; non viene fornita una console interattiva.

## Uso sicuro

Scaricare il contratto non richiede credenziali:

```bash
curl --fail --proto '=https' \
  --output wireguard-system-openapi-v1.json \
  https://wg.example.invalid/api/v1/openapi.json
```

Per le operazioni protette evitare il token negli argomenti del processo e disabilitare
sempre il tracing shell. Questo esempio Bash crea un file temporaneo `0600` eliminato
automaticamente:

```bash
set +x
read -rsp 'API token: ' WG_PORTAL_TOKEN
printf '\n'
umask 077
WG_AUTH_FILE="$(mktemp)"
trap 'rm -f -- "$WG_AUTH_FILE"; unset WG_PORTAL_TOKEN WG_AUTH_FILE' EXIT
printf 'header = "Authorization: Bearer %s"\n' "$WG_PORTAL_TOKEN" >"$WG_AUTH_FILE"

curl --fail-with-body --proto '=https' --config "$WG_AUTH_FILE" \
  'https://wg.example.invalid/api/v1/networks?limit=50'
```

Una mutazione live richiede sia ETag sia chiave idempotente. Il body vuoto resta un
oggetto JSON, e il job restituito viene seguito tramite `Location`:

```bash
NETWORK_ID='20000000-0000-4000-8000-000000000001'
IDEMPOTENCY_KEY="$(uuidgen)"
curl --fail-with-body --proto '=https' --config "$WG_AUTH_FILE" \
  --request POST \
  --header 'Content-Type: application/json' \
  --header 'If-Match: "rev-3"' \
  --header "Idempotency-Key: $IDEMPOTENCY_KEY" \
  --data '{}' \
  "https://wg.example.invalid/api/v1/networks/$NETWORK_ID/actions/start"
```

I file in `examples/` mostrano risposte non sensibili per pagina tenant, Problem Details,
job accettato e telemetria. UUID, IP e domini sono riservati alla documentazione. Ogni
file viene validato nel quality gate contro lo schema corrispondente.

## Regole di modifica

La procedura completa per classificazione, deprecazione, coesistenza fra major, migrazione
client e rollback è in [`../API_EVOLUTION.md`](../API_EVOLUTION.md). In sintesi:

- mantenere il prefisso `/api/v1`; un cambio incompatibile richiede una nuova major;
- non esporre campi storage, hash, envelope cifrati, chiavi server o path host;
- aggiungere sempre `operationId` univoco, errori Problem Details e sicurezza bearer;
- le collezioni usano `limit` e cursore opaco, mai offset o dump illimitati;
- POST mutanti richiedono `Idempotency-Key`; PATCH e azioni richiedono `If-Match`;
- aggiornare contratto, route, esempi, test, `docs/API.md` e changelog insieme;
- non riscrivere `v1.compatibility.json` per far passare una modifica: la baseline v1 è
  congelata e si rigenera soltanto quando viene deliberatamente introdotta una nuova
  major o prima della prima release di una major non ancora pubblicata.

Dopo una modifica compatibile sincronizzare la risorsa packaged e lanciare il gate:

```bash
.venv/bin/python scripts/openapi-contract.py sync
.venv/bin/python scripts/openapi-contract.py check
.venv/bin/python scripts/openapi-contract.py drill
./scripts/check.sh
```

Il controllo blocca drift tra documentazione e pacchetto, rimozione di operazioni o
risposte, cambi di `operationId`/sicurezza, parametri obbligatori aggiunti e schemi
incompatibili. Test separati confrontano l'inventario Flask, le risposte seeded e gli
esempi con il contratto. Il drill non scrive file: prova in memoria un parametro opzionale
accettato e una rimozione di operazione rifiutata, verificando anche che contratto e
baseline restino byte-identici.
